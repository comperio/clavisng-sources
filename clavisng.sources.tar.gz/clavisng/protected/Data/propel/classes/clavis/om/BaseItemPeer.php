<?php


/**
 * Base static class for performing query and update operations on the 'item' table.
 *
 *
 *
 * @package propel.generator.clavis.om
 */
abstract class BaseItemPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'clavis';

    /** the table name for this class */
    const TABLE_NAME = 'item';

    /** the related Propel class for this table */
    const OM_CLASS = 'Item';

    /** the related TableMap class for this table */
    const TM_CLASS = 'ItemTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 76;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 76;

    /** the column name for the item_id field */
    const ITEM_ID = 'item.item_id';

    /** the column name for the title field */
    const TITLE = 'item.title';

    /** the column name for the manifestation_id field */
    const MANIFESTATION_ID = 'item.manifestation_id';

    /** the column name for the manifestation_dewey field */
    const MANIFESTATION_DEWEY = 'item.manifestation_dewey';

    /** the column name for the item_media field */
    const ITEM_MEDIA = 'item.item_media';

    /** the column name for the item_status field */
    const ITEM_STATUS = 'item.item_status';

    /** the column name for the item_order_status field */
    const ITEM_ORDER_STATUS = 'item.item_order_status';

    /** the column name for the item_icon field */
    const ITEM_ICON = 'item.item_icon';

    /** the column name for the physical_status field */
    const PHYSICAL_STATUS = 'item.physical_status';

    /** the column name for the item_source field */
    const ITEM_SOURCE = 'item.item_source';

    /** the column name for the opac_visible field */
    const OPAC_VISIBLE = 'item.opac_visible';

    /** the column name for the inventory_serie_id field */
    const INVENTORY_SERIE_ID = 'item.inventory_serie_id';

    /** the column name for the inventory_number field */
    const INVENTORY_NUMBER = 'item.inventory_number';

    /** the column name for the inventory_date field */
    const INVENTORY_DATE = 'item.inventory_date';

    /** the column name for the owner_library_id field */
    const OWNER_LIBRARY_ID = 'item.owner_library_id';

    /** the column name for the home_library_id field */
    const HOME_LIBRARY_ID = 'item.home_library_id';

    /** the column name for the collocation field */
    const COLLOCATION = 'item.collocation';

    /** the column name for the section field */
    const SECTION = 'item.section';

    /** the column name for the sequence1 field */
    const SEQUENCE1 = 'item.sequence1';

    /** the column name for the sequence2 field */
    const SEQUENCE2 = 'item.sequence2';

    /** the column name for the specification field */
    const SPECIFICATION = 'item.specification';

    /** the column name for the reprint field */
    const REPRINT = 'item.reprint';

    /** the column name for the width field */
    const WIDTH = 'item.width';

    /** the column name for the height field */
    const HEIGHT = 'item.height';

    /** the column name for the weight field */
    const WEIGHT = 'item.weight';

    /** the column name for the volume_number field */
    const VOLUME_NUMBER = 'item.volume_number';

    /** the column name for the volume_text field */
    const VOLUME_TEXT = 'item.volume_text';

    /** the column name for the mediapackage_size field */
    const MEDIAPACKAGE_SIZE = 'item.mediapackage_size';

    /** the column name for the current_loan_id field */
    const CURRENT_LOAN_ID = 'item.current_loan_id';

    /** the column name for the loan_class field */
    const LOAN_CLASS = 'item.loan_class';

    /** the column name for the last_seen field */
    const LAST_SEEN = 'item.last_seen';

    /** the column name for the loan_status field */
    const LOAN_STATUS = 'item.loan_status';

    /** the column name for the loan_alert field */
    const LOAN_ALERT = 'item.loan_alert';

    /** the column name for the loan_alert_note field */
    const LOAN_ALERT_NOTE = 'item.loan_alert_note';

    /** the column name for the usage_count field */
    const USAGE_COUNT = 'item.usage_count';

    /** the column name for the delivery_library_id field */
    const DELIVERY_LIBRARY_ID = 'item.delivery_library_id';

    /** the column name for the due_date field */
    const DUE_DATE = 'item.due_date';

    /** the column name for the patron_id field */
    const PATRON_ID = 'item.patron_id';

    /** the column name for the external_library_id field */
    const EXTERNAL_LIBRARY_ID = 'item.external_library_id';

    /** the column name for the renewal_count field */
    const RENEWAL_COUNT = 'item.renewal_count';

    /** the column name for the notify_count field */
    const NOTIFY_COUNT = 'item.notify_count';

    /** the column name for the check_out field */
    const CHECK_OUT = 'item.check_out';

    /** the column name for the check_in field */
    const CHECK_IN = 'item.check_in';

    /** the column name for the ill_timestamp field */
    const ILL_TIMESTAMP = 'item.ill_timestamp';

    /** the column name for the supplier_id field */
    const SUPPLIER_ID = 'item.supplier_id';

    /** the column name for the invoice_id field */
    const INVOICE_ID = 'item.invoice_id';

    /** the column name for the order_id field */
    const ORDER_ID = 'item.order_id';

    /** the column name for the budget_id field */
    const BUDGET_ID = 'item.budget_id';

    /** the column name for the currency field */
    const CURRENCY = 'item.currency';

    /** the column name for the currency_value field */
    const CURRENCY_VALUE = 'item.currency_value';

    /** the column name for the discount_value field */
    const DISCOUNT_VALUE = 'item.discount_value';

    /** the column name for the inventory_value field */
    const INVENTORY_VALUE = 'item.inventory_value';

    /** the column name for the issue_inventory_number field */
    const ISSUE_INVENTORY_NUMBER = 'item.issue_inventory_number';

    /** the column name for the issue_id field */
    const ISSUE_ID = 'item.issue_id';

    /** the column name for the issue_year field */
    const ISSUE_YEAR = 'item.issue_year';

    /** the column name for the issue_number field */
    const ISSUE_NUMBER = 'item.issue_number';

    /** the column name for the issue_description field */
    const ISSUE_DESCRIPTION = 'item.issue_description';

    /** the column name for the issue_arrival_date field */
    const ISSUE_ARRIVAL_DATE = 'item.issue_arrival_date';

    /** the column name for the issue_arrival_date_expected field */
    const ISSUE_ARRIVAL_DATE_EXPECTED = 'item.issue_arrival_date_expected';

    /** the column name for the issue_status field */
    const ISSUE_STATUS = 'item.issue_status';

    /** the column name for the subscription_id field */
    const SUBSCRIPTION_ID = 'item.subscription_id';

    /** the column name for the consistency_note_id field */
    const CONSISTENCY_NOTE_ID = 'item.consistency_note_id';

    /** the column name for the actual_library_id field */
    const ACTUAL_LIBRARY_ID = 'item.actual_library_id';

    /** the column name for the barcode field */
    const BARCODE = 'item.barcode';

    /** the column name for the rfid_code field */
    const RFID_CODE = 'item.rfid_code';

    /** the column name for the custom_field1 field */
    const CUSTOM_FIELD1 = 'item.custom_field1';

    /** the column name for the custom_field2 field */
    const CUSTOM_FIELD2 = 'item.custom_field2';

    /** the column name for the custom_field3 field */
    const CUSTOM_FIELD3 = 'item.custom_field3';

    /** the column name for the unimarc field */
    const UNIMARC = 'item.unimarc';

    /** the column name for the last_sbn_sync field */
    const LAST_SBN_SYNC = 'item.last_sbn_sync';

    /** the column name for the date_discarded field */
    const DATE_DISCARDED = 'item.date_discarded';

    /** the column name for the discard_note field */
    const DISCARD_NOTE = 'item.discard_note';

    /** the column name for the date_created field */
    const DATE_CREATED = 'item.date_created';

    /** the column name for the date_updated field */
    const DATE_UPDATED = 'item.date_updated';

    /** the column name for the created_by field */
    const CREATED_BY = 'item.created_by';

    /** the column name for the modified_by field */
    const MODIFIED_BY = 'item.modified_by';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identity map to hold any loaded instances of Item objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array Item[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. ItemPeer::$fieldNames[ItemPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('ItemId', 'Title', 'ManifestationId', 'ManifestationDewey', 'ItemMedia', 'ItemStatus', 'ItemOrderStatus', 'ItemIcon', 'PhysicalStatus', 'ItemSource', 'OpacVisible', 'InventorySerieId', 'InventoryNumber', 'InventoryDate', 'OwnerLibraryId', 'HomeLibraryId', 'Collocation', 'Section', 'Sequence1', 'Sequence2', 'Specification', 'Reprint', 'Width', 'Height', 'Weight', 'VolumeNumber', 'VolumeText', 'MediapackageSize', 'CurrentLoanId', 'LoanClass', 'LastSeen', 'LoanStatus', 'LoanAlert', 'LoanAlertNote', 'UsageCount', 'DeliveryLibraryId', 'DueDate', 'PatronId', 'ExternalLibraryId', 'RenewalCount', 'NotifyCount', 'CheckOut', 'CheckIn', 'IllTimestamp', 'SupplierId', 'InvoiceId', 'OrderId', 'BudgetId', 'Currency', 'CurrencyValue', 'DiscountValue', 'InventoryValue', 'IssueInventoryNumber', 'IssueId', 'IssueYear', 'IssueNumber', 'IssueDescription', 'IssueArrivalDate', 'IssueArrivalDateExpected', 'IssueStatus', 'SubscriptionId', 'ConsistencyNoteId', 'ActualLibraryId', 'Barcode', 'RfidCode', 'CustomField1', 'CustomField2', 'CustomField3', 'Unimarc', 'LastSbnSync', 'DateDiscarded', 'DiscardNote', 'DateCreated', 'DateUpdated', 'CreatedBy', 'ModifiedBy', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('itemId', 'title', 'manifestationId', 'manifestationDewey', 'itemMedia', 'itemStatus', 'itemOrderStatus', 'itemIcon', 'physicalStatus', 'itemSource', 'opacVisible', 'inventorySerieId', 'inventoryNumber', 'inventoryDate', 'ownerLibraryId', 'homeLibraryId', 'collocation', 'section', 'sequence1', 'sequence2', 'specification', 'reprint', 'width', 'height', 'weight', 'volumeNumber', 'volumeText', 'mediapackageSize', 'currentLoanId', 'loanClass', 'lastSeen', 'loanStatus', 'loanAlert', 'loanAlertNote', 'usageCount', 'deliveryLibraryId', 'dueDate', 'patronId', 'externalLibraryId', 'renewalCount', 'notifyCount', 'checkOut', 'checkIn', 'illTimestamp', 'supplierId', 'invoiceId', 'orderId', 'budgetId', 'currency', 'currencyValue', 'discountValue', 'inventoryValue', 'issueInventoryNumber', 'issueId', 'issueYear', 'issueNumber', 'issueDescription', 'issueArrivalDate', 'issueArrivalDateExpected', 'issueStatus', 'subscriptionId', 'consistencyNoteId', 'actualLibraryId', 'barcode', 'rfidCode', 'customField1', 'customField2', 'customField3', 'unimarc', 'lastSbnSync', 'dateDiscarded', 'discardNote', 'dateCreated', 'dateUpdated', 'createdBy', 'modifiedBy', ),
        BasePeer::TYPE_COLNAME => array (ItemPeer::ITEM_ID, ItemPeer::TITLE, ItemPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_DEWEY, ItemPeer::ITEM_MEDIA, ItemPeer::ITEM_STATUS, ItemPeer::ITEM_ORDER_STATUS, ItemPeer::ITEM_ICON, ItemPeer::PHYSICAL_STATUS, ItemPeer::ITEM_SOURCE, ItemPeer::OPAC_VISIBLE, ItemPeer::INVENTORY_SERIE_ID, ItemPeer::INVENTORY_NUMBER, ItemPeer::INVENTORY_DATE, ItemPeer::OWNER_LIBRARY_ID, ItemPeer::HOME_LIBRARY_ID, ItemPeer::COLLOCATION, ItemPeer::SECTION, ItemPeer::SEQUENCE1, ItemPeer::SEQUENCE2, ItemPeer::SPECIFICATION, ItemPeer::REPRINT, ItemPeer::WIDTH, ItemPeer::HEIGHT, ItemPeer::WEIGHT, ItemPeer::VOLUME_NUMBER, ItemPeer::VOLUME_TEXT, ItemPeer::MEDIAPACKAGE_SIZE, ItemPeer::CURRENT_LOAN_ID, ItemPeer::LOAN_CLASS, ItemPeer::LAST_SEEN, ItemPeer::LOAN_STATUS, ItemPeer::LOAN_ALERT, ItemPeer::LOAN_ALERT_NOTE, ItemPeer::USAGE_COUNT, ItemPeer::DELIVERY_LIBRARY_ID, ItemPeer::DUE_DATE, ItemPeer::PATRON_ID, ItemPeer::EXTERNAL_LIBRARY_ID, ItemPeer::RENEWAL_COUNT, ItemPeer::NOTIFY_COUNT, ItemPeer::CHECK_OUT, ItemPeer::CHECK_IN, ItemPeer::ILL_TIMESTAMP, ItemPeer::SUPPLIER_ID, ItemPeer::INVOICE_ID, ItemPeer::ORDER_ID, ItemPeer::BUDGET_ID, ItemPeer::CURRENCY, ItemPeer::CURRENCY_VALUE, ItemPeer::DISCOUNT_VALUE, ItemPeer::INVENTORY_VALUE, ItemPeer::ISSUE_INVENTORY_NUMBER, ItemPeer::ISSUE_ID, ItemPeer::ISSUE_YEAR, ItemPeer::ISSUE_NUMBER, ItemPeer::ISSUE_DESCRIPTION, ItemPeer::ISSUE_ARRIVAL_DATE, ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED, ItemPeer::ISSUE_STATUS, ItemPeer::SUBSCRIPTION_ID, ItemPeer::CONSISTENCY_NOTE_ID, ItemPeer::ACTUAL_LIBRARY_ID, ItemPeer::BARCODE, ItemPeer::RFID_CODE, ItemPeer::CUSTOM_FIELD1, ItemPeer::CUSTOM_FIELD2, ItemPeer::CUSTOM_FIELD3, ItemPeer::UNIMARC, ItemPeer::LAST_SBN_SYNC, ItemPeer::DATE_DISCARDED, ItemPeer::DISCARD_NOTE, ItemPeer::DATE_CREATED, ItemPeer::DATE_UPDATED, ItemPeer::CREATED_BY, ItemPeer::MODIFIED_BY, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ITEM_ID', 'TITLE', 'MANIFESTATION_ID', 'MANIFESTATION_DEWEY', 'ITEM_MEDIA', 'ITEM_STATUS', 'ITEM_ORDER_STATUS', 'ITEM_ICON', 'PHYSICAL_STATUS', 'ITEM_SOURCE', 'OPAC_VISIBLE', 'INVENTORY_SERIE_ID', 'INVENTORY_NUMBER', 'INVENTORY_DATE', 'OWNER_LIBRARY_ID', 'HOME_LIBRARY_ID', 'COLLOCATION', 'SECTION', 'SEQUENCE1', 'SEQUENCE2', 'SPECIFICATION', 'REPRINT', 'WIDTH', 'HEIGHT', 'WEIGHT', 'VOLUME_NUMBER', 'VOLUME_TEXT', 'MEDIAPACKAGE_SIZE', 'CURRENT_LOAN_ID', 'LOAN_CLASS', 'LAST_SEEN', 'LOAN_STATUS', 'LOAN_ALERT', 'LOAN_ALERT_NOTE', 'USAGE_COUNT', 'DELIVERY_LIBRARY_ID', 'DUE_DATE', 'PATRON_ID', 'EXTERNAL_LIBRARY_ID', 'RENEWAL_COUNT', 'NOTIFY_COUNT', 'CHECK_OUT', 'CHECK_IN', 'ILL_TIMESTAMP', 'SUPPLIER_ID', 'INVOICE_ID', 'ORDER_ID', 'BUDGET_ID', 'CURRENCY', 'CURRENCY_VALUE', 'DISCOUNT_VALUE', 'INVENTORY_VALUE', 'ISSUE_INVENTORY_NUMBER', 'ISSUE_ID', 'ISSUE_YEAR', 'ISSUE_NUMBER', 'ISSUE_DESCRIPTION', 'ISSUE_ARRIVAL_DATE', 'ISSUE_ARRIVAL_DATE_EXPECTED', 'ISSUE_STATUS', 'SUBSCRIPTION_ID', 'CONSISTENCY_NOTE_ID', 'ACTUAL_LIBRARY_ID', 'BARCODE', 'RFID_CODE', 'CUSTOM_FIELD1', 'CUSTOM_FIELD2', 'CUSTOM_FIELD3', 'UNIMARC', 'LAST_SBN_SYNC', 'DATE_DISCARDED', 'DISCARD_NOTE', 'DATE_CREATED', 'DATE_UPDATED', 'CREATED_BY', 'MODIFIED_BY', ),
        BasePeer::TYPE_FIELDNAME => array ('item_id', 'title', 'manifestation_id', 'manifestation_dewey', 'item_media', 'item_status', 'item_order_status', 'item_icon', 'physical_status', 'item_source', 'opac_visible', 'inventory_serie_id', 'inventory_number', 'inventory_date', 'owner_library_id', 'home_library_id', 'collocation', 'section', 'sequence1', 'sequence2', 'specification', 'reprint', 'width', 'height', 'weight', 'volume_number', 'volume_text', 'mediapackage_size', 'current_loan_id', 'loan_class', 'last_seen', 'loan_status', 'loan_alert', 'loan_alert_note', 'usage_count', 'delivery_library_id', 'due_date', 'patron_id', 'external_library_id', 'renewal_count', 'notify_count', 'check_out', 'check_in', 'ill_timestamp', 'supplier_id', 'invoice_id', 'order_id', 'budget_id', 'currency', 'currency_value', 'discount_value', 'inventory_value', 'issue_inventory_number', 'issue_id', 'issue_year', 'issue_number', 'issue_description', 'issue_arrival_date', 'issue_arrival_date_expected', 'issue_status', 'subscription_id', 'consistency_note_id', 'actual_library_id', 'barcode', 'rfid_code', 'custom_field1', 'custom_field2', 'custom_field3', 'unimarc', 'last_sbn_sync', 'date_discarded', 'discard_note', 'date_created', 'date_updated', 'created_by', 'modified_by', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. ItemPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('ItemId' => 0, 'Title' => 1, 'ManifestationId' => 2, 'ManifestationDewey' => 3, 'ItemMedia' => 4, 'ItemStatus' => 5, 'ItemOrderStatus' => 6, 'ItemIcon' => 7, 'PhysicalStatus' => 8, 'ItemSource' => 9, 'OpacVisible' => 10, 'InventorySerieId' => 11, 'InventoryNumber' => 12, 'InventoryDate' => 13, 'OwnerLibraryId' => 14, 'HomeLibraryId' => 15, 'Collocation' => 16, 'Section' => 17, 'Sequence1' => 18, 'Sequence2' => 19, 'Specification' => 20, 'Reprint' => 21, 'Width' => 22, 'Height' => 23, 'Weight' => 24, 'VolumeNumber' => 25, 'VolumeText' => 26, 'MediapackageSize' => 27, 'CurrentLoanId' => 28, 'LoanClass' => 29, 'LastSeen' => 30, 'LoanStatus' => 31, 'LoanAlert' => 32, 'LoanAlertNote' => 33, 'UsageCount' => 34, 'DeliveryLibraryId' => 35, 'DueDate' => 36, 'PatronId' => 37, 'ExternalLibraryId' => 38, 'RenewalCount' => 39, 'NotifyCount' => 40, 'CheckOut' => 41, 'CheckIn' => 42, 'IllTimestamp' => 43, 'SupplierId' => 44, 'InvoiceId' => 45, 'OrderId' => 46, 'BudgetId' => 47, 'Currency' => 48, 'CurrencyValue' => 49, 'DiscountValue' => 50, 'InventoryValue' => 51, 'IssueInventoryNumber' => 52, 'IssueId' => 53, 'IssueYear' => 54, 'IssueNumber' => 55, 'IssueDescription' => 56, 'IssueArrivalDate' => 57, 'IssueArrivalDateExpected' => 58, 'IssueStatus' => 59, 'SubscriptionId' => 60, 'ConsistencyNoteId' => 61, 'ActualLibraryId' => 62, 'Barcode' => 63, 'RfidCode' => 64, 'CustomField1' => 65, 'CustomField2' => 66, 'CustomField3' => 67, 'Unimarc' => 68, 'LastSbnSync' => 69, 'DateDiscarded' => 70, 'DiscardNote' => 71, 'DateCreated' => 72, 'DateUpdated' => 73, 'CreatedBy' => 74, 'ModifiedBy' => 75, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('itemId' => 0, 'title' => 1, 'manifestationId' => 2, 'manifestationDewey' => 3, 'itemMedia' => 4, 'itemStatus' => 5, 'itemOrderStatus' => 6, 'itemIcon' => 7, 'physicalStatus' => 8, 'itemSource' => 9, 'opacVisible' => 10, 'inventorySerieId' => 11, 'inventoryNumber' => 12, 'inventoryDate' => 13, 'ownerLibraryId' => 14, 'homeLibraryId' => 15, 'collocation' => 16, 'section' => 17, 'sequence1' => 18, 'sequence2' => 19, 'specification' => 20, 'reprint' => 21, 'width' => 22, 'height' => 23, 'weight' => 24, 'volumeNumber' => 25, 'volumeText' => 26, 'mediapackageSize' => 27, 'currentLoanId' => 28, 'loanClass' => 29, 'lastSeen' => 30, 'loanStatus' => 31, 'loanAlert' => 32, 'loanAlertNote' => 33, 'usageCount' => 34, 'deliveryLibraryId' => 35, 'dueDate' => 36, 'patronId' => 37, 'externalLibraryId' => 38, 'renewalCount' => 39, 'notifyCount' => 40, 'checkOut' => 41, 'checkIn' => 42, 'illTimestamp' => 43, 'supplierId' => 44, 'invoiceId' => 45, 'orderId' => 46, 'budgetId' => 47, 'currency' => 48, 'currencyValue' => 49, 'discountValue' => 50, 'inventoryValue' => 51, 'issueInventoryNumber' => 52, 'issueId' => 53, 'issueYear' => 54, 'issueNumber' => 55, 'issueDescription' => 56, 'issueArrivalDate' => 57, 'issueArrivalDateExpected' => 58, 'issueStatus' => 59, 'subscriptionId' => 60, 'consistencyNoteId' => 61, 'actualLibraryId' => 62, 'barcode' => 63, 'rfidCode' => 64, 'customField1' => 65, 'customField2' => 66, 'customField3' => 67, 'unimarc' => 68, 'lastSbnSync' => 69, 'dateDiscarded' => 70, 'discardNote' => 71, 'dateCreated' => 72, 'dateUpdated' => 73, 'createdBy' => 74, 'modifiedBy' => 75, ),
        BasePeer::TYPE_COLNAME => array (ItemPeer::ITEM_ID => 0, ItemPeer::TITLE => 1, ItemPeer::MANIFESTATION_ID => 2, ItemPeer::MANIFESTATION_DEWEY => 3, ItemPeer::ITEM_MEDIA => 4, ItemPeer::ITEM_STATUS => 5, ItemPeer::ITEM_ORDER_STATUS => 6, ItemPeer::ITEM_ICON => 7, ItemPeer::PHYSICAL_STATUS => 8, ItemPeer::ITEM_SOURCE => 9, ItemPeer::OPAC_VISIBLE => 10, ItemPeer::INVENTORY_SERIE_ID => 11, ItemPeer::INVENTORY_NUMBER => 12, ItemPeer::INVENTORY_DATE => 13, ItemPeer::OWNER_LIBRARY_ID => 14, ItemPeer::HOME_LIBRARY_ID => 15, ItemPeer::COLLOCATION => 16, ItemPeer::SECTION => 17, ItemPeer::SEQUENCE1 => 18, ItemPeer::SEQUENCE2 => 19, ItemPeer::SPECIFICATION => 20, ItemPeer::REPRINT => 21, ItemPeer::WIDTH => 22, ItemPeer::HEIGHT => 23, ItemPeer::WEIGHT => 24, ItemPeer::VOLUME_NUMBER => 25, ItemPeer::VOLUME_TEXT => 26, ItemPeer::MEDIAPACKAGE_SIZE => 27, ItemPeer::CURRENT_LOAN_ID => 28, ItemPeer::LOAN_CLASS => 29, ItemPeer::LAST_SEEN => 30, ItemPeer::LOAN_STATUS => 31, ItemPeer::LOAN_ALERT => 32, ItemPeer::LOAN_ALERT_NOTE => 33, ItemPeer::USAGE_COUNT => 34, ItemPeer::DELIVERY_LIBRARY_ID => 35, ItemPeer::DUE_DATE => 36, ItemPeer::PATRON_ID => 37, ItemPeer::EXTERNAL_LIBRARY_ID => 38, ItemPeer::RENEWAL_COUNT => 39, ItemPeer::NOTIFY_COUNT => 40, ItemPeer::CHECK_OUT => 41, ItemPeer::CHECK_IN => 42, ItemPeer::ILL_TIMESTAMP => 43, ItemPeer::SUPPLIER_ID => 44, ItemPeer::INVOICE_ID => 45, ItemPeer::ORDER_ID => 46, ItemPeer::BUDGET_ID => 47, ItemPeer::CURRENCY => 48, ItemPeer::CURRENCY_VALUE => 49, ItemPeer::DISCOUNT_VALUE => 50, ItemPeer::INVENTORY_VALUE => 51, ItemPeer::ISSUE_INVENTORY_NUMBER => 52, ItemPeer::ISSUE_ID => 53, ItemPeer::ISSUE_YEAR => 54, ItemPeer::ISSUE_NUMBER => 55, ItemPeer::ISSUE_DESCRIPTION => 56, ItemPeer::ISSUE_ARRIVAL_DATE => 57, ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED => 58, ItemPeer::ISSUE_STATUS => 59, ItemPeer::SUBSCRIPTION_ID => 60, ItemPeer::CONSISTENCY_NOTE_ID => 61, ItemPeer::ACTUAL_LIBRARY_ID => 62, ItemPeer::BARCODE => 63, ItemPeer::RFID_CODE => 64, ItemPeer::CUSTOM_FIELD1 => 65, ItemPeer::CUSTOM_FIELD2 => 66, ItemPeer::CUSTOM_FIELD3 => 67, ItemPeer::UNIMARC => 68, ItemPeer::LAST_SBN_SYNC => 69, ItemPeer::DATE_DISCARDED => 70, ItemPeer::DISCARD_NOTE => 71, ItemPeer::DATE_CREATED => 72, ItemPeer::DATE_UPDATED => 73, ItemPeer::CREATED_BY => 74, ItemPeer::MODIFIED_BY => 75, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ITEM_ID' => 0, 'TITLE' => 1, 'MANIFESTATION_ID' => 2, 'MANIFESTATION_DEWEY' => 3, 'ITEM_MEDIA' => 4, 'ITEM_STATUS' => 5, 'ITEM_ORDER_STATUS' => 6, 'ITEM_ICON' => 7, 'PHYSICAL_STATUS' => 8, 'ITEM_SOURCE' => 9, 'OPAC_VISIBLE' => 10, 'INVENTORY_SERIE_ID' => 11, 'INVENTORY_NUMBER' => 12, 'INVENTORY_DATE' => 13, 'OWNER_LIBRARY_ID' => 14, 'HOME_LIBRARY_ID' => 15, 'COLLOCATION' => 16, 'SECTION' => 17, 'SEQUENCE1' => 18, 'SEQUENCE2' => 19, 'SPECIFICATION' => 20, 'REPRINT' => 21, 'WIDTH' => 22, 'HEIGHT' => 23, 'WEIGHT' => 24, 'VOLUME_NUMBER' => 25, 'VOLUME_TEXT' => 26, 'MEDIAPACKAGE_SIZE' => 27, 'CURRENT_LOAN_ID' => 28, 'LOAN_CLASS' => 29, 'LAST_SEEN' => 30, 'LOAN_STATUS' => 31, 'LOAN_ALERT' => 32, 'LOAN_ALERT_NOTE' => 33, 'USAGE_COUNT' => 34, 'DELIVERY_LIBRARY_ID' => 35, 'DUE_DATE' => 36, 'PATRON_ID' => 37, 'EXTERNAL_LIBRARY_ID' => 38, 'RENEWAL_COUNT' => 39, 'NOTIFY_COUNT' => 40, 'CHECK_OUT' => 41, 'CHECK_IN' => 42, 'ILL_TIMESTAMP' => 43, 'SUPPLIER_ID' => 44, 'INVOICE_ID' => 45, 'ORDER_ID' => 46, 'BUDGET_ID' => 47, 'CURRENCY' => 48, 'CURRENCY_VALUE' => 49, 'DISCOUNT_VALUE' => 50, 'INVENTORY_VALUE' => 51, 'ISSUE_INVENTORY_NUMBER' => 52, 'ISSUE_ID' => 53, 'ISSUE_YEAR' => 54, 'ISSUE_NUMBER' => 55, 'ISSUE_DESCRIPTION' => 56, 'ISSUE_ARRIVAL_DATE' => 57, 'ISSUE_ARRIVAL_DATE_EXPECTED' => 58, 'ISSUE_STATUS' => 59, 'SUBSCRIPTION_ID' => 60, 'CONSISTENCY_NOTE_ID' => 61, 'ACTUAL_LIBRARY_ID' => 62, 'BARCODE' => 63, 'RFID_CODE' => 64, 'CUSTOM_FIELD1' => 65, 'CUSTOM_FIELD2' => 66, 'CUSTOM_FIELD3' => 67, 'UNIMARC' => 68, 'LAST_SBN_SYNC' => 69, 'DATE_DISCARDED' => 70, 'DISCARD_NOTE' => 71, 'DATE_CREATED' => 72, 'DATE_UPDATED' => 73, 'CREATED_BY' => 74, 'MODIFIED_BY' => 75, ),
        BasePeer::TYPE_FIELDNAME => array ('item_id' => 0, 'title' => 1, 'manifestation_id' => 2, 'manifestation_dewey' => 3, 'item_media' => 4, 'item_status' => 5, 'item_order_status' => 6, 'item_icon' => 7, 'physical_status' => 8, 'item_source' => 9, 'opac_visible' => 10, 'inventory_serie_id' => 11, 'inventory_number' => 12, 'inventory_date' => 13, 'owner_library_id' => 14, 'home_library_id' => 15, 'collocation' => 16, 'section' => 17, 'sequence1' => 18, 'sequence2' => 19, 'specification' => 20, 'reprint' => 21, 'width' => 22, 'height' => 23, 'weight' => 24, 'volume_number' => 25, 'volume_text' => 26, 'mediapackage_size' => 27, 'current_loan_id' => 28, 'loan_class' => 29, 'last_seen' => 30, 'loan_status' => 31, 'loan_alert' => 32, 'loan_alert_note' => 33, 'usage_count' => 34, 'delivery_library_id' => 35, 'due_date' => 36, 'patron_id' => 37, 'external_library_id' => 38, 'renewal_count' => 39, 'notify_count' => 40, 'check_out' => 41, 'check_in' => 42, 'ill_timestamp' => 43, 'supplier_id' => 44, 'invoice_id' => 45, 'order_id' => 46, 'budget_id' => 47, 'currency' => 48, 'currency_value' => 49, 'discount_value' => 50, 'inventory_value' => 51, 'issue_inventory_number' => 52, 'issue_id' => 53, 'issue_year' => 54, 'issue_number' => 55, 'issue_description' => 56, 'issue_arrival_date' => 57, 'issue_arrival_date_expected' => 58, 'issue_status' => 59, 'subscription_id' => 60, 'consistency_note_id' => 61, 'actual_library_id' => 62, 'barcode' => 63, 'rfid_code' => 64, 'custom_field1' => 65, 'custom_field2' => 66, 'custom_field3' => 67, 'unimarc' => 68, 'last_sbn_sync' => 69, 'date_discarded' => 70, 'discard_note' => 71, 'date_created' => 72, 'date_updated' => 73, 'created_by' => 74, 'modified_by' => 75, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, )
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = ItemPeer::getFieldNames($toType);
        $key = isset(ItemPeer::$fieldKeys[$fromType][$name]) ? ItemPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(ItemPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, ItemPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return ItemPeer::$fieldNames[$type];
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. ItemPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(ItemPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(ItemPeer::ITEM_ID);
            $criteria->addSelectColumn(ItemPeer::TITLE);
            $criteria->addSelectColumn(ItemPeer::MANIFESTATION_ID);
            $criteria->addSelectColumn(ItemPeer::MANIFESTATION_DEWEY);
            $criteria->addSelectColumn(ItemPeer::ITEM_MEDIA);
            $criteria->addSelectColumn(ItemPeer::ITEM_STATUS);
            $criteria->addSelectColumn(ItemPeer::ITEM_ORDER_STATUS);
            $criteria->addSelectColumn(ItemPeer::ITEM_ICON);
            $criteria->addSelectColumn(ItemPeer::PHYSICAL_STATUS);
            $criteria->addSelectColumn(ItemPeer::ITEM_SOURCE);
            $criteria->addSelectColumn(ItemPeer::OPAC_VISIBLE);
            $criteria->addSelectColumn(ItemPeer::INVENTORY_SERIE_ID);
            $criteria->addSelectColumn(ItemPeer::INVENTORY_NUMBER);
            $criteria->addSelectColumn(ItemPeer::INVENTORY_DATE);
            $criteria->addSelectColumn(ItemPeer::OWNER_LIBRARY_ID);
            $criteria->addSelectColumn(ItemPeer::HOME_LIBRARY_ID);
            $criteria->addSelectColumn(ItemPeer::COLLOCATION);
            $criteria->addSelectColumn(ItemPeer::SECTION);
            $criteria->addSelectColumn(ItemPeer::SEQUENCE1);
            $criteria->addSelectColumn(ItemPeer::SEQUENCE2);
            $criteria->addSelectColumn(ItemPeer::SPECIFICATION);
            $criteria->addSelectColumn(ItemPeer::REPRINT);
            $criteria->addSelectColumn(ItemPeer::WIDTH);
            $criteria->addSelectColumn(ItemPeer::HEIGHT);
            $criteria->addSelectColumn(ItemPeer::WEIGHT);
            $criteria->addSelectColumn(ItemPeer::VOLUME_NUMBER);
            $criteria->addSelectColumn(ItemPeer::VOLUME_TEXT);
            $criteria->addSelectColumn(ItemPeer::MEDIAPACKAGE_SIZE);
            $criteria->addSelectColumn(ItemPeer::CURRENT_LOAN_ID);
            $criteria->addSelectColumn(ItemPeer::LOAN_CLASS);
            $criteria->addSelectColumn(ItemPeer::LAST_SEEN);
            $criteria->addSelectColumn(ItemPeer::LOAN_STATUS);
            $criteria->addSelectColumn(ItemPeer::LOAN_ALERT);
            $criteria->addSelectColumn(ItemPeer::LOAN_ALERT_NOTE);
            $criteria->addSelectColumn(ItemPeer::USAGE_COUNT);
            $criteria->addSelectColumn(ItemPeer::DELIVERY_LIBRARY_ID);
            $criteria->addSelectColumn(ItemPeer::DUE_DATE);
            $criteria->addSelectColumn(ItemPeer::PATRON_ID);
            $criteria->addSelectColumn(ItemPeer::EXTERNAL_LIBRARY_ID);
            $criteria->addSelectColumn(ItemPeer::RENEWAL_COUNT);
            $criteria->addSelectColumn(ItemPeer::NOTIFY_COUNT);
            $criteria->addSelectColumn(ItemPeer::CHECK_OUT);
            $criteria->addSelectColumn(ItemPeer::CHECK_IN);
            $criteria->addSelectColumn(ItemPeer::ILL_TIMESTAMP);
            $criteria->addSelectColumn(ItemPeer::SUPPLIER_ID);
            $criteria->addSelectColumn(ItemPeer::INVOICE_ID);
            $criteria->addSelectColumn(ItemPeer::ORDER_ID);
            $criteria->addSelectColumn(ItemPeer::BUDGET_ID);
            $criteria->addSelectColumn(ItemPeer::CURRENCY);
            $criteria->addSelectColumn(ItemPeer::CURRENCY_VALUE);
            $criteria->addSelectColumn(ItemPeer::DISCOUNT_VALUE);
            $criteria->addSelectColumn(ItemPeer::INVENTORY_VALUE);
            $criteria->addSelectColumn(ItemPeer::ISSUE_INVENTORY_NUMBER);
            $criteria->addSelectColumn(ItemPeer::ISSUE_ID);
            $criteria->addSelectColumn(ItemPeer::ISSUE_YEAR);
            $criteria->addSelectColumn(ItemPeer::ISSUE_NUMBER);
            $criteria->addSelectColumn(ItemPeer::ISSUE_DESCRIPTION);
            $criteria->addSelectColumn(ItemPeer::ISSUE_ARRIVAL_DATE);
            $criteria->addSelectColumn(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED);
            $criteria->addSelectColumn(ItemPeer::ISSUE_STATUS);
            $criteria->addSelectColumn(ItemPeer::SUBSCRIPTION_ID);
            $criteria->addSelectColumn(ItemPeer::CONSISTENCY_NOTE_ID);
            $criteria->addSelectColumn(ItemPeer::ACTUAL_LIBRARY_ID);
            $criteria->addSelectColumn(ItemPeer::BARCODE);
            $criteria->addSelectColumn(ItemPeer::RFID_CODE);
            $criteria->addSelectColumn(ItemPeer::CUSTOM_FIELD1);
            $criteria->addSelectColumn(ItemPeer::CUSTOM_FIELD2);
            $criteria->addSelectColumn(ItemPeer::CUSTOM_FIELD3);
            $criteria->addSelectColumn(ItemPeer::UNIMARC);
            $criteria->addSelectColumn(ItemPeer::LAST_SBN_SYNC);
            $criteria->addSelectColumn(ItemPeer::DATE_DISCARDED);
            $criteria->addSelectColumn(ItemPeer::DISCARD_NOTE);
            $criteria->addSelectColumn(ItemPeer::DATE_CREATED);
            $criteria->addSelectColumn(ItemPeer::DATE_UPDATED);
            $criteria->addSelectColumn(ItemPeer::CREATED_BY);
            $criteria->addSelectColumn(ItemPeer::MODIFIED_BY);
        } else {
            $criteria->addSelectColumn($alias . '.item_id');
            $criteria->addSelectColumn($alias . '.title');
            $criteria->addSelectColumn($alias . '.manifestation_id');
            $criteria->addSelectColumn($alias . '.manifestation_dewey');
            $criteria->addSelectColumn($alias . '.item_media');
            $criteria->addSelectColumn($alias . '.item_status');
            $criteria->addSelectColumn($alias . '.item_order_status');
            $criteria->addSelectColumn($alias . '.item_icon');
            $criteria->addSelectColumn($alias . '.physical_status');
            $criteria->addSelectColumn($alias . '.item_source');
            $criteria->addSelectColumn($alias . '.opac_visible');
            $criteria->addSelectColumn($alias . '.inventory_serie_id');
            $criteria->addSelectColumn($alias . '.inventory_number');
            $criteria->addSelectColumn($alias . '.inventory_date');
            $criteria->addSelectColumn($alias . '.owner_library_id');
            $criteria->addSelectColumn($alias . '.home_library_id');
            $criteria->addSelectColumn($alias . '.collocation');
            $criteria->addSelectColumn($alias . '.section');
            $criteria->addSelectColumn($alias . '.sequence1');
            $criteria->addSelectColumn($alias . '.sequence2');
            $criteria->addSelectColumn($alias . '.specification');
            $criteria->addSelectColumn($alias . '.reprint');
            $criteria->addSelectColumn($alias . '.width');
            $criteria->addSelectColumn($alias . '.height');
            $criteria->addSelectColumn($alias . '.weight');
            $criteria->addSelectColumn($alias . '.volume_number');
            $criteria->addSelectColumn($alias . '.volume_text');
            $criteria->addSelectColumn($alias . '.mediapackage_size');
            $criteria->addSelectColumn($alias . '.current_loan_id');
            $criteria->addSelectColumn($alias . '.loan_class');
            $criteria->addSelectColumn($alias . '.last_seen');
            $criteria->addSelectColumn($alias . '.loan_status');
            $criteria->addSelectColumn($alias . '.loan_alert');
            $criteria->addSelectColumn($alias . '.loan_alert_note');
            $criteria->addSelectColumn($alias . '.usage_count');
            $criteria->addSelectColumn($alias . '.delivery_library_id');
            $criteria->addSelectColumn($alias . '.due_date');
            $criteria->addSelectColumn($alias . '.patron_id');
            $criteria->addSelectColumn($alias . '.external_library_id');
            $criteria->addSelectColumn($alias . '.renewal_count');
            $criteria->addSelectColumn($alias . '.notify_count');
            $criteria->addSelectColumn($alias . '.check_out');
            $criteria->addSelectColumn($alias . '.check_in');
            $criteria->addSelectColumn($alias . '.ill_timestamp');
            $criteria->addSelectColumn($alias . '.supplier_id');
            $criteria->addSelectColumn($alias . '.invoice_id');
            $criteria->addSelectColumn($alias . '.order_id');
            $criteria->addSelectColumn($alias . '.budget_id');
            $criteria->addSelectColumn($alias . '.currency');
            $criteria->addSelectColumn($alias . '.currency_value');
            $criteria->addSelectColumn($alias . '.discount_value');
            $criteria->addSelectColumn($alias . '.inventory_value');
            $criteria->addSelectColumn($alias . '.issue_inventory_number');
            $criteria->addSelectColumn($alias . '.issue_id');
            $criteria->addSelectColumn($alias . '.issue_year');
            $criteria->addSelectColumn($alias . '.issue_number');
            $criteria->addSelectColumn($alias . '.issue_description');
            $criteria->addSelectColumn($alias . '.issue_arrival_date');
            $criteria->addSelectColumn($alias . '.issue_arrival_date_expected');
            $criteria->addSelectColumn($alias . '.issue_status');
            $criteria->addSelectColumn($alias . '.subscription_id');
            $criteria->addSelectColumn($alias . '.consistency_note_id');
            $criteria->addSelectColumn($alias . '.actual_library_id');
            $criteria->addSelectColumn($alias . '.barcode');
            $criteria->addSelectColumn($alias . '.rfid_code');
            $criteria->addSelectColumn($alias . '.custom_field1');
            $criteria->addSelectColumn($alias . '.custom_field2');
            $criteria->addSelectColumn($alias . '.custom_field3');
            $criteria->addSelectColumn($alias . '.unimarc');
            $criteria->addSelectColumn($alias . '.last_sbn_sync');
            $criteria->addSelectColumn($alias . '.date_discarded');
            $criteria->addSelectColumn($alias . '.discard_note');
            $criteria->addSelectColumn($alias . '.date_created');
            $criteria->addSelectColumn($alias . '.date_updated');
            $criteria->addSelectColumn($alias . '.created_by');
            $criteria->addSelectColumn($alias . '.modified_by');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(ItemPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return Item
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = ItemPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return ItemPeer::populateObjects(ItemPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            ItemPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param Item $obj A Item object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getItemId();
            } // if key === null
            ItemPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A Item object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof Item) {
                $key = (string) $value->getItemId();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or Item object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(ItemPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return Item Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(ItemPeer::$instances[$key])) {
                return ItemPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references) {
        foreach (ItemPeer::$instances as $instance) {
          $instance->clearAllReferences(true);
        }
      }
        ItemPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to item
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = ItemPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = ItemPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                ItemPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (Item object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = ItemPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + ItemPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = ItemPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            ItemPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Issue table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinIssue(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Manifestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinManifestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related ConsistencyNote table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinConsistencyNote(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByOwnerLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByOwnerLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByHomeLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByHomeLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByDeliveryLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByDeliveryLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByActualLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByActualLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related InventorySerie table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinInventorySerie(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related PurchaseOrder table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinPurchaseOrder(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Invoice table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinInvoice(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Supplier table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinSupplier(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Patron table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinPatron(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByExternalLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByExternalLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LoanRelatedByCurrentLoanId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLoanRelatedByCurrentLoanId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Budget table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinBudget(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Librarian)
                $obj2->addItemRelatedByModifiedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Issue objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinIssue(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        IssuePeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = IssuePeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = IssuePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    IssuePeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Issue)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Manifestation objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinManifestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        ManifestationPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = ManifestationPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = ManifestationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    ManifestationPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Manifestation)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their ConsistencyNote objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinConsistencyNote(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        ConsistencyNotePeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = ConsistencyNotePeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = ConsistencyNotePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    ConsistencyNotePeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (ConsistencyNote)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByOwnerLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Library)
                $obj2->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByHomeLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Library)
                $obj2->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByDeliveryLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Library)
                $obj2->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByActualLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Library)
                $obj2->addItemRelatedByActualLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their InventorySerie objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinInventorySerie(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        InventorySeriePeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = InventorySeriePeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = InventorySeriePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    InventorySeriePeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (InventorySerie)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their PurchaseOrder objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinPurchaseOrder(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        PurchaseOrderPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = PurchaseOrderPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = PurchaseOrderPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    PurchaseOrderPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (PurchaseOrder)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Invoice objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinInvoice(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        InvoicePeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = InvoicePeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = InvoicePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    InvoicePeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Invoice)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Supplier objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinSupplier(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        SupplierPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = SupplierPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = SupplierPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    SupplierPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Supplier)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Patron objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinPatron(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        PatronPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = PatronPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = PatronPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    PatronPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Patron)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByExternalLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Library)
                $obj2->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Loan objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLoanRelatedByCurrentLoanId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        LoanPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LoanPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LoanPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LoanPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Loan)
                $obj2->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with their Budget objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinBudget(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol = ItemPeer::NUM_HYDRATE_COLUMNS;
        BudgetPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = BudgetPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = BudgetPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    BudgetPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Item) to $obj2 (Budget)
                $obj2->addItem($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of Item objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol19 = $startcol18 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined Librarian rows

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);
            } // if joined row not null

            // Add objects for joined Librarian rows

            $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);
            } // if joined row not null

            // Add objects for joined Issue rows

            $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = IssuePeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);
            } // if joined row not null

            // Add objects for joined Manifestation rows

            $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
            if ($key5 !== null) {
                $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                if (!$obj5) {

                    $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if obj5 loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);
            } // if joined row not null

            // Add objects for joined ConsistencyNote rows

            $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
            if ($key6 !== null) {
                $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                if (!$obj6) {

                    $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if obj6 loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
            if ($key7 !== null) {
                $obj7 = LibraryPeer::getInstanceFromPool($key7);
                if (!$obj7) {

                    $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if obj7 loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
            if ($key8 !== null) {
                $obj8 = LibraryPeer::getInstanceFromPool($key8);
                if (!$obj8) {

                    $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if obj8 loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
            if ($key9 !== null) {
                $obj9 = LibraryPeer::getInstanceFromPool($key9);
                if (!$obj9) {

                    $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if obj9 loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
            if ($key10 !== null) {
                $obj10 = LibraryPeer::getInstanceFromPool($key10);
                if (!$obj10) {

                    $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if obj10 loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined InventorySerie rows

            $key11 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol11);
            if ($key11 !== null) {
                $obj11 = InventorySeriePeer::getInstanceFromPool($key11);
                if (!$obj11) {

                    $cls = InventorySeriePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InventorySeriePeer::addInstanceToPool($obj11, $key11);
                } // if obj11 loaded

                // Add the $obj1 (Item) to the collection in $obj11 (InventorySerie)
                $obj11->addItem($obj1);
            } // if joined row not null

            // Add objects for joined PurchaseOrder rows

            $key12 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol12);
            if ($key12 !== null) {
                $obj12 = PurchaseOrderPeer::getInstanceFromPool($key12);
                if (!$obj12) {

                    $cls = PurchaseOrderPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    PurchaseOrderPeer::addInstanceToPool($obj12, $key12);
                } // if obj12 loaded

                // Add the $obj1 (Item) to the collection in $obj12 (PurchaseOrder)
                $obj12->addItem($obj1);
            } // if joined row not null

            // Add objects for joined Invoice rows

            $key13 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol13);
            if ($key13 !== null) {
                $obj13 = InvoicePeer::getInstanceFromPool($key13);
                if (!$obj13) {

                    $cls = InvoicePeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    InvoicePeer::addInstanceToPool($obj13, $key13);
                } // if obj13 loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Invoice)
                $obj13->addItem($obj1);
            } // if joined row not null

            // Add objects for joined Supplier rows

            $key14 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol14);
            if ($key14 !== null) {
                $obj14 = SupplierPeer::getInstanceFromPool($key14);
                if (!$obj14) {

                    $cls = SupplierPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    SupplierPeer::addInstanceToPool($obj14, $key14);
                } // if obj14 loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Supplier)
                $obj14->addItem($obj1);
            } // if joined row not null

            // Add objects for joined Patron rows

            $key15 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol15);
            if ($key15 !== null) {
                $obj15 = PatronPeer::getInstanceFromPool($key15);
                if (!$obj15) {

                    $cls = PatronPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    PatronPeer::addInstanceToPool($obj15, $key15);
                } // if obj15 loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Patron)
                $obj15->addItem($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key16 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol16);
            if ($key16 !== null) {
                $obj16 = LibraryPeer::getInstanceFromPool($key16);
                if (!$obj16) {

                    $cls = LibraryPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LibraryPeer::addInstanceToPool($obj16, $key16);
                } // if obj16 loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Library)
                $obj16->addItemRelatedByExternalLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined Loan rows

            $key17 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol17);
            if ($key17 !== null) {
                $obj17 = LoanPeer::getInstanceFromPool($key17);
                if (!$obj17) {

                    $cls = LoanPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    LoanPeer::addInstanceToPool($obj17, $key17);
                } // if obj17 loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Loan)
                $obj17->addItemRelatedByCurrentLoanId($obj1);
            } // if joined row not null

            // Add objects for joined Budget rows

            $key18 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol18);
            if ($key18 !== null) {
                $obj18 = BudgetPeer::getInstanceFromPool($key18);
                if (!$obj18) {

                    $cls = BudgetPeer::getOMClass();

                    $obj18 = new $cls();
                    $obj18->hydrate($row, $startcol18);
                    BudgetPeer::addInstanceToPool($obj18, $key18);
                } // if obj18 loaded

                // Add the $obj1 (Item) to the collection in $obj18 (Budget)
                $obj18->addItem($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Issue table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptIssue(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Manifestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptManifestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related ConsistencyNote table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptConsistencyNote(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByOwnerLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByOwnerLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByHomeLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByHomeLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByDeliveryLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByDeliveryLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByActualLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByActualLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related InventorySerie table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptInventorySerie(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related PurchaseOrder table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptPurchaseOrder(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Invoice table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptInvoice(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Supplier table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptSupplier(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Patron table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptPatron(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByExternalLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByExternalLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LoanRelatedByCurrentLoanId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLoanRelatedByCurrentLoanId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Budget table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptBudget(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LibrarianRelatedByCreatedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Issue rows

                $key2 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = IssuePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = IssuePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    IssuePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Issue)
                $obj2->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key3 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = ManifestationPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    ManifestationPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Manifestation)
                $obj3->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key4 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ConsistencyNotePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ConsistencyNotePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (ConsistencyNote)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key5 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = LibraryPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = LibraryPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    LibraryPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Library)
                $obj5->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (Library)
                $obj6->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key9 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = InventorySeriePeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    InventorySeriePeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (InventorySerie)
                $obj9->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key10 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = PurchaseOrderPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    PurchaseOrderPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (PurchaseOrder)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key11 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InvoicePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InvoicePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InvoicePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (Invoice)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key12 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = SupplierPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = SupplierPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    SupplierPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Supplier)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key13 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = PatronPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = PatronPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    PatronPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Patron)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key14 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = LibraryPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = LibraryPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    LibraryPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Library)
                $obj14->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key15 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LoanPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LoanPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LoanPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Loan)
                $obj15->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key16 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = BudgetPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = BudgetPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    BudgetPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Budget)
                $obj16->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LibrarianRelatedByModifiedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Issue rows

                $key2 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = IssuePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = IssuePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    IssuePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Issue)
                $obj2->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key3 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = ManifestationPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    ManifestationPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Manifestation)
                $obj3->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key4 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ConsistencyNotePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ConsistencyNotePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (ConsistencyNote)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key5 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = LibraryPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = LibraryPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    LibraryPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Library)
                $obj5->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (Library)
                $obj6->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key9 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = InventorySeriePeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    InventorySeriePeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (InventorySerie)
                $obj9->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key10 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = PurchaseOrderPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    PurchaseOrderPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (PurchaseOrder)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key11 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InvoicePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InvoicePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InvoicePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (Invoice)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key12 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = SupplierPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = SupplierPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    SupplierPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Supplier)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key13 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = PatronPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = PatronPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    PatronPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Patron)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key14 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = LibraryPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = LibraryPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    LibraryPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Library)
                $obj14->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key15 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LoanPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LoanPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LoanPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Loan)
                $obj15->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key16 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = BudgetPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = BudgetPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    BudgetPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Budget)
                $obj16->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except Issue.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptIssue(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key4 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ManifestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ManifestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Manifestation)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key5 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ConsistencyNotePeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ConsistencyNotePeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (ConsistencyNote)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (Library)
                $obj6->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key10 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = InventorySeriePeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    InventorySeriePeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (InventorySerie)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key11 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PurchaseOrderPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PurchaseOrderPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (PurchaseOrder)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key12 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = InvoicePeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = InvoicePeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    InvoicePeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Invoice)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key13 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = SupplierPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = SupplierPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    SupplierPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Supplier)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key14 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = PatronPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = PatronPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    PatronPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Patron)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except Manifestation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptManifestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key5 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ConsistencyNotePeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ConsistencyNotePeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (ConsistencyNote)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (Library)
                $obj6->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key10 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = InventorySeriePeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    InventorySeriePeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (InventorySerie)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key11 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PurchaseOrderPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PurchaseOrderPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (PurchaseOrder)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key12 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = InvoicePeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = InvoicePeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    InvoicePeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Invoice)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key13 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = SupplierPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = SupplierPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    SupplierPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Supplier)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key14 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = PatronPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = PatronPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    PatronPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Patron)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except ConsistencyNote.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptConsistencyNote(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (Library)
                $obj6->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key10 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = InventorySeriePeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    InventorySeriePeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (InventorySerie)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key11 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PurchaseOrderPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PurchaseOrderPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (PurchaseOrder)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key12 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = InvoicePeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = InvoicePeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    InvoicePeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Invoice)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key13 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = SupplierPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = SupplierPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    SupplierPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Supplier)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key14 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = PatronPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = PatronPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    PatronPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Patron)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LibraryRelatedByOwnerLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByOwnerLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key7 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = InventorySeriePeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    InventorySeriePeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (InventorySerie)
                $obj7->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key8 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = PurchaseOrderPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    PurchaseOrderPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (PurchaseOrder)
                $obj8->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key9 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = InvoicePeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = InvoicePeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    InvoicePeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Invoice)
                $obj9->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key10 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = SupplierPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = SupplierPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    SupplierPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Supplier)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key11 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PatronPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PatronPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PatronPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (Patron)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key12 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = LoanPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = LoanPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    LoanPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Loan)
                $obj12->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key13 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = BudgetPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = BudgetPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    BudgetPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Budget)
                $obj13->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LibraryRelatedByHomeLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByHomeLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key7 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = InventorySeriePeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    InventorySeriePeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (InventorySerie)
                $obj7->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key8 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = PurchaseOrderPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    PurchaseOrderPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (PurchaseOrder)
                $obj8->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key9 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = InvoicePeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = InvoicePeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    InvoicePeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Invoice)
                $obj9->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key10 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = SupplierPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = SupplierPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    SupplierPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Supplier)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key11 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PatronPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PatronPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PatronPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (Patron)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key12 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = LoanPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = LoanPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    LoanPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Loan)
                $obj12->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key13 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = BudgetPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = BudgetPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    BudgetPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Budget)
                $obj13->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LibraryRelatedByDeliveryLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByDeliveryLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key7 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = InventorySeriePeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    InventorySeriePeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (InventorySerie)
                $obj7->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key8 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = PurchaseOrderPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    PurchaseOrderPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (PurchaseOrder)
                $obj8->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key9 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = InvoicePeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = InvoicePeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    InvoicePeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Invoice)
                $obj9->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key10 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = SupplierPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = SupplierPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    SupplierPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Supplier)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key11 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PatronPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PatronPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PatronPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (Patron)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key12 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = LoanPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = LoanPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    LoanPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Loan)
                $obj12->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key13 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = BudgetPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = BudgetPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    BudgetPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Budget)
                $obj13->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LibraryRelatedByActualLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByActualLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key7 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = InventorySeriePeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    InventorySeriePeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (InventorySerie)
                $obj7->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key8 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = PurchaseOrderPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    PurchaseOrderPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (PurchaseOrder)
                $obj8->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key9 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = InvoicePeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = InvoicePeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    InvoicePeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Invoice)
                $obj9->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key10 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = SupplierPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = SupplierPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    SupplierPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Supplier)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key11 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PatronPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PatronPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PatronPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (Patron)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key12 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = LoanPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = LoanPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    LoanPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Loan)
                $obj12->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key13 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = BudgetPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = BudgetPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    BudgetPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Budget)
                $obj13->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except InventorySerie.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptInventorySerie(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = LibraryPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key11 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PurchaseOrderPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PurchaseOrderPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (PurchaseOrder)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key12 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = InvoicePeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = InvoicePeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    InvoicePeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Invoice)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key13 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = SupplierPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = SupplierPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    SupplierPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Supplier)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key14 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = PatronPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = PatronPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    PatronPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Patron)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except PurchaseOrder.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptPurchaseOrder(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = LibraryPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key11 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InventorySeriePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InventorySeriePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (InventorySerie)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key12 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = InvoicePeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = InvoicePeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    InvoicePeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Invoice)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key13 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = SupplierPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = SupplierPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    SupplierPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Supplier)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key14 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = PatronPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = PatronPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    PatronPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Patron)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except Invoice.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptInvoice(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = LibraryPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key11 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InventorySeriePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InventorySeriePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (InventorySerie)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key12 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = PurchaseOrderPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    PurchaseOrderPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (PurchaseOrder)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key13 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = SupplierPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = SupplierPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    SupplierPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Supplier)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key14 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = PatronPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = PatronPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    PatronPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Patron)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except Supplier.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptSupplier(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = LibraryPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key11 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InventorySeriePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InventorySeriePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (InventorySerie)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key12 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = PurchaseOrderPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    PurchaseOrderPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (PurchaseOrder)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key13 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = InvoicePeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = InvoicePeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    InvoicePeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Invoice)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key14 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = PatronPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = PatronPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    PatronPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Patron)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except Patron.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptPatron(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = LibraryPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key11 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InventorySeriePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InventorySeriePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (InventorySerie)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key12 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = PurchaseOrderPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    PurchaseOrderPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (PurchaseOrder)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key13 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = InvoicePeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = InvoicePeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    InvoicePeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Invoice)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key14 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = SupplierPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = SupplierPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    SupplierPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Supplier)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key15 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = LibraryPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = LibraryPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    LibraryPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Library)
                $obj15->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key16 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LoanPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LoanPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LoanPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Loan)
                $obj16->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LibraryRelatedByExternalLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByExternalLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + LoanPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key7 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = InventorySeriePeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    InventorySeriePeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (InventorySerie)
                $obj7->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key8 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = PurchaseOrderPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    PurchaseOrderPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (PurchaseOrder)
                $obj8->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key9 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = InvoicePeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = InvoicePeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    InvoicePeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Invoice)
                $obj9->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key10 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = SupplierPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = SupplierPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    SupplierPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Supplier)
                $obj10->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key11 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = PatronPeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = PatronPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    PatronPeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (Patron)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key12 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = LoanPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = LoanPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    LoanPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (Loan)
                $obj12->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key13 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = BudgetPeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = BudgetPeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    BudgetPeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Budget)
                $obj13->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except LoanRelatedByCurrentLoanId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLoanRelatedByCurrentLoanId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        BudgetPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + BudgetPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::BUDGET_ID, BudgetPeer::BUDGET_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = LibraryPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key11 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InventorySeriePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InventorySeriePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (InventorySerie)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key12 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = PurchaseOrderPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    PurchaseOrderPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (PurchaseOrder)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key13 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = InvoicePeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = InvoicePeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    InvoicePeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Invoice)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key14 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = SupplierPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = SupplierPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    SupplierPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Supplier)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key15 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = PatronPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = PatronPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    PatronPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Patron)
                $obj15->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key16 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LibraryPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LibraryPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LibraryPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Library)
                $obj16->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Budget rows

                $key17 = BudgetPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = BudgetPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = BudgetPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    BudgetPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Budget)
                $obj17->addItem($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Item objects pre-filled with all related objects except Budget.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Item objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptBudget(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemPeer::DATABASE_NAME);
        }

        ItemPeer::addSelectColumns($criteria);
        $startcol2 = ItemPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        IssuePeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + IssuePeer::NUM_HYDRATE_COLUMNS;

        ManifestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + ManifestationPeer::NUM_HYDRATE_COLUMNS;

        ConsistencyNotePeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + ConsistencyNotePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        InventorySeriePeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + InventorySeriePeer::NUM_HYDRATE_COLUMNS;

        PurchaseOrderPeer::addSelectColumns($criteria);
        $startcol13 = $startcol12 + PurchaseOrderPeer::NUM_HYDRATE_COLUMNS;

        InvoicePeer::addSelectColumns($criteria);
        $startcol14 = $startcol13 + InvoicePeer::NUM_HYDRATE_COLUMNS;

        SupplierPeer::addSelectColumns($criteria);
        $startcol15 = $startcol14 + SupplierPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol16 = $startcol15 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol17 = $startcol16 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LoanPeer::addSelectColumns($criteria);
        $startcol18 = $startcol17 + LoanPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CONSISTENCY_NOTE_ID, ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::OWNER_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::HOME_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVENTORY_SERIE_ID, InventorySeriePeer::INVENTORY_SERIE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::ORDER_ID, PurchaseOrderPeer::ORDER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::INVOICE_ID, InvoicePeer::INVOICE_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::SUPPLIER_ID, SupplierPeer::SUPPLIER_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Item) to the collection in $obj2 (Librarian)
                $obj2->addItemRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Item) to the collection in $obj3 (Librarian)
                $obj3->addItemRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Issue rows

                $key4 = IssuePeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = IssuePeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = IssuePeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    IssuePeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (Item) to the collection in $obj4 (Issue)
                $obj4->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Manifestation rows

                $key5 = ManifestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = ManifestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = ManifestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    ManifestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (Item) to the collection in $obj5 (Manifestation)
                $obj5->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined ConsistencyNote rows

                $key6 = ConsistencyNotePeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = ConsistencyNotePeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = ConsistencyNotePeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    ConsistencyNotePeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (Item) to the collection in $obj6 (ConsistencyNote)
                $obj6->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (Item) to the collection in $obj7 (Library)
                $obj7->addItemRelatedByOwnerLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (Item) to the collection in $obj8 (Library)
                $obj8->addItemRelatedByHomeLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = LibraryPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (Item) to the collection in $obj9 (Library)
                $obj9->addItemRelatedByDeliveryLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key10 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = LibraryPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = LibraryPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    LibraryPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (Item) to the collection in $obj10 (Library)
                $obj10->addItemRelatedByActualLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined InventorySerie rows

                $key11 = InventorySeriePeer::getPrimaryKeyHashFromRow($row, $startcol11);
                if ($key11 !== null) {
                    $obj11 = InventorySeriePeer::getInstanceFromPool($key11);
                    if (!$obj11) {

                        $cls = InventorySeriePeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    InventorySeriePeer::addInstanceToPool($obj11, $key11);
                } // if $obj11 already loaded

                // Add the $obj1 (Item) to the collection in $obj11 (InventorySerie)
                $obj11->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined PurchaseOrder rows

                $key12 = PurchaseOrderPeer::getPrimaryKeyHashFromRow($row, $startcol12);
                if ($key12 !== null) {
                    $obj12 = PurchaseOrderPeer::getInstanceFromPool($key12);
                    if (!$obj12) {

                        $cls = PurchaseOrderPeer::getOMClass();

                    $obj12 = new $cls();
                    $obj12->hydrate($row, $startcol12);
                    PurchaseOrderPeer::addInstanceToPool($obj12, $key12);
                } // if $obj12 already loaded

                // Add the $obj1 (Item) to the collection in $obj12 (PurchaseOrder)
                $obj12->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Invoice rows

                $key13 = InvoicePeer::getPrimaryKeyHashFromRow($row, $startcol13);
                if ($key13 !== null) {
                    $obj13 = InvoicePeer::getInstanceFromPool($key13);
                    if (!$obj13) {

                        $cls = InvoicePeer::getOMClass();

                    $obj13 = new $cls();
                    $obj13->hydrate($row, $startcol13);
                    InvoicePeer::addInstanceToPool($obj13, $key13);
                } // if $obj13 already loaded

                // Add the $obj1 (Item) to the collection in $obj13 (Invoice)
                $obj13->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Supplier rows

                $key14 = SupplierPeer::getPrimaryKeyHashFromRow($row, $startcol14);
                if ($key14 !== null) {
                    $obj14 = SupplierPeer::getInstanceFromPool($key14);
                    if (!$obj14) {

                        $cls = SupplierPeer::getOMClass();

                    $obj14 = new $cls();
                    $obj14->hydrate($row, $startcol14);
                    SupplierPeer::addInstanceToPool($obj14, $key14);
                } // if $obj14 already loaded

                // Add the $obj1 (Item) to the collection in $obj14 (Supplier)
                $obj14->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key15 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol15);
                if ($key15 !== null) {
                    $obj15 = PatronPeer::getInstanceFromPool($key15);
                    if (!$obj15) {

                        $cls = PatronPeer::getOMClass();

                    $obj15 = new $cls();
                    $obj15->hydrate($row, $startcol15);
                    PatronPeer::addInstanceToPool($obj15, $key15);
                } // if $obj15 already loaded

                // Add the $obj1 (Item) to the collection in $obj15 (Patron)
                $obj15->addItem($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key16 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol16);
                if ($key16 !== null) {
                    $obj16 = LibraryPeer::getInstanceFromPool($key16);
                    if (!$obj16) {

                        $cls = LibraryPeer::getOMClass();

                    $obj16 = new $cls();
                    $obj16->hydrate($row, $startcol16);
                    LibraryPeer::addInstanceToPool($obj16, $key16);
                } // if $obj16 already loaded

                // Add the $obj1 (Item) to the collection in $obj16 (Library)
                $obj16->addItemRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Loan rows

                $key17 = LoanPeer::getPrimaryKeyHashFromRow($row, $startcol17);
                if ($key17 !== null) {
                    $obj17 = LoanPeer::getInstanceFromPool($key17);
                    if (!$obj17) {

                        $cls = LoanPeer::getOMClass();

                    $obj17 = new $cls();
                    $obj17->hydrate($row, $startcol17);
                    LoanPeer::addInstanceToPool($obj17, $key17);
                } // if $obj17 already loaded

                // Add the $obj1 (Item) to the collection in $obj17 (Loan)
                $obj17->addItemRelatedByCurrentLoanId($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(ItemPeer::DATABASE_NAME)->getTable(ItemPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseItemPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseItemPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new \ItemTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return ItemPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a Item or Criteria object.
     *
     * @param      mixed $values Criteria or Item object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from Item object
        }

        if ($criteria->containsKey(ItemPeer::ITEM_ID) && $criteria->keyContainsValue(ItemPeer::ITEM_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.ItemPeer::ITEM_ID.')');
        }


        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a Item or Criteria object.
     *
     * @param      mixed $values Criteria or Item object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(ItemPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(ItemPeer::ITEM_ID);
            $value = $criteria->remove(ItemPeer::ITEM_ID);
            if ($value) {
                $selectCriteria->add(ItemPeer::ITEM_ID, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(ItemPeer::TABLE_NAME);
            }

        } else { // $values is Item object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the item table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(ItemPeer::TABLE_NAME, $con, ItemPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            ItemPeer::clearInstancePool();
            ItemPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a Item or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or Item object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            ItemPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof Item) { // it's a model object
            // invalidate the cache for this single object
            ItemPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(ItemPeer::DATABASE_NAME);
            $criteria->add(ItemPeer::ITEM_ID, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                ItemPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(ItemPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            ItemPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given Item object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param Item $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(ItemPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(ItemPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(ItemPeer::DATABASE_NAME, ItemPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return Item
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = ItemPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(ItemPeer::DATABASE_NAME);
        $criteria->add(ItemPeer::ITEM_ID, $pk);

        $v = ItemPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return Item[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(ItemPeer::DATABASE_NAME);
            $criteria->add(ItemPeer::ITEM_ID, $pks, Criteria::IN);
            $objs = ItemPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseItemPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseItemPeer::buildTableMap();

