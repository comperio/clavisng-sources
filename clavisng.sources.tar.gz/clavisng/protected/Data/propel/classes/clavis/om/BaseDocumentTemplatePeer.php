<?php


/**
 * Base static class for performing query and update operations on the 'document_template' table.
 *
 *
 *
 * @package propel.generator.clavis.om
 */
abstract class BaseDocumentTemplatePeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'clavis';

    /** the table name for this class */
    const TABLE_NAME = 'document_template';

    /** the related Propel class for this table */
    const OM_CLASS = 'DocumentTemplate';

    /** the related TableMap class for this table */
    const TM_CLASS = 'DocumentTemplateTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 13;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 13;

    /** the column name for the document_template_id field */
    const DOCUMENT_TEMPLATE_ID = 'document_template.document_template_id';

    /** the column name for the template_media field */
    const TEMPLATE_MEDIA = 'document_template.template_media';

    /** the column name for the template_description field */
    const TEMPLATE_DESCRIPTION = 'document_template.template_description';

    /** the column name for the template_title field */
    const TEMPLATE_TITLE = 'document_template.template_title';

    /** the column name for the template_subject field */
    const TEMPLATE_SUBJECT = 'document_template.template_subject';

    /** the column name for the template_body field */
    const TEMPLATE_BODY = 'document_template.template_body';

    /** the column name for the template_class field */
    const TEMPLATE_CLASS = 'document_template.template_class';

    /** the column name for the template_lang field */
    const TEMPLATE_LANG = 'document_template.template_lang';

    /** the column name for the library_id field */
    const LIBRARY_ID = 'document_template.library_id';

    /** the column name for the date_created field */
    const DATE_CREATED = 'document_template.date_created';

    /** the column name for the date_updated field */
    const DATE_UPDATED = 'document_template.date_updated';

    /** the column name for the created_by field */
    const CREATED_BY = 'document_template.created_by';

    /** the column name for the modified_by field */
    const MODIFIED_BY = 'document_template.modified_by';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identity map to hold any loaded instances of DocumentTemplate objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array DocumentTemplate[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. DocumentTemplatePeer::$fieldNames[DocumentTemplatePeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('DocumentTemplateId', 'TemplateMedia', 'TemplateDescription', 'TemplateTitle', 'TemplateSubject', 'TemplateBody', 'TemplateClass', 'TemplateLang', 'LibraryId', 'DateCreated', 'DateUpdated', 'CreatedBy', 'ModifiedBy', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('documentTemplateId', 'templateMedia', 'templateDescription', 'templateTitle', 'templateSubject', 'templateBody', 'templateClass', 'templateLang', 'libraryId', 'dateCreated', 'dateUpdated', 'createdBy', 'modifiedBy', ),
        BasePeer::TYPE_COLNAME => array (DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, DocumentTemplatePeer::TEMPLATE_MEDIA, DocumentTemplatePeer::TEMPLATE_DESCRIPTION, DocumentTemplatePeer::TEMPLATE_TITLE, DocumentTemplatePeer::TEMPLATE_SUBJECT, DocumentTemplatePeer::TEMPLATE_BODY, DocumentTemplatePeer::TEMPLATE_CLASS, DocumentTemplatePeer::TEMPLATE_LANG, DocumentTemplatePeer::LIBRARY_ID, DocumentTemplatePeer::DATE_CREATED, DocumentTemplatePeer::DATE_UPDATED, DocumentTemplatePeer::CREATED_BY, DocumentTemplatePeer::MODIFIED_BY, ),
        BasePeer::TYPE_RAW_COLNAME => array ('DOCUMENT_TEMPLATE_ID', 'TEMPLATE_MEDIA', 'TEMPLATE_DESCRIPTION', 'TEMPLATE_TITLE', 'TEMPLATE_SUBJECT', 'TEMPLATE_BODY', 'TEMPLATE_CLASS', 'TEMPLATE_LANG', 'LIBRARY_ID', 'DATE_CREATED', 'DATE_UPDATED', 'CREATED_BY', 'MODIFIED_BY', ),
        BasePeer::TYPE_FIELDNAME => array ('document_template_id', 'template_media', 'template_description', 'template_title', 'template_subject', 'template_body', 'template_class', 'template_lang', 'library_id', 'date_created', 'date_updated', 'created_by', 'modified_by', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. DocumentTemplatePeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('DocumentTemplateId' => 0, 'TemplateMedia' => 1, 'TemplateDescription' => 2, 'TemplateTitle' => 3, 'TemplateSubject' => 4, 'TemplateBody' => 5, 'TemplateClass' => 6, 'TemplateLang' => 7, 'LibraryId' => 8, 'DateCreated' => 9, 'DateUpdated' => 10, 'CreatedBy' => 11, 'ModifiedBy' => 12, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('documentTemplateId' => 0, 'templateMedia' => 1, 'templateDescription' => 2, 'templateTitle' => 3, 'templateSubject' => 4, 'templateBody' => 5, 'templateClass' => 6, 'templateLang' => 7, 'libraryId' => 8, 'dateCreated' => 9, 'dateUpdated' => 10, 'createdBy' => 11, 'modifiedBy' => 12, ),
        BasePeer::TYPE_COLNAME => array (DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID => 0, DocumentTemplatePeer::TEMPLATE_MEDIA => 1, DocumentTemplatePeer::TEMPLATE_DESCRIPTION => 2, DocumentTemplatePeer::TEMPLATE_TITLE => 3, DocumentTemplatePeer::TEMPLATE_SUBJECT => 4, DocumentTemplatePeer::TEMPLATE_BODY => 5, DocumentTemplatePeer::TEMPLATE_CLASS => 6, DocumentTemplatePeer::TEMPLATE_LANG => 7, DocumentTemplatePeer::LIBRARY_ID => 8, DocumentTemplatePeer::DATE_CREATED => 9, DocumentTemplatePeer::DATE_UPDATED => 10, DocumentTemplatePeer::CREATED_BY => 11, DocumentTemplatePeer::MODIFIED_BY => 12, ),
        BasePeer::TYPE_RAW_COLNAME => array ('DOCUMENT_TEMPLATE_ID' => 0, 'TEMPLATE_MEDIA' => 1, 'TEMPLATE_DESCRIPTION' => 2, 'TEMPLATE_TITLE' => 3, 'TEMPLATE_SUBJECT' => 4, 'TEMPLATE_BODY' => 5, 'TEMPLATE_CLASS' => 6, 'TEMPLATE_LANG' => 7, 'LIBRARY_ID' => 8, 'DATE_CREATED' => 9, 'DATE_UPDATED' => 10, 'CREATED_BY' => 11, 'MODIFIED_BY' => 12, ),
        BasePeer::TYPE_FIELDNAME => array ('document_template_id' => 0, 'template_media' => 1, 'template_description' => 2, 'template_title' => 3, 'template_subject' => 4, 'template_body' => 5, 'template_class' => 6, 'template_lang' => 7, 'library_id' => 8, 'date_created' => 9, 'date_updated' => 10, 'created_by' => 11, 'modified_by' => 12, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, )
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = DocumentTemplatePeer::getFieldNames($toType);
        $key = isset(DocumentTemplatePeer::$fieldKeys[$fromType][$name]) ? DocumentTemplatePeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(DocumentTemplatePeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, DocumentTemplatePeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return DocumentTemplatePeer::$fieldNames[$type];
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. DocumentTemplatePeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(DocumentTemplatePeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID);
            $criteria->addSelectColumn(DocumentTemplatePeer::TEMPLATE_MEDIA);
            $criteria->addSelectColumn(DocumentTemplatePeer::TEMPLATE_DESCRIPTION);
            $criteria->addSelectColumn(DocumentTemplatePeer::TEMPLATE_TITLE);
            $criteria->addSelectColumn(DocumentTemplatePeer::TEMPLATE_SUBJECT);
            $criteria->addSelectColumn(DocumentTemplatePeer::TEMPLATE_BODY);
            $criteria->addSelectColumn(DocumentTemplatePeer::TEMPLATE_CLASS);
            $criteria->addSelectColumn(DocumentTemplatePeer::TEMPLATE_LANG);
            $criteria->addSelectColumn(DocumentTemplatePeer::LIBRARY_ID);
            $criteria->addSelectColumn(DocumentTemplatePeer::DATE_CREATED);
            $criteria->addSelectColumn(DocumentTemplatePeer::DATE_UPDATED);
            $criteria->addSelectColumn(DocumentTemplatePeer::CREATED_BY);
            $criteria->addSelectColumn(DocumentTemplatePeer::MODIFIED_BY);
        } else {
            $criteria->addSelectColumn($alias . '.document_template_id');
            $criteria->addSelectColumn($alias . '.template_media');
            $criteria->addSelectColumn($alias . '.template_description');
            $criteria->addSelectColumn($alias . '.template_title');
            $criteria->addSelectColumn($alias . '.template_subject');
            $criteria->addSelectColumn($alias . '.template_body');
            $criteria->addSelectColumn($alias . '.template_class');
            $criteria->addSelectColumn($alias . '.template_lang');
            $criteria->addSelectColumn($alias . '.library_id');
            $criteria->addSelectColumn($alias . '.date_created');
            $criteria->addSelectColumn($alias . '.date_updated');
            $criteria->addSelectColumn($alias . '.created_by');
            $criteria->addSelectColumn($alias . '.modified_by');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return DocumentTemplate
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = DocumentTemplatePeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return DocumentTemplatePeer::populateObjects(DocumentTemplatePeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param DocumentTemplate $obj A DocumentTemplate object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getDocumentTemplateId();
            } // if key === null
            DocumentTemplatePeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A DocumentTemplate object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof DocumentTemplate) {
                $key = (string) $value->getDocumentTemplateId();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or DocumentTemplate object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(DocumentTemplatePeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return DocumentTemplate Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(DocumentTemplatePeer::$instances[$key])) {
                return DocumentTemplatePeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references) {
        foreach (DocumentTemplatePeer::$instances as $instance) {
          $instance->clearAllReferences(true);
        }
      }
        DocumentTemplatePeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to document_template
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = DocumentTemplatePeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = DocumentTemplatePeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                DocumentTemplatePeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (DocumentTemplate object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = DocumentTemplatePeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = DocumentTemplatePeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            DocumentTemplatePeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(DocumentTemplatePeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(DocumentTemplatePeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Library table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrary(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of DocumentTemplate objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of DocumentTemplate objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);
        }

        DocumentTemplatePeer::addSelectColumns($criteria);
        $startcol = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(DocumentTemplatePeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = DocumentTemplatePeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = DocumentTemplatePeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                DocumentTemplatePeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (DocumentTemplate) to $obj2 (Librarian)
                $obj2->addDocumentTemplateRelatedByCreatedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of DocumentTemplate objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of DocumentTemplate objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);
        }

        DocumentTemplatePeer::addSelectColumns($criteria);
        $startcol = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(DocumentTemplatePeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = DocumentTemplatePeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = DocumentTemplatePeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                DocumentTemplatePeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (DocumentTemplate) to $obj2 (Librarian)
                $obj2->addDocumentTemplateRelatedByModifiedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of DocumentTemplate objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of DocumentTemplate objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrary(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);
        }

        DocumentTemplatePeer::addSelectColumns($criteria);
        $startcol = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = DocumentTemplatePeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = DocumentTemplatePeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                DocumentTemplatePeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (DocumentTemplate) to $obj2 (Library)
                $obj2->addDocumentTemplate($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(DocumentTemplatePeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(DocumentTemplatePeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of DocumentTemplate objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of DocumentTemplate objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);
        }

        DocumentTemplatePeer::addSelectColumns($criteria);
        $startcol2 = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(DocumentTemplatePeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(DocumentTemplatePeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = DocumentTemplatePeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = DocumentTemplatePeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                DocumentTemplatePeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined Librarian rows

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (DocumentTemplate) to the collection in $obj2 (Librarian)
                $obj2->addDocumentTemplateRelatedByCreatedBy($obj1);
            } // if joined row not null

            // Add objects for joined Librarian rows

            $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (DocumentTemplate) to the collection in $obj3 (Librarian)
                $obj3->addDocumentTemplateRelatedByModifiedBy($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key4 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = LibraryPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = LibraryPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    LibraryPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (DocumentTemplate) to the collection in $obj4 (Library)
                $obj4->addDocumentTemplate($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Library table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrary(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            DocumentTemplatePeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(DocumentTemplatePeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(DocumentTemplatePeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of DocumentTemplate objects pre-filled with all related objects except LibrarianRelatedByCreatedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of DocumentTemplate objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);
        }

        DocumentTemplatePeer::addSelectColumns($criteria);
        $startcol2 = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = DocumentTemplatePeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = DocumentTemplatePeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                DocumentTemplatePeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Library rows

                $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibraryPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (DocumentTemplate) to the collection in $obj2 (Library)
                $obj2->addDocumentTemplate($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of DocumentTemplate objects pre-filled with all related objects except LibrarianRelatedByModifiedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of DocumentTemplate objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);
        }

        DocumentTemplatePeer::addSelectColumns($criteria);
        $startcol2 = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(DocumentTemplatePeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = DocumentTemplatePeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = DocumentTemplatePeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                DocumentTemplatePeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Library rows

                $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibraryPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (DocumentTemplate) to the collection in $obj2 (Library)
                $obj2->addDocumentTemplate($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of DocumentTemplate objects pre-filled with all related objects except Library.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of DocumentTemplate objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrary(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);
        }

        DocumentTemplatePeer::addSelectColumns($criteria);
        $startcol2 = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(DocumentTemplatePeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(DocumentTemplatePeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = DocumentTemplatePeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = DocumentTemplatePeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = DocumentTemplatePeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                DocumentTemplatePeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (DocumentTemplate) to the collection in $obj2 (Librarian)
                $obj2->addDocumentTemplateRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (DocumentTemplate) to the collection in $obj3 (Librarian)
                $obj3->addDocumentTemplateRelatedByModifiedBy($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(DocumentTemplatePeer::DATABASE_NAME)->getTable(DocumentTemplatePeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseDocumentTemplatePeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseDocumentTemplatePeer::TABLE_NAME)) {
        $dbMap->addTableObject(new \DocumentTemplateTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return DocumentTemplatePeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a DocumentTemplate or Criteria object.
     *
     * @param      mixed $values Criteria or DocumentTemplate object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from DocumentTemplate object
        }

        if ($criteria->containsKey(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID) && $criteria->keyContainsValue(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID.')');
        }


        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a DocumentTemplate or Criteria object.
     *
     * @param      mixed $values Criteria or DocumentTemplate object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(DocumentTemplatePeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID);
            $value = $criteria->remove(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID);
            if ($value) {
                $selectCriteria->add(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(DocumentTemplatePeer::TABLE_NAME);
            }

        } else { // $values is DocumentTemplate object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the document_template table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(DocumentTemplatePeer::TABLE_NAME, $con, DocumentTemplatePeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            DocumentTemplatePeer::clearInstancePool();
            DocumentTemplatePeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a DocumentTemplate or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or DocumentTemplate object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            DocumentTemplatePeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof DocumentTemplate) { // it's a model object
            // invalidate the cache for this single object
            DocumentTemplatePeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(DocumentTemplatePeer::DATABASE_NAME);
            $criteria->add(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                DocumentTemplatePeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(DocumentTemplatePeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            DocumentTemplatePeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given DocumentTemplate object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param DocumentTemplate $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(DocumentTemplatePeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(DocumentTemplatePeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(DocumentTemplatePeer::DATABASE_NAME, DocumentTemplatePeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return DocumentTemplate
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = DocumentTemplatePeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(DocumentTemplatePeer::DATABASE_NAME);
        $criteria->add(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $pk);

        $v = DocumentTemplatePeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return DocumentTemplate[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(DocumentTemplatePeer::DATABASE_NAME);
            $criteria->add(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $pks, Criteria::IN);
            $objs = DocumentTemplatePeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseDocumentTemplatePeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseDocumentTemplatePeer::buildTableMap();

