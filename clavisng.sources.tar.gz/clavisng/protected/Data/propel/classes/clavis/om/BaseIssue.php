<?php


/**
 * Base class that represents a row from the 'issue' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseIssue extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'IssuePeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        IssuePeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the issue_id field.
     * @var        int
     */
    protected $issue_id;

    /**
     * The value for the issue_number field.
     * @var        string
     */
    protected $issue_number;

    /**
     * The value for the start_number field.
     * @var        int
     */
    protected $start_number;

    /**
     * The value for the end_number field.
     * @var        int
     */
    protected $end_number;

    /**
     * The value for the issue_year field.
     * @var        string
     */
    protected $issue_year;

    /**
     * The value for the issue_volume field.
     * @var        string
     */
    protected $issue_volume;

    /**
     * The value for the issue_note field.
     * @var        string
     */
    protected $issue_note;

    /**
     * The value for the issue_type field.
     * @var        string
     */
    protected $issue_type;

    /**
     * The value for the issue_date field.
     * @var        string
     */
    protected $issue_date;

    /**
     * The value for the manifestation_id field.
     * @var        int
     */
    protected $manifestation_id;

    /**
     * The value for the date_created field.
     * @var        string
     */
    protected $date_created;

    /**
     * The value for the date_updated field.
     * @var        string
     */
    protected $date_updated;

    /**
     * The value for the created_by field.
     * @var        int
     */
    protected $created_by;

    /**
     * The value for the modified_by field.
     * @var        int
     */
    protected $modified_by;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByCreatedBy;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByModifiedBy;

    /**
     * @var        Manifestation
     */
    protected $aManifestation;

    /**
     * @var        PropelObjectCollection|Item[] Collection to store aggregation of Item objects.
     */
    protected $collItems;
    protected $collItemsPartial;

    /**
     * @var        PropelObjectCollection|ItemRequest[] Collection to store aggregation of ItemRequest objects.
     */
    protected $collItemRequests;
    protected $collItemRequestsPartial;

    /**
     * @var        PropelObjectCollection|LManifestation[] Collection to store aggregation of LManifestation objects.
     */
    protected $collLManifestations;
    protected $collLManifestationsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $itemsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $itemRequestsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lManifestationsScheduledForDeletion = null;

    /**
     * Get the [issue_id] column value.
     *
     * @return int
     */
    public function getIssueId()
    {

        return $this->issue_id;
    }

    /**
     * Get the [issue_number] column value.
     *
     * @return string
     */
    public function getIssueNumber()
    {

        return $this->issue_number;
    }

    /**
     * Get the [start_number] column value.
     *
     * @return int
     */
    public function getStartNumber()
    {

        return $this->start_number;
    }

    /**
     * Get the [end_number] column value.
     *
     * @return int
     */
    public function getEndNumber()
    {

        return $this->end_number;
    }

    /**
     * Get the [issue_year] column value.
     *
     * @return string
     */
    public function getIssueYear()
    {

        return $this->issue_year;
    }

    /**
     * Get the [issue_volume] column value.
     *
     * @return string
     */
    public function getIssueVolume()
    {

        return $this->issue_volume;
    }

    /**
     * Get the [issue_note] column value.
     *
     * @return string
     */
    public function getIssueNote()
    {

        return $this->issue_note;
    }

    /**
     * Get the [issue_type] column value.
     *
     * @return string
     */
    public function getIssueType()
    {

        return $this->issue_type;
    }

    /**
     * Get the [optionally formatted] temporal [issue_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getIssueDate($format = '%F %T')
    {
        if ($this->issue_date === null) {
            return null;
        }

        if ($this->issue_date === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->issue_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->issue_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [manifestation_id] column value.
     *
     * @return int
     */
    public function getManifestationId()
    {

        return $this->manifestation_id;
    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_created === null) {
            return null;
        }

        if ($this->date_created === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_created);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_created, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_updated] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateUpdated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_updated === null) {
            return null;
        }

        if ($this->date_updated === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_updated);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_updated, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [created_by] column value.
     *
     * @return int
     */
    public function getCreatedBy()
    {

        return $this->created_by;
    }

    /**
     * Get the [modified_by] column value.
     *
     * @return int
     */
    public function getModifiedBy()
    {

        return $this->modified_by;
    }

    /**
     * Set the value of [issue_id] column.
     *
     * @param  int $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setIssueId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->issue_id !== $v) {
            $this->issue_id = $v;
            $this->modifiedColumns[] = IssuePeer::ISSUE_ID;
        }


        return $this;
    } // setIssueId()

    /**
     * Set the value of [issue_number] column.
     *
     * @param  string $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setIssueNumber($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_number !== $v) {
            $this->issue_number = $v;
            $this->modifiedColumns[] = IssuePeer::ISSUE_NUMBER;
        }


        return $this;
    } // setIssueNumber()

    /**
     * Set the value of [start_number] column.
     *
     * @param  int $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setStartNumber($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->start_number !== $v) {
            $this->start_number = $v;
            $this->modifiedColumns[] = IssuePeer::START_NUMBER;
        }


        return $this;
    } // setStartNumber()

    /**
     * Set the value of [end_number] column.
     *
     * @param  int $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setEndNumber($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->end_number !== $v) {
            $this->end_number = $v;
            $this->modifiedColumns[] = IssuePeer::END_NUMBER;
        }


        return $this;
    } // setEndNumber()

    /**
     * Set the value of [issue_year] column.
     *
     * @param  string $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setIssueYear($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_year !== $v) {
            $this->issue_year = $v;
            $this->modifiedColumns[] = IssuePeer::ISSUE_YEAR;
        }


        return $this;
    } // setIssueYear()

    /**
     * Set the value of [issue_volume] column.
     *
     * @param  string $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setIssueVolume($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_volume !== $v) {
            $this->issue_volume = $v;
            $this->modifiedColumns[] = IssuePeer::ISSUE_VOLUME;
        }


        return $this;
    } // setIssueVolume()

    /**
     * Set the value of [issue_note] column.
     *
     * @param  string $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setIssueNote($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_note !== $v) {
            $this->issue_note = $v;
            $this->modifiedColumns[] = IssuePeer::ISSUE_NOTE;
        }


        return $this;
    } // setIssueNote()

    /**
     * Set the value of [issue_type] column.
     *
     * @param  string $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setIssueType($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_type !== $v) {
            $this->issue_type = $v;
            $this->modifiedColumns[] = IssuePeer::ISSUE_TYPE;
        }


        return $this;
    } // setIssueType()

    /**
     * Sets the value of [issue_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Issue The current object (for fluent API support)
     */
    public function setIssueDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->issue_date !== null || $dt !== null) {
            $currentDateAsString = ($this->issue_date !== null && $tmpDt = new DateTime($this->issue_date)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->issue_date = $newDateAsString;
                $this->modifiedColumns[] = IssuePeer::ISSUE_DATE;
            }
        } // if either are not null


        return $this;
    } // setIssueDate()

    /**
     * Set the value of [manifestation_id] column.
     *
     * @param  int $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setManifestationId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->manifestation_id !== $v) {
            $this->manifestation_id = $v;
            $this->modifiedColumns[] = IssuePeer::MANIFESTATION_ID;
        }

        if ($this->aManifestation !== null && $this->aManifestation->getManifestationId() !== $v) {
            $this->aManifestation = null;
        }


        return $this;
    } // setManifestationId()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Issue The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            $currentDateAsString = ($this->date_created !== null && $tmpDt = new DateTime($this->date_created)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_created = $newDateAsString;
                $this->modifiedColumns[] = IssuePeer::DATE_CREATED;
            }
        } // if either are not null


        return $this;
    } // setDateCreated()

    /**
     * Sets the value of [date_updated] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Issue The current object (for fluent API support)
     */
    public function setDateUpdated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_updated !== null || $dt !== null) {
            $currentDateAsString = ($this->date_updated !== null && $tmpDt = new DateTime($this->date_updated)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_updated = $newDateAsString;
                $this->modifiedColumns[] = IssuePeer::DATE_UPDATED;
            }
        } // if either are not null


        return $this;
    } // setDateUpdated()

    /**
     * Set the value of [created_by] column.
     *
     * @param  int $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[] = IssuePeer::CREATED_BY;
        }

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->aLibrarianRelatedByCreatedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }


        return $this;
    } // setCreatedBy()

    /**
     * Set the value of [modified_by] column.
     *
     * @param  int $v new value
     * @return Issue The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[] = IssuePeer::MODIFIED_BY;
        }

        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->aLibrarianRelatedByModifiedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }


        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->issue_id = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->issue_number = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->start_number = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->end_number = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->issue_year = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->issue_volume = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->issue_note = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->issue_type = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->issue_date = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->manifestation_id = ($row[$startcol + 9] !== null) ? (int) $row[$startcol + 9] : null;
            $this->date_created = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->date_updated = ($row[$startcol + 11] !== null) ? (string) $row[$startcol + 11] : null;
            $this->created_by = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->modified_by = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 14; // 14 = IssuePeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating Issue object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aManifestation !== null && $this->manifestation_id !== $this->aManifestation->getManifestationId()) {
            $this->aManifestation = null;
        }
        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->created_by !== $this->aLibrarianRelatedByCreatedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }
        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->modified_by !== $this->aLibrarianRelatedByModifiedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(IssuePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = IssuePeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aLibrarianRelatedByCreatedBy = null;
            $this->aLibrarianRelatedByModifiedBy = null;
            $this->aManifestation = null;
            $this->collItems = null;

            $this->collItemRequests = null;

            $this->collLManifestations = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(IssuePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = IssueQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(IssuePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                if (!$this->isColumnModified(IssuePeer::DATE_CREATED)) {
                    $this->setDateCreated(time());
                }
                if (!$this->isColumnModified(IssuePeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                $librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 ;
                if (!$this->isColumnModified(IssuePeer::CREATED_BY)) {
                    $this->setCreatedBy($librarianId);
                }
                if (!$this->isColumnModified(IssuePeer::MODIFIED_BY)) {
                    $this->setModifiedBy($librarianId);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(IssuePeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                if ($this->isModified() && !$this->isColumnModified(IssuePeer::MODIFIED_BY)) {
                    $this->setModifiedBy((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 );
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                IssuePeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if ($this->aLibrarianRelatedByCreatedBy->isModified() || $this->aLibrarianRelatedByCreatedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByCreatedBy->save($con);
                }
                $this->setLibrarianRelatedByCreatedBy($this->aLibrarianRelatedByCreatedBy);
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if ($this->aLibrarianRelatedByModifiedBy->isModified() || $this->aLibrarianRelatedByModifiedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByModifiedBy->save($con);
                }
                $this->setLibrarianRelatedByModifiedBy($this->aLibrarianRelatedByModifiedBy);
            }

            if ($this->aManifestation !== null) {
                if ($this->aManifestation->isModified() || $this->aManifestation->isNew()) {
                    $affectedRows += $this->aManifestation->save($con);
                }
                $this->setManifestation($this->aManifestation);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->itemsScheduledForDeletion !== null) {
                if (!$this->itemsScheduledForDeletion->isEmpty()) {
                    foreach ($this->itemsScheduledForDeletion as $item) {
                        // need to save related object because we set the relation to null
                        $item->save($con);
                    }
                    $this->itemsScheduledForDeletion = null;
                }
            }

            if ($this->collItems !== null) {
                foreach ($this->collItems as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->itemRequestsScheduledForDeletion !== null) {
                if (!$this->itemRequestsScheduledForDeletion->isEmpty()) {
                    foreach ($this->itemRequestsScheduledForDeletion as $itemRequest) {
                        // need to save related object because we set the relation to null
                        $itemRequest->save($con);
                    }
                    $this->itemRequestsScheduledForDeletion = null;
                }
            }

            if ($this->collItemRequests !== null) {
                foreach ($this->collItemRequests as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lManifestationsScheduledForDeletion !== null) {
                if (!$this->lManifestationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->lManifestationsScheduledForDeletion as $lManifestation) {
                        // need to save related object because we set the relation to null
                        $lManifestation->save($con);
                    }
                    $this->lManifestationsScheduledForDeletion = null;
                }
            }

            if ($this->collLManifestations !== null) {
                foreach ($this->collLManifestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = IssuePeer::ISSUE_ID;
        if (null !== $this->issue_id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . IssuePeer::ISSUE_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(IssuePeer::ISSUE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`issue_id`';
        }
        if ($this->isColumnModified(IssuePeer::ISSUE_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`issue_number`';
        }
        if ($this->isColumnModified(IssuePeer::START_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`start_number`';
        }
        if ($this->isColumnModified(IssuePeer::END_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`end_number`';
        }
        if ($this->isColumnModified(IssuePeer::ISSUE_YEAR)) {
            $modifiedColumns[':p' . $index++]  = '`issue_year`';
        }
        if ($this->isColumnModified(IssuePeer::ISSUE_VOLUME)) {
            $modifiedColumns[':p' . $index++]  = '`issue_volume`';
        }
        if ($this->isColumnModified(IssuePeer::ISSUE_NOTE)) {
            $modifiedColumns[':p' . $index++]  = '`issue_note`';
        }
        if ($this->isColumnModified(IssuePeer::ISSUE_TYPE)) {
            $modifiedColumns[':p' . $index++]  = '`issue_type`';
        }
        if ($this->isColumnModified(IssuePeer::ISSUE_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`issue_date`';
        }
        if ($this->isColumnModified(IssuePeer::MANIFESTATION_ID)) {
            $modifiedColumns[':p' . $index++]  = '`manifestation_id`';
        }
        if ($this->isColumnModified(IssuePeer::DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_created`';
        }
        if ($this->isColumnModified(IssuePeer::DATE_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_updated`';
        }
        if ($this->isColumnModified(IssuePeer::CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`created_by`';
        }
        if ($this->isColumnModified(IssuePeer::MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`modified_by`';
        }

        $sql = sprintf(
            'INSERT INTO `issue` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`issue_id`':
                        $stmt->bindValue($identifier, $this->issue_id, PDO::PARAM_INT);
                        break;
                    case '`issue_number`':
                        $stmt->bindValue($identifier, $this->issue_number, PDO::PARAM_STR);
                        break;
                    case '`start_number`':
                        $stmt->bindValue($identifier, $this->start_number, PDO::PARAM_INT);
                        break;
                    case '`end_number`':
                        $stmt->bindValue($identifier, $this->end_number, PDO::PARAM_INT);
                        break;
                    case '`issue_year`':
                        $stmt->bindValue($identifier, $this->issue_year, PDO::PARAM_STR);
                        break;
                    case '`issue_volume`':
                        $stmt->bindValue($identifier, $this->issue_volume, PDO::PARAM_STR);
                        break;
                    case '`issue_note`':
                        $stmt->bindValue($identifier, $this->issue_note, PDO::PARAM_STR);
                        break;
                    case '`issue_type`':
                        $stmt->bindValue($identifier, $this->issue_type, PDO::PARAM_STR);
                        break;
                    case '`issue_date`':
                        $stmt->bindValue($identifier, $this->issue_date, PDO::PARAM_STR);
                        break;
                    case '`manifestation_id`':
                        $stmt->bindValue($identifier, $this->manifestation_id, PDO::PARAM_INT);
                        break;
                    case '`date_created`':
                        $stmt->bindValue($identifier, $this->date_created, PDO::PARAM_STR);
                        break;
                    case '`date_updated`':
                        $stmt->bindValue($identifier, $this->date_updated, PDO::PARAM_STR);
                        break;
                    case '`created_by`':
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_INT);
                        break;
                    case '`modified_by`':
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIssueId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if (!$this->aLibrarianRelatedByCreatedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByCreatedBy->getValidationFailures());
                }
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if (!$this->aLibrarianRelatedByModifiedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByModifiedBy->getValidationFailures());
                }
            }

            if ($this->aManifestation !== null) {
                if (!$this->aManifestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aManifestation->getValidationFailures());
                }
            }


            if (($retval = IssuePeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collItems !== null) {
                    foreach ($this->collItems as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collItemRequests !== null) {
                    foreach ($this->collItemRequests as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLManifestations !== null) {
                    foreach ($this->collLManifestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = IssuePeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getIssueId();
                break;
            case 1:
                return $this->getIssueNumber();
                break;
            case 2:
                return $this->getStartNumber();
                break;
            case 3:
                return $this->getEndNumber();
                break;
            case 4:
                return $this->getIssueYear();
                break;
            case 5:
                return $this->getIssueVolume();
                break;
            case 6:
                return $this->getIssueNote();
                break;
            case 7:
                return $this->getIssueType();
                break;
            case 8:
                return $this->getIssueDate();
                break;
            case 9:
                return $this->getManifestationId();
                break;
            case 10:
                return $this->getDateCreated();
                break;
            case 11:
                return $this->getDateUpdated();
                break;
            case 12:
                return $this->getCreatedBy();
                break;
            case 13:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['Issue'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['Issue'][$this->getPrimaryKey()] = true;
        $keys = IssuePeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getIssueId(),
            $keys[1] => $this->getIssueNumber(),
            $keys[2] => $this->getStartNumber(),
            $keys[3] => $this->getEndNumber(),
            $keys[4] => $this->getIssueYear(),
            $keys[5] => $this->getIssueVolume(),
            $keys[6] => $this->getIssueNote(),
            $keys[7] => $this->getIssueType(),
            $keys[8] => $this->getIssueDate(),
            $keys[9] => $this->getManifestationId(),
            $keys[10] => $this->getDateCreated(),
            $keys[11] => $this->getDateUpdated(),
            $keys[12] => $this->getCreatedBy(),
            $keys[13] => $this->getModifiedBy(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aLibrarianRelatedByCreatedBy) {
                $result['LibrarianRelatedByCreatedBy'] = $this->aLibrarianRelatedByCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrarianRelatedByModifiedBy) {
                $result['LibrarianRelatedByModifiedBy'] = $this->aLibrarianRelatedByModifiedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aManifestation) {
                $result['Manifestation'] = $this->aManifestation->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->collItems) {
                $result['Items'] = $this->collItems->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collItemRequests) {
                $result['ItemRequests'] = $this->collItemRequests->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLManifestations) {
                $result['LManifestations'] = $this->collLManifestations->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = IssuePeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setIssueId($value);
                break;
            case 1:
                $this->setIssueNumber($value);
                break;
            case 2:
                $this->setStartNumber($value);
                break;
            case 3:
                $this->setEndNumber($value);
                break;
            case 4:
                $this->setIssueYear($value);
                break;
            case 5:
                $this->setIssueVolume($value);
                break;
            case 6:
                $this->setIssueNote($value);
                break;
            case 7:
                $this->setIssueType($value);
                break;
            case 8:
                $this->setIssueDate($value);
                break;
            case 9:
                $this->setManifestationId($value);
                break;
            case 10:
                $this->setDateCreated($value);
                break;
            case 11:
                $this->setDateUpdated($value);
                break;
            case 12:
                $this->setCreatedBy($value);
                break;
            case 13:
                $this->setModifiedBy($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = IssuePeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setIssueId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setIssueNumber($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setStartNumber($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setEndNumber($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setIssueYear($arr[$keys[4]]);
        if (array_key_exists($keys[5], $arr)) $this->setIssueVolume($arr[$keys[5]]);
        if (array_key_exists($keys[6], $arr)) $this->setIssueNote($arr[$keys[6]]);
        if (array_key_exists($keys[7], $arr)) $this->setIssueType($arr[$keys[7]]);
        if (array_key_exists($keys[8], $arr)) $this->setIssueDate($arr[$keys[8]]);
        if (array_key_exists($keys[9], $arr)) $this->setManifestationId($arr[$keys[9]]);
        if (array_key_exists($keys[10], $arr)) $this->setDateCreated($arr[$keys[10]]);
        if (array_key_exists($keys[11], $arr)) $this->setDateUpdated($arr[$keys[11]]);
        if (array_key_exists($keys[12], $arr)) $this->setCreatedBy($arr[$keys[12]]);
        if (array_key_exists($keys[13], $arr)) $this->setModifiedBy($arr[$keys[13]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(IssuePeer::DATABASE_NAME);

        if ($this->isColumnModified(IssuePeer::ISSUE_ID)) $criteria->add(IssuePeer::ISSUE_ID, $this->issue_id);
        if ($this->isColumnModified(IssuePeer::ISSUE_NUMBER)) $criteria->add(IssuePeer::ISSUE_NUMBER, $this->issue_number);
        if ($this->isColumnModified(IssuePeer::START_NUMBER)) $criteria->add(IssuePeer::START_NUMBER, $this->start_number);
        if ($this->isColumnModified(IssuePeer::END_NUMBER)) $criteria->add(IssuePeer::END_NUMBER, $this->end_number);
        if ($this->isColumnModified(IssuePeer::ISSUE_YEAR)) $criteria->add(IssuePeer::ISSUE_YEAR, $this->issue_year);
        if ($this->isColumnModified(IssuePeer::ISSUE_VOLUME)) $criteria->add(IssuePeer::ISSUE_VOLUME, $this->issue_volume);
        if ($this->isColumnModified(IssuePeer::ISSUE_NOTE)) $criteria->add(IssuePeer::ISSUE_NOTE, $this->issue_note);
        if ($this->isColumnModified(IssuePeer::ISSUE_TYPE)) $criteria->add(IssuePeer::ISSUE_TYPE, $this->issue_type);
        if ($this->isColumnModified(IssuePeer::ISSUE_DATE)) $criteria->add(IssuePeer::ISSUE_DATE, $this->issue_date);
        if ($this->isColumnModified(IssuePeer::MANIFESTATION_ID)) $criteria->add(IssuePeer::MANIFESTATION_ID, $this->manifestation_id);
        if ($this->isColumnModified(IssuePeer::DATE_CREATED)) $criteria->add(IssuePeer::DATE_CREATED, $this->date_created);
        if ($this->isColumnModified(IssuePeer::DATE_UPDATED)) $criteria->add(IssuePeer::DATE_UPDATED, $this->date_updated);
        if ($this->isColumnModified(IssuePeer::CREATED_BY)) $criteria->add(IssuePeer::CREATED_BY, $this->created_by);
        if ($this->isColumnModified(IssuePeer::MODIFIED_BY)) $criteria->add(IssuePeer::MODIFIED_BY, $this->modified_by);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(IssuePeer::DATABASE_NAME);
        $criteria->add(IssuePeer::ISSUE_ID, $this->issue_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIssueId();
    }

    /**
     * Generic method to set the primary key (issue_id column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIssueId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIssueId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of Issue (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setIssueNumber($this->getIssueNumber());
        $copyObj->setStartNumber($this->getStartNumber());
        $copyObj->setEndNumber($this->getEndNumber());
        $copyObj->setIssueYear($this->getIssueYear());
        $copyObj->setIssueVolume($this->getIssueVolume());
        $copyObj->setIssueNote($this->getIssueNote());
        $copyObj->setIssueType($this->getIssueType());
        $copyObj->setIssueDate($this->getIssueDate());
        $copyObj->setManifestationId($this->getManifestationId());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setDateUpdated($this->getDateUpdated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setModifiedBy($this->getModifiedBy());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getItems() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addItem($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getItemRequests() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addItemRequest($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLManifestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLManifestation($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIssueId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return Issue Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return IssuePeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new IssuePeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Issue The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByCreatedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setCreatedBy(NULL);
        } else {
            $this->setCreatedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addIssueRelatedByCreatedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByCreatedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByCreatedBy === null && ($this->created_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByCreatedBy = LibrarianQuery::create()->findPk($this->created_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByCreatedBy->addIssuesRelatedByCreatedBy($this);
             */
        }

        return $this->aLibrarianRelatedByCreatedBy;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Issue The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByModifiedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setModifiedBy(NULL);
        } else {
            $this->setModifiedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByModifiedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addIssueRelatedByModifiedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByModifiedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByModifiedBy === null && ($this->modified_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByModifiedBy = LibrarianQuery::create()->findPk($this->modified_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByModifiedBy->addIssuesRelatedByModifiedBy($this);
             */
        }

        return $this->aLibrarianRelatedByModifiedBy;
    }

    /**
     * Declares an association between this object and a Manifestation object.
     *
     * @param                  Manifestation $v
     * @return Issue The current object (for fluent API support)
     * @throws PropelException
     */
    public function setManifestation(Manifestation $v = null)
    {
        if ($v === null) {
            $this->setManifestationId(NULL);
        } else {
            $this->setManifestationId($v->getManifestationId());
        }

        $this->aManifestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Manifestation object, it will not be re-added.
        if ($v !== null) {
            $v->addIssue($this);
        }


        return $this;
    }


    /**
     * Get the associated Manifestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Manifestation The associated Manifestation object.
     * @throws PropelException
     */
    public function getManifestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aManifestation === null && ($this->manifestation_id !== null) && $doQuery) {
            $this->aManifestation = ManifestationQuery::create()->findPk($this->manifestation_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aManifestation->addIssues($this);
             */
        }

        return $this->aManifestation;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('Item' == $relationName) {
            $this->initItems();
        }
        if ('ItemRequest' == $relationName) {
            $this->initItemRequests();
        }
        if ('LManifestation' == $relationName) {
            $this->initLManifestations();
        }
    }

    /**
     * Clears out the collItems collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Issue The current object (for fluent API support)
     * @see        addItems()
     */
    public function clearItems()
    {
        $this->collItems = null; // important to set this to null since that means it is uninitialized
        $this->collItemsPartial = null;

        return $this;
    }

    /**
     * reset is the collItems collection loaded partially
     *
     * @return void
     */
    public function resetPartialItems($v = true)
    {
        $this->collItemsPartial = $v;
    }

    /**
     * Initializes the collItems collection.
     *
     * By default this just sets the collItems collection to an empty array (like clearcollItems());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initItems($overrideExisting = true)
    {
        if (null !== $this->collItems && !$overrideExisting) {
            return;
        }
        $this->collItems = new PropelObjectCollection();
        $this->collItems->setModel('Item');
    }

    /**
     * Gets an array of Item objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Issue is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|Item[] List of Item objects
     * @throws PropelException
     */
    public function getItems($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collItemsPartial && !$this->isNew();
        if (null === $this->collItems || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collItems) {
                // return empty collection
                $this->initItems();
            } else {
                $collItems = ItemQuery::create(null, $criteria)
                    ->filterByIssue($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collItemsPartial && count($collItems)) {
                      $this->initItems(false);

                      foreach ($collItems as $obj) {
                        if (false == $this->collItems->contains($obj)) {
                          $this->collItems->append($obj);
                        }
                      }

                      $this->collItemsPartial = true;
                    }

                    $collItems->getInternalIterator()->rewind();

                    return $collItems;
                }

                if ($partial && $this->collItems) {
                    foreach ($this->collItems as $obj) {
                        if ($obj->isNew()) {
                            $collItems[] = $obj;
                        }
                    }
                }

                $this->collItems = $collItems;
                $this->collItemsPartial = false;
            }
        }

        return $this->collItems;
    }

    /**
     * Sets a collection of Item objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $items A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Issue The current object (for fluent API support)
     */
    public function setItems(PropelCollection $items, PropelPDO $con = null)
    {
        $itemsToDelete = $this->getItems(new Criteria(), $con)->diff($items);


        $this->itemsScheduledForDeletion = $itemsToDelete;

        foreach ($itemsToDelete as $itemRemoved) {
            $itemRemoved->setIssue(null);
        }

        $this->collItems = null;
        foreach ($items as $item) {
            $this->addItem($item);
        }

        $this->collItems = $items;
        $this->collItemsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Item objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related Item objects.
     * @throws PropelException
     */
    public function countItems(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collItemsPartial && !$this->isNew();
        if (null === $this->collItems || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collItems) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getItems());
            }
            $query = ItemQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByIssue($this)
                ->count($con);
        }

        return count($this->collItems);
    }

    /**
     * Method called to associate a Item object to this object
     * through the Item foreign key attribute.
     *
     * @param    Item $l Item
     * @return Issue The current object (for fluent API support)
     */
    public function addItem(Item $l)
    {
        if ($this->collItems === null) {
            $this->initItems();
            $this->collItemsPartial = true;
        }

        if (!in_array($l, $this->collItems->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddItem($l);

            if ($this->itemsScheduledForDeletion and $this->itemsScheduledForDeletion->contains($l)) {
                $this->itemsScheduledForDeletion->remove($this->itemsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	Item $item The item object to add.
     */
    protected function doAddItem($item)
    {
        $this->collItems[]= $item;
        $item->setIssue($this);
    }

    /**
     * @param	Item $item The item object to remove.
     * @return Issue The current object (for fluent API support)
     */
    public function removeItem($item)
    {
        if ($this->getItems()->contains($item)) {
            $this->collItems->remove($this->collItems->search($item));
            if (null === $this->itemsScheduledForDeletion) {
                $this->itemsScheduledForDeletion = clone $this->collItems;
                $this->itemsScheduledForDeletion->clear();
            }
            $this->itemsScheduledForDeletion[]= $item;
            $item->setIssue(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinManifestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Manifestation', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinConsistencyNote($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('ConsistencyNote', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByOwnerLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByOwnerLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByHomeLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByHomeLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByDeliveryLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByDeliveryLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByActualLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByActualLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinInventorySerie($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('InventorySerie', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinPurchaseOrder($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('PurchaseOrder', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinInvoice($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Invoice', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinSupplier($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Supplier', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinPatron($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Patron', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByExternalLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByExternalLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLoanRelatedByCurrentLoanId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LoanRelatedByCurrentLoanId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinBudget($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Budget', $join_behavior);

        return $this->getItems($query, $con);
    }

    /**
     * Clears out the collItemRequests collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Issue The current object (for fluent API support)
     * @see        addItemRequests()
     */
    public function clearItemRequests()
    {
        $this->collItemRequests = null; // important to set this to null since that means it is uninitialized
        $this->collItemRequestsPartial = null;

        return $this;
    }

    /**
     * reset is the collItemRequests collection loaded partially
     *
     * @return void
     */
    public function resetPartialItemRequests($v = true)
    {
        $this->collItemRequestsPartial = $v;
    }

    /**
     * Initializes the collItemRequests collection.
     *
     * By default this just sets the collItemRequests collection to an empty array (like clearcollItemRequests());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initItemRequests($overrideExisting = true)
    {
        if (null !== $this->collItemRequests && !$overrideExisting) {
            return;
        }
        $this->collItemRequests = new PropelObjectCollection();
        $this->collItemRequests->setModel('ItemRequest');
    }

    /**
     * Gets an array of ItemRequest objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Issue is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     * @throws PropelException
     */
    public function getItemRequests($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collItemRequestsPartial && !$this->isNew();
        if (null === $this->collItemRequests || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collItemRequests) {
                // return empty collection
                $this->initItemRequests();
            } else {
                $collItemRequests = ItemRequestQuery::create(null, $criteria)
                    ->filterByIssue($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collItemRequestsPartial && count($collItemRequests)) {
                      $this->initItemRequests(false);

                      foreach ($collItemRequests as $obj) {
                        if (false == $this->collItemRequests->contains($obj)) {
                          $this->collItemRequests->append($obj);
                        }
                      }

                      $this->collItemRequestsPartial = true;
                    }

                    $collItemRequests->getInternalIterator()->rewind();

                    return $collItemRequests;
                }

                if ($partial && $this->collItemRequests) {
                    foreach ($this->collItemRequests as $obj) {
                        if ($obj->isNew()) {
                            $collItemRequests[] = $obj;
                        }
                    }
                }

                $this->collItemRequests = $collItemRequests;
                $this->collItemRequestsPartial = false;
            }
        }

        return $this->collItemRequests;
    }

    /**
     * Sets a collection of ItemRequest objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $itemRequests A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Issue The current object (for fluent API support)
     */
    public function setItemRequests(PropelCollection $itemRequests, PropelPDO $con = null)
    {
        $itemRequestsToDelete = $this->getItemRequests(new Criteria(), $con)->diff($itemRequests);


        $this->itemRequestsScheduledForDeletion = $itemRequestsToDelete;

        foreach ($itemRequestsToDelete as $itemRequestRemoved) {
            $itemRequestRemoved->setIssue(null);
        }

        $this->collItemRequests = null;
        foreach ($itemRequests as $itemRequest) {
            $this->addItemRequest($itemRequest);
        }

        $this->collItemRequests = $itemRequests;
        $this->collItemRequestsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related ItemRequest objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related ItemRequest objects.
     * @throws PropelException
     */
    public function countItemRequests(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collItemRequestsPartial && !$this->isNew();
        if (null === $this->collItemRequests || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collItemRequests) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getItemRequests());
            }
            $query = ItemRequestQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByIssue($this)
                ->count($con);
        }

        return count($this->collItemRequests);
    }

    /**
     * Method called to associate a ItemRequest object to this object
     * through the ItemRequest foreign key attribute.
     *
     * @param    ItemRequest $l ItemRequest
     * @return Issue The current object (for fluent API support)
     */
    public function addItemRequest(ItemRequest $l)
    {
        if ($this->collItemRequests === null) {
            $this->initItemRequests();
            $this->collItemRequestsPartial = true;
        }

        if (!in_array($l, $this->collItemRequests->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddItemRequest($l);

            if ($this->itemRequestsScheduledForDeletion and $this->itemRequestsScheduledForDeletion->contains($l)) {
                $this->itemRequestsScheduledForDeletion->remove($this->itemRequestsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	ItemRequest $itemRequest The itemRequest object to add.
     */
    protected function doAddItemRequest($itemRequest)
    {
        $this->collItemRequests[]= $itemRequest;
        $itemRequest->setIssue($this);
    }

    /**
     * @param	ItemRequest $itemRequest The itemRequest object to remove.
     * @return Issue The current object (for fluent API support)
     */
    public function removeItemRequest($itemRequest)
    {
        if ($this->getItemRequests()->contains($itemRequest)) {
            $this->collItemRequests->remove($this->collItemRequests->search($itemRequest));
            if (null === $this->itemRequestsScheduledForDeletion) {
                $this->itemRequestsScheduledForDeletion = clone $this->collItemRequests;
                $this->itemRequestsScheduledForDeletion->clear();
            }
            $this->itemRequestsScheduledForDeletion[]= $itemRequest;
            $itemRequest->setIssue(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibrarianRelatedByLibrarianId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByLibrarianId', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinPatron($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('Patron', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibraryRelatedByExternalLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByExternalLibraryId', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinManifestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('Manifestation', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinItem($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('Item', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibraryRelatedByDeliveryLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByDeliveryLibraryId', $join_behavior);

        return $this->getItemRequests($query, $con);
    }

    /**
     * Clears out the collLManifestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Issue The current object (for fluent API support)
     * @see        addLManifestations()
     */
    public function clearLManifestations()
    {
        $this->collLManifestations = null; // important to set this to null since that means it is uninitialized
        $this->collLManifestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collLManifestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialLManifestations($v = true)
    {
        $this->collLManifestationsPartial = $v;
    }

    /**
     * Initializes the collLManifestations collection.
     *
     * By default this just sets the collLManifestations collection to an empty array (like clearcollLManifestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLManifestations($overrideExisting = true)
    {
        if (null !== $this->collLManifestations && !$overrideExisting) {
            return;
        }
        $this->collLManifestations = new PropelObjectCollection();
        $this->collLManifestations->setModel('LManifestation');
    }

    /**
     * Gets an array of LManifestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Issue is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LManifestation[] List of LManifestation objects
     * @throws PropelException
     */
    public function getLManifestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLManifestationsPartial && !$this->isNew();
        if (null === $this->collLManifestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLManifestations) {
                // return empty collection
                $this->initLManifestations();
            } else {
                $collLManifestations = LManifestationQuery::create(null, $criteria)
                    ->filterByIssue($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLManifestationsPartial && count($collLManifestations)) {
                      $this->initLManifestations(false);

                      foreach ($collLManifestations as $obj) {
                        if (false == $this->collLManifestations->contains($obj)) {
                          $this->collLManifestations->append($obj);
                        }
                      }

                      $this->collLManifestationsPartial = true;
                    }

                    $collLManifestations->getInternalIterator()->rewind();

                    return $collLManifestations;
                }

                if ($partial && $this->collLManifestations) {
                    foreach ($this->collLManifestations as $obj) {
                        if ($obj->isNew()) {
                            $collLManifestations[] = $obj;
                        }
                    }
                }

                $this->collLManifestations = $collLManifestations;
                $this->collLManifestationsPartial = false;
            }
        }

        return $this->collLManifestations;
    }

    /**
     * Sets a collection of LManifestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lManifestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Issue The current object (for fluent API support)
     */
    public function setLManifestations(PropelCollection $lManifestations, PropelPDO $con = null)
    {
        $lManifestationsToDelete = $this->getLManifestations(new Criteria(), $con)->diff($lManifestations);


        $this->lManifestationsScheduledForDeletion = $lManifestationsToDelete;

        foreach ($lManifestationsToDelete as $lManifestationRemoved) {
            $lManifestationRemoved->setIssue(null);
        }

        $this->collLManifestations = null;
        foreach ($lManifestations as $lManifestation) {
            $this->addLManifestation($lManifestation);
        }

        $this->collLManifestations = $lManifestations;
        $this->collLManifestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LManifestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LManifestation objects.
     * @throws PropelException
     */
    public function countLManifestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLManifestationsPartial && !$this->isNew();
        if (null === $this->collLManifestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLManifestations) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLManifestations());
            }
            $query = LManifestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByIssue($this)
                ->count($con);
        }

        return count($this->collLManifestations);
    }

    /**
     * Method called to associate a LManifestation object to this object
     * through the LManifestation foreign key attribute.
     *
     * @param    LManifestation $l LManifestation
     * @return Issue The current object (for fluent API support)
     */
    public function addLManifestation(LManifestation $l)
    {
        if ($this->collLManifestations === null) {
            $this->initLManifestations();
            $this->collLManifestationsPartial = true;
        }

        if (!in_array($l, $this->collLManifestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLManifestation($l);

            if ($this->lManifestationsScheduledForDeletion and $this->lManifestationsScheduledForDeletion->contains($l)) {
                $this->lManifestationsScheduledForDeletion->remove($this->lManifestationsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LManifestation $lManifestation The lManifestation object to add.
     */
    protected function doAddLManifestation($lManifestation)
    {
        $this->collLManifestations[]= $lManifestation;
        $lManifestation->setIssue($this);
    }

    /**
     * @param	LManifestation $lManifestation The lManifestation object to remove.
     * @return Issue The current object (for fluent API support)
     */
    public function removeLManifestation($lManifestation)
    {
        if ($this->getLManifestations()->contains($lManifestation)) {
            $this->collLManifestations->remove($this->collLManifestations->search($lManifestation));
            if (null === $this->lManifestationsScheduledForDeletion) {
                $this->lManifestationsScheduledForDeletion = clone $this->collLManifestations;
                $this->lManifestationsScheduledForDeletion->clear();
            }
            $this->lManifestationsScheduledForDeletion[]= $lManifestation;
            $lManifestation->setIssue(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related LManifestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|LManifestation[] List of LManifestation objects
     */
    public function getLManifestationsJoinManifestationRelatedByManifestationIdUp($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LManifestationQuery::create(null, $criteria);
        $query->joinWith('ManifestationRelatedByManifestationIdUp', $join_behavior);

        return $this->getLManifestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Issue is new, it will return
     * an empty collection; or if this Issue has previously
     * been saved, it will retrieve related LManifestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Issue.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|LManifestation[] List of LManifestation objects
     */
    public function getLManifestationsJoinManifestationRelatedByManifestationIdDown($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LManifestationQuery::create(null, $criteria);
        $query->joinWith('ManifestationRelatedByManifestationIdDown', $join_behavior);

        return $this->getLManifestations($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->issue_id = null;
        $this->issue_number = null;
        $this->start_number = null;
        $this->end_number = null;
        $this->issue_year = null;
        $this->issue_volume = null;
        $this->issue_note = null;
        $this->issue_type = null;
        $this->issue_date = null;
        $this->manifestation_id = null;
        $this->date_created = null;
        $this->date_updated = null;
        $this->created_by = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collItems) {
                foreach ($this->collItems as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collItemRequests) {
                foreach ($this->collItemRequests as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLManifestations) {
                foreach ($this->collLManifestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aLibrarianRelatedByCreatedBy instanceof Persistent) {
              $this->aLibrarianRelatedByCreatedBy->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByModifiedBy instanceof Persistent) {
              $this->aLibrarianRelatedByModifiedBy->clearAllReferences($deep);
            }
            if ($this->aManifestation instanceof Persistent) {
              $this->aManifestation->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collItems instanceof PropelCollection) {
            $this->collItems->clearIterator();
        }
        $this->collItems = null;
        if ($this->collItemRequests instanceof PropelCollection) {
            $this->collItemRequests->clearIterator();
        }
        $this->collItemRequests = null;
        if ($this->collLManifestations instanceof PropelCollection) {
            $this->collLManifestations->clearIterator();
        }
        $this->collLManifestations = null;
        $this->aLibrarianRelatedByCreatedBy = null;
        $this->aLibrarianRelatedByModifiedBy = null;
        $this->aManifestation = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(IssuePeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Issue The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[] = IssuePeer::DATE_UPDATED;

        return $this;
    }

    // librariantrace behavior

    /**
     * Returns the complete name of the librarian that created this object.
     *
     * @return string
     */
    public function getCreatedByNameString()
    {
        $l = $this->getLibrarianRelatedByCreatedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Returns the complete name of the librarian that last updated this object.
     *
     * @return string
     */
    public function getModifiedByNameString()
    {
        $l = $this->getLibrarianRelatedByModifiedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Issue The current object (for fluent API support)
     */
    public function keepUpdateLibrarianUnchanged()
    {
        $this->modifiedColumns[] = IssuePeer::MODIFIED_BY;
        return $this;
    }

}
