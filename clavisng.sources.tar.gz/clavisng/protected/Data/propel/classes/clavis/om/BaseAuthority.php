<?php


/**
 * Base class that represents a row from the 'authority' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseAuthority extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'AuthorityPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        AuthorityPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the authority_id field.
     * @var        int
     */
    protected $authority_id;

    /**
     * The value for the non_sort_text field.
     * @var        string
     */
    protected $non_sort_text;

    /**
     * The value for the sort_text field.
     * @var        string
     */
    protected $sort_text;

    /**
     * The value for the full_text field.
     * @var        string
     */
    protected $full_text;

    /**
     * The value for the authority_type field.
     * @var        string
     */
    protected $authority_type;

    /**
     * The value for the authority_subtype field.
     * @var        string
     */
    protected $authority_subtype;

    /**
     * The value for the authority_rectype field.
     * @var        string
     */
    protected $authority_rectype;

    /**
     * The value for the authority_status field.
     * @var        string
     */
    protected $authority_status;

    /**
     * The value for the unimarc field.
     * @var        string
     */
    protected $unimarc;

    /**
     * The value for the ext_data field.
     * @var        string
     */
    protected $ext_data;

    /**
     * The value for the authority_lang field.
     * @var        string
     */
    protected $authority_lang;

    /**
     * The value for the authority_codlevel field.
     * @var        string
     */
    protected $authority_codlevel;

    /**
     * The value for the parent_id field.
     * @var        int
     */
    protected $parent_id;

    /**
     * The value for the subject_class field.
     * @var        string
     */
    protected $subject_class;

    /**
     * The value for the class_code field.
     * @var        string
     */
    protected $class_code;

    /**
     * The value for the bid_source field.
     * @var        string
     */
    protected $bid_source;

    /**
     * The value for the bid field.
     * @var        string
     */
    protected $bid;

    /**
     * The value for the last_sbn_sync field.
     * @var        string
     */
    protected $last_sbn_sync;

    /**
     * The value for the date_created field.
     * @var        string
     */
    protected $date_created;

    /**
     * The value for the date_updated field.
     * @var        string
     */
    protected $date_updated;

    /**
     * The value for the created_by field.
     * @var        int
     */
    protected $created_by;

    /**
     * The value for the modified_by field.
     * @var        int
     */
    protected $modified_by;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByCreatedBy;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByModifiedBy;

    /**
     * @var        Authority
     */
    protected $aAuthorityRelatedByParentId;

    /**
     * @var        PropelObjectCollection|Authority[] Collection to store aggregation of Authority objects.
     */
    protected $collAuthoritysRelatedByAuthorityId;
    protected $collAuthoritysRelatedByAuthorityIdPartial;

    /**
     * @var        PropelObjectCollection|LAuthority[] Collection to store aggregation of LAuthority objects.
     */
    protected $collLAuthoritysRelatedByAuthorityIdDown;
    protected $collLAuthoritysRelatedByAuthorityIdDownPartial;

    /**
     * @var        PropelObjectCollection|LAuthority[] Collection to store aggregation of LAuthority objects.
     */
    protected $collLAuthoritysRelatedByAuthorityIdUp;
    protected $collLAuthoritysRelatedByAuthorityIdUpPartial;

    /**
     * @var        PropelObjectCollection|LAuthorityItem[] Collection to store aggregation of LAuthorityItem objects.
     */
    protected $collLAuthorityItems;
    protected $collLAuthorityItemsPartial;

    /**
     * @var        PropelObjectCollection|LAuthorityManifestation[] Collection to store aggregation of LAuthorityManifestation objects.
     */
    protected $collLAuthorityManifestations;
    protected $collLAuthorityManifestationsPartial;

    /**
     * @var        PropelObjectCollection|LSubject[] Collection to store aggregation of LSubject objects.
     */
    protected $collLSubjectsRelatedByAuthorityId;
    protected $collLSubjectsRelatedByAuthorityIdPartial;

    /**
     * @var        PropelObjectCollection|LSubject[] Collection to store aggregation of LSubject objects.
     */
    protected $collLSubjectsRelatedBySubjectId;
    protected $collLSubjectsRelatedBySubjectIdPartial;

    /**
     * @var        TurbomarcauthorityCache one-to-one related TurbomarcauthorityCache object
     */
    protected $singleTurbomarcauthorityCache;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $authoritysRelatedByAuthorityIdScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lAuthorityItemsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lAuthorityManifestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lSubjectsRelatedByAuthorityIdScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lSubjectsRelatedBySubjectIdScheduledForDeletion = null;

    /**
     * Get the [authority_id] column value.
     *
     * @return int
     */
    public function getAuthorityId()
    {

        return $this->authority_id;
    }

    /**
     * Get the [non_sort_text] column value.
     *
     * @return string
     */
    public function getNonSortText()
    {

        return $this->non_sort_text;
    }

    /**
     * Get the [sort_text] column value.
     *
     * @return string
     */
    public function getSortText()
    {

        return $this->sort_text;
    }

    /**
     * Get the [full_text] column value.
     *
     * @return string
     */
    public function getFullText()
    {

        return $this->full_text;
    }

    /**
     * Get the [authority_type] column value.
     *
     * @return string
     */
    public function getAuthorityType()
    {

        return $this->authority_type;
    }

    /**
     * Get the [authority_subtype] column value.
     *
     * @return string
     */
    public function getAuthoritySubtype()
    {

        return $this->authority_subtype;
    }

    /**
     * Get the [authority_rectype] column value.
     *
     * @return string
     */
    public function getAuthorityRectype()
    {

        return $this->authority_rectype;
    }

    /**
     * Get the [authority_status] column value.
     *
     * @return string
     */
    public function getAuthorityStatus()
    {

        return $this->authority_status;
    }

    /**
     * Get the [unimarc] column value.
     *
     * @return string
     */
    public function getUnimarc()
    {

        return $this->unimarc;
    }

    /**
     * Get the [ext_data] column value.
     *
     * @return string
     */
    public function getExtData()
    {

        return $this->ext_data;
    }

    /**
     * Get the [authority_lang] column value.
     *
     * @return string
     */
    public function getAuthorityLang()
    {

        return $this->authority_lang;
    }

    /**
     * Get the [authority_codlevel] column value.
     *
     * @return string
     */
    public function getAuthorityCodlevel()
    {

        return $this->authority_codlevel;
    }

    /**
     * Get the [parent_id] column value.
     *
     * @return int
     */
    public function getParentId()
    {

        return $this->parent_id;
    }

    /**
     * Get the [subject_class] column value.
     *
     * @return string
     */
    public function getSubjectClass()
    {

        return $this->subject_class;
    }

    /**
     * Get the [class_code] column value.
     *
     * @return string
     */
    public function getClassCode()
    {

        return $this->class_code;
    }

    /**
     * Get the [bid_source] column value.
     *
     * @return string
     */
    public function getBidSource()
    {

        return $this->bid_source;
    }

    /**
     * Get the [bid] column value.
     *
     * @return string
     */
    public function getBid()
    {

        return $this->bid;
    }

    /**
     * Get the [optionally formatted] temporal [last_sbn_sync] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getLastSbnSync($format = 'Y-m-d H:i:s')
    {
        if ($this->last_sbn_sync === null) {
            return null;
        }

        if ($this->last_sbn_sync === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->last_sbn_sync);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->last_sbn_sync, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_created === null) {
            return null;
        }

        if ($this->date_created === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_created);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_created, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_updated] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateUpdated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_updated === null) {
            return null;
        }

        if ($this->date_updated === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_updated);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_updated, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [created_by] column value.
     *
     * @return int
     */
    public function getCreatedBy()
    {

        return $this->created_by;
    }

    /**
     * Get the [modified_by] column value.
     *
     * @return int
     */
    public function getModifiedBy()
    {

        return $this->modified_by;
    }

    /**
     * Set the value of [authority_id] column.
     *
     * @param  int $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthorityId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->authority_id !== $v) {
            $this->authority_id = $v;
            $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_ID;
        }


        return $this;
    } // setAuthorityId()

    /**
     * Set the value of [non_sort_text] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setNonSortText($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->non_sort_text !== $v) {
            $this->non_sort_text = $v;
            $this->modifiedColumns[] = AuthorityPeer::NON_SORT_TEXT;
        }


        return $this;
    } // setNonSortText()

    /**
     * Set the value of [sort_text] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setSortText($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->sort_text !== $v) {
            $this->sort_text = $v;
            $this->modifiedColumns[] = AuthorityPeer::SORT_TEXT;
        }


        return $this;
    } // setSortText()

    /**
     * Set the value of [full_text] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setFullText($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->full_text !== $v) {
            $this->full_text = $v;
            $this->modifiedColumns[] = AuthorityPeer::FULL_TEXT;
        }


        return $this;
    } // setFullText()

    /**
     * Set the value of [authority_type] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthorityType($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->authority_type !== $v) {
            $this->authority_type = $v;
            $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_TYPE;
        }


        return $this;
    } // setAuthorityType()

    /**
     * Set the value of [authority_subtype] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthoritySubtype($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->authority_subtype !== $v) {
            $this->authority_subtype = $v;
            $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_SUBTYPE;
        }


        return $this;
    } // setAuthoritySubtype()

    /**
     * Set the value of [authority_rectype] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthorityRectype($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->authority_rectype !== $v) {
            $this->authority_rectype = $v;
            $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_RECTYPE;
        }


        return $this;
    } // setAuthorityRectype()

    /**
     * Set the value of [authority_status] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthorityStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->authority_status !== $v) {
            $this->authority_status = $v;
            $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_STATUS;
        }


        return $this;
    } // setAuthorityStatus()

    /**
     * Set the value of [unimarc] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setUnimarc($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->unimarc !== $v) {
            $this->unimarc = $v;
            $this->modifiedColumns[] = AuthorityPeer::UNIMARC;
        }


        return $this;
    } // setUnimarc()

    /**
     * Set the value of [ext_data] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setExtData($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->ext_data !== $v) {
            $this->ext_data = $v;
            $this->modifiedColumns[] = AuthorityPeer::EXT_DATA;
        }


        return $this;
    } // setExtData()

    /**
     * Set the value of [authority_lang] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthorityLang($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->authority_lang !== $v) {
            $this->authority_lang = $v;
            $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_LANG;
        }


        return $this;
    } // setAuthorityLang()

    /**
     * Set the value of [authority_codlevel] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthorityCodlevel($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->authority_codlevel !== $v) {
            $this->authority_codlevel = $v;
            $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_CODLEVEL;
        }


        return $this;
    } // setAuthorityCodlevel()

    /**
     * Set the value of [parent_id] column.
     *
     * @param  int $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setParentId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->parent_id !== $v) {
            $this->parent_id = $v;
            $this->modifiedColumns[] = AuthorityPeer::PARENT_ID;
        }

        if ($this->aAuthorityRelatedByParentId !== null && $this->aAuthorityRelatedByParentId->getAuthorityId() !== $v) {
            $this->aAuthorityRelatedByParentId = null;
        }


        return $this;
    } // setParentId()

    /**
     * Set the value of [subject_class] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setSubjectClass($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->subject_class !== $v) {
            $this->subject_class = $v;
            $this->modifiedColumns[] = AuthorityPeer::SUBJECT_CLASS;
        }


        return $this;
    } // setSubjectClass()

    /**
     * Set the value of [class_code] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setClassCode($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->class_code !== $v) {
            $this->class_code = $v;
            $this->modifiedColumns[] = AuthorityPeer::CLASS_CODE;
        }


        return $this;
    } // setClassCode()

    /**
     * Set the value of [bid_source] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setBidSource($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->bid_source !== $v) {
            $this->bid_source = $v;
            $this->modifiedColumns[] = AuthorityPeer::BID_SOURCE;
        }


        return $this;
    } // setBidSource()

    /**
     * Set the value of [bid] column.
     *
     * @param  string $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setBid($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->bid !== $v) {
            $this->bid = $v;
            $this->modifiedColumns[] = AuthorityPeer::BID;
        }


        return $this;
    } // setBid()

    /**
     * Sets the value of [last_sbn_sync] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Authority The current object (for fluent API support)
     */
    public function setLastSbnSync($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->last_sbn_sync !== null || $dt !== null) {
            $currentDateAsString = ($this->last_sbn_sync !== null && $tmpDt = new DateTime($this->last_sbn_sync)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->last_sbn_sync = $newDateAsString;
                $this->modifiedColumns[] = AuthorityPeer::LAST_SBN_SYNC;
            }
        } // if either are not null


        return $this;
    } // setLastSbnSync()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Authority The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            $currentDateAsString = ($this->date_created !== null && $tmpDt = new DateTime($this->date_created)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_created = $newDateAsString;
                $this->modifiedColumns[] = AuthorityPeer::DATE_CREATED;
            }
        } // if either are not null


        return $this;
    } // setDateCreated()

    /**
     * Sets the value of [date_updated] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Authority The current object (for fluent API support)
     */
    public function setDateUpdated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_updated !== null || $dt !== null) {
            $currentDateAsString = ($this->date_updated !== null && $tmpDt = new DateTime($this->date_updated)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_updated = $newDateAsString;
                $this->modifiedColumns[] = AuthorityPeer::DATE_UPDATED;
            }
        } // if either are not null


        return $this;
    } // setDateUpdated()

    /**
     * Set the value of [created_by] column.
     *
     * @param  int $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[] = AuthorityPeer::CREATED_BY;
        }

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->aLibrarianRelatedByCreatedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }


        return $this;
    } // setCreatedBy()

    /**
     * Set the value of [modified_by] column.
     *
     * @param  int $v new value
     * @return Authority The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[] = AuthorityPeer::MODIFIED_BY;
        }

        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->aLibrarianRelatedByModifiedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }


        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->authority_id = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->non_sort_text = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->sort_text = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->full_text = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->authority_type = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->authority_subtype = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->authority_rectype = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->authority_status = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->unimarc = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->ext_data = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->authority_lang = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->authority_codlevel = ($row[$startcol + 11] !== null) ? (string) $row[$startcol + 11] : null;
            $this->parent_id = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->subject_class = ($row[$startcol + 13] !== null) ? (string) $row[$startcol + 13] : null;
            $this->class_code = ($row[$startcol + 14] !== null) ? (string) $row[$startcol + 14] : null;
            $this->bid_source = ($row[$startcol + 15] !== null) ? (string) $row[$startcol + 15] : null;
            $this->bid = ($row[$startcol + 16] !== null) ? (string) $row[$startcol + 16] : null;
            $this->last_sbn_sync = ($row[$startcol + 17] !== null) ? (string) $row[$startcol + 17] : null;
            $this->date_created = ($row[$startcol + 18] !== null) ? (string) $row[$startcol + 18] : null;
            $this->date_updated = ($row[$startcol + 19] !== null) ? (string) $row[$startcol + 19] : null;
            $this->created_by = ($row[$startcol + 20] !== null) ? (int) $row[$startcol + 20] : null;
            $this->modified_by = ($row[$startcol + 21] !== null) ? (int) $row[$startcol + 21] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 22; // 22 = AuthorityPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating Authority object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aAuthorityRelatedByParentId !== null && $this->parent_id !== $this->aAuthorityRelatedByParentId->getAuthorityId()) {
            $this->aAuthorityRelatedByParentId = null;
        }
        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->created_by !== $this->aLibrarianRelatedByCreatedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }
        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->modified_by !== $this->aLibrarianRelatedByModifiedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = AuthorityPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aLibrarianRelatedByCreatedBy = null;
            $this->aLibrarianRelatedByModifiedBy = null;
            $this->aAuthorityRelatedByParentId = null;
            $this->collAuthoritysRelatedByAuthorityId = null;

            $this->collLAuthoritysRelatedByAuthorityIdDown = null;

            $this->collLAuthoritysRelatedByAuthorityIdUp = null;

            $this->collLAuthorityItems = null;

            $this->collLAuthorityManifestations = null;

            $this->collLSubjectsRelatedByAuthorityId = null;

            $this->collLSubjectsRelatedBySubjectId = null;

            $this->singleTurbomarcauthorityCache = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = AuthorityQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                if (!$this->isColumnModified(AuthorityPeer::DATE_CREATED)) {
                    $this->setDateCreated(time());
                }
                if (!$this->isColumnModified(AuthorityPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                $librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 ;
                if (!$this->isColumnModified(AuthorityPeer::CREATED_BY)) {
                    $this->setCreatedBy($librarianId);
                }
                if (!$this->isColumnModified(AuthorityPeer::MODIFIED_BY)) {
                    $this->setModifiedBy($librarianId);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(AuthorityPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                if ($this->isModified() && !$this->isColumnModified(AuthorityPeer::MODIFIED_BY)) {
                    $this->setModifiedBy((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 );
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                AuthorityPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if ($this->aLibrarianRelatedByCreatedBy->isModified() || $this->aLibrarianRelatedByCreatedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByCreatedBy->save($con);
                }
                $this->setLibrarianRelatedByCreatedBy($this->aLibrarianRelatedByCreatedBy);
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if ($this->aLibrarianRelatedByModifiedBy->isModified() || $this->aLibrarianRelatedByModifiedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByModifiedBy->save($con);
                }
                $this->setLibrarianRelatedByModifiedBy($this->aLibrarianRelatedByModifiedBy);
            }

            if ($this->aAuthorityRelatedByParentId !== null) {
                if ($this->aAuthorityRelatedByParentId->isModified() || $this->aAuthorityRelatedByParentId->isNew()) {
                    $affectedRows += $this->aAuthorityRelatedByParentId->save($con);
                }
                $this->setAuthorityRelatedByParentId($this->aAuthorityRelatedByParentId);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->authoritysRelatedByAuthorityIdScheduledForDeletion !== null) {
                if (!$this->authoritysRelatedByAuthorityIdScheduledForDeletion->isEmpty()) {
                    foreach ($this->authoritysRelatedByAuthorityIdScheduledForDeletion as $authorityRelatedByAuthorityId) {
                        // need to save related object because we set the relation to null
                        $authorityRelatedByAuthorityId->save($con);
                    }
                    $this->authoritysRelatedByAuthorityIdScheduledForDeletion = null;
                }
            }

            if ($this->collAuthoritysRelatedByAuthorityId !== null) {
                foreach ($this->collAuthoritysRelatedByAuthorityId as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion !== null) {
                if (!$this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion->isEmpty()) {
                    LAuthorityQuery::create()
                        ->filterByPrimaryKeys($this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion = null;
                }
            }

            if ($this->collLAuthoritysRelatedByAuthorityIdDown !== null) {
                foreach ($this->collLAuthoritysRelatedByAuthorityIdDown as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion !== null) {
                if (!$this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion->isEmpty()) {
                    LAuthorityQuery::create()
                        ->filterByPrimaryKeys($this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion = null;
                }
            }

            if ($this->collLAuthoritysRelatedByAuthorityIdUp !== null) {
                foreach ($this->collLAuthoritysRelatedByAuthorityIdUp as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lAuthorityItemsScheduledForDeletion !== null) {
                if (!$this->lAuthorityItemsScheduledForDeletion->isEmpty()) {
                    LAuthorityItemQuery::create()
                        ->filterByPrimaryKeys($this->lAuthorityItemsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->lAuthorityItemsScheduledForDeletion = null;
                }
            }

            if ($this->collLAuthorityItems !== null) {
                foreach ($this->collLAuthorityItems as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lAuthorityManifestationsScheduledForDeletion !== null) {
                if (!$this->lAuthorityManifestationsScheduledForDeletion->isEmpty()) {
                    LAuthorityManifestationQuery::create()
                        ->filterByPrimaryKeys($this->lAuthorityManifestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->lAuthorityManifestationsScheduledForDeletion = null;
                }
            }

            if ($this->collLAuthorityManifestations !== null) {
                foreach ($this->collLAuthorityManifestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lSubjectsRelatedByAuthorityIdScheduledForDeletion !== null) {
                if (!$this->lSubjectsRelatedByAuthorityIdScheduledForDeletion->isEmpty()) {
                    LSubjectQuery::create()
                        ->filterByPrimaryKeys($this->lSubjectsRelatedByAuthorityIdScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion = null;
                }
            }

            if ($this->collLSubjectsRelatedByAuthorityId !== null) {
                foreach ($this->collLSubjectsRelatedByAuthorityId as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lSubjectsRelatedBySubjectIdScheduledForDeletion !== null) {
                if (!$this->lSubjectsRelatedBySubjectIdScheduledForDeletion->isEmpty()) {
                    LSubjectQuery::create()
                        ->filterByPrimaryKeys($this->lSubjectsRelatedBySubjectIdScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->lSubjectsRelatedBySubjectIdScheduledForDeletion = null;
                }
            }

            if ($this->collLSubjectsRelatedBySubjectId !== null) {
                foreach ($this->collLSubjectsRelatedBySubjectId as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->singleTurbomarcauthorityCache !== null) {
                if (!$this->singleTurbomarcauthorityCache->isDeleted() && ($this->singleTurbomarcauthorityCache->isNew() || $this->singleTurbomarcauthorityCache->isModified())) {
                        $affectedRows += $this->singleTurbomarcauthorityCache->save($con);
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = AuthorityPeer::AUTHORITY_ID;
        if (null !== $this->authority_id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . AuthorityPeer::AUTHORITY_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`authority_id`';
        }
        if ($this->isColumnModified(AuthorityPeer::NON_SORT_TEXT)) {
            $modifiedColumns[':p' . $index++]  = '`non_sort_text`';
        }
        if ($this->isColumnModified(AuthorityPeer::SORT_TEXT)) {
            $modifiedColumns[':p' . $index++]  = '`sort_text`';
        }
        if ($this->isColumnModified(AuthorityPeer::FULL_TEXT)) {
            $modifiedColumns[':p' . $index++]  = '`full_text`';
        }
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_TYPE)) {
            $modifiedColumns[':p' . $index++]  = '`authority_type`';
        }
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_SUBTYPE)) {
            $modifiedColumns[':p' . $index++]  = '`authority_subtype`';
        }
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_RECTYPE)) {
            $modifiedColumns[':p' . $index++]  = '`authority_rectype`';
        }
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`authority_status`';
        }
        if ($this->isColumnModified(AuthorityPeer::UNIMARC)) {
            $modifiedColumns[':p' . $index++]  = '`unimarc`';
        }
        if ($this->isColumnModified(AuthorityPeer::EXT_DATA)) {
            $modifiedColumns[':p' . $index++]  = '`ext_data`';
        }
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_LANG)) {
            $modifiedColumns[':p' . $index++]  = '`authority_lang`';
        }
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_CODLEVEL)) {
            $modifiedColumns[':p' . $index++]  = '`authority_codlevel`';
        }
        if ($this->isColumnModified(AuthorityPeer::PARENT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`parent_id`';
        }
        if ($this->isColumnModified(AuthorityPeer::SUBJECT_CLASS)) {
            $modifiedColumns[':p' . $index++]  = '`subject_class`';
        }
        if ($this->isColumnModified(AuthorityPeer::CLASS_CODE)) {
            $modifiedColumns[':p' . $index++]  = '`class_code`';
        }
        if ($this->isColumnModified(AuthorityPeer::BID_SOURCE)) {
            $modifiedColumns[':p' . $index++]  = '`bid_source`';
        }
        if ($this->isColumnModified(AuthorityPeer::BID)) {
            $modifiedColumns[':p' . $index++]  = '`bid`';
        }
        if ($this->isColumnModified(AuthorityPeer::LAST_SBN_SYNC)) {
            $modifiedColumns[':p' . $index++]  = '`last_sbn_sync`';
        }
        if ($this->isColumnModified(AuthorityPeer::DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_created`';
        }
        if ($this->isColumnModified(AuthorityPeer::DATE_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_updated`';
        }
        if ($this->isColumnModified(AuthorityPeer::CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`created_by`';
        }
        if ($this->isColumnModified(AuthorityPeer::MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`modified_by`';
        }

        $sql = sprintf(
            'INSERT INTO `authority` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`authority_id`':
                        $stmt->bindValue($identifier, $this->authority_id, PDO::PARAM_INT);
                        break;
                    case '`non_sort_text`':
                        $stmt->bindValue($identifier, $this->non_sort_text, PDO::PARAM_STR);
                        break;
                    case '`sort_text`':
                        $stmt->bindValue($identifier, $this->sort_text, PDO::PARAM_STR);
                        break;
                    case '`full_text`':
                        $stmt->bindValue($identifier, $this->full_text, PDO::PARAM_STR);
                        break;
                    case '`authority_type`':
                        $stmt->bindValue($identifier, $this->authority_type, PDO::PARAM_STR);
                        break;
                    case '`authority_subtype`':
                        $stmt->bindValue($identifier, $this->authority_subtype, PDO::PARAM_STR);
                        break;
                    case '`authority_rectype`':
                        $stmt->bindValue($identifier, $this->authority_rectype, PDO::PARAM_STR);
                        break;
                    case '`authority_status`':
                        $stmt->bindValue($identifier, $this->authority_status, PDO::PARAM_STR);
                        break;
                    case '`unimarc`':
                        $stmt->bindValue($identifier, $this->unimarc, PDO::PARAM_STR);
                        break;
                    case '`ext_data`':
                        $stmt->bindValue($identifier, $this->ext_data, PDO::PARAM_STR);
                        break;
                    case '`authority_lang`':
                        $stmt->bindValue($identifier, $this->authority_lang, PDO::PARAM_STR);
                        break;
                    case '`authority_codlevel`':
                        $stmt->bindValue($identifier, $this->authority_codlevel, PDO::PARAM_STR);
                        break;
                    case '`parent_id`':
                        $stmt->bindValue($identifier, $this->parent_id, PDO::PARAM_INT);
                        break;
                    case '`subject_class`':
                        $stmt->bindValue($identifier, $this->subject_class, PDO::PARAM_STR);
                        break;
                    case '`class_code`':
                        $stmt->bindValue($identifier, $this->class_code, PDO::PARAM_STR);
                        break;
                    case '`bid_source`':
                        $stmt->bindValue($identifier, $this->bid_source, PDO::PARAM_STR);
                        break;
                    case '`bid`':
                        $stmt->bindValue($identifier, $this->bid, PDO::PARAM_STR);
                        break;
                    case '`last_sbn_sync`':
                        $stmt->bindValue($identifier, $this->last_sbn_sync, PDO::PARAM_STR);
                        break;
                    case '`date_created`':
                        $stmt->bindValue($identifier, $this->date_created, PDO::PARAM_STR);
                        break;
                    case '`date_updated`':
                        $stmt->bindValue($identifier, $this->date_updated, PDO::PARAM_STR);
                        break;
                    case '`created_by`':
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_INT);
                        break;
                    case '`modified_by`':
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setAuthorityId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if (!$this->aLibrarianRelatedByCreatedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByCreatedBy->getValidationFailures());
                }
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if (!$this->aLibrarianRelatedByModifiedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByModifiedBy->getValidationFailures());
                }
            }

            if ($this->aAuthorityRelatedByParentId !== null) {
                if (!$this->aAuthorityRelatedByParentId->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aAuthorityRelatedByParentId->getValidationFailures());
                }
            }


            if (($retval = AuthorityPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collAuthoritysRelatedByAuthorityId !== null) {
                    foreach ($this->collAuthoritysRelatedByAuthorityId as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLAuthoritysRelatedByAuthorityIdDown !== null) {
                    foreach ($this->collLAuthoritysRelatedByAuthorityIdDown as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLAuthoritysRelatedByAuthorityIdUp !== null) {
                    foreach ($this->collLAuthoritysRelatedByAuthorityIdUp as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLAuthorityItems !== null) {
                    foreach ($this->collLAuthorityItems as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLAuthorityManifestations !== null) {
                    foreach ($this->collLAuthorityManifestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLSubjectsRelatedByAuthorityId !== null) {
                    foreach ($this->collLSubjectsRelatedByAuthorityId as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLSubjectsRelatedBySubjectId !== null) {
                    foreach ($this->collLSubjectsRelatedBySubjectId as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->singleTurbomarcauthorityCache !== null) {
                    if (!$this->singleTurbomarcauthorityCache->validate($columns)) {
                        $failureMap = array_merge($failureMap, $this->singleTurbomarcauthorityCache->getValidationFailures());
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = AuthorityPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getAuthorityId();
                break;
            case 1:
                return $this->getNonSortText();
                break;
            case 2:
                return $this->getSortText();
                break;
            case 3:
                return $this->getFullText();
                break;
            case 4:
                return $this->getAuthorityType();
                break;
            case 5:
                return $this->getAuthoritySubtype();
                break;
            case 6:
                return $this->getAuthorityRectype();
                break;
            case 7:
                return $this->getAuthorityStatus();
                break;
            case 8:
                return $this->getUnimarc();
                break;
            case 9:
                return $this->getExtData();
                break;
            case 10:
                return $this->getAuthorityLang();
                break;
            case 11:
                return $this->getAuthorityCodlevel();
                break;
            case 12:
                return $this->getParentId();
                break;
            case 13:
                return $this->getSubjectClass();
                break;
            case 14:
                return $this->getClassCode();
                break;
            case 15:
                return $this->getBidSource();
                break;
            case 16:
                return $this->getBid();
                break;
            case 17:
                return $this->getLastSbnSync();
                break;
            case 18:
                return $this->getDateCreated();
                break;
            case 19:
                return $this->getDateUpdated();
                break;
            case 20:
                return $this->getCreatedBy();
                break;
            case 21:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['Authority'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['Authority'][$this->getPrimaryKey()] = true;
        $keys = AuthorityPeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getAuthorityId(),
            $keys[1] => $this->getNonSortText(),
            $keys[2] => $this->getSortText(),
            $keys[3] => $this->getFullText(),
            $keys[4] => $this->getAuthorityType(),
            $keys[5] => $this->getAuthoritySubtype(),
            $keys[6] => $this->getAuthorityRectype(),
            $keys[7] => $this->getAuthorityStatus(),
            $keys[8] => $this->getUnimarc(),
            $keys[9] => $this->getExtData(),
            $keys[10] => $this->getAuthorityLang(),
            $keys[11] => $this->getAuthorityCodlevel(),
            $keys[12] => $this->getParentId(),
            $keys[13] => $this->getSubjectClass(),
            $keys[14] => $this->getClassCode(),
            $keys[15] => $this->getBidSource(),
            $keys[16] => $this->getBid(),
            $keys[17] => $this->getLastSbnSync(),
            $keys[18] => $this->getDateCreated(),
            $keys[19] => $this->getDateUpdated(),
            $keys[20] => $this->getCreatedBy(),
            $keys[21] => $this->getModifiedBy(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aLibrarianRelatedByCreatedBy) {
                $result['LibrarianRelatedByCreatedBy'] = $this->aLibrarianRelatedByCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrarianRelatedByModifiedBy) {
                $result['LibrarianRelatedByModifiedBy'] = $this->aLibrarianRelatedByModifiedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aAuthorityRelatedByParentId) {
                $result['AuthorityRelatedByParentId'] = $this->aAuthorityRelatedByParentId->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->collAuthoritysRelatedByAuthorityId) {
                $result['AuthoritysRelatedByAuthorityId'] = $this->collAuthoritysRelatedByAuthorityId->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLAuthoritysRelatedByAuthorityIdDown) {
                $result['LAuthoritysRelatedByAuthorityIdDown'] = $this->collLAuthoritysRelatedByAuthorityIdDown->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLAuthoritysRelatedByAuthorityIdUp) {
                $result['LAuthoritysRelatedByAuthorityIdUp'] = $this->collLAuthoritysRelatedByAuthorityIdUp->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLAuthorityItems) {
                $result['LAuthorityItems'] = $this->collLAuthorityItems->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLAuthorityManifestations) {
                $result['LAuthorityManifestations'] = $this->collLAuthorityManifestations->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLSubjectsRelatedByAuthorityId) {
                $result['LSubjectsRelatedByAuthorityId'] = $this->collLSubjectsRelatedByAuthorityId->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLSubjectsRelatedBySubjectId) {
                $result['LSubjectsRelatedBySubjectId'] = $this->collLSubjectsRelatedBySubjectId->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->singleTurbomarcauthorityCache) {
                $result['TurbomarcauthorityCache'] = $this->singleTurbomarcauthorityCache->toArray($keyType, $includeLazyLoadColumns, $alreadyDumpedObjects, true);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = AuthorityPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setAuthorityId($value);
                break;
            case 1:
                $this->setNonSortText($value);
                break;
            case 2:
                $this->setSortText($value);
                break;
            case 3:
                $this->setFullText($value);
                break;
            case 4:
                $this->setAuthorityType($value);
                break;
            case 5:
                $this->setAuthoritySubtype($value);
                break;
            case 6:
                $this->setAuthorityRectype($value);
                break;
            case 7:
                $this->setAuthorityStatus($value);
                break;
            case 8:
                $this->setUnimarc($value);
                break;
            case 9:
                $this->setExtData($value);
                break;
            case 10:
                $this->setAuthorityLang($value);
                break;
            case 11:
                $this->setAuthorityCodlevel($value);
                break;
            case 12:
                $this->setParentId($value);
                break;
            case 13:
                $this->setSubjectClass($value);
                break;
            case 14:
                $this->setClassCode($value);
                break;
            case 15:
                $this->setBidSource($value);
                break;
            case 16:
                $this->setBid($value);
                break;
            case 17:
                $this->setLastSbnSync($value);
                break;
            case 18:
                $this->setDateCreated($value);
                break;
            case 19:
                $this->setDateUpdated($value);
                break;
            case 20:
                $this->setCreatedBy($value);
                break;
            case 21:
                $this->setModifiedBy($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = AuthorityPeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setAuthorityId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setNonSortText($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setSortText($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setFullText($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setAuthorityType($arr[$keys[4]]);
        if (array_key_exists($keys[5], $arr)) $this->setAuthoritySubtype($arr[$keys[5]]);
        if (array_key_exists($keys[6], $arr)) $this->setAuthorityRectype($arr[$keys[6]]);
        if (array_key_exists($keys[7], $arr)) $this->setAuthorityStatus($arr[$keys[7]]);
        if (array_key_exists($keys[8], $arr)) $this->setUnimarc($arr[$keys[8]]);
        if (array_key_exists($keys[9], $arr)) $this->setExtData($arr[$keys[9]]);
        if (array_key_exists($keys[10], $arr)) $this->setAuthorityLang($arr[$keys[10]]);
        if (array_key_exists($keys[11], $arr)) $this->setAuthorityCodlevel($arr[$keys[11]]);
        if (array_key_exists($keys[12], $arr)) $this->setParentId($arr[$keys[12]]);
        if (array_key_exists($keys[13], $arr)) $this->setSubjectClass($arr[$keys[13]]);
        if (array_key_exists($keys[14], $arr)) $this->setClassCode($arr[$keys[14]]);
        if (array_key_exists($keys[15], $arr)) $this->setBidSource($arr[$keys[15]]);
        if (array_key_exists($keys[16], $arr)) $this->setBid($arr[$keys[16]]);
        if (array_key_exists($keys[17], $arr)) $this->setLastSbnSync($arr[$keys[17]]);
        if (array_key_exists($keys[18], $arr)) $this->setDateCreated($arr[$keys[18]]);
        if (array_key_exists($keys[19], $arr)) $this->setDateUpdated($arr[$keys[19]]);
        if (array_key_exists($keys[20], $arr)) $this->setCreatedBy($arr[$keys[20]]);
        if (array_key_exists($keys[21], $arr)) $this->setModifiedBy($arr[$keys[21]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(AuthorityPeer::DATABASE_NAME);

        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_ID)) $criteria->add(AuthorityPeer::AUTHORITY_ID, $this->authority_id);
        if ($this->isColumnModified(AuthorityPeer::NON_SORT_TEXT)) $criteria->add(AuthorityPeer::NON_SORT_TEXT, $this->non_sort_text);
        if ($this->isColumnModified(AuthorityPeer::SORT_TEXT)) $criteria->add(AuthorityPeer::SORT_TEXT, $this->sort_text);
        if ($this->isColumnModified(AuthorityPeer::FULL_TEXT)) $criteria->add(AuthorityPeer::FULL_TEXT, $this->full_text);
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_TYPE)) $criteria->add(AuthorityPeer::AUTHORITY_TYPE, $this->authority_type);
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_SUBTYPE)) $criteria->add(AuthorityPeer::AUTHORITY_SUBTYPE, $this->authority_subtype);
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_RECTYPE)) $criteria->add(AuthorityPeer::AUTHORITY_RECTYPE, $this->authority_rectype);
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_STATUS)) $criteria->add(AuthorityPeer::AUTHORITY_STATUS, $this->authority_status);
        if ($this->isColumnModified(AuthorityPeer::UNIMARC)) $criteria->add(AuthorityPeer::UNIMARC, $this->unimarc);
        if ($this->isColumnModified(AuthorityPeer::EXT_DATA)) $criteria->add(AuthorityPeer::EXT_DATA, $this->ext_data);
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_LANG)) $criteria->add(AuthorityPeer::AUTHORITY_LANG, $this->authority_lang);
        if ($this->isColumnModified(AuthorityPeer::AUTHORITY_CODLEVEL)) $criteria->add(AuthorityPeer::AUTHORITY_CODLEVEL, $this->authority_codlevel);
        if ($this->isColumnModified(AuthorityPeer::PARENT_ID)) $criteria->add(AuthorityPeer::PARENT_ID, $this->parent_id);
        if ($this->isColumnModified(AuthorityPeer::SUBJECT_CLASS)) $criteria->add(AuthorityPeer::SUBJECT_CLASS, $this->subject_class);
        if ($this->isColumnModified(AuthorityPeer::CLASS_CODE)) $criteria->add(AuthorityPeer::CLASS_CODE, $this->class_code);
        if ($this->isColumnModified(AuthorityPeer::BID_SOURCE)) $criteria->add(AuthorityPeer::BID_SOURCE, $this->bid_source);
        if ($this->isColumnModified(AuthorityPeer::BID)) $criteria->add(AuthorityPeer::BID, $this->bid);
        if ($this->isColumnModified(AuthorityPeer::LAST_SBN_SYNC)) $criteria->add(AuthorityPeer::LAST_SBN_SYNC, $this->last_sbn_sync);
        if ($this->isColumnModified(AuthorityPeer::DATE_CREATED)) $criteria->add(AuthorityPeer::DATE_CREATED, $this->date_created);
        if ($this->isColumnModified(AuthorityPeer::DATE_UPDATED)) $criteria->add(AuthorityPeer::DATE_UPDATED, $this->date_updated);
        if ($this->isColumnModified(AuthorityPeer::CREATED_BY)) $criteria->add(AuthorityPeer::CREATED_BY, $this->created_by);
        if ($this->isColumnModified(AuthorityPeer::MODIFIED_BY)) $criteria->add(AuthorityPeer::MODIFIED_BY, $this->modified_by);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(AuthorityPeer::DATABASE_NAME);
        $criteria->add(AuthorityPeer::AUTHORITY_ID, $this->authority_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getAuthorityId();
    }

    /**
     * Generic method to set the primary key (authority_id column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setAuthorityId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getAuthorityId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of Authority (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setNonSortText($this->getNonSortText());
        $copyObj->setSortText($this->getSortText());
        $copyObj->setFullText($this->getFullText());
        $copyObj->setAuthorityType($this->getAuthorityType());
        $copyObj->setAuthoritySubtype($this->getAuthoritySubtype());
        $copyObj->setAuthorityRectype($this->getAuthorityRectype());
        $copyObj->setAuthorityStatus($this->getAuthorityStatus());
        $copyObj->setUnimarc($this->getUnimarc());
        $copyObj->setExtData($this->getExtData());
        $copyObj->setAuthorityLang($this->getAuthorityLang());
        $copyObj->setAuthorityCodlevel($this->getAuthorityCodlevel());
        $copyObj->setParentId($this->getParentId());
        $copyObj->setSubjectClass($this->getSubjectClass());
        $copyObj->setClassCode($this->getClassCode());
        $copyObj->setBidSource($this->getBidSource());
        $copyObj->setBid($this->getBid());
        $copyObj->setLastSbnSync($this->getLastSbnSync());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setDateUpdated($this->getDateUpdated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setModifiedBy($this->getModifiedBy());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getAuthoritysRelatedByAuthorityId() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addAuthorityRelatedByAuthorityId($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLAuthoritysRelatedByAuthorityIdDown() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLAuthorityRelatedByAuthorityIdDown($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLAuthoritysRelatedByAuthorityIdUp() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLAuthorityRelatedByAuthorityIdUp($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLAuthorityItems() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLAuthorityItem($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLAuthorityManifestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLAuthorityManifestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLSubjectsRelatedByAuthorityId() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLSubjectRelatedByAuthorityId($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLSubjectsRelatedBySubjectId() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLSubjectRelatedBySubjectId($relObj->copy($deepCopy));
                }
            }

            $relObj = $this->getTurbomarcauthorityCache();
            if ($relObj) {
                $copyObj->setTurbomarcauthorityCache($relObj->copy($deepCopy));
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setAuthorityId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return Authority Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return AuthorityPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new AuthorityPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Authority The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByCreatedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setCreatedBy(NULL);
        } else {
            $this->setCreatedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addAuthorityRelatedByCreatedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByCreatedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByCreatedBy === null && ($this->created_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByCreatedBy = LibrarianQuery::create()->findPk($this->created_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByCreatedBy->addAuthoritysRelatedByCreatedBy($this);
             */
        }

        return $this->aLibrarianRelatedByCreatedBy;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Authority The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByModifiedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setModifiedBy(NULL);
        } else {
            $this->setModifiedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByModifiedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addAuthorityRelatedByModifiedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByModifiedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByModifiedBy === null && ($this->modified_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByModifiedBy = LibrarianQuery::create()->findPk($this->modified_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByModifiedBy->addAuthoritysRelatedByModifiedBy($this);
             */
        }

        return $this->aLibrarianRelatedByModifiedBy;
    }

    /**
     * Declares an association between this object and a Authority object.
     *
     * @param                  Authority $v
     * @return Authority The current object (for fluent API support)
     * @throws PropelException
     */
    public function setAuthorityRelatedByParentId(Authority $v = null)
    {
        if ($v === null) {
            $this->setParentId(NULL);
        } else {
            $this->setParentId($v->getAuthorityId());
        }

        $this->aAuthorityRelatedByParentId = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Authority object, it will not be re-added.
        if ($v !== null) {
            $v->addAuthorityRelatedByAuthorityId($this);
        }


        return $this;
    }


    /**
     * Get the associated Authority object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Authority The associated Authority object.
     * @throws PropelException
     */
    public function getAuthorityRelatedByParentId(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aAuthorityRelatedByParentId === null && ($this->parent_id !== null) && $doQuery) {
            $this->aAuthorityRelatedByParentId = AuthorityQuery::create()->findPk($this->parent_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aAuthorityRelatedByParentId->addAuthoritysRelatedByAuthorityId($this);
             */
        }

        return $this->aAuthorityRelatedByParentId;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('AuthorityRelatedByAuthorityId' == $relationName) {
            $this->initAuthoritysRelatedByAuthorityId();
        }
        if ('LAuthorityRelatedByAuthorityIdDown' == $relationName) {
            $this->initLAuthoritysRelatedByAuthorityIdDown();
        }
        if ('LAuthorityRelatedByAuthorityIdUp' == $relationName) {
            $this->initLAuthoritysRelatedByAuthorityIdUp();
        }
        if ('LAuthorityItem' == $relationName) {
            $this->initLAuthorityItems();
        }
        if ('LAuthorityManifestation' == $relationName) {
            $this->initLAuthorityManifestations();
        }
        if ('LSubjectRelatedByAuthorityId' == $relationName) {
            $this->initLSubjectsRelatedByAuthorityId();
        }
        if ('LSubjectRelatedBySubjectId' == $relationName) {
            $this->initLSubjectsRelatedBySubjectId();
        }
    }

    /**
     * Clears out the collAuthoritysRelatedByAuthorityId collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Authority The current object (for fluent API support)
     * @see        addAuthoritysRelatedByAuthorityId()
     */
    public function clearAuthoritysRelatedByAuthorityId()
    {
        $this->collAuthoritysRelatedByAuthorityId = null; // important to set this to null since that means it is uninitialized
        $this->collAuthoritysRelatedByAuthorityIdPartial = null;

        return $this;
    }

    /**
     * reset is the collAuthoritysRelatedByAuthorityId collection loaded partially
     *
     * @return void
     */
    public function resetPartialAuthoritysRelatedByAuthorityId($v = true)
    {
        $this->collAuthoritysRelatedByAuthorityIdPartial = $v;
    }

    /**
     * Initializes the collAuthoritysRelatedByAuthorityId collection.
     *
     * By default this just sets the collAuthoritysRelatedByAuthorityId collection to an empty array (like clearcollAuthoritysRelatedByAuthorityId());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initAuthoritysRelatedByAuthorityId($overrideExisting = true)
    {
        if (null !== $this->collAuthoritysRelatedByAuthorityId && !$overrideExisting) {
            return;
        }
        $this->collAuthoritysRelatedByAuthorityId = new PropelObjectCollection();
        $this->collAuthoritysRelatedByAuthorityId->setModel('Authority');
    }

    /**
     * Gets an array of Authority objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Authority is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|Authority[] List of Authority objects
     * @throws PropelException
     */
    public function getAuthoritysRelatedByAuthorityId($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collAuthoritysRelatedByAuthorityIdPartial && !$this->isNew();
        if (null === $this->collAuthoritysRelatedByAuthorityId || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collAuthoritysRelatedByAuthorityId) {
                // return empty collection
                $this->initAuthoritysRelatedByAuthorityId();
            } else {
                $collAuthoritysRelatedByAuthorityId = AuthorityQuery::create(null, $criteria)
                    ->filterByAuthorityRelatedByParentId($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collAuthoritysRelatedByAuthorityIdPartial && count($collAuthoritysRelatedByAuthorityId)) {
                      $this->initAuthoritysRelatedByAuthorityId(false);

                      foreach ($collAuthoritysRelatedByAuthorityId as $obj) {
                        if (false == $this->collAuthoritysRelatedByAuthorityId->contains($obj)) {
                          $this->collAuthoritysRelatedByAuthorityId->append($obj);
                        }
                      }

                      $this->collAuthoritysRelatedByAuthorityIdPartial = true;
                    }

                    $collAuthoritysRelatedByAuthorityId->getInternalIterator()->rewind();

                    return $collAuthoritysRelatedByAuthorityId;
                }

                if ($partial && $this->collAuthoritysRelatedByAuthorityId) {
                    foreach ($this->collAuthoritysRelatedByAuthorityId as $obj) {
                        if ($obj->isNew()) {
                            $collAuthoritysRelatedByAuthorityId[] = $obj;
                        }
                    }
                }

                $this->collAuthoritysRelatedByAuthorityId = $collAuthoritysRelatedByAuthorityId;
                $this->collAuthoritysRelatedByAuthorityIdPartial = false;
            }
        }

        return $this->collAuthoritysRelatedByAuthorityId;
    }

    /**
     * Sets a collection of AuthorityRelatedByAuthorityId objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $authoritysRelatedByAuthorityId A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Authority The current object (for fluent API support)
     */
    public function setAuthoritysRelatedByAuthorityId(PropelCollection $authoritysRelatedByAuthorityId, PropelPDO $con = null)
    {
        $authoritysRelatedByAuthorityIdToDelete = $this->getAuthoritysRelatedByAuthorityId(new Criteria(), $con)->diff($authoritysRelatedByAuthorityId);


        $this->authoritysRelatedByAuthorityIdScheduledForDeletion = $authoritysRelatedByAuthorityIdToDelete;

        foreach ($authoritysRelatedByAuthorityIdToDelete as $authorityRelatedByAuthorityIdRemoved) {
            $authorityRelatedByAuthorityIdRemoved->setAuthorityRelatedByParentId(null);
        }

        $this->collAuthoritysRelatedByAuthorityId = null;
        foreach ($authoritysRelatedByAuthorityId as $authorityRelatedByAuthorityId) {
            $this->addAuthorityRelatedByAuthorityId($authorityRelatedByAuthorityId);
        }

        $this->collAuthoritysRelatedByAuthorityId = $authoritysRelatedByAuthorityId;
        $this->collAuthoritysRelatedByAuthorityIdPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Authority objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related Authority objects.
     * @throws PropelException
     */
    public function countAuthoritysRelatedByAuthorityId(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collAuthoritysRelatedByAuthorityIdPartial && !$this->isNew();
        if (null === $this->collAuthoritysRelatedByAuthorityId || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collAuthoritysRelatedByAuthorityId) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getAuthoritysRelatedByAuthorityId());
            }
            $query = AuthorityQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAuthorityRelatedByParentId($this)
                ->count($con);
        }

        return count($this->collAuthoritysRelatedByAuthorityId);
    }

    /**
     * Method called to associate a Authority object to this object
     * through the Authority foreign key attribute.
     *
     * @param    Authority $l Authority
     * @return Authority The current object (for fluent API support)
     */
    public function addAuthorityRelatedByAuthorityId(Authority $l)
    {
        if ($this->collAuthoritysRelatedByAuthorityId === null) {
            $this->initAuthoritysRelatedByAuthorityId();
            $this->collAuthoritysRelatedByAuthorityIdPartial = true;
        }

        if (!in_array($l, $this->collAuthoritysRelatedByAuthorityId->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddAuthorityRelatedByAuthorityId($l);

            if ($this->authoritysRelatedByAuthorityIdScheduledForDeletion and $this->authoritysRelatedByAuthorityIdScheduledForDeletion->contains($l)) {
                $this->authoritysRelatedByAuthorityIdScheduledForDeletion->remove($this->authoritysRelatedByAuthorityIdScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	AuthorityRelatedByAuthorityId $authorityRelatedByAuthorityId The authorityRelatedByAuthorityId object to add.
     */
    protected function doAddAuthorityRelatedByAuthorityId($authorityRelatedByAuthorityId)
    {
        $this->collAuthoritysRelatedByAuthorityId[]= $authorityRelatedByAuthorityId;
        $authorityRelatedByAuthorityId->setAuthorityRelatedByParentId($this);
    }

    /**
     * @param	AuthorityRelatedByAuthorityId $authorityRelatedByAuthorityId The authorityRelatedByAuthorityId object to remove.
     * @return Authority The current object (for fluent API support)
     */
    public function removeAuthorityRelatedByAuthorityId($authorityRelatedByAuthorityId)
    {
        if ($this->getAuthoritysRelatedByAuthorityId()->contains($authorityRelatedByAuthorityId)) {
            $this->collAuthoritysRelatedByAuthorityId->remove($this->collAuthoritysRelatedByAuthorityId->search($authorityRelatedByAuthorityId));
            if (null === $this->authoritysRelatedByAuthorityIdScheduledForDeletion) {
                $this->authoritysRelatedByAuthorityIdScheduledForDeletion = clone $this->collAuthoritysRelatedByAuthorityId;
                $this->authoritysRelatedByAuthorityIdScheduledForDeletion->clear();
            }
            $this->authoritysRelatedByAuthorityIdScheduledForDeletion[]= $authorityRelatedByAuthorityId;
            $authorityRelatedByAuthorityId->setAuthorityRelatedByParentId(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Authority is new, it will return
     * an empty collection; or if this Authority has previously
     * been saved, it will retrieve related AuthoritysRelatedByAuthorityId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Authority.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Authority[] List of Authority objects
     */
    public function getAuthoritysRelatedByAuthorityIdJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = AuthorityQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getAuthoritysRelatedByAuthorityId($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Authority is new, it will return
     * an empty collection; or if this Authority has previously
     * been saved, it will retrieve related AuthoritysRelatedByAuthorityId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Authority.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Authority[] List of Authority objects
     */
    public function getAuthoritysRelatedByAuthorityIdJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = AuthorityQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getAuthoritysRelatedByAuthorityId($query, $con);
    }

    /**
     * Clears out the collLAuthoritysRelatedByAuthorityIdDown collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Authority The current object (for fluent API support)
     * @see        addLAuthoritysRelatedByAuthorityIdDown()
     */
    public function clearLAuthoritysRelatedByAuthorityIdDown()
    {
        $this->collLAuthoritysRelatedByAuthorityIdDown = null; // important to set this to null since that means it is uninitialized
        $this->collLAuthoritysRelatedByAuthorityIdDownPartial = null;

        return $this;
    }

    /**
     * reset is the collLAuthoritysRelatedByAuthorityIdDown collection loaded partially
     *
     * @return void
     */
    public function resetPartialLAuthoritysRelatedByAuthorityIdDown($v = true)
    {
        $this->collLAuthoritysRelatedByAuthorityIdDownPartial = $v;
    }

    /**
     * Initializes the collLAuthoritysRelatedByAuthorityIdDown collection.
     *
     * By default this just sets the collLAuthoritysRelatedByAuthorityIdDown collection to an empty array (like clearcollLAuthoritysRelatedByAuthorityIdDown());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLAuthoritysRelatedByAuthorityIdDown($overrideExisting = true)
    {
        if (null !== $this->collLAuthoritysRelatedByAuthorityIdDown && !$overrideExisting) {
            return;
        }
        $this->collLAuthoritysRelatedByAuthorityIdDown = new PropelObjectCollection();
        $this->collLAuthoritysRelatedByAuthorityIdDown->setModel('LAuthority');
    }

    /**
     * Gets an array of LAuthority objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Authority is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LAuthority[] List of LAuthority objects
     * @throws PropelException
     */
    public function getLAuthoritysRelatedByAuthorityIdDown($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLAuthoritysRelatedByAuthorityIdDownPartial && !$this->isNew();
        if (null === $this->collLAuthoritysRelatedByAuthorityIdDown || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLAuthoritysRelatedByAuthorityIdDown) {
                // return empty collection
                $this->initLAuthoritysRelatedByAuthorityIdDown();
            } else {
                $collLAuthoritysRelatedByAuthorityIdDown = LAuthorityQuery::create(null, $criteria)
                    ->filterByAuthorityRelatedByAuthorityIdDown($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLAuthoritysRelatedByAuthorityIdDownPartial && count($collLAuthoritysRelatedByAuthorityIdDown)) {
                      $this->initLAuthoritysRelatedByAuthorityIdDown(false);

                      foreach ($collLAuthoritysRelatedByAuthorityIdDown as $obj) {
                        if (false == $this->collLAuthoritysRelatedByAuthorityIdDown->contains($obj)) {
                          $this->collLAuthoritysRelatedByAuthorityIdDown->append($obj);
                        }
                      }

                      $this->collLAuthoritysRelatedByAuthorityIdDownPartial = true;
                    }

                    $collLAuthoritysRelatedByAuthorityIdDown->getInternalIterator()->rewind();

                    return $collLAuthoritysRelatedByAuthorityIdDown;
                }

                if ($partial && $this->collLAuthoritysRelatedByAuthorityIdDown) {
                    foreach ($this->collLAuthoritysRelatedByAuthorityIdDown as $obj) {
                        if ($obj->isNew()) {
                            $collLAuthoritysRelatedByAuthorityIdDown[] = $obj;
                        }
                    }
                }

                $this->collLAuthoritysRelatedByAuthorityIdDown = $collLAuthoritysRelatedByAuthorityIdDown;
                $this->collLAuthoritysRelatedByAuthorityIdDownPartial = false;
            }
        }

        return $this->collLAuthoritysRelatedByAuthorityIdDown;
    }

    /**
     * Sets a collection of LAuthorityRelatedByAuthorityIdDown objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lAuthoritysRelatedByAuthorityIdDown A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Authority The current object (for fluent API support)
     */
    public function setLAuthoritysRelatedByAuthorityIdDown(PropelCollection $lAuthoritysRelatedByAuthorityIdDown, PropelPDO $con = null)
    {
        $lAuthoritysRelatedByAuthorityIdDownToDelete = $this->getLAuthoritysRelatedByAuthorityIdDown(new Criteria(), $con)->diff($lAuthoritysRelatedByAuthorityIdDown);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion = clone $lAuthoritysRelatedByAuthorityIdDownToDelete;

        foreach ($lAuthoritysRelatedByAuthorityIdDownToDelete as $lAuthorityRelatedByAuthorityIdDownRemoved) {
            $lAuthorityRelatedByAuthorityIdDownRemoved->setAuthorityRelatedByAuthorityIdDown(null);
        }

        $this->collLAuthoritysRelatedByAuthorityIdDown = null;
        foreach ($lAuthoritysRelatedByAuthorityIdDown as $lAuthorityRelatedByAuthorityIdDown) {
            $this->addLAuthorityRelatedByAuthorityIdDown($lAuthorityRelatedByAuthorityIdDown);
        }

        $this->collLAuthoritysRelatedByAuthorityIdDown = $lAuthoritysRelatedByAuthorityIdDown;
        $this->collLAuthoritysRelatedByAuthorityIdDownPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LAuthority objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LAuthority objects.
     * @throws PropelException
     */
    public function countLAuthoritysRelatedByAuthorityIdDown(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLAuthoritysRelatedByAuthorityIdDownPartial && !$this->isNew();
        if (null === $this->collLAuthoritysRelatedByAuthorityIdDown || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLAuthoritysRelatedByAuthorityIdDown) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLAuthoritysRelatedByAuthorityIdDown());
            }
            $query = LAuthorityQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAuthorityRelatedByAuthorityIdDown($this)
                ->count($con);
        }

        return count($this->collLAuthoritysRelatedByAuthorityIdDown);
    }

    /**
     * Method called to associate a LAuthority object to this object
     * through the LAuthority foreign key attribute.
     *
     * @param    LAuthority $l LAuthority
     * @return Authority The current object (for fluent API support)
     */
    public function addLAuthorityRelatedByAuthorityIdDown(LAuthority $l)
    {
        if ($this->collLAuthoritysRelatedByAuthorityIdDown === null) {
            $this->initLAuthoritysRelatedByAuthorityIdDown();
            $this->collLAuthoritysRelatedByAuthorityIdDownPartial = true;
        }

        if (!in_array($l, $this->collLAuthoritysRelatedByAuthorityIdDown->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLAuthorityRelatedByAuthorityIdDown($l);

            if ($this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion and $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion->contains($l)) {
                $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion->remove($this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LAuthorityRelatedByAuthorityIdDown $lAuthorityRelatedByAuthorityIdDown The lAuthorityRelatedByAuthorityIdDown object to add.
     */
    protected function doAddLAuthorityRelatedByAuthorityIdDown($lAuthorityRelatedByAuthorityIdDown)
    {
        $this->collLAuthoritysRelatedByAuthorityIdDown[]= $lAuthorityRelatedByAuthorityIdDown;
        $lAuthorityRelatedByAuthorityIdDown->setAuthorityRelatedByAuthorityIdDown($this);
    }

    /**
     * @param	LAuthorityRelatedByAuthorityIdDown $lAuthorityRelatedByAuthorityIdDown The lAuthorityRelatedByAuthorityIdDown object to remove.
     * @return Authority The current object (for fluent API support)
     */
    public function removeLAuthorityRelatedByAuthorityIdDown($lAuthorityRelatedByAuthorityIdDown)
    {
        if ($this->getLAuthoritysRelatedByAuthorityIdDown()->contains($lAuthorityRelatedByAuthorityIdDown)) {
            $this->collLAuthoritysRelatedByAuthorityIdDown->remove($this->collLAuthoritysRelatedByAuthorityIdDown->search($lAuthorityRelatedByAuthorityIdDown));
            if (null === $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion) {
                $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion = clone $this->collLAuthoritysRelatedByAuthorityIdDown;
                $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion->clear();
            }
            $this->lAuthoritysRelatedByAuthorityIdDownScheduledForDeletion[]= clone $lAuthorityRelatedByAuthorityIdDown;
            $lAuthorityRelatedByAuthorityIdDown->setAuthorityRelatedByAuthorityIdDown(null);
        }

        return $this;
    }

    /**
     * Clears out the collLAuthoritysRelatedByAuthorityIdUp collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Authority The current object (for fluent API support)
     * @see        addLAuthoritysRelatedByAuthorityIdUp()
     */
    public function clearLAuthoritysRelatedByAuthorityIdUp()
    {
        $this->collLAuthoritysRelatedByAuthorityIdUp = null; // important to set this to null since that means it is uninitialized
        $this->collLAuthoritysRelatedByAuthorityIdUpPartial = null;

        return $this;
    }

    /**
     * reset is the collLAuthoritysRelatedByAuthorityIdUp collection loaded partially
     *
     * @return void
     */
    public function resetPartialLAuthoritysRelatedByAuthorityIdUp($v = true)
    {
        $this->collLAuthoritysRelatedByAuthorityIdUpPartial = $v;
    }

    /**
     * Initializes the collLAuthoritysRelatedByAuthorityIdUp collection.
     *
     * By default this just sets the collLAuthoritysRelatedByAuthorityIdUp collection to an empty array (like clearcollLAuthoritysRelatedByAuthorityIdUp());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLAuthoritysRelatedByAuthorityIdUp($overrideExisting = true)
    {
        if (null !== $this->collLAuthoritysRelatedByAuthorityIdUp && !$overrideExisting) {
            return;
        }
        $this->collLAuthoritysRelatedByAuthorityIdUp = new PropelObjectCollection();
        $this->collLAuthoritysRelatedByAuthorityIdUp->setModel('LAuthority');
    }

    /**
     * Gets an array of LAuthority objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Authority is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LAuthority[] List of LAuthority objects
     * @throws PropelException
     */
    public function getLAuthoritysRelatedByAuthorityIdUp($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLAuthoritysRelatedByAuthorityIdUpPartial && !$this->isNew();
        if (null === $this->collLAuthoritysRelatedByAuthorityIdUp || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLAuthoritysRelatedByAuthorityIdUp) {
                // return empty collection
                $this->initLAuthoritysRelatedByAuthorityIdUp();
            } else {
                $collLAuthoritysRelatedByAuthorityIdUp = LAuthorityQuery::create(null, $criteria)
                    ->filterByAuthorityRelatedByAuthorityIdUp($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLAuthoritysRelatedByAuthorityIdUpPartial && count($collLAuthoritysRelatedByAuthorityIdUp)) {
                      $this->initLAuthoritysRelatedByAuthorityIdUp(false);

                      foreach ($collLAuthoritysRelatedByAuthorityIdUp as $obj) {
                        if (false == $this->collLAuthoritysRelatedByAuthorityIdUp->contains($obj)) {
                          $this->collLAuthoritysRelatedByAuthorityIdUp->append($obj);
                        }
                      }

                      $this->collLAuthoritysRelatedByAuthorityIdUpPartial = true;
                    }

                    $collLAuthoritysRelatedByAuthorityIdUp->getInternalIterator()->rewind();

                    return $collLAuthoritysRelatedByAuthorityIdUp;
                }

                if ($partial && $this->collLAuthoritysRelatedByAuthorityIdUp) {
                    foreach ($this->collLAuthoritysRelatedByAuthorityIdUp as $obj) {
                        if ($obj->isNew()) {
                            $collLAuthoritysRelatedByAuthorityIdUp[] = $obj;
                        }
                    }
                }

                $this->collLAuthoritysRelatedByAuthorityIdUp = $collLAuthoritysRelatedByAuthorityIdUp;
                $this->collLAuthoritysRelatedByAuthorityIdUpPartial = false;
            }
        }

        return $this->collLAuthoritysRelatedByAuthorityIdUp;
    }

    /**
     * Sets a collection of LAuthorityRelatedByAuthorityIdUp objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lAuthoritysRelatedByAuthorityIdUp A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Authority The current object (for fluent API support)
     */
    public function setLAuthoritysRelatedByAuthorityIdUp(PropelCollection $lAuthoritysRelatedByAuthorityIdUp, PropelPDO $con = null)
    {
        $lAuthoritysRelatedByAuthorityIdUpToDelete = $this->getLAuthoritysRelatedByAuthorityIdUp(new Criteria(), $con)->diff($lAuthoritysRelatedByAuthorityIdUp);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion = clone $lAuthoritysRelatedByAuthorityIdUpToDelete;

        foreach ($lAuthoritysRelatedByAuthorityIdUpToDelete as $lAuthorityRelatedByAuthorityIdUpRemoved) {
            $lAuthorityRelatedByAuthorityIdUpRemoved->setAuthorityRelatedByAuthorityIdUp(null);
        }

        $this->collLAuthoritysRelatedByAuthorityIdUp = null;
        foreach ($lAuthoritysRelatedByAuthorityIdUp as $lAuthorityRelatedByAuthorityIdUp) {
            $this->addLAuthorityRelatedByAuthorityIdUp($lAuthorityRelatedByAuthorityIdUp);
        }

        $this->collLAuthoritysRelatedByAuthorityIdUp = $lAuthoritysRelatedByAuthorityIdUp;
        $this->collLAuthoritysRelatedByAuthorityIdUpPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LAuthority objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LAuthority objects.
     * @throws PropelException
     */
    public function countLAuthoritysRelatedByAuthorityIdUp(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLAuthoritysRelatedByAuthorityIdUpPartial && !$this->isNew();
        if (null === $this->collLAuthoritysRelatedByAuthorityIdUp || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLAuthoritysRelatedByAuthorityIdUp) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLAuthoritysRelatedByAuthorityIdUp());
            }
            $query = LAuthorityQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAuthorityRelatedByAuthorityIdUp($this)
                ->count($con);
        }

        return count($this->collLAuthoritysRelatedByAuthorityIdUp);
    }

    /**
     * Method called to associate a LAuthority object to this object
     * through the LAuthority foreign key attribute.
     *
     * @param    LAuthority $l LAuthority
     * @return Authority The current object (for fluent API support)
     */
    public function addLAuthorityRelatedByAuthorityIdUp(LAuthority $l)
    {
        if ($this->collLAuthoritysRelatedByAuthorityIdUp === null) {
            $this->initLAuthoritysRelatedByAuthorityIdUp();
            $this->collLAuthoritysRelatedByAuthorityIdUpPartial = true;
        }

        if (!in_array($l, $this->collLAuthoritysRelatedByAuthorityIdUp->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLAuthorityRelatedByAuthorityIdUp($l);

            if ($this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion and $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion->contains($l)) {
                $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion->remove($this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LAuthorityRelatedByAuthorityIdUp $lAuthorityRelatedByAuthorityIdUp The lAuthorityRelatedByAuthorityIdUp object to add.
     */
    protected function doAddLAuthorityRelatedByAuthorityIdUp($lAuthorityRelatedByAuthorityIdUp)
    {
        $this->collLAuthoritysRelatedByAuthorityIdUp[]= $lAuthorityRelatedByAuthorityIdUp;
        $lAuthorityRelatedByAuthorityIdUp->setAuthorityRelatedByAuthorityIdUp($this);
    }

    /**
     * @param	LAuthorityRelatedByAuthorityIdUp $lAuthorityRelatedByAuthorityIdUp The lAuthorityRelatedByAuthorityIdUp object to remove.
     * @return Authority The current object (for fluent API support)
     */
    public function removeLAuthorityRelatedByAuthorityIdUp($lAuthorityRelatedByAuthorityIdUp)
    {
        if ($this->getLAuthoritysRelatedByAuthorityIdUp()->contains($lAuthorityRelatedByAuthorityIdUp)) {
            $this->collLAuthoritysRelatedByAuthorityIdUp->remove($this->collLAuthoritysRelatedByAuthorityIdUp->search($lAuthorityRelatedByAuthorityIdUp));
            if (null === $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion) {
                $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion = clone $this->collLAuthoritysRelatedByAuthorityIdUp;
                $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion->clear();
            }
            $this->lAuthoritysRelatedByAuthorityIdUpScheduledForDeletion[]= clone $lAuthorityRelatedByAuthorityIdUp;
            $lAuthorityRelatedByAuthorityIdUp->setAuthorityRelatedByAuthorityIdUp(null);
        }

        return $this;
    }

    /**
     * Clears out the collLAuthorityItems collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Authority The current object (for fluent API support)
     * @see        addLAuthorityItems()
     */
    public function clearLAuthorityItems()
    {
        $this->collLAuthorityItems = null; // important to set this to null since that means it is uninitialized
        $this->collLAuthorityItemsPartial = null;

        return $this;
    }

    /**
     * reset is the collLAuthorityItems collection loaded partially
     *
     * @return void
     */
    public function resetPartialLAuthorityItems($v = true)
    {
        $this->collLAuthorityItemsPartial = $v;
    }

    /**
     * Initializes the collLAuthorityItems collection.
     *
     * By default this just sets the collLAuthorityItems collection to an empty array (like clearcollLAuthorityItems());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLAuthorityItems($overrideExisting = true)
    {
        if (null !== $this->collLAuthorityItems && !$overrideExisting) {
            return;
        }
        $this->collLAuthorityItems = new PropelObjectCollection();
        $this->collLAuthorityItems->setModel('LAuthorityItem');
    }

    /**
     * Gets an array of LAuthorityItem objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Authority is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LAuthorityItem[] List of LAuthorityItem objects
     * @throws PropelException
     */
    public function getLAuthorityItems($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLAuthorityItemsPartial && !$this->isNew();
        if (null === $this->collLAuthorityItems || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLAuthorityItems) {
                // return empty collection
                $this->initLAuthorityItems();
            } else {
                $collLAuthorityItems = LAuthorityItemQuery::create(null, $criteria)
                    ->filterByAuthority($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLAuthorityItemsPartial && count($collLAuthorityItems)) {
                      $this->initLAuthorityItems(false);

                      foreach ($collLAuthorityItems as $obj) {
                        if (false == $this->collLAuthorityItems->contains($obj)) {
                          $this->collLAuthorityItems->append($obj);
                        }
                      }

                      $this->collLAuthorityItemsPartial = true;
                    }

                    $collLAuthorityItems->getInternalIterator()->rewind();

                    return $collLAuthorityItems;
                }

                if ($partial && $this->collLAuthorityItems) {
                    foreach ($this->collLAuthorityItems as $obj) {
                        if ($obj->isNew()) {
                            $collLAuthorityItems[] = $obj;
                        }
                    }
                }

                $this->collLAuthorityItems = $collLAuthorityItems;
                $this->collLAuthorityItemsPartial = false;
            }
        }

        return $this->collLAuthorityItems;
    }

    /**
     * Sets a collection of LAuthorityItem objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lAuthorityItems A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Authority The current object (for fluent API support)
     */
    public function setLAuthorityItems(PropelCollection $lAuthorityItems, PropelPDO $con = null)
    {
        $lAuthorityItemsToDelete = $this->getLAuthorityItems(new Criteria(), $con)->diff($lAuthorityItems);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->lAuthorityItemsScheduledForDeletion = clone $lAuthorityItemsToDelete;

        foreach ($lAuthorityItemsToDelete as $lAuthorityItemRemoved) {
            $lAuthorityItemRemoved->setAuthority(null);
        }

        $this->collLAuthorityItems = null;
        foreach ($lAuthorityItems as $lAuthorityItem) {
            $this->addLAuthorityItem($lAuthorityItem);
        }

        $this->collLAuthorityItems = $lAuthorityItems;
        $this->collLAuthorityItemsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LAuthorityItem objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LAuthorityItem objects.
     * @throws PropelException
     */
    public function countLAuthorityItems(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLAuthorityItemsPartial && !$this->isNew();
        if (null === $this->collLAuthorityItems || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLAuthorityItems) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLAuthorityItems());
            }
            $query = LAuthorityItemQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAuthority($this)
                ->count($con);
        }

        return count($this->collLAuthorityItems);
    }

    /**
     * Method called to associate a LAuthorityItem object to this object
     * through the LAuthorityItem foreign key attribute.
     *
     * @param    LAuthorityItem $l LAuthorityItem
     * @return Authority The current object (for fluent API support)
     */
    public function addLAuthorityItem(LAuthorityItem $l)
    {
        if ($this->collLAuthorityItems === null) {
            $this->initLAuthorityItems();
            $this->collLAuthorityItemsPartial = true;
        }

        if (!in_array($l, $this->collLAuthorityItems->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLAuthorityItem($l);

            if ($this->lAuthorityItemsScheduledForDeletion and $this->lAuthorityItemsScheduledForDeletion->contains($l)) {
                $this->lAuthorityItemsScheduledForDeletion->remove($this->lAuthorityItemsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LAuthorityItem $lAuthorityItem The lAuthorityItem object to add.
     */
    protected function doAddLAuthorityItem($lAuthorityItem)
    {
        $this->collLAuthorityItems[]= $lAuthorityItem;
        $lAuthorityItem->setAuthority($this);
    }

    /**
     * @param	LAuthorityItem $lAuthorityItem The lAuthorityItem object to remove.
     * @return Authority The current object (for fluent API support)
     */
    public function removeLAuthorityItem($lAuthorityItem)
    {
        if ($this->getLAuthorityItems()->contains($lAuthorityItem)) {
            $this->collLAuthorityItems->remove($this->collLAuthorityItems->search($lAuthorityItem));
            if (null === $this->lAuthorityItemsScheduledForDeletion) {
                $this->lAuthorityItemsScheduledForDeletion = clone $this->collLAuthorityItems;
                $this->lAuthorityItemsScheduledForDeletion->clear();
            }
            $this->lAuthorityItemsScheduledForDeletion[]= clone $lAuthorityItem;
            $lAuthorityItem->setAuthority(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Authority is new, it will return
     * an empty collection; or if this Authority has previously
     * been saved, it will retrieve related LAuthorityItems from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Authority.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|LAuthorityItem[] List of LAuthorityItem objects
     */
    public function getLAuthorityItemsJoinItem($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LAuthorityItemQuery::create(null, $criteria);
        $query->joinWith('Item', $join_behavior);

        return $this->getLAuthorityItems($query, $con);
    }

    /**
     * Clears out the collLAuthorityManifestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Authority The current object (for fluent API support)
     * @see        addLAuthorityManifestations()
     */
    public function clearLAuthorityManifestations()
    {
        $this->collLAuthorityManifestations = null; // important to set this to null since that means it is uninitialized
        $this->collLAuthorityManifestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collLAuthorityManifestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialLAuthorityManifestations($v = true)
    {
        $this->collLAuthorityManifestationsPartial = $v;
    }

    /**
     * Initializes the collLAuthorityManifestations collection.
     *
     * By default this just sets the collLAuthorityManifestations collection to an empty array (like clearcollLAuthorityManifestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLAuthorityManifestations($overrideExisting = true)
    {
        if (null !== $this->collLAuthorityManifestations && !$overrideExisting) {
            return;
        }
        $this->collLAuthorityManifestations = new PropelObjectCollection();
        $this->collLAuthorityManifestations->setModel('LAuthorityManifestation');
    }

    /**
     * Gets an array of LAuthorityManifestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Authority is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LAuthorityManifestation[] List of LAuthorityManifestation objects
     * @throws PropelException
     */
    public function getLAuthorityManifestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLAuthorityManifestationsPartial && !$this->isNew();
        if (null === $this->collLAuthorityManifestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLAuthorityManifestations) {
                // return empty collection
                $this->initLAuthorityManifestations();
            } else {
                $collLAuthorityManifestations = LAuthorityManifestationQuery::create(null, $criteria)
                    ->filterByAuthority($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLAuthorityManifestationsPartial && count($collLAuthorityManifestations)) {
                      $this->initLAuthorityManifestations(false);

                      foreach ($collLAuthorityManifestations as $obj) {
                        if (false == $this->collLAuthorityManifestations->contains($obj)) {
                          $this->collLAuthorityManifestations->append($obj);
                        }
                      }

                      $this->collLAuthorityManifestationsPartial = true;
                    }

                    $collLAuthorityManifestations->getInternalIterator()->rewind();

                    return $collLAuthorityManifestations;
                }

                if ($partial && $this->collLAuthorityManifestations) {
                    foreach ($this->collLAuthorityManifestations as $obj) {
                        if ($obj->isNew()) {
                            $collLAuthorityManifestations[] = $obj;
                        }
                    }
                }

                $this->collLAuthorityManifestations = $collLAuthorityManifestations;
                $this->collLAuthorityManifestationsPartial = false;
            }
        }

        return $this->collLAuthorityManifestations;
    }

    /**
     * Sets a collection of LAuthorityManifestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lAuthorityManifestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Authority The current object (for fluent API support)
     */
    public function setLAuthorityManifestations(PropelCollection $lAuthorityManifestations, PropelPDO $con = null)
    {
        $lAuthorityManifestationsToDelete = $this->getLAuthorityManifestations(new Criteria(), $con)->diff($lAuthorityManifestations);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->lAuthorityManifestationsScheduledForDeletion = clone $lAuthorityManifestationsToDelete;

        foreach ($lAuthorityManifestationsToDelete as $lAuthorityManifestationRemoved) {
            $lAuthorityManifestationRemoved->setAuthority(null);
        }

        $this->collLAuthorityManifestations = null;
        foreach ($lAuthorityManifestations as $lAuthorityManifestation) {
            $this->addLAuthorityManifestation($lAuthorityManifestation);
        }

        $this->collLAuthorityManifestations = $lAuthorityManifestations;
        $this->collLAuthorityManifestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LAuthorityManifestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LAuthorityManifestation objects.
     * @throws PropelException
     */
    public function countLAuthorityManifestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLAuthorityManifestationsPartial && !$this->isNew();
        if (null === $this->collLAuthorityManifestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLAuthorityManifestations) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLAuthorityManifestations());
            }
            $query = LAuthorityManifestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAuthority($this)
                ->count($con);
        }

        return count($this->collLAuthorityManifestations);
    }

    /**
     * Method called to associate a LAuthorityManifestation object to this object
     * through the LAuthorityManifestation foreign key attribute.
     *
     * @param    LAuthorityManifestation $l LAuthorityManifestation
     * @return Authority The current object (for fluent API support)
     */
    public function addLAuthorityManifestation(LAuthorityManifestation $l)
    {
        if ($this->collLAuthorityManifestations === null) {
            $this->initLAuthorityManifestations();
            $this->collLAuthorityManifestationsPartial = true;
        }

        if (!in_array($l, $this->collLAuthorityManifestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLAuthorityManifestation($l);

            if ($this->lAuthorityManifestationsScheduledForDeletion and $this->lAuthorityManifestationsScheduledForDeletion->contains($l)) {
                $this->lAuthorityManifestationsScheduledForDeletion->remove($this->lAuthorityManifestationsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LAuthorityManifestation $lAuthorityManifestation The lAuthorityManifestation object to add.
     */
    protected function doAddLAuthorityManifestation($lAuthorityManifestation)
    {
        $this->collLAuthorityManifestations[]= $lAuthorityManifestation;
        $lAuthorityManifestation->setAuthority($this);
    }

    /**
     * @param	LAuthorityManifestation $lAuthorityManifestation The lAuthorityManifestation object to remove.
     * @return Authority The current object (for fluent API support)
     */
    public function removeLAuthorityManifestation($lAuthorityManifestation)
    {
        if ($this->getLAuthorityManifestations()->contains($lAuthorityManifestation)) {
            $this->collLAuthorityManifestations->remove($this->collLAuthorityManifestations->search($lAuthorityManifestation));
            if (null === $this->lAuthorityManifestationsScheduledForDeletion) {
                $this->lAuthorityManifestationsScheduledForDeletion = clone $this->collLAuthorityManifestations;
                $this->lAuthorityManifestationsScheduledForDeletion->clear();
            }
            $this->lAuthorityManifestationsScheduledForDeletion[]= clone $lAuthorityManifestation;
            $lAuthorityManifestation->setAuthority(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Authority is new, it will return
     * an empty collection; or if this Authority has previously
     * been saved, it will retrieve related LAuthorityManifestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Authority.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|LAuthorityManifestation[] List of LAuthorityManifestation objects
     */
    public function getLAuthorityManifestationsJoinManifestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LAuthorityManifestationQuery::create(null, $criteria);
        $query->joinWith('Manifestation', $join_behavior);

        return $this->getLAuthorityManifestations($query, $con);
    }

    /**
     * Clears out the collLSubjectsRelatedByAuthorityId collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Authority The current object (for fluent API support)
     * @see        addLSubjectsRelatedByAuthorityId()
     */
    public function clearLSubjectsRelatedByAuthorityId()
    {
        $this->collLSubjectsRelatedByAuthorityId = null; // important to set this to null since that means it is uninitialized
        $this->collLSubjectsRelatedByAuthorityIdPartial = null;

        return $this;
    }

    /**
     * reset is the collLSubjectsRelatedByAuthorityId collection loaded partially
     *
     * @return void
     */
    public function resetPartialLSubjectsRelatedByAuthorityId($v = true)
    {
        $this->collLSubjectsRelatedByAuthorityIdPartial = $v;
    }

    /**
     * Initializes the collLSubjectsRelatedByAuthorityId collection.
     *
     * By default this just sets the collLSubjectsRelatedByAuthorityId collection to an empty array (like clearcollLSubjectsRelatedByAuthorityId());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLSubjectsRelatedByAuthorityId($overrideExisting = true)
    {
        if (null !== $this->collLSubjectsRelatedByAuthorityId && !$overrideExisting) {
            return;
        }
        $this->collLSubjectsRelatedByAuthorityId = new PropelObjectCollection();
        $this->collLSubjectsRelatedByAuthorityId->setModel('LSubject');
    }

    /**
     * Gets an array of LSubject objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Authority is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LSubject[] List of LSubject objects
     * @throws PropelException
     */
    public function getLSubjectsRelatedByAuthorityId($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLSubjectsRelatedByAuthorityIdPartial && !$this->isNew();
        if (null === $this->collLSubjectsRelatedByAuthorityId || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLSubjectsRelatedByAuthorityId) {
                // return empty collection
                $this->initLSubjectsRelatedByAuthorityId();
            } else {
                $collLSubjectsRelatedByAuthorityId = LSubjectQuery::create(null, $criteria)
                    ->filterByAuthorityRelatedByAuthorityId($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLSubjectsRelatedByAuthorityIdPartial && count($collLSubjectsRelatedByAuthorityId)) {
                      $this->initLSubjectsRelatedByAuthorityId(false);

                      foreach ($collLSubjectsRelatedByAuthorityId as $obj) {
                        if (false == $this->collLSubjectsRelatedByAuthorityId->contains($obj)) {
                          $this->collLSubjectsRelatedByAuthorityId->append($obj);
                        }
                      }

                      $this->collLSubjectsRelatedByAuthorityIdPartial = true;
                    }

                    $collLSubjectsRelatedByAuthorityId->getInternalIterator()->rewind();

                    return $collLSubjectsRelatedByAuthorityId;
                }

                if ($partial && $this->collLSubjectsRelatedByAuthorityId) {
                    foreach ($this->collLSubjectsRelatedByAuthorityId as $obj) {
                        if ($obj->isNew()) {
                            $collLSubjectsRelatedByAuthorityId[] = $obj;
                        }
                    }
                }

                $this->collLSubjectsRelatedByAuthorityId = $collLSubjectsRelatedByAuthorityId;
                $this->collLSubjectsRelatedByAuthorityIdPartial = false;
            }
        }

        return $this->collLSubjectsRelatedByAuthorityId;
    }

    /**
     * Sets a collection of LSubjectRelatedByAuthorityId objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lSubjectsRelatedByAuthorityId A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Authority The current object (for fluent API support)
     */
    public function setLSubjectsRelatedByAuthorityId(PropelCollection $lSubjectsRelatedByAuthorityId, PropelPDO $con = null)
    {
        $lSubjectsRelatedByAuthorityIdToDelete = $this->getLSubjectsRelatedByAuthorityId(new Criteria(), $con)->diff($lSubjectsRelatedByAuthorityId);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion = clone $lSubjectsRelatedByAuthorityIdToDelete;

        foreach ($lSubjectsRelatedByAuthorityIdToDelete as $lSubjectRelatedByAuthorityIdRemoved) {
            $lSubjectRelatedByAuthorityIdRemoved->setAuthorityRelatedByAuthorityId(null);
        }

        $this->collLSubjectsRelatedByAuthorityId = null;
        foreach ($lSubjectsRelatedByAuthorityId as $lSubjectRelatedByAuthorityId) {
            $this->addLSubjectRelatedByAuthorityId($lSubjectRelatedByAuthorityId);
        }

        $this->collLSubjectsRelatedByAuthorityId = $lSubjectsRelatedByAuthorityId;
        $this->collLSubjectsRelatedByAuthorityIdPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LSubject objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LSubject objects.
     * @throws PropelException
     */
    public function countLSubjectsRelatedByAuthorityId(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLSubjectsRelatedByAuthorityIdPartial && !$this->isNew();
        if (null === $this->collLSubjectsRelatedByAuthorityId || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLSubjectsRelatedByAuthorityId) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLSubjectsRelatedByAuthorityId());
            }
            $query = LSubjectQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAuthorityRelatedByAuthorityId($this)
                ->count($con);
        }

        return count($this->collLSubjectsRelatedByAuthorityId);
    }

    /**
     * Method called to associate a LSubject object to this object
     * through the LSubject foreign key attribute.
     *
     * @param    LSubject $l LSubject
     * @return Authority The current object (for fluent API support)
     */
    public function addLSubjectRelatedByAuthorityId(LSubject $l)
    {
        if ($this->collLSubjectsRelatedByAuthorityId === null) {
            $this->initLSubjectsRelatedByAuthorityId();
            $this->collLSubjectsRelatedByAuthorityIdPartial = true;
        }

        if (!in_array($l, $this->collLSubjectsRelatedByAuthorityId->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLSubjectRelatedByAuthorityId($l);

            if ($this->lSubjectsRelatedByAuthorityIdScheduledForDeletion and $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion->contains($l)) {
                $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion->remove($this->lSubjectsRelatedByAuthorityIdScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LSubjectRelatedByAuthorityId $lSubjectRelatedByAuthorityId The lSubjectRelatedByAuthorityId object to add.
     */
    protected function doAddLSubjectRelatedByAuthorityId($lSubjectRelatedByAuthorityId)
    {
        $this->collLSubjectsRelatedByAuthorityId[]= $lSubjectRelatedByAuthorityId;
        $lSubjectRelatedByAuthorityId->setAuthorityRelatedByAuthorityId($this);
    }

    /**
     * @param	LSubjectRelatedByAuthorityId $lSubjectRelatedByAuthorityId The lSubjectRelatedByAuthorityId object to remove.
     * @return Authority The current object (for fluent API support)
     */
    public function removeLSubjectRelatedByAuthorityId($lSubjectRelatedByAuthorityId)
    {
        if ($this->getLSubjectsRelatedByAuthorityId()->contains($lSubjectRelatedByAuthorityId)) {
            $this->collLSubjectsRelatedByAuthorityId->remove($this->collLSubjectsRelatedByAuthorityId->search($lSubjectRelatedByAuthorityId));
            if (null === $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion) {
                $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion = clone $this->collLSubjectsRelatedByAuthorityId;
                $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion->clear();
            }
            $this->lSubjectsRelatedByAuthorityIdScheduledForDeletion[]= clone $lSubjectRelatedByAuthorityId;
            $lSubjectRelatedByAuthorityId->setAuthorityRelatedByAuthorityId(null);
        }

        return $this;
    }

    /**
     * Clears out the collLSubjectsRelatedBySubjectId collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Authority The current object (for fluent API support)
     * @see        addLSubjectsRelatedBySubjectId()
     */
    public function clearLSubjectsRelatedBySubjectId()
    {
        $this->collLSubjectsRelatedBySubjectId = null; // important to set this to null since that means it is uninitialized
        $this->collLSubjectsRelatedBySubjectIdPartial = null;

        return $this;
    }

    /**
     * reset is the collLSubjectsRelatedBySubjectId collection loaded partially
     *
     * @return void
     */
    public function resetPartialLSubjectsRelatedBySubjectId($v = true)
    {
        $this->collLSubjectsRelatedBySubjectIdPartial = $v;
    }

    /**
     * Initializes the collLSubjectsRelatedBySubjectId collection.
     *
     * By default this just sets the collLSubjectsRelatedBySubjectId collection to an empty array (like clearcollLSubjectsRelatedBySubjectId());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLSubjectsRelatedBySubjectId($overrideExisting = true)
    {
        if (null !== $this->collLSubjectsRelatedBySubjectId && !$overrideExisting) {
            return;
        }
        $this->collLSubjectsRelatedBySubjectId = new PropelObjectCollection();
        $this->collLSubjectsRelatedBySubjectId->setModel('LSubject');
    }

    /**
     * Gets an array of LSubject objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Authority is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LSubject[] List of LSubject objects
     * @throws PropelException
     */
    public function getLSubjectsRelatedBySubjectId($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLSubjectsRelatedBySubjectIdPartial && !$this->isNew();
        if (null === $this->collLSubjectsRelatedBySubjectId || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLSubjectsRelatedBySubjectId) {
                // return empty collection
                $this->initLSubjectsRelatedBySubjectId();
            } else {
                $collLSubjectsRelatedBySubjectId = LSubjectQuery::create(null, $criteria)
                    ->filterByAuthorityRelatedBySubjectId($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLSubjectsRelatedBySubjectIdPartial && count($collLSubjectsRelatedBySubjectId)) {
                      $this->initLSubjectsRelatedBySubjectId(false);

                      foreach ($collLSubjectsRelatedBySubjectId as $obj) {
                        if (false == $this->collLSubjectsRelatedBySubjectId->contains($obj)) {
                          $this->collLSubjectsRelatedBySubjectId->append($obj);
                        }
                      }

                      $this->collLSubjectsRelatedBySubjectIdPartial = true;
                    }

                    $collLSubjectsRelatedBySubjectId->getInternalIterator()->rewind();

                    return $collLSubjectsRelatedBySubjectId;
                }

                if ($partial && $this->collLSubjectsRelatedBySubjectId) {
                    foreach ($this->collLSubjectsRelatedBySubjectId as $obj) {
                        if ($obj->isNew()) {
                            $collLSubjectsRelatedBySubjectId[] = $obj;
                        }
                    }
                }

                $this->collLSubjectsRelatedBySubjectId = $collLSubjectsRelatedBySubjectId;
                $this->collLSubjectsRelatedBySubjectIdPartial = false;
            }
        }

        return $this->collLSubjectsRelatedBySubjectId;
    }

    /**
     * Sets a collection of LSubjectRelatedBySubjectId objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lSubjectsRelatedBySubjectId A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Authority The current object (for fluent API support)
     */
    public function setLSubjectsRelatedBySubjectId(PropelCollection $lSubjectsRelatedBySubjectId, PropelPDO $con = null)
    {
        $lSubjectsRelatedBySubjectIdToDelete = $this->getLSubjectsRelatedBySubjectId(new Criteria(), $con)->diff($lSubjectsRelatedBySubjectId);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->lSubjectsRelatedBySubjectIdScheduledForDeletion = clone $lSubjectsRelatedBySubjectIdToDelete;

        foreach ($lSubjectsRelatedBySubjectIdToDelete as $lSubjectRelatedBySubjectIdRemoved) {
            $lSubjectRelatedBySubjectIdRemoved->setAuthorityRelatedBySubjectId(null);
        }

        $this->collLSubjectsRelatedBySubjectId = null;
        foreach ($lSubjectsRelatedBySubjectId as $lSubjectRelatedBySubjectId) {
            $this->addLSubjectRelatedBySubjectId($lSubjectRelatedBySubjectId);
        }

        $this->collLSubjectsRelatedBySubjectId = $lSubjectsRelatedBySubjectId;
        $this->collLSubjectsRelatedBySubjectIdPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LSubject objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LSubject objects.
     * @throws PropelException
     */
    public function countLSubjectsRelatedBySubjectId(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLSubjectsRelatedBySubjectIdPartial && !$this->isNew();
        if (null === $this->collLSubjectsRelatedBySubjectId || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLSubjectsRelatedBySubjectId) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLSubjectsRelatedBySubjectId());
            }
            $query = LSubjectQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAuthorityRelatedBySubjectId($this)
                ->count($con);
        }

        return count($this->collLSubjectsRelatedBySubjectId);
    }

    /**
     * Method called to associate a LSubject object to this object
     * through the LSubject foreign key attribute.
     *
     * @param    LSubject $l LSubject
     * @return Authority The current object (for fluent API support)
     */
    public function addLSubjectRelatedBySubjectId(LSubject $l)
    {
        if ($this->collLSubjectsRelatedBySubjectId === null) {
            $this->initLSubjectsRelatedBySubjectId();
            $this->collLSubjectsRelatedBySubjectIdPartial = true;
        }

        if (!in_array($l, $this->collLSubjectsRelatedBySubjectId->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLSubjectRelatedBySubjectId($l);

            if ($this->lSubjectsRelatedBySubjectIdScheduledForDeletion and $this->lSubjectsRelatedBySubjectIdScheduledForDeletion->contains($l)) {
                $this->lSubjectsRelatedBySubjectIdScheduledForDeletion->remove($this->lSubjectsRelatedBySubjectIdScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LSubjectRelatedBySubjectId $lSubjectRelatedBySubjectId The lSubjectRelatedBySubjectId object to add.
     */
    protected function doAddLSubjectRelatedBySubjectId($lSubjectRelatedBySubjectId)
    {
        $this->collLSubjectsRelatedBySubjectId[]= $lSubjectRelatedBySubjectId;
        $lSubjectRelatedBySubjectId->setAuthorityRelatedBySubjectId($this);
    }

    /**
     * @param	LSubjectRelatedBySubjectId $lSubjectRelatedBySubjectId The lSubjectRelatedBySubjectId object to remove.
     * @return Authority The current object (for fluent API support)
     */
    public function removeLSubjectRelatedBySubjectId($lSubjectRelatedBySubjectId)
    {
        if ($this->getLSubjectsRelatedBySubjectId()->contains($lSubjectRelatedBySubjectId)) {
            $this->collLSubjectsRelatedBySubjectId->remove($this->collLSubjectsRelatedBySubjectId->search($lSubjectRelatedBySubjectId));
            if (null === $this->lSubjectsRelatedBySubjectIdScheduledForDeletion) {
                $this->lSubjectsRelatedBySubjectIdScheduledForDeletion = clone $this->collLSubjectsRelatedBySubjectId;
                $this->lSubjectsRelatedBySubjectIdScheduledForDeletion->clear();
            }
            $this->lSubjectsRelatedBySubjectIdScheduledForDeletion[]= clone $lSubjectRelatedBySubjectId;
            $lSubjectRelatedBySubjectId->setAuthorityRelatedBySubjectId(null);
        }

        return $this;
    }

    /**
     * Gets a single TurbomarcauthorityCache object, which is related to this object by a one-to-one relationship.
     *
     * @param PropelPDO $con optional connection object
     * @return TurbomarcauthorityCache
     * @throws PropelException
     */
    public function getTurbomarcauthorityCache(PropelPDO $con = null)
    {

        if ($this->singleTurbomarcauthorityCache === null && !$this->isNew()) {
            $this->singleTurbomarcauthorityCache = TurbomarcauthorityCacheQuery::create()->findPk($this->getPrimaryKey(), $con);
        }

        return $this->singleTurbomarcauthorityCache;
    }

    /**
     * Sets a single TurbomarcauthorityCache object as related to this object by a one-to-one relationship.
     *
     * @param                  TurbomarcauthorityCache $v TurbomarcauthorityCache
     * @return Authority The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTurbomarcauthorityCache(TurbomarcauthorityCache $v = null)
    {
        $this->singleTurbomarcauthorityCache = $v;

        // Make sure that that the passed-in TurbomarcauthorityCache isn't already associated with this object
        if ($v !== null && $v->getAuthority(null, false) === null) {
            $v->setAuthority($this);
        }

        return $this;
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->authority_id = null;
        $this->non_sort_text = null;
        $this->sort_text = null;
        $this->full_text = null;
        $this->authority_type = null;
        $this->authority_subtype = null;
        $this->authority_rectype = null;
        $this->authority_status = null;
        $this->unimarc = null;
        $this->ext_data = null;
        $this->authority_lang = null;
        $this->authority_codlevel = null;
        $this->parent_id = null;
        $this->subject_class = null;
        $this->class_code = null;
        $this->bid_source = null;
        $this->bid = null;
        $this->last_sbn_sync = null;
        $this->date_created = null;
        $this->date_updated = null;
        $this->created_by = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collAuthoritysRelatedByAuthorityId) {
                foreach ($this->collAuthoritysRelatedByAuthorityId as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLAuthoritysRelatedByAuthorityIdDown) {
                foreach ($this->collLAuthoritysRelatedByAuthorityIdDown as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLAuthoritysRelatedByAuthorityIdUp) {
                foreach ($this->collLAuthoritysRelatedByAuthorityIdUp as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLAuthorityItems) {
                foreach ($this->collLAuthorityItems as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLAuthorityManifestations) {
                foreach ($this->collLAuthorityManifestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLSubjectsRelatedByAuthorityId) {
                foreach ($this->collLSubjectsRelatedByAuthorityId as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLSubjectsRelatedBySubjectId) {
                foreach ($this->collLSubjectsRelatedBySubjectId as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->singleTurbomarcauthorityCache) {
                $this->singleTurbomarcauthorityCache->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByCreatedBy instanceof Persistent) {
              $this->aLibrarianRelatedByCreatedBy->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByModifiedBy instanceof Persistent) {
              $this->aLibrarianRelatedByModifiedBy->clearAllReferences($deep);
            }
            if ($this->aAuthorityRelatedByParentId instanceof Persistent) {
              $this->aAuthorityRelatedByParentId->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collAuthoritysRelatedByAuthorityId instanceof PropelCollection) {
            $this->collAuthoritysRelatedByAuthorityId->clearIterator();
        }
        $this->collAuthoritysRelatedByAuthorityId = null;
        if ($this->collLAuthoritysRelatedByAuthorityIdDown instanceof PropelCollection) {
            $this->collLAuthoritysRelatedByAuthorityIdDown->clearIterator();
        }
        $this->collLAuthoritysRelatedByAuthorityIdDown = null;
        if ($this->collLAuthoritysRelatedByAuthorityIdUp instanceof PropelCollection) {
            $this->collLAuthoritysRelatedByAuthorityIdUp->clearIterator();
        }
        $this->collLAuthoritysRelatedByAuthorityIdUp = null;
        if ($this->collLAuthorityItems instanceof PropelCollection) {
            $this->collLAuthorityItems->clearIterator();
        }
        $this->collLAuthorityItems = null;
        if ($this->collLAuthorityManifestations instanceof PropelCollection) {
            $this->collLAuthorityManifestations->clearIterator();
        }
        $this->collLAuthorityManifestations = null;
        if ($this->collLSubjectsRelatedByAuthorityId instanceof PropelCollection) {
            $this->collLSubjectsRelatedByAuthorityId->clearIterator();
        }
        $this->collLSubjectsRelatedByAuthorityId = null;
        if ($this->collLSubjectsRelatedBySubjectId instanceof PropelCollection) {
            $this->collLSubjectsRelatedBySubjectId->clearIterator();
        }
        $this->collLSubjectsRelatedBySubjectId = null;
        if ($this->singleTurbomarcauthorityCache instanceof PropelCollection) {
            $this->singleTurbomarcauthorityCache->clearIterator();
        }
        $this->singleTurbomarcauthorityCache = null;
        $this->aLibrarianRelatedByCreatedBy = null;
        $this->aLibrarianRelatedByModifiedBy = null;
        $this->aAuthorityRelatedByParentId = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(AuthorityPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Authority The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[] = AuthorityPeer::DATE_UPDATED;

        return $this;
    }

    // librariantrace behavior

    /**
     * Returns the complete name of the librarian that created this object.
     *
     * @return string
     */
    public function getCreatedByNameString()
    {
        $l = $this->getLibrarianRelatedByCreatedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Returns the complete name of the librarian that last updated this object.
     *
     * @return string
     */
    public function getModifiedByNameString()
    {
        $l = $this->getLibrarianRelatedByModifiedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Authority The current object (for fluent API support)
     */
    public function keepUpdateLibrarianUnchanged()
    {
        $this->modifiedColumns[] = AuthorityPeer::MODIFIED_BY;
        return $this;
    }

}
