<?php

// include base peer class
require_once 'clavis/om/BasePurchaseOrderPeer.php';
  
// include object class
include_once 'clavis/PurchaseOrder.php';

class PurchaseOrderPeer extends BasePurchaseOrderPeer 
{
	const STATUS_OPEN = 'A';
	const STATUS_CLOSED = 'B';
	const STATUS_SENT = 'C';
	const STATUS_PARTDISPATCHED = 'D';
	const STATUS_FULLDISPATCHED = 'E';
	
	const TYPE_DUMMY = 'A';
	const TYPE_SUPPLIER = 'B';
	const TYPE_SUBSCRIPTION = 'C';

	public function orders2array($criteria = null)
	{
		$output = array();
		if (!($criteria instanceof Criteria))
			$criteria = new Criteria();
		
		$orders = PurchaseOrderPeer::doSelect($criteria);
		
		foreach ($orders as $order)
		{
			$orderId = intval($order->getOrderId());
			$orderTitle = trim($order->getOrderTitle());
			if ($orderTitle == '')
				$orderTitle = (string) $orderId;
			
			if (($orderId > 0) && ($orderTitle != ''))
				$output[$orderId] = $orderTitle;
		}
		
		return $output;
	}

} // PurchaseOrderPeer
