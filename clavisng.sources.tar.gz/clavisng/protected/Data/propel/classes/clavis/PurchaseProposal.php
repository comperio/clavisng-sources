<?php

require_once 'clavis/om/BasePurchaseProposal.php';

class PurchaseProposal extends BasePurchaseProposal {

	/* It returns a string with the value, taken from lookupvalue
	 * table, relative to the status of this proposal.
	 * 
	 * @return string
	 */
	public function getStatusString() {
		return LookupValuePeer::getLookupValue('PROPOSALSTATUS',$this->getStatus());
	}

	public function getProposalLabel() {
		$label = $this->getTitle();
		if (trim($this->getRda()))
			$label .= " (RDA: {$this->getRda()})";
		return $label;
	}

	public function getManifestationId() {
		$i = $this->getItem();
		return ($i instanceof Item) ? $i->getManifestationId() : null;
	}

	public function getManifestation() {
		$i = $this->getItem();
		return ($i instanceof Item) ? $i->getManifestation() : (object)null;
	}

	public function getItemTitle() {
		$i = $this->getItem();
		return ($i instanceof Item) ? $i->getTitle() : '';
	}
} // PurchaseProposal
