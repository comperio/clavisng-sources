<?php
/**
 * SupplierPeer class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once 'clavis/om/BaseSupplierPeer.php';
include_once 'clavis/Supplier.php';

/**
 * SupplierPeer Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */

class SupplierPeer extends BaseSupplierPeer {

	/**
	 * Get a list of supplier based on a start string and optional criterions.
	 *
	 * @param string $token The string to use as a base search.
	 * @param integer $limit The maximum of librarians to return (defaults to 10).
	 * @param Array $criterions Optional criterions to further filter the results.
	 * @return Array A list of Suppliers.
	 */
	public static function doSuggest($token,$limit=10) {
		$list = SupplierQuery::create()
			->filterBySupplierName($token.'%')
			->orderBySupplierName()
			->limit($limit)
			->find();
		return $list;
	}
	
	public static function findAll2DataSource(	$withBlank = false,
											$limit = null,
											$trim = null)
	{
		$trim = intval($trim);
		if ($trim > 0)
			$labelBlock = "LEFT(supplier_name, " . $trim .")";
		else
			$labelBlock = "supplier_name";
		
		$queryString = "SELECT supplier_id AS id, " . $labelBlock . " AS label FROM supplier ORDER BY supplier_id";
		$limit = intval($limit);
		if ($limit > 0)
			$queryString .= " LIMIT " . $limit;

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();

		$output = array();
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$output[$row['id']] = $row['label'];
		
		if ($withBlank === true)
		{
			$output[-1] = '---';
			ksort($output);
		}
		
		return $output;
	}
	
} // SupplierPeer
