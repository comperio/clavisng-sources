<?php

require_once 'clavis/om/BaseAppModulePeer.php';
include_once 'clavis/AppModule.php';

class AppModulePeer extends BaseAppModulePeer {

} // AppModulePeer
