<?php

/**
 * PurchaseProposalPeer class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */

require_once 'clavis/om/BasePurchaseProposalPeer.php';
include_once 'clavis/PurchaseProposal.php';

class PurchaseProposalPeer extends BasePurchaseProposalPeer {
	const STATUS_PENDING = 'A';
	const STATUS_ACCEPTED = 'B';
	const STATUS_REFUSED = 'C';
	const STATUS_RETIRED = 'D';
	const STATUS_FULFILLED = 'E';

} // PurchaseProposalPeer
