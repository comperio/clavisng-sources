<?php
/**
 * Issue class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseIssue.php';

/**
 * Issue class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class Issue extends BaseIssue {

	public $_oldValues = array();
	private $_baseChanged = false;

	public function preSave(PropelPDO $con = null)
	{
		if ($this->getEndNumber() < $this->getStartNumber())
			$this->setEndNumber($this->getStartNumber());
		return true;
	}

	public function preDelete(PropelPDO $con = null)
	{
		$canDelete = ItemQuery::create()
			->filterByIssueId($this->getIssueId())
			->filterByIssueStatus(ItemPeer::ISSUESTATUS_ARRIVED)
			->count();
		if ($canDelete > 0) {
			throw new Exception('Cannot delete an issue with arrived items attached.', 1);
			return false;
		}
		return true;
	}

	public function postSave(PropelPDO $con = null)
	{
		$retval = true;
		$m = $this->getManifestation();
		if ($m instanceof Manifestation)
			$m->invalidateCache();
		if (method_exists('ObjectTriggers','onIssueSave'))
			$retval = ObjectTriggers::onIssueSave($this);
		return $retval;
	}

	public function postInsert(PropelPDO $con = null)
	{
		$retval = true;
		if (method_exists('ObjectTriggers','onIssueInsert'))
			$retval = ObjectTriggers::onIssueInsert($this);
		return $retval;
	}

	public function postUpdate(PropelPDO $con = null)
	{
		$retval = true;
		if (method_exists('ObjectTriggers','onIssueUpdate'))
			$retval = ObjectTriggers::onIssueUpdate($this);
		return $retval;
	}

	public function postDelete(PropelPDO $con = null)
	{
		$retval = true;
		if (method_exists('ObjectTriggers','onIssueDelete'))
			$retval = ObjectTriggers::onIssueDelete($this);
		return $retval;
	}

	public function updateLinkedItems()
	{
		foreach ($this->getItems() as $i) {
			$i->setIssueNumber($this->getStartNumber());
			$i->setIssueDescription($this->getIssueNumber());
			$i->save();
		}
	}

	public function setIssueVolume($v) {
		$this->_baseChanged = ( $v != $this->getIssueVolume());
		parent::setIssueVolume($v);
	}

	public function setStartNumber($v) {
		if (!$this->isNew())
			$this->_oldValues['startNumber'] = $this->getStartNumber();
		parent::setStartNumber($v);
	}

	public function setEndNumber($v) {
		if (!$this->isNew())
			$this->_oldValues['endNumber'] = $this->getEndNumber();
		parent::setEndNumber($v);
	}

	public function getIssueCombo($verbose = true)
	{
		$issueNote = $this->getIssueNote();
		if (trim($issueNote))
			$issueNote = ' ('.trim($issueNote).')';
		$issueNum = $this->getIssueNumber();
		$issueYear = $this->getIssueYear();
		if ($verbose) {
			$issueNote =  ' - '.LookupValuePeer::getLookupValue('ISSUETYPE',$this->getIssueType()).$issueNote;
		}
		return "{$issueNum}/{$issueYear}{$issueNote}";
	}

	/**
	 * It returns the id of the issue (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->issue_id;
	}

	public function getAnalytics() {
		$cup = new Criteria();
		$cup->add(LManifestationPeer::ISSUE_ID,$this->getIssueId());
		$cdown = clone $cup;
		$cup->add(LManifestationPeer::MANIFESTATION_ID_UP,$this->getManifestationId());
		$cup->clearSelectColumns()->addSelectColumn(LManifestationPeer::MANIFESTATION_ID_DOWN);
		$cdown->add(LManifestationPeer::MANIFESTATION_ID_DOWN,$this->getManifestationId());
		$cup->clearSelectColumns()->addSelectColumn(LManifestationPeer::MANIFESTATION_ID_UP);

		$stmt = LManifestationPeer::doSelectStmt($cup);
		$man_ids = $stmt->fetchAll(PDO::FETCH_COLUMN,0);
		$stmt = LManifestationPeer::doSelectStmt($cdown);
		$man_ids += $stmt->fetchAll(PDO::FETCH_COLUMN,0);

		$c = new Criteria();
		$c->add(ManifestationPeer::BIB_LEVEL,ManifestationPeer::LVL_ANALYTIC);
		$c->add(ManifestationPeer::MANIFESTATION_ID,$man_ids,Criteria::IN);

		return ManifestationPeer::doSelect($c);
	}

	public function getCompleteTitle() {
		return $this->getManifestation()->getCompleteTitle().' (fasc: '.$this->getIssueCombo(false).')';
	}

	public function getNavigateUrl()
	{
		return IssuePeer::getNavigateUrl();
	}
	
	public function isLoanableByMyLibrary($myLibraryId = null)
	{
		$loanmanager = Prado::getApplication()->getModule("loan");

		if ($myLibraryId == null)
			$myLibraryId = Prado::getApplication()->getUser()->getActualLibraryId();
		
		$criteria = new Criteria();
		$criteria->add(ItemPeer::ACTUAL_LIBRARY_ID, $myLibraryId);

		$criteria->add(ItemPeer::LOAN_CLASS, $loanmanager->CollectItemAvailableClass(), Criteria::IN);
		$criteria->add(ItemPeer::LOAN_STATUS, $loanmanager->CollectItemAvailableStati(), Criteria::IN);

		$itemCount = $this->countItems($criteria);
		return ($itemCount > 0);
	}

	public function isLoanableByAll()
	{
		$loanmanager = Prado::getApplication()->getModule("loan");
		$criteria = new Criteria();

		$criteria->add(ItemPeer::LOAN_CLASS, $loanmanager->CollectItemAvailableClass(), Criteria::IN);
		$criteria->add(ItemPeer::LOAN_STATUS, $loanmanager->CollectItemAvailableStati(), Criteria::IN);

		$itemCount = $this->countItems($criteria);
		return ($itemCount > 0);
	}

	/**
	 * It replaces all the references of $issueSource whith the ones in $issueDestination
	 * and deletes $issueSource
	 *
	 * @param Issue $issueDestination : destination Issue
	 * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
	 *
	 * @return boolean (transaction result)
	 */
	public function replaceWith(Issue $dst, $clavisLibrarian = null)
	{
		$arrRowsAffected = array(); //associative array (key: db table, value: num of rows affected by update)
		$dst_id = $dst->getIssueId();
		if ($this->issue_id == $dst_id)
			return false;

		if (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian)
			throw new Exception('Wrong ClavisLibrarian');
		/* @var $_connection Connection */
		$_connection = Propel::getConnection();

		try {
			$_connection->beginTransaction();
			$destIssueNumber = $dst->getStartNumber();
			$destIssueDescription = $dst->getIssueNumber();
			$arrRowsAffected['item'] = ItemQuery::create()
				->filterByIssueId($this->issue_id)
				->update(array('IssueId' => $dst_id, 'IssueNumber' => $destIssueNumber,
					'IssueDescription' => $destIssueDescription),$_connection);

			$arrRowsAffected['l_manifestation'] = LManifestationQuery::create()
				->filterByIssueId($this->issue_id)
				->update(array('IssueId' => $dst_id),$_connection);

			$this->delete();
			$_connection->commit();

			if (count($arrRowsAffected) >0) {
				$description = "Fascicolo con id = {$this->issue_id}";
				foreach ($arrRowsAffected as $table => $count)
					if ($count > 0)
						$description .= " [$table : $count entry]";
				$description .= " schiacciato su fascicolo con id = {$dst_id}";
				ChangelogPeer::logAction($dst, ChangelogPeer::LOG_UPDATE, $clavisLibrarian, $description);
			}
		} catch (PropelException $e) {
			$_connection->rollback();
			Prado::log('Error in '.__CLASS__.'::'.__FUNCTION__.'(): .'.$e);
			return false;
		}
		return true;
	}

} // Issue
