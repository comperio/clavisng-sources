<?php

require_once 'clavis/om/BaseBulletin.php';

class Bulletin extends BaseBulletin
{
	/**
	 * It returns the id of this object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->bulletin_id;
	}

	public function getTitle()
	{
		$title = $this->title;

		if (is_null($title) && ($title == ''))
			$title = '(senza titolo)';

		return $title;
	}

} // Bulletin
