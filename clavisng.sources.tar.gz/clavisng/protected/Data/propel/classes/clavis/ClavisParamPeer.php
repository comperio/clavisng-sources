<?php

/**
 * ClavisParamPeer class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
require_once 'clavis/om/BaseClavisParamPeer.php';

include_once 'clavis/ClavisParam.php';

class ClavisParamPeer extends BaseClavisParamPeer {

	public static function getParam($class, $name = null, $libraryId = 0, $librarianId = 0)
	{
        if(class_exists("Prado") && php_sapi_name()!=='cli')
        {
            $cacheKey = Prado::getApplication()->getID() . "-PARAM-{$class}-{$name}-{$libraryId}-{$librarianId}";
            if(apc_exists($cacheKey)) return apc_fetch($cacheKey);
        }
        else
        {
            $cacheKey = null;
        }

		$q = ClavisParamQuery::create()
			->filterByParamClass($class);
		if (!is_null($name))
			$q->filterByParamName($name);
		if (intval($libraryId) > 0)
			$q->filterByLibraryId($libraryId);
		if (intval($librarianId) > 0)
			$q->filterByLibrarianId($librarianId);

		if ($q->count() < 1)
        {
            $value = '';
        }
        else
        {
            $value = $q->findOne()->getParamValue();

        }

        if($cacheKey != null) apc_store($cacheKey,$value);

		return $value;
	}

	public static function getClassParams($class, $libraryId = 0, $librarianId = 0)
	{
        if(class_exists("Prado") && php_sapi_name()!=='cli')
        {
            $cacheKey = Prado::getApplication()->getID() . "-PARAM-{$class}-{$libraryId}-{$librarianId}";
            if(apc_exists($cacheKey)) return apc_fetch($cacheKey);
        }
        else
        {
            $cacheKey = null;
        }

		$q = ClavisParamQuery::create()
			->filterByParamClass($class);
		if (intval($libraryId) > 0)
			$q->filterByLibraryId($libraryId);
		if (intval($librarianId) > 0)
			$q->filterByLibrarianId($librarianId);
		$labels = array();

		foreach ($q->find() as $param)
			$labels[$param->getParamName()] = $param->getParamValue();

        if($cacheKey != null) apc_store($cacheKey,$labels);

		return $labels;
	}
} // ClavisParamPeer
