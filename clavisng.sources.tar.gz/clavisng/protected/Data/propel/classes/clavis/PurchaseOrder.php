<?php

/**
 * PurchaseOrder.php file
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 20 Comperio srl
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */

require_once 'clavis/om/BasePurchaseOrder.php';

/**
 * PurchaseOrder class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @package propel.generator.clavis
 * @since 2.0
 */
class PurchaseOrder extends BasePurchaseOrder {

	/**
	 * Wrapper: it returns the id of the object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->order_id;
	}

	/**
	 * Helper method which returns the order library label.
	 *
	 * @return string The library label, empty string if order isn't associated to a library
	 */
	public function getLibraryLabel()
	{
		$library = $this->getLibrary();
		return ($library instanceof Library) ? $library->getLabel() : '';
	}

	/**
	 * Helper method which returns the order supplier name.
	 *
	 * @return string The supplier name, empty string if order doesn't have a supplier
	 */
	public function getSupplierName()
	{
		$supplier = $this->getSupplier();
		return ($supplier instanceof Supplier) ? $supplier->getSupplierName() : '';
	}

	public function addItemToOrder(	$manifestationId = null,
										$myLibraryId = null,
										$currencyValue = 0,
										$inventoryValue = 0,
										$budgetId = null)
	{
		$manifestation = null;
		$manifestationId = intval($manifestationId);
		if ($manifestationId > 0)
			$manifestation = ManifestationQuery::create()->findPK($manifestationId);
		if (!($manifestation instanceof Manifestation))
			return null;

		$actualLibrary = null;
		$myLibraryId = intval($myLibraryId);
		if ($myLibraryId > 0)
			$actualLibrary = LibraryQuery::create()->findPK($myLibraryId);
		if (!($actualLibrary instanceof Library))
			return null;
		
		$orderLibrary = $this->getLibrary();
		if ($orderLibrary instanceof Library)
			$orderLibraryId = $orderLibrary->getLibraryId();
		else
			$orderLibraryId = $myLibraryId;

		/// parameters are ok
		try
		{
			$item = new Item();
			$item->setManifestationId($manifestationId);
			$item->setItemMedia(Clavis::BibtypeToItemmedia($manifestation->getBibType()));
			$item->setOrderId($this->getOrderId());
            $item->setSupplierId($this->getSupplierId());
			$item->setItemStatus(ItemStatus::ITEMSTATUS_INORDER);
			$item->setItemOrderStatus(itemstatus::ITEMORDERSTATUS_INORDER);
			$item->setLoanClass(ItemPeer::LOANCLASS_UNAVAILABLE);
			$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
			$item->setTitle($manifestation->getTitle());

            $item->setOwnerLibraryId($orderLibraryId);
			$item->setHomeLibraryId($orderLibraryId);
			$item->setActualLibraryId($orderLibraryId);
			
			$item->setCurrencyValue(number_format($currencyValue, 2));
			$item->setInventoryValue(number_format($inventoryValue, 2));

			$item->setBudgetId($budgetId);
			
            $item->setDateDiscarded(null);
			
			$item->save();

			ChangelogPeer::logAction($item, ChangelogPeer::LOG_CREATE, Prado::getApplication()->getUser(),
										'Creato nuovo esemplare in ordine (item_id: ' . $item->getItemId() . ')');

			return $item->getItemId();
		}
		catch (Exception $e)
		{
			//throw $e;
     		return null;
		}
	}

	public function deleteLastItemFromOrder($manifestationId = null, $ownerLibraryId = null)
	{
		$manifestationId = intval($manifestationId);
		$ownerLibraryId = intval($ownerLibraryId);
		if ($manifestationId * $ownerLibraryId == 0)
			return null;

		$criteria = new Criteria();
		$criteria->add(ItemPeer::ORDER_ID, $this->getOrderId());
		$criteria->add(ItemPeer::ITEM_STATUS, ItemStatus::ITEMSTATUS_INORDER);
		$criteria->add(ItemPeer::OWNER_LIBRARY_ID, $ownerLibraryId);
		$criteria->add(ItemPeer::MANIFESTATION_ID, $manifestationId);
		$criteria->addDescendingOrderByColumn(ItemPeer::ITEM_ID);

		$item = ItemPeer::doSelectOne($criteria);
		if (!($item instanceof Item))
			return null;

		$itemId = $item->getItemId();

		try
		{
			$item->delete();
			return $itemId;
		}
		catch (Exception $e)
		{
     		return null;
		}
	}

	public function getCurrencies()
	{
		$statement = Propel::getConnection()->prepare(	"SELECT SUM(" . ItemPeer::CURRENCY_VALUE . "), "
														. "SUM(" . ItemPeer::INVENTORY_VALUE . ") FROM " . ItemPeer::TABLE_NAME .
															" WHERE " . ItemPeer::ORDER_ID . " = :value" .
															" AND "	. ItemPeer::ITEM_ORDER_STATUS . " != '" . ItemStatus::ITEMORDERSTATUS_ORDERNULL . "'");
			$statement->execute(array(':value' => $this->getOrderId()));

			$result = $statement->fetch();
			return array(	InvoicePeer::CURRENCY_AMOUNT_VALUE => $result[0], 
							InvoicePeer::INVENTORY_AMOUNT_VALUE => $result[1]);
	}
	
	public function getInventoryAmountValue()
	{
		$currencies = $this->getCurrencies();
		
		if (array_key_exists(InvoicePeer::INVENTORY_AMOUNT_VALUE, $currencies))
			return $currencies[InvoicePeer::INVENTORY_AMOUNT_VALUE];
	}
	
	public function getOrderStatusString($value = null)
	{
		if (is_null($value))
			$status = $this->getOrderStatus();
		else
			$status = $value;

		if (!is_null($status))
		{
			$label = LookupValuePeer::getLookupValue('PURCHASEORDERSTATUS', $status);
			return $label;
		}
		else
		{
			return '--';
		}
	}
	
	public function recalculateOrderStatus()
	{
		$c = new Criteria();
		$c->add(ItemPeer::ITEM_STATUS, ItemStatus::ITEMORDERSTATUS_INORDER);
		$itemsInOrderCount = $this->countItems($c);
		$order_status = ($itemsInOrderCount > 0) 
							? PurchaseOrderPeer::STATUS_PARTDISPATCHED 
							: PurchaseOrderPeer::STATUS_FULLDISPATCHED;
		
		$this->setOrderStatus($order_status);
		$this->save();
	}
	
	
} // PurchaseOrder
