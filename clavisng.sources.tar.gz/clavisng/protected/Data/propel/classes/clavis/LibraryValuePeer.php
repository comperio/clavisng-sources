<?php

// include base peer class
require_once 'clavis/om/BaseLibraryValuePeer.php';

// include object class
include_once 'clavis/LibraryValue.php';

class LibraryValuePeer extends BaseLibraryValuePeer {

	const DEFAULTBLANKLABEL = '';

	public static $_localCache = array();

	/**
	 * Returns the label for a given class/key pair.
	 *
	 * @param string $class The class for the library value.
	 * @param string $key The key for the library value.
	 * @param string $libraryId The ID for the library (defaults to 0).
	 * @return string The label associated for the given class/key pair.
	 */
	public static function getLibraryValue($class, $key, $libraryId=0) {
	    $cacheKey = $class.'-'.$key.'-'.$libraryId;
		if (! array_key_exists($cacheKey,self::$_localCache)) {
			$c = new Criteria();
			$c->add(LibraryValuePeer::VALUE_CLASS , $class);
     		$c->add(LibraryValuePeer::VALUE_KEY, $key);
     		if (intval($libraryId)>0)
				$c->add(LibraryValuePeer::VALUE_LIBRARY_ID, $libraryId);
			$values = LibraryValuePeer::doSelect($c);
			/* if not found, DO NOT fallback */
			self::$_localCache[$cacheKey] = (count($values) > 0) ?
				$values[0]->getValueLabel() : '';
		}
		return self::$_localCache[$cacheKey];
	}

	/**
	 * Returns an hash of key => label for a given library class.
	 *
	 * @param string $class The wanted class.
	 * @param int $libraryId The specified library ID, defaults to 0.
	 * @param boolean $sorted Whether the list should be sorted by label.
	 * @param int $labelLength The max length for the label. 0 for no-trimming (default)
	 * @return Array The hash for the given library class.
	 */
	public static function getLibraryClassValues($class, $libraryId=0, $sorted=false, $labelLength=null) {
		$values = array();
		$c = new Criteria();
		$c->add(self::VALUE_CLASS, $class);
		if (intval($libraryId) > 0)
			$c->add(self::VALUE_LIBRARY_ID, intval($libraryId));
		if ($sorted)
			$c->addAscendingOrderByColumn(self::VALUE_LABEL);
		$values = self::doSelect($c);
		if (count($values) > 0) {
			$dataSource = array();
			/* @var $value LibraryValue */
			foreach ($values as $value) {
				$dataSource[$value->getValueKey()] = $value->getTrimmedValueLabel($labelLength);
			}
		} else {
			$dataSource = array();
		}
		return $dataSource;
	}
} // LibraryValuePeer