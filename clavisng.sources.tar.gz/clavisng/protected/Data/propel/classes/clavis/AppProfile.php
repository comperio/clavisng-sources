<?php

require_once 'clavis/om/BaseAppProfile.php';

class AppProfile extends BaseAppProfile {

} // AppProfile
