<?php
/**
 * Item class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once 'clavis/om/BaseItem.php';

/**
 * Item Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class Item extends BaseItem {

	public $_oldValues = array();

	public function preDelete(PropelPDO $con = null) {
		foreach ($this->getItemNotes() as $n)
			$n->delete();
		return true;
	}

	public function preInsert(PropelPDO $con = null)
	{
		$this->setOpacVisibleUponStatus();
		return true;
	}

	public function preUpdate(PropelPDO $con = null)
	{
		if ($this->isColumnModified(ItemPeer::ITEM_STATUS)) {
			$this->setOpacVisibleUponStatus();
			$this->setDiscardedUponStatus();
		}
		return true;
	}

	public function postSave(PropelPDO $con = null)
	{
		$retval = true;
		if ($this->manifestation_id > 0)
			TurbomarcCachePeer::invalidate($this->manifestation_id);
		if (method_exists('ObjectTriggers','onItemSave'))
			$retval = ObjectTriggers::onItemSave($this);
		return $retval;
	}

	public function postInsert(PropelPDO $con = null)
	{
		$retval = true;
		if (method_exists('ObjectTriggers','onItemInsert'))
			$retval = ObjectTriggers::onItemInsert($this);
		return $retval;
	}

	public function postUpdate(PropelPDO $con = null)
	{
		$retval = true;
		if (method_exists('ObjectTriggers','onItemUpdate'))
			$retval = ObjectTriggers::onItemUpdate($this);
		return $retval;
	}

	public function postDelete(PropelPDO $con = null)
	{
		$retval = true;
		if (method_exists('ObjectTriggers','onItemDelete'))
			$retval = ObjectTriggers::onItemDelete($this);
		return $retval;
	}

	public function getCustomField1String() {
		return LookupValuePeer::classExists('ITEMCUST1')
			? LookupValuePeer::getLookupValue('ITEMCUST1', self::getCustomField1())
			: self::getCustomField1();
	}

	public function getCustomField2String() {
		return LookupValuePeer::classExists('ITEMCUST2')
			? LookupValuePeer::getLookupValue('ITEMCUST2', self::getCustomField2())
			: self::getCustomField2();
	}

	public function getCustomField3String() {
		return LookupValuePeer::classExists('ITEMCUST3')
			? LookupValuePeer::getLookupValue('ITEMCUST3', self::getCustomField3())
			: self::getCustomField3();
	}

	/**
	 * Checks if an item is safely deletable (i.e. doesn't link).
	 *
	 * @return boolean True if item doesn't have any link, false elsewhere.
	 */
	public function isDeleteable()
	{
		try {
			// if item is unsaved reload should fail, so catch and let it pass
			$this->reload(true);
		} catch (Exception $e) {}
		$linkcount = $this->countLoansRelatedByItemId() + $this->budget_id + $this->invoice_id + $this->order_id;
		return $linkcount < 1;
	}

	/**
	 * This function sets opac_visible value upon status, based upon function in ItemStatus class.
	 */
	private function setOpacVisibleUponStatus()
	{
		if ($this->isNew() || !$this->isColumnModified(ItemPeer::OPAC_VISIBLE))
			$this->setOpacVisible(in_array($this->getItemStatus(),ItemStatus::getItemStatusOpacVisible()));
	}

	/**
	 * This function sets opac_visible value upon status, based upon function in ItemStatus class.
	 */
	private function setDiscardedUponStatus()
	{
		// if date discarded is not already set, previous status WAS NOT discarded, and now it is.
		if (!$this->date_discarded &&
				isset($this->_oldValues['itemStatus']) &&
				ItemStatus::ITEMSTATUS_DISCARDED != $this->_oldValues['itemStatus'] &&
				ItemStatus::ITEMSTATUS_DISCARDED == $this->item_status)
			$this->setDateDiscarded(time());
	}

	public function setItemStatus($v) {
		if ($this->getItemStatus() != null)
			$this->_oldValues['itemStatus'] = $this->getItemStatus();
		parent::setItemStatus($v);
	}

	public function setIssueStatus($v) {
		if ($this->getIssueStatus() != null)
			$this->_oldValues['issueStatus'] = $this->getIssueStatus();
		parent::setIssueStatus($v);
	}

	public function setIssueDateArrival($v) {
		if ($this->getIssueDateArrivalExpected() != null)
			$this->_oldValues['date'] = $this->getIssueDateArrivalExpected();
		parent::setIssueDateArrival($v);
	}

	/**
	 * It returns the id of the item (for compatibility).
	 *
	 * @return int
	 */
	public function getId() 
	{
		return $this->item_id;
	}

	/**
	 * It returns the complete name (unsort . sort text) of the
	 * manifestation whose this item is a representation.
	 *
	 * @return string
	 */
	public function getCompleteTitle() 
	{
		$title = trim($this->getTitle());
		if ($title == '') 
		{
			$manifestation = $this->getManifestation();
			if ($manifestation instanceof Manifestation)
				$title = trim($manifestation->getTitle());
		}
		
		return $title;
	}

	public function isExternal() 
	{
		$output = false;
		$ownerLibrary = $this->getOwnerLibrary();
		if ($ownerLibrary instanceof Library) 
		{
			if ($ownerLibrary->isExternal())
				$output = true;
		}

		return $output;
	}

	public function isOutOfHome($actualLibraryId = null)
	{
		$homeLibraryId = intval($this->getHomeLibraryId());
		
		$actualLibraryId = intval($actualLibraryId);
		if ($actualLibraryId == 0)
			$actualLibraryId = intval($this->getActualLibraryId());

		if ($homeLibraryId * $actualLibraryId == 0)
			return null;

		return ($homeLibraryId != $actualLibraryId);
	}

	public function isOoc() 
	{
		return (intval($this->getManifestationId()) == 0);
	}

	public function isOutOfOwner($actualLibraryId = null)
	{
		$ownerLibraryId = intval($this->getOwnerLibraryId());

		$actualLibraryId = intval($actualLibraryId);
		if ($actualLibraryId == 0)
			$actualLibraryId = intval($this->getActualLibraryId());

		if ($ownerLibraryId * $actualLibraryId == 0)
			return null;

		return ($ownerLibraryId != $actualLibraryId);
	}

	public function isOutOfSystem() 
	{
		$actualLibrary = $this->getActualLibrary();
		if (!($actualLibrary instanceof Library))
			return null;

		return ($actualLibrary->getLibraryInternal() != "1");
	}

	public function checkLoanableSince($time = null) {
		$m = $this->getManifestation();
		if ($m instanceof Manifestation && null !== $m->getLoanableSince(null)) {
			if (null === $time)
				$time = new DateTime('now');
			else
				$time = PropelDateTime::newInstance($time, null, 'DateTime');
			return (in_array($this->loan_class,ItemPeer::getLoanClassesConsultation()) || ($m->getLoanableSince(null) < $time));
		}
		return true;
	}

	public function IsLoaned($patron = null)
	{
		if (!is_null($patron)) 
		{
			if (!($patron instanceof Patron))
				return false;
		}

		$exitCode = in_array($this->getLoanStatus(), ItemPeer::getLoanStatusCurrent());

		if (!is_null($patron))
			$exitCode = ($exitCode && ($this->getPatronId() == $patron->getPatronId()));

		return $exitCode;
	}

	/**
	 * Declares an association between this object and a Loan object.
	 * Alias to setLoanRelatedByCurrentLoanId().
	 *
	 * @param      Loan $v
	 * @return     Item The current object (for fluent API support)
	 * @throws     PropelException
	 */
	public function setCurrentLoan(Loan $v = null)
	{
		return parent::setLoanRelatedByCurrentLoanId($v);
	}

	/**
	 * Get the associated Loan object.
	 * Alias to getLoanRelatedByCurrentLoanId().
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Loan The associated Loan object.
	 * @throws     PropelException
	 */
	public function getCurrentLoan(PropelPDO $con = null)
	{
		return parent::getLoanRelatedByCurrentLoanId($con);
	}

	/**
	 * Gets an array of Loan objects which contain a foreign key that references this object.
	 *
	 * If this collection has already been initialized with an identical Criteria, it returns the collection.
	 * Otherwise if this Item has previously been saved, it will retrieve
	 * related LoansRelatedByItemId from storage. If this Item is new, it will return
	 * an empty collection or the current collection, the criteria is ignored on a new object.
	 *
	 * Alias to parent::getLoansRelatedByItemId()
	 *
	 * @param      Criteria $criteria
	 * @param      PropelPDO $con
	 * @return     array Loan[]
	 * @throws     PropelException
	 */
	public function getLoans(Criteria $criteria = null, PropelPDO $con = null)
	{
		return parent::getLoansRelatedByItemId($criteria, $con);
	}

	public function getTitle($externalFlag = false)
	{
		$title = parent::getTitle();
		if ($externalFlag)
			$title .= $this->getExternalString();

		return $title;
	}

	public function getExternalConst() 
	{
		return " <span style='color: red'>[" . Prado::localize("esterno") . "]</span>";
	}

	public function getExternalString() 
	{
		if ($this->isExternal())
			return $this->getExternalConst();
		else
			return '';
	}

	public function getTrimmedTitle(	$count = null,
										$externalFlag = false,
										$stripTags = false )
	{
		$title = $this->getCompleteTitle();
		if (!is_null($count)) 
		{
			if (strlen($title) > $count) 
			{
				$parts = preg_split("/\(fasc/s", $title);
				if (count($parts) > 0) 
					$title = $parts[0];

				$title = mb_substr($title, 0, $count, 'utf8') . '...';
				if (array_key_exists(1, $parts))
					$title .= '(fasc' . $parts[1];
			}
		}

		if ($externalFlag) 
		{
			$subfix = $this->getExternalString();
		
			if ($stripTags)
				$subfix = strip_tags($subfix);
			
			$title .= $subfix;
		}

		return $title;
	}

	public function getEditionDate() 
	{
		$manifestation = $this->getManifestation();
		if (!is_null($manifestation))
			return $manifestation->getEditionDate();
		else
			return '';
	}

	/**
	 * It returns a string with the value, taken from lookupvalue
	 * table, relative to the loan_status of this item.
	 * If a string parameter is passed, we assume that string
	 * as the value key for the right string to extract.
	 *
	 * @param string $value
	 * @return string
	 */
	public function getLoanStatusString($value = null, $includeExternal = true, $newLineFlag = false)
	{
		$output = null;

		if (is_null($value))
			$status = $this->getLoanStatus();
		else
			$status = $value;

		if (!is_null($status)) 
		{
			$label = LookupValuePeer::getLookupValue('LOANSTATUS', $status);

			if ($status == ItemPeer::LOANSTATUS_INLOAN && $includeExternal) 
			{
				$ownerLibrary = $this->getOwnerLibrary();
				if ($ownerLibrary instanceof Library) 
				{
					/* TODO: solve localization issue */
					if ($ownerLibrary->isExternal())
						$label .= ($newLineFlag
										? "<br/>"
										: " ") 
									. "(" . Prado::localize("da extra-sistema") . ")";
				}
			}

			$output = $label;
		}

		return $output;
	}

	public function getItemStatusString($value = null)
	{
		if (is_null($value))
			$status = $this->getItemStatus();
		else
			$status = $value;

		if (!is_null($status)) 
		{
			$label = LookupValuePeer::getLookupValue("ITEMSTATUS", $status);
			return $label;
		}
		else
		{
			return null;
		}
	}

	public function getItemOrderStatusString($value = null)
	{
		if (is_null($value))
			$status = $this->getItemOrderStatus();
		else
			$status = $value;

		if (!is_null($status)) 
		{
			$label = LookupValuePeer::getLookupValue("ITEMORDERSTATUS", $status);
			return $label;
		}
		else
		{
			return null;
		}
	}
	
	public function getPhysicalStatusString($value = null)
	{
		if (is_null($value))
			$status = $this->getPhysicalStatus();
		else
			$status = $value;

		if (!is_null($status)) 
		{
			$label = LookupValuePeer::getLookupValue("ITEMPHYSICALSTATUS", $status);
			return $label;
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * It returns a string with the value, taken from lookupvalue
	 * table, relative to the loan_status of this item.
	 * If a string parameter is passed, we assume that string
	 * as the value key for the right string to extract.
	 *
	 * @param string $value
	 * @return string
	 */
	public function getLoanClassString($value = null, $forceResult = false) {
		if ($forceResult)
			$output = '---';
		else
			$output = null;

		if (is_null($value))
			$class = $this->getLoanClass();
		else
			$class = $value;

		if (!is_null($class)) 
		{
			$label = LookupValuePeer::getLookupValue('LOANCLASS', $class);
			if ($label != '')
				$output = $label;
		}

		return $output;
	}

	public function unLoan() 
	{
		$patron = $this->getPatron();
		$clavisLibrarian = Prado::getApplication()->getUser();

		if (!is_null($patron) && !is_null($clavisLibrarian)) 
		{
			if (Prado::getApplication()->getModule('loan')->DoReturnItem($this, $patron, $clavisLibrarian)) 
			{
				Prado::log(Prado::varDump($this) . "\nDoreturnItem(() OK!\n\n\n");
				return true;
			} 
			else 
			{
				Prado::log(Prado::varDump($this) . "\nDoLoanItem(() FAILED, non ritornato!\n\n\n");
				return false;
			}
		} 
		else 
		{
			Prado::log('!!!o est nulla il clavislibrarian o il patron.');
			return false;
		}
	}

	/**
	 * It's a subclass method, which by default outputs the
	 * value 'D' (cartographic material) in case the real field
	 * is null.
	 *
	 * @return string
	 */
	public function getItemMedia() 
	{
		$itemMedia = $this->item_media;

		if (is_null($itemMedia))
			$itemMedia = "D";

		return $itemMedia;
	}

	/**
	 * It outputs a string where there are (separated by slashes)
	 * the four fields of the item which describe the phisical
	 * collocation inside the library.
	 *
	 * If the parameter $libraryId is passed, we check whether this item
	 * belongs to the actual library we're working from.
	 * If the latter isn't verified, the string which is returned hasn't
	 * the collocation combo string, but a localized word which express
	 * the fact that this item is "external".
	 *
	 * @param int $libraryId
	 * @return string
	 */
	public function getCollocationCombo(	$libraryId = null,
											$inventoryFlag = false,
											$sectionFlag = true )
	{
		$leftPar = $rightPar = '';
		$libraryId = intval($libraryId);
		if (($libraryId > 0) && ($this->home_library_id != $libraryId)) 
		{
			$leftPar = '';
			$rightPar = '';
		}

		if ($sectionFlag) 
		{
			$section = trim($this->section);
			if ($section != '')
				$section .= ' ';
		}
		else
		{
			$section = '';
		}

		$collocation = trim($this->collocation);
		$sequence1 = trim($this->sequence1);
		if ($sequence1 != '')
			$sequence1 = ' ' . $sequence1;
		$sequence2 = trim($this->sequence2);
		if ($sequence2 != '')
			$sequence2 = ' ' . $sequence2;
		$specification = trim($this->specification);
		if ($specification != '')
			$specification = ' ' . $specification;

		$output = trim($section . $collocation . $specification . $sequence1 . $sequence2);  // exact correct sequence
		if ($output != '')
			$output = $leftPar . $output . $rightPar;

		if ($inventoryFlag) 
		{
			$inventory = $this->getCompleteInventoryNumber();
			$output .= "\n" . '(inv: ' . $inventory . ')';
		}
		
		return $output;
	}

	public function getHyperLinkCollocationCombo($pageForm, 
													$libraryId = null,
													$inventoryFlag = false,
													$sectionFlag = true)
	{
		$leftPar = $rightPar = '';
		$collocationString = '';
		$libraryId = intval($libraryId);

		if (($libraryId > 0) && ($this->home_library_id != $libraryId)) 
		{
			$leftPar = '';
			$rightPar = '';
		}

		if ($sectionFlag) 
		{
			$section = trim($this->section);
			if ($section != '')
				$section .= ' ';
		}
		else
		{
			$section = '';
		}

		$collocation = trim($this->collocation);
		$sequence1 = trim($this->sequence1);
		if ($sequence1 != '')
			$sequence1 = ' ' . $sequence1;
		$sequence2 = trim($this->sequence2);
		if ($sequence2 != '')
			$sequence2 = ' ' . $sequence2;
		$specification = trim($this->specification);
		if ($specification != '')
			$specification = ' ' . $specification;

		$collocationString = trim($section . $collocation . $specification . $sequence1 . $sequence2);
		if ($collocationString != '')
			$collocationString = $leftPar . $collocationString . $rightPar;

		$inventory = $this->getCompleteInventoryNumber();
		
		// XXX TODO: the following snippet should definitely moved out of this object,
		// 	'cause it's completely dependent on Prado.
		if (Prado::getApplication()->getUser()->getEditPermission($this))
			$output = '<a title="' . Prado::localize('inventario') . ': ' . $inventory . ', id: ' . $this->item_id .
				'" target="_self" href="javascript:void(0)" onclick="openIframe(\'Catalog.ItemEditPopup\', null, null, \'' .
				$pageForm . '\',null,null,null,null,\'' . $this->getItemId() . '\', \'Item\'); return false;"  >' . $collocationString .
				($inventoryFlag ? '<br />(inv: ' . $inventory . ')' : '') . '</a>';
		else
			$output = '<span alt="' . Prado::localize('inventario') . ': ' . $inventory .
				', id: ' . $this->item_id . '" >' . $collocationString .
				($inventoryFlag ? '<br />(inv: ' . $inventory . ')' : '') . '</span>';

		return $output;
	}

	public function getCompleteInventoryNumber($connector = '-') 
	{
		$inventory_serie_id = trim($this->inventory_serie_id);
		$inventory_number = $this->inventory_number;
		if (!is_numeric($inventory_number))
			$inventory_number = null;

		if (($inventory_serie_id != '') && !is_null($inventory_number))
			return $inventory_serie_id . $connector . $inventory_number;
		else
			return $inventory_serie_id . $inventory_number;
	}

	/**
	 * Get the owner Library object.
	 * Alias to getLibraryRelatedByOwnerLibraryId().
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Library The associated Library object.
	 * @throws     PropelException
	 */
	public function getOwnerLibrary(PropelPDO $con = null)
	{
		return parent::getLibraryRelatedByOwnerLibraryId($con);
	}

	/**
	 * Get the home Library object.
	 * Alias to getLibraryRelatedByHomeLibraryId().
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Library The associated Library object.
	 * @throws     PropelException
	 */
	public function getHomeLibrary(PropelPDO $con = null)
	{
		return parent::getLibraryRelatedByHomeLibraryId($con);
	}

	/**
	 * @param bool $appendExternal
	 * @param bool $stripTags
	 * @param bool $appendConsortia
	 * @param null $trim
	 * @return string
	 */
	public function getHomeLibraryLabel(	$appendExternal = false,
											$stripTags = false,
											$appendConsortia = false,
											$trim = null)
	{
		$library = $this->getHomeLibrary();
		if (!is_null($library))
			return $library->getLabel(	$appendExternal, 
										$stripTags, 
										$appendConsortia, 
										$trim);
		else
			return '';
	}

	/**
	 * Get the delivery Library object.
	 * Alias to getLibraryRelatedByDeliveryLibraryId().
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Library The associated Library object.
	 * @throws     PropelException
	 */
	public function getDeliveryLibrary(PropelPDO $con = null)
	{
		return parent::getLibraryRelatedByDeliveryLibraryId($con);
	}

	/**
	 * @param bool $appendExternal
	 * @param bool $stripTags
	 * @param bool $appendConsortia
	 * @param null $trim
	 * @return string
	 */
	public function getDeliveryLibraryLabel(	$appendExternal = false,
												$stripTags = false,
												$appendConsortia = false,
												$trim = null )
	{
		$library = $this->getDeliveryLibrary();
		if (!is_null($library)) 
		{
			$libraryLabel = $library->getLabel($appendExternal, $stripTags, $appendConsortia, $trim);
			return $libraryLabel;
		}
		else
		{
			return '';
		}
	}

	/**
	 * Get the actual Library object.
	 * Alias to getLibraryRelatedByActualLibraryId().
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Library The associated Library object.
	 * @throws     PropelException
	 */
	public function getActualLibrary(PropelPDO $con = null)
	{
		return parent::getLibraryRelatedByActualLibraryId($con);
	}

	/**
	 * It returns the description (in string) of the  actual library.
	 *
	 * @return string
	 */
	public function getActualLibraryDescription() 
	{
		$library = $this->getActualLibrary();

		if ($library instanceof Library)
			return $library->getDescription();
		else
			return '';
	}

	public function getActualLibraryLabel(	$appendExternal = false,
												$stripTags = false,
												$appendConsortia = false,
												$trim = null )
	{
		$library = $this->getActualLibrary();

		if ($library instanceof Library)
			return $library->getLabel($appendExternal, $stripTags, $appendConsortia, $trim);
		else
			return '';
	}

	/**
	 * It returns the complete name of the patron (eventually
	 * with a comma in between.
	 *
	 * @return string
	 */
	public function getPatronCompleteName() 
	{
		$p = $this->getPatron();
		return ($p instanceof Patron)
			? $p->getCompleteName() : '';
	}

	public function getPatronBarcode() 
	{
		$p = $this->getPatron();
		return ($p instanceof Patron) ? $p->getBarcode() : '';
	}

	/**
	 * It's an alias ...
	 *
	 * @return string
	 */
	public function getCompleteName() 
	{
		return $this->getPatronCompleteName();
	}

	public function getLastItemAction() 
	{
		return ItemActionQuery::create()
			->filterByItemId($this->item_id)
			->filterByActionType(ItemActionPeer::TYPE_MANAGEREQUEST)
			->orderByActionDate(Criteria::DESC)
			->findOne();
	}

	public function isLoanableByMyLibrary($myLibraryId = null)
	{
		if (is_null($myLibraryId))
			$myLibraryId = Prado::getApplication()->getUser()->getActualLibraryId();
		$actualLibraryId = $this->getActualLibraryId();

		$availabilityClasses = array_merge(ItemPeer::getLoanClassesAvailable(), ItemPeer::getLoanClassesLocallyAvailable());
		$hasClass = in_array($this->getLoanClass(), $availabilityClasses);
		$hasStatus = in_array($this->getLoanStatus(), ItemPeer::getLoanStatusAvailable());

		if (($myLibraryId == $actualLibraryId) && $hasClass && $hasStatus)
			return true;
		else
			return false;
	}

	public function isLoanableByAll() 
	{
		$availabilityClasses = array_merge(ItemPeer::getLoanClassesAvailable(), ItemPeer::getLoanClassesLocallyAvailable());
		$hasClass = in_array($this->getLoanClass(), $availabilityClasses);
		$hasStatus = in_array($this->getLoanStatus(), ItemPeer::getLoanStatusAvailable());

		if ($hasClass && $hasStatus)
			return true;
		else
			return false;
	}

	public function retrieveFirstItemRequestId($librarianId = null)
	{
		$itemRequestId = null;
		$manifestationId = intval($this->getManifestationId());
		$issueId = intval($this->getIssueId());

		$criteria = new Criteria();
		if (is_null($librarianId) && class_exists('Prado'))
			$librarian = Prado::getApplication()->getUser();
		$librarianId = ($librarian instanceof ClavisLibrarian) ? $librarian->getId() : 1;
		$criteria->add(ItemRequestPeer::LIBRARIAN_ID, $librarianId);

		if ($manifestationId > 0)
			$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $manifestationId);
		else
			$criteria->addAnd(ItemRequestPeer::ITEM_ID, $this->getItemId());

		if ($issueId > 0)
			$criteria->addAnd(ItemRequestPeer::ISSUE_ID, $issueId);

		$criteria->addAscendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);
		$criteria->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_WORKING);

		if ($manifestationId > 0)
			$itemRequests = ItemRequestPeer::doSelectJoinManifestation($criteria);
		else
			$itemRequests = ItemRequestPeer::doSelectJoinItem($criteria);

		if (count($itemRequests) > 0) 
		{
			$itemRequest = is_array($itemRequests) ? array_shift($itemRequests) : $itemRequests->shift();
			$itemRequestId = $itemRequest->getRequestId();
		}

		return $itemRequestId;
	}

	public function getIsAlien() 
	{
		return in_array($this->getLoanStatus(), array(ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME));
	}

	public function getShelfDescription() 
	{
		$completeTitle = $this->getTrimmedTitle(80);
		if ($completeTitle !== '')
			return Prado::localize('Titolo') . ': ' . $completeTitle;
		else
			return '';
	}

	public function getShelfDescriptionLabel() 
	{
		return 'titolo: ';
	}

	// XXX FIXME: solve localization issue
	public function getShelfDescriptionText() 
	{
		$output = $this->getTrimmedTitle(80);

		$inv = trim($this->getCompleteInventoryNumber());
		if ($inv != '')
			$output .= "&nbsp;(inv:&nbsp;$inv)";

		return $output;
	}

	/**
	 * It returns the Portlet.Page which will be used in the
	 * url of the grid row, to hyper-transport ourselves to the
	 * right visualization page of the object.
	 *
	 * @return string
	 */
	public function getShelfUrl() 
	{
		return 'Catalog.ItemViewPage&id=';
	}

	public function getNavigateUrl() 
	{
		return ItemPeer::getNavigateUrl();
	}

	/**
	 * Returns the shelves the object is contained in (or not in).
	 *
	 * @param ClavisLibrarian $user
	 * @param SehlfQuery $baseQuery
	 * @param int|string $limit
	 * @param int $offset
	 * @param boolean $except If true, returns all shelves the object is NOT contained in.
	 * @return PropelObjectCollection|array|int|mixed
	 */
	public function getShelvesIn(ClavisLibrarian $user, ShelfQuery $baseQuery, $limit=null, $offset=null, $except = false)
	{
		if (!$baseQuery)
			$baseQuery = ShelfQuery::create();
		if ($except)
			$sideQuery = clone $baseQuery;

		$baseQuery->useShelfItemQuery()
			->filterByObjectClass(ShelfPeer::TYPE_ITEM)
			->filterByObjectId($this->item_id)
			->endUse();

		if ($except) {
			$shelvesIds = array_keys(ShelfPeer::getVisibleShelvesArray($user, null, null, null, $baseQuery));
			$sideQuery->filterByShelfId($shelvesIds,Criteria::NOT_IN);
			$shelves = ShelfPeer::getVisibleShelves($user, null, $limit, $offset, $baseQuery);
		} else {
			$shelves = ShelfPeer::getVisibleShelves($user, null, $limit, $offset, $baseQuery);
		}
		return $shelves;
	}

	public function getObjectTypeString() 
	{
		return 'esemplare';
	}

	public function getIssueSummary() 
	{
		$output = '';
		$issueId = intval($this->issue_id);
		if ($issueId > 0) 
		{
			/// TODO
		}

		return $output;
	}

	public function getInventoryCollocationCombo() 
	{
		$inventory = $this->inventory_number;
		$collocation = trim($this->getCollocationCombo());
		if ($collocation != '')
			$inventory .= ' (' . $collocation . ')';

		return $inventory;
	}

	/**
	 * Alias to setLibraryRelatedByExternalLibraryId().
	 *
	 * @param                  Library $v
	 * @return Item The current object (for fluent API support)
	 * @throws PropelException
	 */
	public function setExternalLibrary(Library $v = null)
	{
		return parent::setLibraryRelatedByExternalLibraryId($v);
	}

	/**
	 * Alias to getLibraryRelatedByExternalLibraryId().
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Library The associated Library object.
	 * @throws     PropelException
	 */
	public function getExternalLibrary(PropelPDO $con = null)
	{
		return parent::getLibraryRelatedByExternalLibraryId($con);
	}

	public function getItemIcon() 
	{
		$icon = str_pad(trim(parent::getItemIcon()), 3, "0", STR_PAD_LEFT);
		return $icon;
	}

	public function getItemiconFile() 
	{
		// don't touch this please, it's correct as it is.
		$number = '000';
		$itemIcon = $this->getItemIcon();
		if (!is_null($itemIcon))
			$number = str_pad(intval($itemIcon), 3, '0', STR_PAD_LEFT);

		return "itemicon{$number}.png";
	}

	public function getItemiconLabel() 
	{
		$label = '';
		$itemIcon = $this->getItemIcon();
		if (!is_null($itemIcon))
			$label = LookupValuePeer::getLookupValue('ITEMICON', $itemIcon);

		return $label;
	}

	/**
	 * @return array($name, $url), whereas the name is the patron (or external library)
	 * 										and the $url is the direct address of that object
	 */
	public function getPatronUrlArray() 
	{
		$patron = $this->getPatron();
		if (!is_null($patron)) 
		{
			$patronCompleteName = $patron->getCompleteName();
			$navigateUrl = $patron->getNavigateUrl() . $patron->getPatronId();
		} 
		else 
		{
			$externalLibraryId = $this->getExternalLibraryId();
			$externalLibrary = LibraryPeer::retrieveByPK($externalLibraryId);
			if ($externalLibrary instanceof Library) 
			{
				$patronCompleteName = "<span style='color: red'>[" . Prado::localize("extra-sistema") . "]</span>&nbsp;" .
					$externalLibrary->getLabel() . ' (' . $externalLibrary->getConsortiaId() . ')';

				$navigateUrl = $externalLibrary->getNavigateUrl() . $externalLibrary->getLibraryId();
			} 
			else 
			{
				$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
				$navigateUrl = '';
			}
		}

		return array($patronCompleteName, $navigateUrl);
	}

	public function getOwnerLibraryLabel(	$multiRow = false,
											$stripTags = false,
											$appendExternal = true,
											$appendConsortia = true )
	{
		if ($appendExternal !== false)
			$appendExternal = true;

		if ($appendConsortia !== false)
			$appendConsortia = true;

		$return = '';
		$library = $this->getOwnerLibrary();
		if ($library instanceof Library) {
			$return = $library->getLabel(null, $stripTags, null);

			if ($multiRow)
				$sep = "\n";
			else
				$sep = "";

			$consortia = trim($library->getConsortiaId());
			if ($consortia != '' && $appendConsortia && $library->isExternal())
				$return .= $sep . ' (' . $consortia . ')';

			$extra = '';
			if ($library->isExternal() && $appendExternal) {
				if ($stripTags)
					$extra = "[" . Prado::localize("esterna") . "]&nbsp;" . $sep;
				else
					$extra = "<span style='color: red'>[" . Prado::localize("esterna") . "]</span>&nbsp;" . $sep;
			}

			$return = $extra . $return;
		}

		return $return;
	}

	public function getRenewalCountLabel($str = null)
	{
		$count = parent::getRenewalCount();
		if ($count < 0)
			$count = '(' . $this->getPeer()->decodeRenew($count) . ')';

		return (string) $count;
	}

	/**
	 * Can we ask an external library a renew of an item of theirs to
	 * one of our patrons ? .........
	 *
	 * @param int $actualLibraryId
	 * @return boolean
	 */
	public function isAskRenew($actualLibraryId = null)
	{
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = Prado::getApplication()->getUser()->getActualLibraryId();

		return ($this->getLoanStatus() == ItemPeer::LOANSTATUS_INLOAN	// extra IN
			&& $this->isExternal()
			&& (($this->getActualLibraryId() == $actualLibraryId)
			|| ($this->getHomeLibraryId() == $actualLibraryId)));
	}

	public function getLoanDestinationObject() 
	{
		$returnObject = (object) null;

		$patron = $this->getPatron();
		if ($patron instanceof Patron)
		{
			$returnObject = $patron;
		}
		else 
		{
			$externalLibrary = $this->getExternalLibrary();
			if ($externalLibrary instanceof Library)
				$returnObject = $externalLibrary;
		}

		return $returnObject;
	}

	public function getOrderTitle() 
	{
		$output = "";
		$order = null;
		$orderId = intval($this->getOrderId());

		if ($orderId > 0)
			$order = PurchaseOrderPeer::retrieveByPK($orderId);

		if ($order instanceof PurchaseOrder)
			$output = $order->getOrderTitle();

		return $output;
	}
	
	public function isStatusConsultation()
	{
		return in_array($this->getLoanClass(), ItemPeer::getLoanClassesConsultation());
	}

	/**
	 * It replaces all the references of $manifestationSource whith the ones in $manifestationDestination
	 * and deletes $manifestationSource
	 *
	 * @param Item $item : item towards manifestation replacement has to be done
	 * @param Manifestation $manifestation : manifestation for replacing
	 * @param Issue $issue : the new issue for replacement (used if the manifestation is a serial).
	 * @param bool $clearIssueData : whether to clear all issue data in item (default) or not
	 * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
	 * @return boolean (transaction result)
	 */
	public function moveToManifestation(Manifestation $manifestation, $issue = null, $clearIssueData = false, $clavisLibrarian = null)
	{
		$arrRowsAffected = array();
		$old_manif = $this->getManifestation();
		$manif_dest_id = $manifestation->getManifestationId();

		if (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian)
			throw new Exception('Wrong ClavisLibrarian');

		$_connection = Propel::getConnection();
		try {
			$manifestation_title = $manifestation->getTitle();
			$manifestation_dewey = $manifestation->getClass();
			$issue_id = ($manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL && $issue instanceof Issue)
				? $issue->getIssueId() : null;

			$this->setManifestationId($manif_dest_id);
			$this->setTitle($manifestation_title);
			$this->setManifestationDewey($manifestation_dewey);
			$this->setIssueId($issue_id);
			$this->save();
			$old_manif->invalidateCache();

			//item_request
			$arrRowsAffected['item_request'] = ItemRequestQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ManifestationId' => $manif_dest_id),$_connection);

			//loan
			$arrRowsAffected['loan'] = LoanQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ManifestationId' => $manif_dest_id),$_connection);

			$manifestation->invalidateCache();
			$_connection->commit();

			if (count($arrRowsAffected) >0) {
				$description = "Esemplare spostato da manifestation [{$old_manif->getManifestationId()}] ".
					"a Manifestation [{$manif_dest_id}] -";
				foreach ($arrRowsAffected as $table => $count)
					if ($count > 0)
						$description .= " [$table : $count entry]";
				ChangelogPeer::logAction($this, ChangelogPeer::LOG_UPDATE, $clavisLibrarian, $description);
			}
		} catch (PropelException $e) {
			$_connection->rollback();
			Prado::log('Error in '.__CLASS__.'::'.__FUNCTION__.'(): .'.$e);
			return false;
		}
		return true;
	}

	/**
	 * Replaces an Item with another, updating links accordingly.
	 *
	 * @todo Check for duplicates in rows update
	 * @param Item $item_dst The destination Item
	 * @param ClavisLibrarian $clavisLibrarian
	 */
	public function replaceWith(Item $item_dst, $clavisLibrarian = null)
	{
		$newItemId = $item_dst->getItemId();
		$arrRowsAffected = array();

		if (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian)
			throw new Exception('Wrong ClavisLibrarian');
		if ($this->item_id == $newItemId)
			return false;

		$_connection = Propel::getConnection();
		try {
			//loan
			$arrRowsAffected['loan'] = LoanQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ItemId' => $newItemId),$_connection);

			//item_action
			$arrRowsAffected['item_action'] = ItemActionQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ItemId' => $newItemId),$_connection);

			//item_request
			$arrRowsAffected['item_request'] = ItemRequestQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ItemId' => $newItemId),$_connection);

			//item_note
			$arrRowsAffected['item_note'] = ItemNoteQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ItemId' => $newItemId),$_connection);

			//l_authority_item
			$arrRowsAffected['l_authority_item'] = LAuthorityItemQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ItemId' => $newItemId),$_connection);

			//purchase_proposal
			$arrRowsAffected['purchase_proposal'] = PurchaseProposalQuery::create()
				->filterByItemId($this->item_id)
				->update(array('ItemId' => $newItemId),$_connection);

			$_connection->commit();
			$item_dst->save();
			$this->delete();

			if (count($arrRowsAffected) >0) {
				$description = "Esemplare con id = {$this->item_id} ";
				foreach ($arrRowsAffected as $table => $count)
					if ($count > 0)
						$description .= " [$table : $count entry]";
				$description .= " schiacciato su id [{$newItemId}]";
				ChangelogPeer::logAction($item_dst, ChangelogPeer::LOG_UPDATE, $clavisLibrarian, $description);
			}
		} catch (PropelException $e) {
			$_connection->rollback();
			Prado::log('Error in '.__CLASS__.'::'.__FUNCTION__.'(): .'.$e);
			return false;
		}
		return true;
	}
	
	public function getEnsuredCurrency()
	{
		$itemCurrency = TPropertyValue::ensureString($this->getCurrency());
		if ($itemCurrency == "")
			$itemCurrency = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');
		
		return $itemCurrency;
	}
		
	public function getExtendedItemNoteText($noteType = null)
	{
		return ItemNotePeer::getItemNoteTextByType(	$noteType,
													$this->getItemId());
	}
        
        /*
         * This method check inventory number unique
         * 
         * Note: serial item of the same year can have same inv number.
         */
        public function isInventoryNumberUnique() 
        {
            try{
                
                /*
                 * Check if item is related to an issue
                 */                
                if( !is_null($this->issue_id ) )
                {
                    
                    
                    /*
                     * Get the issue, we need to know the year
                     */
                    $thisIssue = IssueQuery::create()
                            ->filterByIssueId($this->issue_id)
                            ->findOne();
                    
                    /*
                     * Ensure issue exists
                     */
                    if($thisIssue instanceof Issue)
                    {
                        /*
                         * Count item with same inv number but different issue year:
                         * if exists, number is not unique.
                         */
                        $ic = ItemQuery::create()
                        ->leftJoinIssue()
                        ->filterByHomeLibraryId($this->home_library_id, Criteria::EQUAL)
                        ->filterByInventorySerieId($this->inventory_serie_id, Criteria::EQUAL)
                        ->filterByInventoryNumber($this->inventory_number, Criteria::EQUAL)
                        ->filterByManifestationId($this->manifestation_id, Criteria::EQUAL)
                        ->filterByIssueYear($thisIssue->getIssueYear(), Criteria::NOT_EQUAL)
                        ->filterByItemId($this->item_id, Criteria::NOT_EQUAL)
                        ->count();
                        //Prado::log(__METHOD__ . " serial item id " . $this->item_id . " ic " . $ic);
                        if($ic > 0) return FALSE;
                    }
                    else 
                    {
                        Prado::log(__METHOD__ . " issue id ". $this->issue_id . " not found");
                        //Prado::log(Prado::varDump($thisIssue));
                        return FALSE;
                    }
                    
                    
                }
                //else
                {
                    /*
                     * If not related to an issue, simple count item with same inv nr
                     */
                    
                    $ic = ItemQuery::create()
                        ->filterByHomeLibraryId($this->home_library_id, Criteria::EQUAL)
                        ->filterByInventorySerieId($this->inventory_serie_id, Criteria::EQUAL)
                        ->filterByInventoryNumber($this->inventory_number, Criteria::EQUAL)
                        ->filterByItemId($this->item_id, Criteria::NOT_EQUAL)
                        ->filterByIssueId(null,  Criteria::ISNULL)
                        ->count();
                    //Prado::log(__METHOD__ . " item id " . $this->item_id . " ic " . $ic);
                }
                
                
                if( $ic == 0 ) return TRUE;
                else return FALSE;
                
            } catch (Exception $ex) {
                Prado::log("Exception: " . __FILE__ . " " . __LINE__ . " " . $ex->getMessage());
                return FALSE;
            }
            
        }
        
        /*
         * Search for items by issue serie/number
         * @return PropelArrayCollection
         */
        public function getIssueExistingInventory($issueId, $libId, $manifId) 
        { 
            $iNrs = array();
            if( !is_null($issueId) )
            {
                $thisIssue = IssueQuery::create()->findOneByIssueId($issueId);
                if( ! is_null( $thisIssue ) )
                {
                    //Search item inv numbers for item
                    $iNrs = ItemQuery::create()
                        ->select(array(ItemPeer::INVENTORY_NUMBER, ItemPeer::INVENTORY_SERIE_ID))
                        ->distinct()
                        ->filterByManifestationId($manifId, Criteria::EQUAL)
                        ->filterByHomeLibraryId($libId, Criteria::EQUAL)
                        ->filterByIssueYear($thisIssue->getIssueYear(), Criteria::EQUAL)
			->filterByInventoryNumber(NULL, Criteria::ISNOTNULL)
                        ->find();
             
                    
                }// not null issue
            }// not null issue id
            
            return $iNrs;
        }

}
// Item
