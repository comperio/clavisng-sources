<?php

  // include base peer class
	require_once 'clavis/om/BasePatronPeer.php';

  // include object class
	include_once 'clavis/Patron.php';


class PatronPeer extends BasePatronPeer {

	const EXCP_USERNAME_DUP = 773;

	const STATUS_ENABLED	= 'A';
	const STATUS_EXPIRED	= 'B';
	const STATUS_REVOKED	= 'C';
	const STATUS_DECEASED	= 'D';
	const STATUS_INCOMPLETE	= 'E';
	const STATUS_AUTOMATICREVOKED	= 'R';

	const PATRONALERT_ALWAYS = 'A';
	const PATRONALERT_RETURN = 'B';
	const PATRONALERT_LOAN = 'C';
	
	/**
	 * It returns patrons which matchs the barcode passed
	 * as parameter.
	 *
	 * @param string $barcode
	 * @return array
	 */
	static public function getPatronsByBarcode($barcode)
	{
		if (!$barcode)
			return null;
		return PatronQuery::create()->findByBarcode($barcode);
	}

	/**
	 * For compatibility
	 *
	 * @param string $barcode
	 * @return Patron
	 */
	static public function getPatronByBarcode($barcode)
	{
		if (!$barcode)
			return null;
		return PatronQuery::create()->findOneByBarcode($barcode);
	}

	static public function isBarcodeDuplicate($barcode,$patron_id=null)
	{
		if (is_null($barcode))
			return false;
		$barcode = trim(TPropertyValue::ensureString($barcode));
		if ($barcode == '')
			return false;

		$criteria = new Criteria();
		$criteria->add(PatronPeer::BARCODE, $barcode);

		if (intval($patron_id) > 0) {
			$criteria->add(PatronPeer::PATRON_ID,$patron_id,Criteria::NOT_EQUAL);
			return PatronPeer::doCount($criteria) > 0;
		} else {
			return PatronPeer::doCount($criteria) > 1;
		}
	}

	/**
	 * It returns one patron which matchs the rfid passed
	 * as parameter.
	 *
	 * @param string $code
	 * @return Patron
	 */
	static public function getPatronByRfidcode($code)
	{
		if ($code != '')
		{
			$c = new Criteria();
			$c->add(PatronPeer::RFID_CODE  , $code);
			$patrons = PatronPeer::doSelect($c);
			if(count($patrons) == 0) return null;
			return $patrons[0];
		}
		else
			return null;
	}

	/**
	 * Returns a Patron by his username.
	 *
	 * @param string $name The username to search
	 * @return Patron The Patron or null if search was unsuccessful.
	 */
	static public function getPatronByOpacUsername($name) {
		if ($name=='')
			return null;
		$c = new Criteria();
		$c->add(PatronPeer::OPAC_USERNAME,$name);
		$patrons = PatronPeer::doSelect($c);
		if (count($patrons) != 1)
			return null;
		return $patrons[0];
	}

	/**
	 * Returns all patrons having a specified webkey.
	 *
	 * @param string $webkey The webkey to search.
	 * @return array An array of Patron objects.
	 */
	static public function getPatronsByWebkey($webkey='') {
		if ($webkey=='')
			return null;
		$c = new Criteria();
		$c->add(PatronPeer::OPAC_WEBKEY,$webkey);
		return PatronPeer::doSelect($c);
	}

	/**
	 * It returns the complete name of the patron whose id
	 * is passed as the parameter.
	 *
	 * @param int $patronId
	 * @return string
	 */
	static public function getCompleteName($patronId)
	{
		$patron = PatronPeer::retrieveByPK($patronId);
		return ($patron instanceof Patron) ? $patron->getCompleteName() : '';
	}

	/**
	 * Crypts the patron password.
	 *
	 * @param string $password The uncrypted password.
	 * @throws Exception
	 */
	static public function pwdCrypt($password) {
//		return sha1($password);
		throw new Exception('Don\'t use pwdCrypt(). Get ClavisCrypt module, instead.');
	}

	/**
	 * Get a list of patrons based on a start string and optional criterions.
	 *
	 * @param string $token The string to use as a base search.
	 * @param integer $limit The maximum of patrons to return (defaults to 10).
	 * @param boolean $hideDeceased If true filter out deceased patrons.
	 * @return PropelObjectCollection A list of Patrons.
	 */
	public static function doSuggest($token, $limit=10, $hideDeceased=false)
	{
		$q = PatronQuery::create();
		if (strpos($token,',')!==false) {
			$parts = explode(',',$token);
			if (trim($parts[1]))
				$q->filterByName(trim($parts[1]).'%');
			$token = $parts[0];
		}
		if ($hideDeceased)
			$q->filterByPatronStatus(self::STATUS_DECEASED, Criteria::NOT_EQUAL);
		return $q->filterByLastname($token.'%')
			->filterByPatronStatus(self::STATUS_INCOMPLETE, Criteria::NOT_EQUAL)
			->orderByLastname()->orderByName()
			->limit($limit)
			->find();
	}

	public static function doSuggestAddress($param, $field = PatronPeer::BIRTH_CITY, $limit = 10)
	{
		$res = array();

		$limit = intval($limit);
		if ($limit < 1)
			$limit = 10;

		$param = trim($param);
		if ($param != '')
		{
			/**
			 * In this second implementation, anagraphic addresses
			 * get autocompletated from other anagraphic addresses only,
			 * and the same for addresses from table `address`.
			 * (Previously thery were always unioned)
			 */
			/* TODO: the following is highly MySQL-bound. We should make it less db-dependent */
			switch ($field)
			{
				case PatronPeer::BIRTH_CITY:
					$sql = "SELECT DISTINCT birth_city AS ci,
							birth_province AS pr,
							birth_country AS co,
							(birth_city is null) * 100 + (birth_province is null) * 10 + (birth_country is null) AS ord
						FROM patron
						WHERE birth_city LIKE :param
						ORDER BY ord, ci, pr, co";
					$colNum = 3;
					$zipFlag = false;
					break;

				case PatronPeer::BIRTH_PROVINCE:
					$sql = "SELECT DISTINCT birth_province AS pr,
							birth_country AS co,
							(birth_province is null) * 10 + (birth_country is null) AS ord
						FROM patron
						WHERE birth_province LIKE :param
						ORDER BY ord, pr, co";
					$colNum = 2;
					$zipFlag = false;
					break;

				case PatronPeer::BIRTH_COUNTRY:
					$sql = "SELECT DISTINCT birth_country AS co,
							(birth_country is null) AS ord
						FROM patron
						WHERE birth_country LIKE :param
						ORDER BY ord, co";
					$colNum = 1;
					$zipFlag = false;
					break;

				case AddressPeer::CITY:
					$sql = "SELECT DISTINCT city AS ci,
							zip AS zi,
							province AS pr,
							country AS co,
							(city is null) * 1000 + (zip is null)* 100 + (province is null) * 10 + (country is null) AS ord
						FROM address
						WHERE city LIKE :param
						ORDER BY ord, ci, zi, pr, co";
					$colNum = 4;
					$zipFlag = true;
					break;

				case AddressPeer::ZIP:
					$sql = "SELECT DISTINCT zip AS zi,
							province AS pr,
							country AS co,
							(zip is null) * 100 + (province is null) * 10 + (country is null) AS ord
						FROM address
						WHERE zip LIKE :param
						ORDER BY ord, zi, pr, co";
					$colNum = 3;
					$zipFlag = true;
					break;

				case AddressPeer::PROVINCE:
					$sql = "SELECT DISTINCT province AS pr,
							country AS co,
							(province is null) * 10 + (country is null) AS ord
						FROM address
						WHERE province LIKE :param
						ORDER BY ord, pr, co";
					$colNum = 2;
					$zipFlag = true;
					break;

				case AddressPeer::COUNTRY:
					$sql = "SELECT DISTINCT country AS co,
							(country is null) AS ord
						FROM address
						WHERE country LIKE :param
						ORDER BY ord, co";
					$colNum = 1;
					$zipFlag = true;
					break;

				default:
					break;
			}

			$sql .= " LIMIT $limit";

			try
			{
				$connection = Propel::getConnection();
				$stmt = $connection->prepare($sql);
				$stmt->execute(array(':param' => "$param%"));

				$firstPatronIds = array();
				$counter = 0;
				while ($row = $stmt->fetch(PDO::FETCH_NUM))
				{
					array_pop($row);
					$res[] = array(
										'id' => $counter,
										'text' => self::patronAddressFormat($row, $colNum, $zipFlag),
										'array' => $row
										);
					$counter++;
				}
			}
			catch (PDOException $e)
			{
				throw new Exception($e->getMessage());
			}
		}

		return $res;
	}

	public static function patronAddressFormat($arr = array(), $colNum = null, $zipFlag = false)
	{
		if (count($arr) == 0 || is_null($arr) || !is_array($arr))
			return Prado::localize("errore");

		$city = $zip = $province = $country = '';
		$zipFlag = TPropertyValue::ensureBoolean($zipFlag);

		switch ($colNum)
		{
			case 4:  // caso indirizzo address normale (abitazione), per city
				$city = trim(TPropertyValue::ensureString($arr[0]));
				$zip = trim(TPropertyValue::ensureString($arr[1]));
				$province = trim(TPropertyValue::ensureString($arr[2]));
				$country = trim(TPropertyValue::ensureString($arr[3]));
			break;

			case 3:  // caso indirizzo address normale (abitazione) per zip, oppure birth per city
				if ($zipFlag)
				{
					$zip = trim(TPropertyValue::ensureString($arr[0]));
					$province = trim(TPropertyValue::ensureString($arr[1]));
					$country = trim(TPropertyValue::ensureString($arr[2]));
				}
				else
				{
					$city = trim(TPropertyValue::ensureString($arr[0]));
					$province = trim(TPropertyValue::ensureString($arr[1]));
					$country = trim(TPropertyValue::ensureString($arr[2]));
				}
			break;

			case 2:  // caso indirizzo address normale (abitazione) per province, oppure birth per province
				$province = trim(TPropertyValue::ensureString($arr[0]));
				$country = trim(TPropertyValue::ensureString($arr[1]));
			break;

			case 1:  // caso indirizzo address normale (abitazione) per country, oppure birth per country
				$country = trim(TPropertyValue::ensureString($arr[0]));
			break;

			default:
				return '';
		}

		if ($zip == '999')
			$zip = '';

		if ($country != '' && ($province != '' || $zip != '' || $city != ''))
			$country = " ($country)";

		if ($zip != '')
		{
			if ($city != '')
				$city = $zip . " " . $city;
			else
				$city = $zip;
		}

		if ($province != '' && $city != '')
			$province = ", $province";

		return $city . $province . $country;
	}

	public static function doSuggestCitizenship($param, $limit = 10)
	{
		$res = array();

		$limit = intval($limit);
		if ($limit < 1)
			$limit = 10;

		$param = trim($param);
		if ($param != '')
		{
			$sql = 'SELECT DISTINCT '. self::CITIZENSHIP . ' FROM ' . self::TABLE_NAME . ' WHERE ' . self::CITIZENSHIP . ' LIKE :param ORDER BY ' . self::CITIZENSHIP .	' LIMIT '. $limit;
			try
			{
				$connection = Propel::getConnection();
				$stmt = $connection->prepare($sql);
				$stmt->execute(array(':param' => "$param%"));

				$firstPatronIds = array();
				$counter = 0;
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
				{
					$res[] = array(
										'id' => $counter,
										'text' => $row['CITIZENSHIP']
										);
					$counter++;
				}
			}
			catch (PDOException $e)
			{
				throw new Exception($e->getMessage());
			}
		}
		return $res;
	}

	public static function retrieveByBarcode($barcode, $criteria = null)
	{
		$barcode = trim($barcode);

		if (is_null($criteria) || !($criteria instanceof Criteria))
			$criteria = new Criteria();

		$criteria->addAnd(self::BARCODE, $barcode, Criteria::EQUAL);
		$result = self::doSelect($criteria);
		return $result;
	}

	public static function getNavigateUrl($id = null)
	{
		$subfix = "";
		$id = intval($id);
		if ($id > 0)
			$subfix = $id;

		return 'index.php?page=' . self::getViewPage() .'&id=' . $subfix;
	}

	public static function getViewPage()
	{
		return 'Circulation.PatronViewPage';
	}

} // PatronPeer
