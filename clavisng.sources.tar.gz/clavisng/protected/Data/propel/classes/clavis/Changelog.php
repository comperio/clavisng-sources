<?php

require_once 'clavis/om/BaseChangelog.php';

class Changelog extends BaseChangelog {

} // Changelog
