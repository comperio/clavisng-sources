<?php
/**
 * LibraryPeer class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
// include base peer class
require_once 'clavis/om/BaseLibraryPeer.php';

// include object class
include_once 'clavis/Library.php';

/**
 * LibraryPeer class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class LibraryPeer extends BaseLibraryPeer
{
	const BLANKVALUE = 0;
	const EXCLUDEMYLIBRARY = -1;
	const MAX_LIBRARY_ID = 999999;

	const OPEN = 1;
	const CLOSED = -1;
	const PAUSE = 0;
	const NOTSETOPEN = -2;

	const STATUS_ACTIVE		= 'A';
	const STATUS_INACTIVE	= 'B';
	const STATUS_CLOSED		= 'C';

	public static $_libraries = array();

	/**
 	 * Performs an extraction of all library objects according to the
	 * given parameters:
	 *
	 * @param int $currentPage			current page of grid
	 * @param int $pageSize				size of page (10, 20, ....)
	 * @param string $searchString		optional string which have to match a library.label
	 * @param array $excludedIds		optional array of libraries whose ids are to be excluded
	 * @return array
	 */
	static public function extractAllLLibraryLibrarian(	$currentPage,
															$pageSize,
															$searchString = '',

															$active = null,
															$external = null,
															$excludedIds = null,

															$open = null) // 7
	{
		$c = new Criteria();
		$c->addAscendingOrderByColumn(LibraryPeer::DESCRIPTION);
		if ($pageSize > 0)
		{
			$c->setLimit($pageSize);
			$c->setOffset($currentPage * $pageSize);
		}

		if ($searchString !== '')
			$c->add(self::DESCRIPTION , "%" . $searchString . "%", Criteria::LIKE);

		if (!is_null($active))
			$c->add(self::LIBRARY_STATUS , $active);

		if (!is_null($external))
		{
			if ($external === "1")
				$c->add(self::LIBRARY_INTERNAL, 1);

			if ($external === "0")
				$c->add(self::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);
		}

		if (is_array($excludedIds))
			$c->add(self::LIBRARY_ID, $excludedIds, Criteria::NOT_IN);

		if (!is_null($open))
		{
			$c->addJoin(LibraryPeer::LIBRARY_ID, LibraryTimetablePeer::LIBRARY_ID, criteria::INNER_JOIN);
			$c->addAnd(LibraryTimetablePeer::TIMETABLE_DAY, date("Y-m-d"));

			if ($open === "1")
			{
				$c->addAnd(LibraryTimetablePeer::TIMETABLE_OPEN, true);
			}
			elseif ($open === "-1")
			{
				$c->addAnd(LibraryTimetablePeer::TIMETABLE_OPEN, false);
			}
		}

		$libraries = self::doSelect($c);

		return $libraries;
	}

	/**
	 * Performs an extraction of the total number of library objects
	 * according to the given parameters:
	 *
	 * @param string $searchString		optional string which have to match a library.label
	 * @param array $excludedIds		optional array of libraries whose ids are to be excluded
	 * @return array
	 */
	static public function countAllLLibraryLibrarian($searchString = '',
														$active = null,
														$external = null,

														$excludedIds = null,
														$open = null)  // 5
	{
		$c = new Criteria();

		if ($searchString !== '')
			$c->add(self::DESCRIPTION , "%" . $searchString . "%", Criteria::LIKE);

		if (!is_null($active))
			$c->add(self::LIBRARY_STATUS , $active);

		if (!is_null($external))
		{
			if ($external === "1")
				$c->add(self::LIBRARY_INTERNAL, 1);

			if ($external === "0")
				$c->add(self::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);
		}

		if (!is_null($excludedIds) and (is_array($excludedIds)))
			$c->add(self::LIBRARY_ID, $excludedIds, Criteria::NOT_IN);

		if (!is_null($open))
		{
			$c->addJoin(LibraryPeer::LIBRARY_ID, LibraryTimetablePeer::LIBRARY_ID, criteria::INNER_JOIN);
			$c->addAnd(LibraryTimetablePeer::TIMETABLE_DAY, date("Y-m-d"));

			if ($open === "1")
			{
				$c->addAnd(LibraryTimetablePeer::TIMETABLE_OPEN, true);
			}
			elseif ($open === "-1")
			{
				$c->addAnd(LibraryTimetablePeer::TIMETABLE_OPEN, false);
			}
		}

		$count = parent::doCount($c);
		return $count;
	}

	/**
	 * It extracts the description of the library whose id
	 * is passed as the parameter.
	 *
	 * @param int $libraryId
	 * @return string
	 */
	static public function getLibraryDescription($libraryId)
	{
		$libraryId = intval($libraryId);

		if ($libraryId > 0)
		{
			$library = self::retrieveByPK($libraryId);
			if (!is_null($library))
				return $library->getDescription();
			else
				return Prado::localize('(senza nome)');
		}
		else
			return Prado::localize('(senza nome)');
	}

	/**
	 * It extracts the label of the library whose id
	 * is passed as the parameter.
	 *
	 * @param int $libraryId
	 * @param string $fallbackLabel
	 * @return string
	 */
	static public function getLibraryLabel($libraryId, $fallbackLabel='')
	{
		if (!self::$_libraries) {
			$crit = new Criteria();
			$crit->clearSelectColumns()->addSelectColumn(self::LIBRARY_ID);
			$crit->addSelectColumn(self::LABEL);
			$stmt = self::doSelectStmt($crit);
			while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
				self::$_libraries[$row[0]] = $row[1];
			}
		}
		return array_key_exists($libraryId, self::$_libraries) ?
			self::$_libraries[$libraryId] : $fallbackLabel;
	}

	static public function getLibraries($activeonly = false, $internal = null)
	{
		$criteria = new Criteria();

		if ($activeonly)
			$criteria->add(self::LIBRARY_STATUS,LibraryPeer::STATUS_ACTIVE);

		if ($internal === true)
			$criteria->add(self::LIBRARY_INTERNAL, "1");
		elseif ($internal === false)
			$criteria->add(self::LIBRARY_INTERNAL, "1", Criteria::NOT_LIKE);

		$libraries = parent::doSelect($criteria);
		$output = array();

		foreach ($libraries as $library)
			$output[] = $library->getLibraryId();

		return $output;
	}

	/**
	 *
	 * @param int|array $indexes 
	 * @param string|array $contents
	 * @param boolean $activeonly
	 * @param boolean $internal
	 * @param boolean $appendExternal
	 * @param boolean $trim
	 * @param int $orderMode
	 * @return array
	 */
	static public function getLibrariesHash(	$indexes = null,
												$contents = null,
												$activeonly = false,
												$internal = null,
												$appendExternal = false,
			
												$trim = null,
												$orderMode = 1)
	{
		$libquery = LibraryQuery::create();

		if ($activeonly)
			$libquery->filterByLibraryStatus(LibraryPeer::STATUS_ACTIVE);

		if ($internal === true)
			$libquery->filterByLibraryInternal('1');
		else if ($internal === false)
			$libquery->filterByLibraryInternal('1',Criteria::NOT_LIKE);

		switch ($orderMode)
		{
			case 4:
				$libquery->useLLibraryRelatedByToLibraryIdQuery(null, Criteria::LEFT_JOIN)
								->orderByDistance(Criteria::DESC)
							->endUse()
						->orderByLibraryId();
				break;

			case 3:
				$libquery->useLLibraryRelatedByToLibraryIdQuery(null, Criteria::LEFT_JOIN)
								->orderByDistance(Criteria::ASC)
							->endUse()
						->orderByLibraryId();
				break;

			case 2:
				$libquery->orderByLabel(Criteria::DESC)
						->orderByLibraryId();
				break;
			
			case 1:
			case null:
			default:
				$libquery->orderByLabel(Criteria::ASC)
						->orderByLibraryId();
				break;
		}
		
		$libraries = $libquery
					->find();

		$output = array();

		if (is_int($indexes) && is_string($contents) && (trim($contents) != ''))
			$output[$indexes] = trim($contents);
		else if (is_array($indexes) && is_array($contents) && (count($indexes) == count($contents)))
			foreach ($indexes as $counter => $index)
				$output[$index] = $contents[$counter];

		foreach ($libraries as $library)
			if (!array_key_exists($library->getLibraryId(), $output))
				$output[$library->getLibraryId()] = $library->getLabel($appendExternal, true, null, $trim);

		return $output;
	}

	/**
	 * It returns a hash with all the libraries present in the database.
	 * The indexes are their ids, while elements pointed are their description.
	 * First one is a "blank", indexed by 0.
	 * 
	 * @param boolean $activeonly If true, returns only active libraries (defaults to false)
	 * @param mixed $internal If true returns only internal libraries, if false returns only external ones,
	 *							if null does not apply filtering on internal status (defaults to null).
	 * @param boolean $appendExternal Adds a suffix to external libraries.
	 * @param mixed $trim
	 * @return array
	 */
	static public function getLibrariesHashWithBlank($activeonly = false,
														$internal = null,
														$appendExternal = false,
														$trim = null )
	{
		return self::getLibrariesHash(self::BLANKVALUE,
										'---',
										$activeonly,
										$internal,
										$appendExternal,
										$trim );
	}

	/**
	 * It returns a hash with all the libraries present in the
	 * database.
	 * The indexes are their ids, while elements pointed are their
	 * label (short text).
	 *
	 * If parameter $blank is true, a first line with a null text of
	 * '---' is added, indexed by 0.
	 *
	 * @param boolean $blank
	 * @return array
	 */
	static public function getLibraryLabelsHash($blank = false)
	{
		$output = array();
		$criteria = new Criteria();
		//$criteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
		$criteria->addAscendingOrderByColumn(LibraryPeer::DESCRIPTION);
		$libraries = parent::doSelect($criteria);
		if (count($libraries) > 0)
		{
			if ($blank)
				$output[0] = '---';
			foreach ($libraries as $library)
				$output[$library->getLibraryId()] = $library->getLabel();
		}
		return $output;
	}

	static public function getNavigateUrl($libraryId = null)
	{
		$subfix = "";
		$libraryId = intval($libraryId);
		if ($libraryId > 0)
			$subfix = $libraryId;

		return 'index.php?page=' . self::getViewPage() . '&id=' . $subfix;
	}

	public static function getViewPage()
	{
		return 'Library.LibraryViewPage';
	}

	/**
	 * Get a list of libraries based on a start string and optional criterions.
	 *
	 * @param string $token The string to use as a base search.
	 * @param integer $limit The maximum of libraries to return (defaults to 10).
	 * @return Array A list of Libraries.
	 */
	public static function doSuggest($token, $limit=10) {
		$list = LibraryQuery::create()
			->filterByLabel($token.'%')
			->orderByLabel()
			->limit($limit)
			->find();
		return $list;
	}

	public static function getConsortiaString($libraryId, $trim = null)
	{
		/* @var $library Library */
		$output = '';
		if (intval($libraryId) > 0)
		{
			$library = self::retrieveByPK($libraryId);
			if (!is_null($library))
				$output = $library->getConsortiaString($trim);
		}
		return $output;
	}

	public static function getDistanceHash(	$libraryId = null,
												$distanceFilter = null,
												$toLibraryIdFilter = null )
	{
		$output = array();
		
		$libraryId = intval($libraryId);
		if ($libraryId > 0)
		{
			$library = LibraryQuery::create()
							->findPk($libraryId);

			if ($library instanceof Library)
				$output = $library->getDistanceHashFromLibrary(	$distanceFilter,
																$toLibraryIdFilter );
		}
	
		return $output;
	}
	
	public static function getInvertedDistanceHash(	$libraryId = null,
														$distanceFilter = null,
														$fromLibraryIdFilter = null)
	{
		$output = array();
		
		$libraryId = intval($libraryId);
		if ($libraryId > 0)
		{
			$library = LibraryQuery::create()
							->findPk($libraryId);

			if ($library instanceof Library)
				$output = $library->getDistanceHashToLibrary(	$distanceFilter,
																$fromLibraryIdFilter);
		}
	
		return $output;
	}
	
} // LibraryPeer
