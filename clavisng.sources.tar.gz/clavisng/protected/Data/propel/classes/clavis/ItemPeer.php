<?php
/**
 * ItemPeer class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once 'clavis/om/BaseItemPeer.php';
include_once 'clavis/Item.php';

/**
 * ItemPeer Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class ItemPeer extends BaseItemPeer
{
	const NOT_INVENTORY = 2132312312312312312;
	const SAVE_UPDATETITLE = 222;
	
	const ISSUESTATUS_MISSING = 'M';
	const ISSUESTATUS_ARRIVED = 'A';
	const ISSUESTATUS_EXPECTED = 'N';
	const ISSUESTATUS_NEXT = 'P';
	const ISSUESTATUS_LAST = 'U';
	
	const LOANCLASS_AVAILABLE = 'B';
	const LOANCLASS_UNAVAILABLE = 'A';
	const LOANCLASS_LOCALLYAVAILABLE = 'C';
	const LOANCLASS_ONLYCONSULTATION = 'D';
	const LOANCLASS_LOCALCONSULTATION = 'F';
	const LOANCLASS_LOCALNEW30 = 'H';
	const LOANCLASS_LOCALNEW60 = 'I';
	const LOANCLASS_LOCALNEW90 = 'J';
	const LOANCLASS_LOCALNEW10 = 'N';
	const LOANCLASS_SHORTLOAN = 'M';
	
	const LOANTYPE_LOCAL = 'A';
	const LOANTYPE_INTRASYSTEM = 'B';
	const LOANTYPE_CONSULTATION = 'C';
	const LOANTYPE_EXTRASYSTEM = 'X';
	
	const LOANSTATUS_AVAILABLE = 'A';
	const LOANSTATUS_INLOAN = 'B';
	const LOANSTATUS_INTRANSIT = 'C';
	const LOANSTATUS_READYFORTRANSIT = 'E';
	const LOANSTATUS_READYFORLOAN = 'F';
	const LOANSTATUS_CLOSED = 'G';
	const LOANSTATUS_CANCELED = 'H';
	const LOANSTATUS_TOSHELF = 'I';
	const LOANSTATUS_READYFORTRANSITTOHOME = 'J';
	const LOANSTATUS_INLOANEXTRA = 'K';
	const LOANSTATUS_INCONSULTATION = 'M';
	const LOANSTATUS_INFREEZEDCONSULTATION = 'N';
	const LOANSTATUS_AVAILABLEEXTRA = 'X';
	const LOANSTATUS_INTRANSITTOEXTRA = 'Y';
	
	const ITEMLOANALERT_ALWAYS = 'A';
	const ITEMLOANALERT_RETURN = 'B';
	const ITEMLOANALERT_LOAN = 'C';

	//////////////

	public static final function getIssueStatusArrived()
	{
		return array(self::ISSUESTATUS_ARRIVED, self::ISSUESTATUS_LAST);
	}

	public static final function getIssueStatusExpected()
	{
		return array(self::ISSUESTATUS_EXPECTED, self::ISSUESTATUS_NEXT);
	}

	public static final function getLoanClassesAvailable($requestMode = false)
	{
		$output =  array(self::LOANCLASS_AVAILABLE, self::LOANCLASS_SHORTLOAN);
		if ($requestMode)
			$output = array_merge($output, self::getLoanClassesLocalNew());
		return $output;
	}

	public static final function getLoanClassesLocallyAvailable($requestMode = false)
	{
		$output =  array_merge(array(self::LOANCLASS_LOCALLYAVAILABLE,
			self::LOANCLASS_ONLYCONSULTATION,
			self::LOANCLASS_LOCALCONSULTATION));
		if (!$requestMode)
			$output = array_merge($output, self::getLoanClassesLocalNew());
		
		return $output;
	}

	public static final function getLoanClassesLocallyAvailableIgnoringConsultations($requestMode = false)
	{
		$output =  array(self::LOANCLASS_LOCALLYAVAILABLE);
		if (!$requestMode)
			$output = array_merge($output, self::getLoanClassesLocalNew());
		return $output;
	}

	public static final function getLoanClassesLocalNew()
	{
		return array(	self::LOANCLASS_LOCALNEW30,
						self::LOANCLASS_LOCALNEW60,
						self::LOANCLASS_LOCALNEW90,
						self::LOANCLASS_LOCALNEW10);
	}

	public static final function getLoanClassesConsultation()
	{
		return array(	self::LOANCLASS_LOCALCONSULTATION,
						self::LOANCLASS_ONLYCONSULTATION);
	}

	public static final function getLoanStatusAvailable()
	{
		return array(	self::LOANSTATUS_AVAILABLE,
						self::LOANSTATUS_AVAILABLEEXTRA,
						self::LOANSTATUS_READYFORTRANSITTOHOME,
						self::LOANSTATUS_INTRANSITTOEXTRA);
	}

	public static final function getLoanStatusActive()
	{
		return array(	self::LOANSTATUS_INLOAN, // B
						self::LOANSTATUS_INTRANSIT, // C
						self::LOANSTATUS_READYFORTRANSIT, // E
						self::LOANSTATUS_READYFORLOAN, // F
						self::LOANSTATUS_READYFORTRANSITTOHOME, // J
						self::LOANSTATUS_INLOANEXTRA, // K
						self::LOANSTATUS_INCONSULTATION, // M
						self::LOANSTATUS_INFREEZEDCONSULTATION); // N
	}

	public static final function getLoanStatusConsultation()
	{
		return array(	self::LOANSTATUS_INCONSULTATION,
						self::LOANSTATUS_INFREEZEDCONSULTATION);
	}

	public static final function getLoanStatusInactive()
	{
		return array(	self::LOANSTATUS_CLOSED,
						self::LOANSTATUS_CANCELED,
						self::LOANSTATUS_TOSHELF,
						self::LOANSTATUS_AVAILABLE);
	}

	public static final function getLoanStatusClosed()
	{
		return array(	self::LOANSTATUS_CLOSED,
						self::LOANSTATUS_CANCELED);
	}

	public static final function getLoanStatusCurrent()
	{
		return array(	self::LOANSTATUS_INLOAN,
						self::LOANSTATUS_INLOANEXTRA,
						self::LOANSTATUS_INCONSULTATION,
						self::LOANSTATUS_INFREEZEDCONSULTATION);
	}

	public static final function getLoanStatusActiveNotCurrent()
	{
		return array(	self::LOANSTATUS_INTRANSIT,
						self::LOANSTATUS_READYFORTRANSIT,
						self::LOANSTATUS_READYFORTRANSITTOHOME);
	}

	public static final function getLoanStatusPending()
	{
		return array(	self::LOANSTATUS_INTRANSIT,
						self::LOANSTATUS_READYFORTRANSIT,
						self::LOANSTATUS_READYFORLOAN,
						self::LOANSTATUS_INFREEZEDCONSULTATION);
	}

	public static final function getItemStatusLost()
	{
		return ItemStatus::getItemStatusLost();
	}

	public static final function getItemStatusVisible()
	{
		return ItemStatus::getItemStatusVisible();
	}

	public static final function getItemStatusOpacVisible()
	{
		return ItemStatus::getItemStatusOpacVisible();
	}

	public static final function getItemStatusManageable()
	{
		return ItemStatus::getItemStatusManageable();
	}

	public static final function getItemStatusNotAvailable()
	{
		return ItemStatus::getItemStatusNotAvailable();
	}

	public static function retrieveByBarcode($barcode, $criteria = null)
	{
		$barcode = trim($barcode);

		if (is_null($criteria) || !($criteria instanceof Criteria))
			$criteria = new Criteria();

		$criteria->addAnd(self::BARCODE, $barcode, Criteria::EQUAL);
		$items = self::doSelect($criteria);

		return $items;
	}

	public static function splitInventoryNumber($input)
	{
		$return = self::NOT_INVENTORY;
		$matrix = explode('-', $input);

		if (count($matrix) == 2)
			array_unshift($matrix, '');

		if (count($matrix) == 3)
		{
			$matrix[0] = trim($matrix[0]);
			$matrix[1] = trim($matrix[1]);
			$matrix[2] = trim($matrix[2]);

			if (($matrix[1] != '') && ($matrix[2] != ''))
			{
				if ($matrix[0] == '')
				{
					$libraryCode = trim(Prado::getApplication()->getUser()->getActualLibrary()->getLibraryCode());
					if (!is_null($libraryCode) && ($libraryCode != ''))
						$matrix[0] = $libraryCode;
					else
						return self::NOT_INVENTORY;
				}
				$return = $matrix;
			}
		}
		
		return $return;
	}

	public static function retrieveByInventoryNumber($input, $criteriaParameter = null)
	{
		$return = self::NOT_INVENTORY;

		$matrix = self::splitInventoryNumber($input);
		if (!is_null($matrix) && ($matrix != self::NOT_INVENTORY))
		{
			$libraryCode = $matrix[0];
			$inventorySerieId = $matrix[1];
			$inventoryNumber = $matrix[2];

			$criteria = self::calculateInventoryCriteria($libraryCode, $inventorySerieId, $inventoryNumber, $criteriaParameter);
			$items = ItemPeer::doSelect($criteria);
			$return = $items;
		}
		
		return $return;
	}

	public static function calculateInventoryCriteria($libraryCode, $inventorySerieId, $inventoryNumber, $criteria = null)
	{
		if (is_null($criteria) || !($criteria instanceof Criteria))
			$criteria = new Criteria;

		$criteria->add(ItemPeer::INVENTORY_SERIE_ID, $inventorySerieId);
		$criteria->add(ItemPeer::INVENTORY_NUMBER, $inventoryNumber);

		return $criteria;
	}

	public static function retrieveByDataInput($input, $criteriaParam = null)
	{
		if (is_object($criteriaParam))
			$criteria = clone($criteriaParam);
		else
			$criteria = null;

		$result = null;

		if (is_null($input) || !is_string($input))
			return null;
		if ($input === '')
			return null;

		$result = self::retrieveByInventoryNumber($input, $criteria);
		if ($result == self::NOT_INVENTORY)
			$result = self::retrieveByBarcode($input, $criteria);

		return $result;
	}

	public static function checkBarcodeUnique($barcode, $item = null)
	{
		if (is_null($barcode) || !trim($barcode))
			return true;
		$q = ItemQuery::create()
				->filterByBarcode($barcode);
		if ($item instanceof Item)
			$q->prune($item);
		
		return $q->count() == 0;
	}

	public static function checkInventoryUnique($inventory_number, $inventory_serie = null, $item = null)
	{
		if (is_null($inventory_number) || !trim($inventory_number))
			return true;
		$q = ItemQuery::create()
				->filterByInventoryNumber($inventory_number);

		if ($inventory_serie instanceof InventorySerie)
			$q->filterByInventorySerie($inventory_serie);
		elseif ($inventory_serie)
			$q->filterByInventorySerieId($inventory_serie);

		if ($item instanceof Item)
			$q->prune($item);
		
		return $q->count() == 0;
	}

	public static function encodeItems2Url($items = array())
	{
		$return = '';

		foreach ($items as $item)
		{
			if (!is_null($item) && ($item instanceof Item))
			{
				$itemId = $item->getItemId();
				if (!is_null($itemId) && ($itemId > 0))
					$return .= "id[]=" . $itemId . "&";
			}
		}

		return $return;
	}

	public static function isInventoryDuplicated($serieId, $inventoryNumber, $ownerLibraryId)
	{
		$criteria = new Criteria();
		$criteria->add(ItemPeer::INVENTORY_NUMBER, $inventoryNumber);
		$criteria->add(ItemPeer::INVENTORY_SERIE_ID, $serieId);
		$criteria->add(ItemPeer::HOME_LIBRARY_ID, $ownerLibraryId);
		
		return ItemPeer::doCount($criteria) > 0;
	}

	public static function encodeRenew($data)
	{
		if (!is_numeric($data))
			return null;
		if ($data < 0)
			return $data;
		return -10 * abs($data) - 1;
	}

	public static function decodeRenew($data)
	{
		if (!is_numeric($data))
			return 0;
		if ($data >= 0)
			return $data;
		return intval(abs($data) / 10);
	}

	public static function getNavigateUrl()
	{
		return 'index.php?page=Catalog.ItemViewPage&id=';
	}
}
// ItemPeer
