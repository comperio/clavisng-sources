<?php

require_once 'clavis/om/BaseLManifestationPeer.php';
include_once 'clavis/LManifestation.php';

class LManifestationPeer extends BaseLManifestationPeer {

	const SRCSYNC_FALSE = '0';
	const SRCSYNC_TRUE = '1';

} // LManifestationPeer
