<?php

  // include base peer class
  require_once 'clavis/om/BaseAttachmentPeer.php';

  // include object class
  include_once 'clavis/Attachment.php';

class AttachmentPeer extends BaseAttachmentPeer {

	const L1_PATHLENGTH = 1;
	const L2_PATHLENGTH = 1;
	const L3_PATHLENGTH = 1;

	const TYPE_PHOTO	= 'A';
	const TYPE_AVATAR	= 'B';
	const TYPE_DOCUMENT	= 'C';
	const TYPE_GENERIC	= 'D';
	const TYPE_COVER	= 'E';
	const TYPE_INDEX	= 'F';
	const TYPE_TEXT		= 'G';
	const TYPE_FULLTEXT	= 'H';
	const TYPE_AUDIO	= 'I';
	const TYPE_VIDEO	= 'J';
	const TYPE_IMAGE	= 'P';

	public static function getRealStoragePath() {
		return realpath(Prado::getPathOfNamespace('Storage.files'));
	}

	/**
	 *
	 * @param string $objectClass
	 * @param string $objectId
	 * @param string $attachmentType
	 * @param string $attachment_id
	 * @return array
	 */
	public static function hashEntry($objectClass, $objectId, $attachmentType, $filename) {
 		$fullName = $objectClass.'_'.$objectId.'_'.$attachmentType.'_'.$filename;
 		$fullHash = md5($fullName);

 		$hash_parts = array(
			'L1'	=> substr($fullHash,0,self::L1_PATHLENGTH),
			'L2'	=> substr($fullHash,self::L1_PATHLENGTH, self::L2_PATHLENGTH),
			'L3'	=> substr($fullHash,self::L1_PATHLENGTH + self::L2_PATHLENGTH, self::L3_PATHLENGTH),
			'filename'	=> $fullName);

 		return $hash_parts;
 	}

	/**
	 *
	 * @param string $objectClass
	 * @param string $objectId
	 * @param string $attachmentType
	 * @param string $attachment_id
	 * @return string
	 */
 	public static function hashEntryAsString($objectClass, $objectId, $attachmentType, $attachment_id) {
 		$hash_parts = self::hashEntry($objectClass,$objectId,$attachmentType,$attachment_id);
 		$as_string = $hash_parts['L1'].'/'.$hash_parts['L2'].'/'.$hash_parts['L3'].'/'.$hash_parts['filename'];
 		return $as_string;
 	}

} // AttachmentPeer
