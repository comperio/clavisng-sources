<?php
/**
 * DocumentTemplatePeer class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once 'clavis/om/BaseDocumentTemplatePeer.php';
include_once 'clavis/DocumentTemplate.php';

/**
 * DocumentTemplatePeer Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.4.1
 */
class DocumentTemplatePeer extends BaseDocumentTemplatePeer {

	const MEDIA_EMAIL	= 'E';
	const MEDIA_SMS		= 'S';
	const MEDIA_JASPER	= 'J';

	/**
	 * Retrieves a template by a library; if the template does not exists for
	 * a library, fallbacks on the default template.
	 *
	 * @param string $class The template's class
	 * @param string $lang The template language. Mandatory.
	 * @param integer $library The library ID, defaults to null.
	 * @return DocumentTemplate The template if found, null elsewhere
	 */
	public static function getTemplate($class,$lang,$library=null) {
		$templates = self::getTemplates($class,$lang,$library,true);
		return (count($templates) > 0) ? $templates[0] : null;
	}

	/**
	 * Retrieves a list of templates by a library; if the template does not exists for
	 * a library, can fallback on the default templates.
	 *
	 * @param string $class The template's class
	 * @param string $lang The template language. Mandatory.
	 * @param integer $library The library ID, defaults to null.
	 * @param boolean $fallbackOnDefault Whether to fallback on null library if library
	 *					templates not found (defaults to true).
	 * @return PropelObjectCollection the list of templates.
	 */
	public static function getTemplates($class,$lang,$library=null,$fallbackOnDefault=true) {
		$tpl = DocumentTemplateQuery::create()
			->filterByTemplateClass($class)
			->filterByTemplateLang($lang)
			->filterByLibraryId($library)
			->orderByTemplateTitle();
		if ($library && $tpl->count() < 1 && $fallbackOnDefault)
			$tpl = DocumentTemplateQuery::create()
				->filterByTemplateClass($class)
				->filterByTemplateLang($lang)
				->filterByLibraryId(null)
				->orderByTemplateTitle();
		return $tpl->find();
	}

	/**
	 * Retrieves a list of templates by a library, merging them with the default ones.
	 *
	 * @param string $class The template's class
	 * @param string $lang The template language. Mandatory.
	 * @param integer $library The library ID, defaults to null.
	 * @return array of DocumentTemplate objects
	 */
	public static function getAllTemplates($class,$lang,$library=null) {
		$c = new Criteria();
		$c->add(self::TEMPLATE_CLASS,$class);
		$c->add(self::TEMPLATE_LANG,$lang);
		$c->add(self::LIBRARY_ID,null);
		$c->addAscendingOrderByColumn(self::TEMPLATE_TITLE);
		$documents = self::doSelect($c);
		if ($library) {
			$c->add(self::LIBRARY_ID,$library);
			$documents = array_merge($documents,self::doSelect($c));
		}
		return $documents;
	}

	/**
	 * Takes a template
	 *
	 */
	public static function templateTransform($tpl, Array $arr_values) {
		foreach ($arr_values as $placeholder => $value) {
			if (is_array($value)) {
				$pregex_search_loop = "/(.*){{$placeholder}}(.*){END{$placeholder}}(.*)/ms";
				if ($ret = preg_match($pregex_search_loop,$tpl,$matches)) {
					$tpl = $matches[1];
					foreach ($value as $sub_values)
						$tpl .= self::templateTransform($matches[2], $sub_values);
					$tpl .= $matches[3];
				}
			} else {
				$tpl = str_replace('{'.$placeholder.'}',$value,$tpl);
			}
		}
		return $tpl;
	}
} // DocumentTemplatePeer
