<?php

  // include base peer class
  require_once 'clavis/om/BaseLoanPeer.php';

  // include object class
  include_once 'clavis/Loan.php';

class LoanPeer extends BaseLoanPeer {

	public static function updateTitle($paramObject = null)
	{
		if (! $paramObject instanceof Manifestation && 
				! $paramObject instanceof Item)
			return false;
		$count = 0;
		$item_pool = ($paramObject instanceof Manifestation) ? 
			$paramObject->getItems() : array($paramObject);
		
		foreach ($item_pool as $item) {
			$newTitle = $item->getCompleteTitle();
			$count += LoanQuery::create()
				->filterByItemRelatedByItemId($item)
				->update(array('Title' => $newTitle));
		}
		return $count;
	}

	/**
	 * Selects a collection of Loan objects pre-filled with their Item objects.
	 * Alias for self::doSelectJoinItemRelatedByItemId()
	 * 
	 * @param      Criteria  $criteria
	 * @param      PropelPDO $con
	 * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
	 * @return     array Array of Loan objects.
	 * @throws     PropelException Any exceptions caught during processing will be
	 *		 rethrown wrapped into a PropelException.
	 */
	public static function doSelectJoinItem(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
	{
		return self::doSelectJoinItemRelatedByItemId($criteria, $con, $join_behavior);
	}


} // LoanPeer
