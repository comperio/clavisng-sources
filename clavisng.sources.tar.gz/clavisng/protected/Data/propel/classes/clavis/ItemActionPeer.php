<?php

  // include base peer class
  require_once 'clavis/om/BaseItemActionPeer.php';

  // include object class
  include_once 'clavis/ItemAction.php';

class ItemActionPeer extends BaseItemActionPeer {

	const TYPE_LOAN			= 'A';
	const TYPE_RETURN		= 'B';
	const TYPE_RENEWAL		= 'C';
	const TYPE_SOLICIT		= 'D';
	const TYPE_READYFORTRANSIT	= 'E';
	const TYPE_INTRANSIT		= 'F';
	const TYPE_MANAGEREQUEST	= 'G';
	const TYPE_ABORT		= 'H';
	const TYPE_ABORTGENERIC	= 'H';
	const TYPE_READYFORLOAN	= 'I';
	const TYPE_BACKTOSHELF	= 'J';
	const TYPE_EXTRALOAN	= 'K';
	const TYPE_EXTRARETURN	= 'L';
	const TYPE_CONSULTATION	= 'O';
	const TYPE_CONSULTSUSPEND	= 'P';
	const TYPE_CONSULTRESUME	= 'Q';
	const TYPE_CONSULTRETURN	= 'R';
	const TYPE_NOTIFY			= 'S';
	const TYPE_DISABLERENEWAL	= 'T';
	const TYPE_ENABLERENEWAL	= 'U';
	const TYPE_ABORTLIBRARYERROR	= 'W';
	const TYPE_EXTRAACCEPT		= 'X';
	const TYPE_EXTRAGOHOME		= 'Y';
	const TYPE_ABORTNOLOAN		= 'Z';

	public static function getAbortTypes()
	{
		return array(self::TYPE_ABORTGENERIC, self::TYPE_ABORTLIBRARYERROR, self::TYPE_ABORTNOLOAN);
	}
	
} // ItemActionPeer
