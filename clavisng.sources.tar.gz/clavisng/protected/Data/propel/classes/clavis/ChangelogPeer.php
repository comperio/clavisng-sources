<?php

require_once 'clavis/om/BaseChangelogPeer.php';
include_once 'clavis/Changelog.php';

class ChangelogPeer extends BaseChangelogPeer
{
	const LOG_CREATE          = 'A';
	const LOG_UPDATE          = 'B';
	const LOG_DELETE          = 'C';
	const LOG_OPEN            = 'D';
	const LOG_CLOSE           = 'E';
	const LOG_MODIFY          = 'F';
	const LOG_ERROR           = 'G';
	const LOG_WARNING         = 'H';
	const LOG_UNKNOWN         = 'J';
	const LOG_PATRONCARDPRINT = 'K';

	/**
	 * Logs an action into database.
	 *
	 * @param mixed $object The object affected by the action. It can be either an istance of an object, or a string.
	 * @param string $action The action taken. Choose among the LOG_* constants of this class.
	 * @param mixed $user The user taking the action.
	 * @param string $description An optional description for the action.
	 * @param integer $objectId The object id, when $object is a string.
	 */
	public static function logAction($object, $action = self::LOG_UNKNOWN, $user = null, $description = '', $objectId = null)
	{
		$object_class = 'null';
		$object_id    = null;

		if (is_object($object)) {
			$object_class = get_class($object);
			$object_id = (method_exists($object, 'getId')) ? $object->getId() : null;
		} else if (is_string($object)) {
			$object_class = ucfirst($object);
			if (intval($objectId) > 0)
				$object_id = intval($objectId);
		}

		$libraryId = null;

		if (is_object($user)) {
			$user_class = get_class($user);
			$user_id    = (method_exists($user, 'getId')) ? $user->getId() : null;

			if ($user_class == 'ClavisLibrarian')
				$libraryId = $user->getActualLibraryId();
		} else {
			$user_class = 'ClavisLibrarian';
			$user_id = intval($user) or 1;
		}

		$current_librarian_sess_id = (class_exists('Prado') && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian)
			? $u->getLibrarianSessionId() : null;

		$entry = new Changelog();
		$entry->setEventDate(time());
		$entry->setEventType($action);
		$entry->setEventDescription($description);
		$entry->setObjectClass($object_class);
		$entry->setObjectId($object_id);
		$entry->setUserClass($user_class);
		$entry->setUserId($user_id);
		$entry->setSessionId($current_librarian_sess_id);
		$entry->setLibraryId($libraryId);

		$entry->save();
	}
} // ChangelogPeer
