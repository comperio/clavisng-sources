<?php

// include base peer class
require_once 'clavis/om/BaseConsistencyNotePeer.php';

// include object class
include_once 'clavis/ConsistencyNote.php';


class ConsistencyNotePeer extends BaseConsistencyNotePeer {

} // ConsistencyNotePeer
