<?php

require_once 'clavis/om/BaseSubscription.php';

class Subscription extends BaseSubscription {

	/**
	 * It returns the id of the subscription (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->subscription_id;
	}


	public function getSubscriptionCombo() {
		return '';
	}

} // Subscription
