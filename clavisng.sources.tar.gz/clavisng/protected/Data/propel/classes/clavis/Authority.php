<?php
/**
 * Authority class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseAuthority.php';

/**
 * Authority Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class Authority extends BaseAuthority
{

    public $links = array();
    /* @var TurboMarc */
    private $_tmarc = null;
    private $needLinkUpdate;

    public function getNeedLinkUpdate()
    {
        return $this->needLinkUpdate;
    }

    public function setNeedLinkUpdate($needLinkUpdate)
    {
        $this->needLinkUpdate = $needLinkUpdate;
    }

    public function preDelete(PropelPDO $con = null)
    {
        if (!$this->isDeleteable())
            throw new Exception('Cannot delete authority because link exists.');
        if ($this->getAuthorityType() == AuthorityPeer::TYPE_SUBJECT)
            foreach ($this->getLSubjectsRelatedBySubjectId() as $l)
                $l->delete();

        // delete cache on predelete to avoid constraint complaints
        TurbomarcauthorityCacheQuery::create()
            ->filterByAuthorityId($this->authority_id)
            ->delete();

        $this->deIndex();
        return true;
    }

    public function preSave(PropelPDO $con = null)
    {
        // encuser tmarc is valorized
        $this->getTurboMarc();
        switch ($this->getAuthorityType()) {

            case AuthorityPeer::TYPE_WORK:
                $this->preSaveWork();
                break;

            case AuthorityPeer::TYPE_SUBJECT:
                $this->preSaveSubject();
                break;

            case AuthorityPeer::TYPE_CLASS:
                $this->preSaveClass();
                break;

            case AuthorityPeer::TYPE_PRINTERSDEVICE:
                $this->preSavePrintersDevice();
                break;

            default:
                $this->preSaveDefault();
                break;
        }

        if ($this->needLinkUpdate == FALSE) {
            $this->needLinkUpdate = $this->isColumnModified(AuthorityPeer::FULL_TEXT);
        }

        return true;
    }

    public function postInsert(PropelPDO $con = null)
    {
        $cache = $this->getTurbomarcauthorityCache();
        if (!$cache instanceof TurbomarcauthorityCache) {
            $cache = new TurbomarcauthorityCache();
            $cache->setAuthorityId($this->authority_id);
            $cache->setIndexed(false);
            $cache->setDirty(true);
            $cache->save();
        }
        return true;
    }

    public function postUpdate(PropelPDO $con=null)
    {
        if (defined('NO_REALTIME_INDEX'))
            return true;

        // invalidate cache
        $this->invalidateCache();
        if (class_exists('Prado') && TPropertyValue::ensureBoolean(Prado::getApplication()->getModule('search')->getRealtimeIndexing()))
            $this->doIndex();
        return true;
    }

    public function postSave(PropelPDO $con = null)
    {
        switch ($this->getAuthorityType())
        {
            case AuthorityPeer::TYPE_SUBJECT:
                break;

            case AuthorityPeer::TYPE_CORPORATEBODYNAME:
            case AuthorityPeer::TYPE_PERSONALNAME:
            case AuthorityPeer::TYPE_FAMILYNAME:
                if ($this->needLinkUpdate) {
                    $this->updateLinkedWorks();
                    $this->updateLinkedManifestations();
                }
            // don't break here

            case AuthorityPeer::TYPE_WORK:
            case AuthorityPeer::TYPE_CLASS:
            case AuthorityPeer::TYPE_ARGUMENT:
            case AuthorityPeer::TYPE_SERIE:
            case AuthorityPeer::TYPE_PLACE:
            case AuthorityPeer::TYPE_PUBPLACE:
            case AuthorityPeer::TYPE_TRADEMARK:
            case AuthorityPeer::TYPE_PRINTERSDEVICE:
            case AuthorityPeer::TYPE_CHRONOLOGICAL:
            default:
                if ($this->needLinkUpdate) {
                    $this->updateLinkedSubjects();
                }
                break;
        }

        if (!defined('NO_CACHE_DIRTY')) {
            $this->invalidateManifestationsCache();
        }

        if (!defined('NO_REALTIME_INDEX')) {
            $this->doIndex();
        }

        return true;
    }


    public function updateNarrowedTerm()
    {
        //$stack = array($this->getFullText());
        //$narrowwd = LAuthority::create()


    }

    public function doIndex()
    {
        // comment below to enable authority indexing.
        //return;

        // TBD here are lions
        $search = Prado::getApplication()->getModule('search');
        $this->cacheTurboMarc(false);
        $search->indexAuthority(array($this->authority_id => $this->getFullTurboMarc()));
    }

    public function deIndex()
    {

        /** @var SolrSearch $search */
        $search = Prado::getApplication()->getModule('search');
        $search->deIndexAuthority($this->authority_id);
    }

    /**
     * Returns the TurboMarc for manifestation's unimarc.
     *
     * @return TurboMarc
     * @throws Exception
     */
    public function getTurboMarc()
    {
        if (!class_exists('TurboMarc')) {
            throw new Exception('TurboMarc class doesn\'t exists', 1);
        }
        if (!$this->_tmarc instanceof TurboMarc) {
            try {
                if ($this->getUnimarc())
                    $this->_tmarc = TurboMarcUtility::sanitize(TurboMarc::createRecord(Clavis::html2xmlEntities($this->getUnimarc())));
                else
                    $this->initTurbomarc();
            } catch (Exception $e) {
                throw new Exception("Unimarc is {$this->getUnimarc()} - Exception throwed: $e");
            }
        }
        return $this->_tmarc;
    }

    private function initTurbomarc()
    {
        $this->_tmarc = TurboMarc::createRecord();
        $l = new TurboMarcLeader();
        $l->recLen = '01234';
        $l->recstatus = 'n';
        $l->type = $this->authority_rectype;
        $l->entitytype = AuthorityPeer::mapTypeClavisToUnimarc($this->authority_type);

        $this->_tmarc->setLeader($l);

        $f001 = $this->_tmarc->setControlField('001', $this->authority_id);
        $c005 = $this->_tmarc->setControlField('005', date('Ymdhms.0'));
        $f100 = $this->_tmarc->addField('100');
        $f100->setCDF('a', 0, $this->getDateUpdated('Y-m-d'));
        $f100->setCDF('a', 8, $this->authority_status);
        $f100->setCDF('a', 13, 50);    // ISO 10646
        return $this->_tmarc;
    }

    /**
     * Override parent implementation to force Turbomarc reload.
     *
     * @param string $v
     * @return Authority The current object (for fluent API support)
     */
    public function setUnimarc($v)
    {
        parent::setUnimarc($v);
        $this->reloadTurboMarc();
        return $this;
    }

    /**
     * Returns the TurboMarc for manifestation's unimarc, forcing its reload.
     *
     * @return TurboMarc
     */
    public function reloadTurboMarc()
    {
        $this->_tmarc = null;
        return $this->getTurboMarc();
    }

    /**
     *
     * @param boolean $onlyDirty
     * @param boolean $asXML
     * @return string The turbomarc.
     */
    public function cacheTurboMarc($onlyDirty = true, $asXML = true)
    {
        $cache = $this->getTurbomarcauthorityCache();
        if (!$cache instanceof TurbomarcauthorityCache) {
            $cache = new TurbomarcauthorityCache();
            $cache->setAuthorityId($this->authority_id);
        }
        if ($onlyDirty && !$cache->isNew() && !$cache->getDirty())
            return $asXML ? $cache->getTurbomarc() : TurboMarc::createRecord($cache->getTurbomarc());
        $cache->setTurbomarc($this->getFullTurboMarc(true, false, true));
        $cache->setIndexed($cache->getIndexed() && !$cache->getDirty());
        $cache->setDirty(false);
        $cache->save();
        $turbomarc = $cache->getTurbomarc();
        $cache->clearAllReferences(true);
        if (!$asXML)
            $turbomarc = TurboMarc::createRecord($turbomarc);
        return $turbomarc;
    }

    public function invalidateCache()
    {
        if (defined('NO_CACHE_DIRTY'))
            return true;
        TurbomarcauthorityCachePeer::invalidate($this->authority_id);
    }

    public function invalidateManifestationsCache()
    {
        $updated = Propel::getConnection()->exec(
            'UPDATE ' . LAuthorityManifestationPeer::TABLE_NAME . ' LEFT JOIN ' . TurbomarcCachePeer::TABLE_NAME
            . ' ON ' . LAuthorityManifestationPeer::MANIFESTATION_ID . '=' . TurbomarcCachePeer::MANIFESTATION_ID
            . ' SET ' . TurbomarcCachePeer::DIRTY . '=1 WHERE ' . LAuthorityManifestationPeer::AUTHORITY_ID . '=' . $this->authority_id);
        if ($this->getAuthorityRectype() == AuthorityPeer::RECTYPE_VARIANT) {
            $accepted = $this->getAcceptedAuthority();
            if ($accepted instanceof Authority)
                $accepted->invalidateManifestationsCache();
        }
        return;
    }

    public function setSortText($v)
    {
        if (AuthorityPeer::TYPE_SUBJECT != $this->authority_type) {
            $v = trim($v);
            $p = strpos($v, '*');
            if ($p > 0) {
                // only set non-sort if * is NOT at string start.
                $nst = substr($v, 0, $p);
                $this->setNonSortText($nst);
                $v = substr($v, $p + 1);
            } else {
                $this->setNonSortText(null);
            }
        }
        parent::setSortText($v);
    }

    /**
     * Returns the authority text complete with non-sort/sort parts.
     *
     * @return string The authority complete text
     */
    public function getCompleteText()
    {
        $nonSortText = $this->getNonSortText();
        $text = trim($this->getSortText());
        if ($nonSortText)
            $text = $nonSortText . '*' . $text;
        return trim($text);
    }

    public function getNotes()
    {
        $this->getTurboMarc();
        $notes = array();
        foreach (array('d300','d305','d310','d320','d330','d340','d390','d391','d392','d393','d394','d395','d396','d830','d928','d929') as $tag) {
            if (isset($this->_tmarc->$tag)) {
                $noteTag = intval(substr($tag, 1));

                foreach($this->_tmarc->$tag as $fld) {
                    $noteText = "";

                    if ($noteTag > 900) {
                        foreach($fld->children() as $c)
                            if(trim((string)$c) != '')
                                $noteText .= "<[" .substr($c->getName(),1) ."] " .$c['l'] .">\n:" .(string)$c ."\n";
                    } else
                        $noteText = (string)$fld->sa;

                    $notes[] = array('NoteNumber' => $noteTag, 'NoteValue' => trim($noteText));
                }
            }
        }
        return $notes;
    }

    public function setNotes($v)
    {
        $this->getTurboMarc();
        foreach (array('d300','d305','d310','d320','d330','d340','d390','d391','d392','d393','d394','d395','d396','d830') as $field)
            unset($this->_tmarc->$field);
        foreach ($v as $note)
            $this->_tmarc->addField($note['NoteNumber'])->addSubField('a', $note['NoteValue']);
        $this->setUnimarc($this->_tmarc->asXML());
        return $this->_tmarc;
    }

    public function getFullTextSpec()
    {
        $spec = '';
        if (AuthorityPeer::INTERNALSTATUS_FINAL == $this->getAuthorityStatus())
            $spec .= "<b>*</b>";

        switch ($this->authority_type) {
            case AuthorityPeer::TYPE_SUBJECT:
                $spec = '/' . $this->subject_class;
            case AuthorityPeer::TYPE_CLASS:
                $this->getTurboMarc();
                if (isset($this->_tmarc->d676))
                    $spec = '/Dewey';
                else if (isset($this->_tmarc->d680))
                    $spec = '/LC';
                else if (isset($this->_tmarc->d686))
                    $spec = '/' . (string)$this->_tmarc->d686->s2;
                break;
            default:
                break;
        }
        $append = AuthorityPeer::RECTYPE_ACCEPTED !== $this->authority_rectype ? ' [v]' : '';
        return "({$this->authority_type}$spec) " . htmlentities($this->getFullText(), ENT_QUOTES, 'UTF-8') . $append;
    }

    public function updateLinkedWorks()
    {
        $work_up = LAuthorityQuery::create()
            ->filterByAuthorityIdUp($this->authority_id)
            ->useAuthorityRelatedByAuthorityIdDownQuery()
            ->filterByAuthorityType(AuthorityPeer::TYPE_WORK)
            ->endUse()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->find();
        foreach ($work_up as $la) {
            $a = $la->getAuthorityRelatedByAuthorityIdDown();
            if ($a instanceof Authority) {
                $a->save();
                $a->clearAllReferences(true);
            } else {
                // dangling link, so delete logging the deletion
                $entry = new Changelog();
                $entry->setEventDate(time());
                $entry->setEventType('C');
                $entry->setEventDescription('Auto-deletion for dangling link between AUTHORITY [' .
                    $this->getAuthorityId() . '] and invalid authority [' .
                    $la->getAuthorityIdDown() . ' (probably authority doesn\'t exists)');
                $entry->setObjectClass('Authority');
                $entry->setObjectId($this->getAuthorityId());
                $entry->setUserClass('ClavisLibrarian');
                $entry->setUserId(1);
                $entry->save();
                $entry->clearAllReferences(true);
                $la->delete();
            }
            $la->clearAllReferences(true);
        }
        unset($work_up);
        $work_down = LAuthorityQuery::create()
            ->filterByAuthorityIdDown($this->authority_id)
            ->useAuthorityRelatedByAuthorityIdUpQuery()
            ->filterByAuthorityType(AuthorityPeer::TYPE_WORK)
            ->endUse()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->find();
        foreach ($work_down as $la) {
            $a = $la->getAuthorityRelatedByAuthorityIdUp();
            if ($a instanceof Authority) {
                $a->save();
                $a->clearAllReferences(true);
            } else {
                // dangling link, so delete logging the deletion
                $entry = new Changelog();
                $entry->setEventDate(time());
                $entry->setEventType('C');
                $entry->setEventDescription('Auto-deletion for dangling link between AUTHORITY [' .
                    $this->getAuthorityId() . '] and invalid authority [' .
                    $la->getAuthorityIdUp() . ' (probably authority doesn\'t exists)');
                $entry->setObjectClass('Authority');
                $entry->setObjectId($this->getAuthorityId());
                $entry->setUserClass('ClavisLibrarian');
                $entry->setUserId(1);
                $entry->save();
                $entry->clearAllReferences(true);
                $la->delete();
            }
            $la->clearAllReferences(true);
        }
        unset($work_down);
    }

    public function updateLinkedSubjects()
    {
        //$slinks = $this->getLSubjectsRelatedByAuthorityId();
        $slinks = LSubjectQuery::create()
            ->joinAuthorityRelatedBySubjectId()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->filterByAuthorityId($this->authority_id)
            ->find();
        foreach ($slinks as $l) {
            $subj = $l->getAuthorityRelatedBySubjectId();
            $subj->save();
            $subj->clearAllReferences(true);
            $l->clearAllReferences(true);
        }
    }

    public function updateLinkedManifestations()
    {
        $aq = LAuthorityManifestationQuery::create()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->joinManifestation()
            ->filterByAuthority($this)
            ->filterByLinkType(array('700', '701', '710', '711', '720', '721'))
            ->orderByLinkType();

        foreach ($aq->find() as $lnk) {
            /* @var $lnk LAuthorityManifestation */
            $m = $lnk->getManifestation();
            $m->syncAuthor();
            $m->save();
            $m->clearAllReferences(true);
            $lnk->clearAllReferences(true);
        }
    }

    private function preSaveDefault()
    {
        $this->setFullText($this->getCompleteText());
    }

    private function preSaveClass()
    {
        $this->getTurboMarc();
        if (isset($this->_tmarc->d676)) {
            $ctype = '676';
            $fld = $this->_tmarc->d676;
        } else if (isset($this->_tmarc->d680)) {
            $ctype = '680';
            $fld = $this->_tmarc->d680;
        } else if (isset($this->_tmarc->d686)) {
            $ctype = '686';
            $fld = $this->_tmarc->d686;
        }
        $desc = isset($fld->sc) ? (string)$fld->sc : '';
        $ver = (isset($fld->sv) && trim((string)$fld->sv)) ? " [{$fld->sv}]" : '';
        $this->setSortText(trim($this->getClassCode() . ' ' . $desc));
        $this->setFullText(trim($this->getClassCode() . ' ' . $desc) . $ver);
    }

    private function preSavePrintersDevice()
    {
        $this->getTurboMarc();
        if (isset($this->_tmarc->d921->sa)) {
            $desc = trim((string)$this->_tmarc->d921->sa);
            $this->setSortText(trim($desc));
            $this->setFullText(trim($desc));
        }
    }

    private function preSaveWork()
    {
        $st = array();
        $auth_up = AuthorityQuery::create()
            ->useLAuthorityRelatedByAuthorityIdDownQuery()
            ->filterByAuthorityIdUp($this->authority_id)
            ->filterByLinkType(array('AB', 'BA', 'CD', 'DC'))// take only main/alternative authors
            ->orderByLinkType()
            ->endUse()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->find();
        foreach ($auth_up as $a)
            $st[] = $a->getCompleteText();
        $auth_down = AuthorityQuery::create()
            ->useLAuthorityRelatedByAuthorityIdUpQuery()
            ->filterByAuthorityIdDown($this->authority_id)
            ->filterByLinkType(array('AB', 'BA', 'CD', 'DC'))// take only main/alternative authors
            ->orderByLinkType()
            ->endUse()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->find();
        foreach ($auth_down as $a)
            $st[] = $a->getCompleteText();
        $authorPrefix = (count($st) > 0) ? implode(', ', $st) . '. ' : '';
        $this->setFullText($authorPrefix . $this->getCompleteText());
    }

    private function preSaveSubject()
    {
        $st = '';
        $auths = LSubjectQuery::create()
            ->joinAuthorityRelatedByAuthorityId()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->filterBySubjectId($this->authority_id)
            ->orderByPosition();
        if ($auths->count() > 0) {
            $parent = true;
            foreach ($auths->find() as $la) {
                $a = $la->getAuthorityRelatedByAuthorityId();
                if (!$a instanceof Authority) {
                    // dangling link!!
                    continue;
                }
                if ($parent) {
                    $this->setParentId($a->getAuthorityId());
                    $parent = false;
                } else {
                    $st .= ' ' . $la->getConnector();
                }
                $st .= $a->getFullText();
                $a->clearAllReferences(true);
                $la->clearAllReferences(true);
            }
        } else {
            // remove subject (add log) for it is built upon no authorities ?
        }
        unset($auths);
        $this->setFullText($st);
        $this->setSortText($this->getFullText());
    }

    /**
     * Returns the full TurboMarc (i.e. with linked fields) for the record.
     *
     * @param boolean $asXML
     * @param boolean $getCollection
     * @return TurboMarc or string
     */
    public function getFullTurboMarc($asXML = true, $getCollection = false)
    {
        // call peer's function to ensure we have a single codebase for the function
        return AuthorityPeer::getFullTurboMarc($this, $asXML, $getCollection);
    }

    /**
     * Builds and saves an Authority object upon a given TurboMarc record.
     * THIS METHOD DOES NOT INDEX THE RECORD CREATED!!!
     *
     * @param TurboMarc $tm A TurboMarc record
     * @param boolean $dummy If true, manifestation will not be created and the function will return
     *                        an array listing all the actions that would be taken (defaults to false)
     * @param array $linkbucket The array to be filled with not imported links.
     * @return Authority The authority created
     */
    public function updateFromTurbomarc(TurboMarc $tm, $dummy = false, &$linkbucket = array())
    {
        $actionLog = array();
        if (isset($tm->r))
            $tm = $tm->r;
        $tm = TurboMarcUtility::sortFields($tm);
        $leader = $tm->getLeader();
        // ensure type is lower-case
        $leader->type = strtolower($leader->type);
        $leader->entitytype = strtolower($leader->entitytype);
        $this->setAuthorityRectype($leader->type);
        $this->setAuthorityType(AuthorityPeer::mapTypeUnimarcToClavis($leader->entitytype));

        if (isset($tm->d100))
            $this->setAuthorityStatus($tm->d100->getCDF('a', 8));
        else
            $this->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);

        $this->setAuthorityCodlevel(05);
        if (isset($tm->d901)) {
            $sf_actions = array();
            if (isset($tm->d901->se)) {
                $this->setAuthorityCodlevel((string)$tm->d901->se);
                $sf_actions[] = 'catalog_level: [' . (string)$tm->d901->se . ']';
            }
            if (isset($tm->d901->sm)) {
                $this->setAuthorityType((string)$tm->d901->sm);
                $sf_actions[] = 'authority_type: [' . (string)$tm->d901->sm . ']';
            }
            if (isset($tm->d901->sn)) {
                $this->setAuthorityRectype((string)$tm->d901->sn);
                $sf_actions[] = 'authority_rectype: [' . (string)$tm->d901->sn . ']';
            }
            $actionLog[] = array('901', 0, true, "Recuperate informazioni codificate ClavisNG (901):\n{info}",
                array('info' => implode("\n", $sf_actions)));
        }

        $uni = TurboMarc::createRecord();
        $uni->setLeader($leader);
        $c001 = $uni->setControlField('001', $this->authority_id);
        if (isset($tm->d035)) {
            $this->setBid((string)$tm->d035->sa);
            $this->setBidSource((string)$tm->d035->s9);
            $actionLog[] = array('035', 0, false, "Sorgente import [{source} - {bid}]",
                array('source' => (string)$tm->d035->s9, 'bid' => (string)$tm->d035->sa));
        }
        $bid_source = $this->getBidSource();
        $sbid = 's' . strtolower($bid_source);

        // build unimarc and resave
        $skip_fields = array('001', '005', '035', '856', '931');
        if (AuthorityPeer::TYPE_CLASS != $this->authority_type)
            $skip_fields = array_merge($skip_fields, array('676', '680', '686'));

        foreach ($tm->children() as $field) {
            /* @var $field TurboMarc */
            $fnum = $field->getTag();
            if ($fnum == '330' && isset($uni->d330)) {
                // for multiple 330, join them in a single entry
                $uni->d330->sa .= "\n" . (string)$field->sa;
                $actionLog[] = array($fnum, 0, false, "Abstract aggiunto: [{field}]", array('field' => htmlspecialchars($field->getTXT())));
            } else if ($fnum > 0 && !in_array($fnum, $skip_fields)) {
                $uni->appendNode($field);
                $actionLog[] = array($fnum, 0, false, "Campo importato: [{field}]", array('field' => htmlspecialchars($field->getTXT())));
            }
        }

        switch ($this->authority_type) {
            case AuthorityPeer::TYPE_TRADEMARK:
            case AuthorityPeer::TYPE_CORPORATEBODYNAME:
            case AuthorityPeer::TYPE_FAMILYNAME:
            case AuthorityPeer::TYPE_PERSONALNAME:
                if (isset($tm->d216))    // trademark
                    $this->setSortText($tm->getAuthor(216));
                else if (isset($tm->d200))    // personal name
                    $this->setSortText($tm->getAuthor(200));
                else if (isset($tm->d210))    // corporate body name
                    $this->setSortText($tm->getAuthor(210));
                else if (isset($tm->d220))    // corporate body name
                    $this->setSortText($tm->getAuthor(220));
                break;
            case AuthorityPeer::TYPE_WORK:    // 230 or 454
                if (isset($tm->d230))
                    $this->setSortText($tm->d230->sa);
                else if (isset($tm->d454)) {
                    $this->setSortText($tm->getFullTitle(true, 454));
                }
                break;
            case AuthorityPeer::TYPE_CLASS:    // 676, 680 or 686
                if (isset($tm->d676))
                    $this->setClassCode($tm->d676->sa);
                else if (isset($tm->d686))
                    $this->setClassCode($tm->d686->sa);
                break;
            case AuthorityPeer::TYPE_PUBPLACE:
            case AuthorityPeer::TYPE_PLACE:    // 260
                if (isset($tm->d260))
                    $this->setSortText((string)$tm->d260->sd);
                break;
            case AuthorityPeer::TYPE_SUBJECT:    // 250
                $this->save();
                // process 931s
                $l = LSubjectQuery::create()
                    ->filterBySubjectId($this->authority_id)
                    ->delete();
                $pos = 0;
                foreach ($tm->d931 as $tfld) {
                    if (!isset($tfld->$sbid) && !isset($tfld->sa))
                        continue;
                    $term = null;
                    if (isset($tfld->$sbid))
                        $term = AuthorityPeer::getOneByBid($bid_source, $tfld->$sbid);
                    if (!$term instanceof Authority && isset($tfld->sa)) {
                        // search for a suitable term not already linked
                        $term = AuthorityQuery::create()
                            ->filterByAuthorityType(AuthorityPeer::TYPE_ARGUMENT)
                            ->filterByBidSource(null)
                            ->filterBySortText((string)$tfld->sa)
                            ->findOne();
                        if ($term instanceof Authority && isset($tfld->$sbid)) {
                            $term->setBidSource($bid_source);
                            $term->setBid((string)$tfld->$sbid);
                            if (isset($tfld->s2))
                                $term->setSubjectClass((string)$tfld->s2);
                            $term->save();
                        }
                    }
                    if (!$term instanceof Authority) {
                        $term = new Authority();
                        $term->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
                        if (isset($tfld->$sbid)) {
                            $term->setBidSource($bid_source);
                            $term->setBid($tfld->$sbid);
                        }
                        if (isset($tfld->sa)) {
                            $term->setSortText((string)$tfld->sa);
                            if (isset($tfld->s2))
                                $term->setSubjectClass((string)$tfld->s2);
                        }
                        $term->save();
                    }
                    $l = new LSubject();
                    $l->setSubjectId($this->authority_id);
                    $l->setAuthorityId($term->getAuthorityId());
                    $l->setPosition($pos);
                    $l->setType('A');
                    $l->setConnector(' - ');
                    $l->save();
                    ++$pos;
                }
                break;
            case AuthorityPeer::TYPE_ARGUMENT:
            case AuthorityPeer::TYPE_CHRONOLOGICAL:
                // 931
                if (isset($tm->d931)) {
                    $this->setSortText((string)$tm->d931->sa);
                    if (isset($tm->d931->s2))
                        $this->setSubjectClass((string)$tm->d931->s2);
                }
                break;
            case AuthorityPeer::TYPE_SERIE:
            default:
                break;
        }
        if (isset($tm->d101->sa))
            $this->setAuthorityLang((string)$tm->d101->sa);

        $this->setUnimarc(TurboMarcUtility::sortFields($uni)->asXML());
        if (!$dummy)
            $this->save();

        // process links
        $linkFields = array(
            '400', '410', '415', '430', '450', '480', '476', '421', '409',    // SEE
            '501', '510', '515', '530', '550', '580', '576', '521', '509',    // SEE ALSO
            '500',    // link to work
            '606',    // link to subject
            '620',    // link to place
            '676', '686',    // link to class
            '700', '701', '702',    // link to personalname
            '710', '711', '712',    // link to corporatebodyname
            '921',    // link to printersdevice
        );
        foreach ($linkFields as $lfnum) {
            $xmlTag = "d{$lfnum}";
            if (!isset($tm->$xmlTag))
                continue;
            foreach ($tm->$xmlTag as $linkfld) {
                // search linked authority
                $lauth = AuthorityPeer::getLinkedAuthority($lfnum, $linkfld, $bid_source, true, $dummy);
                $link_type = null;
                $id_down = $this->authority_id;
                $id_up = $lauth->getAuthorityId();
                // determine linktype
                switch ($lfnum) {

                    case '400':
                    case '410':
                    case '415':
                    case '430':
                    case '450':
                    case '480':
                    case '476':
                    case '421':
                    case '409':
                        // SEE
                        $link_type = '45';
                        if (AuthorityPeer::RECTYPE_VARIANT == $this->authority_rectype) {
                            $id_down = $this->authority_id;
                            $id_up = $lauth->getAuthorityId();
                        } else {
                            $id_down = $lauth->getAuthorityId();
                            $id_up = $this->authority_id;
                            $lauth->setAuthorityRectype(AuthorityPeer::RECTYPE_VARIANT);
                            $lauth->save();
                        }
                        break;

                    case '501':
                    case '510':
                    case '515':
                    case '530':
                    case '550':
                    case '580':
                    case '576':
                    case '521':
                    case '509':
                        // SEE ALSO
                        $link_type = '11';
                        break;

                    case '500':    // link to work
                        break;

                    case '606':    // link to subject
                        $link_type = 'GH';
                        break;

                    case '620':    // link to place
                        $link_type = 'OP';
                        break;

                    case '676':
                    case '686':    // link to class
                        $link_type = 'KL';
                        break;

                    case '700':
                    case '701':
                    case '702':    // link to personalname
                    case '710':
                    case '711':
                    case '712':    // link to corporatebodyname
                        switch ($lfnum[2]) {
                            case 0:
                                $link_type = 'AB';
                                break;
                            case 1:
                                $link_type = 'CD';
                                break;
                            case 2:
                                $link_type = 'EF';
                                break;
                        }
                        break;
                    case '921':    // link to printersdevice
                        break;
                }
                if (!$link_type)
                    continue;
                //check if a link already exists
                $l = LAuthorityQuery::create()
                    ->filterByAuthorityIdDown($id_down)
                    ->filterByAuthorityIdUp($id_up)
                    ->filterByLinkType($link_type)
                    ->findOne();

                if (!$l instanceof LAuthority)
                    $l = LAuthorityQuery::create()
                        ->filterByAuthorityIdDown($id_down)
                        ->filterByAuthorityIdUp($id_up)
                        ->filterByLinkType(strrev($link_type))
                        ->findOne();

                if (!$l instanceof LAuthority) {
                    $l = new LAuthority();
                    $l->setAuthorityIdDown($id_down);
                    $l->setAuthorityIdUp($id_up);
                    $l->setLinkType($link_type);
                }
                if (isset($linkfld->s4))
                    $l->setRelatorCode((string)$linkfld->s4);
                if (isset($linkfld->sn))
                    $l->setLinkNote((string)$linkfld->sn);

                if (isset($linkfld->sdiff) && TurboMarcUtility::FIELDS_TM1ONLY != $linkfld->sdiff)
                    $l->setSourceSync(LAuthorityPeer::SRCSYNC_TRUE);
                else
                    $l->setSourceSync(LAuthorityPeer::SRCSYNC_FALSE);

                if ($l->isModified())
                    $l->save();
            }
        }

        if ($dummy) {
            return $actionLog;
        } else {
            // do you want to take some action with our action log?
            return $this;
        }
    }

    /**
     * It returns the id of this object (for compatibility).
     *
     * @return int
     */
    public function getId()
    {
        return $this->authority_id;
    }

    public function getShelfDescription()
    {
        return ($this->full_text) ?
            $this->getShelfDescriptionLabel() . $this->full_text : '';
    }

    public function getShelfDescriptionLabel()
    {
        return 'nome: ';
    }

    public function getShelfDescriptionText()
    {
        return $this->getFullText();
    }

    /**
     * It returns the Portlet.Page which will be used in the
     * url of the grid row, to hyper-transport ourselves to the
     * right visualization page of the object.
     *
     * @return string
     */
    public function getShelfUrl()
    {
        return 'Catalog.AuthorityEditPage&id=';
    }

    public function getObjectTypeString()
    {
        return 'authority';
    }

    /**
     * Returns the accepted authority for the current one.
     * If the authority is accepted, returns itself.
     *
     * @return Authority The accepted authority object.
     */
    public function getAcceptedAuthority()
    {
        switch ($this->getAuthorityRectype()) {
            case AuthorityPeer::RECTYPE_ACCEPTED:
            case AuthorityPeer::RECTYPE_NODE:
            case AuthorityPeer::RECTYPE_TOPTERM:
                return $this;
            case AuthorityPeer::RECTYPE_VARIANT:
                $link = LAuthorityQuery::create()
                    ->condition('medown', 'LAuthority.AuthorityIdDown = ?', $this->authority_id)
                    ->condition('linkdown', 'LAuthority.LinkType = ?', LAuthorityPeer::VARIANTLINK_DOWN)
                    ->combine(array('medown', 'linkdown'), 'and', 'down')
                    ->condition('meup', 'LAuthority.AuthorityIdUp = ?', $this->authority_id)
                    ->condition('linkup', 'LAuthority.LinkType = ?', LAuthorityPeer::VARIANTLINK_UP)
                    ->combine(array('meup', 'linkup'), 'and', 'up')
                    ->where(array('down', 'up'), 'or')
                    ->findOne();
                if ($link instanceof LAuthority) {
                    return ($link->getLinkType() == LAuthorityPeer::VARIANTLINK_DOWN) ?
                        $link->getAuthorityRelatedByAuthorityIdUp() :
                        $link->getAuthorityRelatedByAuthorityIdDown();
                } else {
                    return null;
                }
                break;
            default:
                return null;
        }
    }

    /**
     * Retrieves all variant forms for the current authority. Returns empty array if the authority
     * is variant itself.
     *
     * @return array An array of Authority objects.
     */
    public function getVariants()
    {
        $ret = array();
        if (AuthorityPeer::RECTYPE_VARIANT == $this->getAuthorityRectype())
            return $ret;

        // retrieve variants
        $q1 = AuthorityQuery::create()
            ->filterByAuthorityRectype(AuthorityPeer::RECTYPE_VARIANT)
            ->useLAuthorityRelatedByAuthorityIdDownQuery()
            ->filterByAuthorityIdUp($this->authority_id)
            ->filterByLinkType(array(LAuthorityPeer::VARIANTLINK_DOWN, LAuthorityPeer::VARIANTLINK_MULTI_DOWN))
            ->endUse()
            ->find();
        $q2 = AuthorityQuery::create()
            ->filterByAuthorityRectype(AuthorityPeer::RECTYPE_VARIANT)
            ->useLAuthorityRelatedByAuthorityIdUpQuery()
            ->filterByAuthorityIdDown($this->authority_id)
            ->filterByLinkType(array(LAuthorityPeer::VARIANTLINK_UP, LAuthorityPeer::VARIANTLINK_MULTI_UP))
            ->endUse()
            ->find();
        $ret = $q1->toArray() + $q2->toArray();
        return $ret;
    }

    /**
     * Returns the class linked to the authority, if there's one.
     *
     * @return Authority The class authority object or null if no class linked.
     */
    public function getClass()
    {
        return ($this->getClassCode()) ?
            AuthorityPeer::retrieveByPK($this->getClassCode()) :
            null;
    }

    /**
     * Returns a human-readable label for authority type.
     *
     * @return string The human-readable authority type.
     */
    public function getAuthorityTypeLabel()
    {
        $ret = LookupValuePeer::getLookupValue('AUTHTYPE', $this->getAuthorityType());
        if ($this->getAuthorityStatus() == AuthorityPeer::INTERNALSTATUS_FINAL)
            $ret .= '*';
        return $ret;
    }

    /**
     * Checks if an authority is safely deletable (i.e. doesn't link to other authorities,
     * manifestations or items).
     *
     * @return boolean True if authority doesn't have any link, false elsewhere.
     */
    public function isDeleteable()
    {
        $this->reload(true);
        $links = array();
        $links['m'] = $this->countLAuthorityManifestations();
        $links['s'] = $this->countLSubjectsRelatedByAuthorityId();
        $links['ad'] = $this->countLAuthoritysRelatedByAuthorityIdDown();
        $links['au'] = $this->countLAuthoritysRelatedByAuthorityIdUp();
        $links['i'] = $this->countLAuthorityItems();
        $this->links = $links;
        return (array_sum($links) < 1);
    }

    public function hasWorkRelatorCode()
    {
        return in_array($this->authority_type, LAuthorityPeer::$hasWorkRelatorCode);
    }

    /**
     * Returns an array with all authority links, grouped by link type.
     *
     * @param bool $sortByTerm
     * @param bool $thesaurusOnly
     * @return array
     */
    public function getAuthoritiesLinkList($sortByTerm = true, $thesaurusOnly = false,$startPage = 0, $pageSize = 0,$filters=null)
    {
        $links = array();


        $lAuthList = LAuthorityQuery::create()
            ->joinWith("AuthorityRelatedByAuthorityIdDown a")
            ->joinWith("AuthorityRelatedByAuthorityIdUp b")
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->condition("a1",'LAuthority.AuthorityIdDown = ?', $this->authority_id)
            ->condition("a2",'LAuthority.AuthorityIdUp = ?', $this->authority_id)
            ->where(array("a1","a2"),"or")
            ->orderByLinkType();

        if ($thesaurusOnly)
            $lAuthList->filterByLinkType(array('11', '23', '32', '45', '54', '67', '76'));

        if($filters != null)
        {
            foreach($filters as $filter => $cond)
                switch($filter)
                {
                    case "AuthorityType":
                        $lAuthList->condition("b1",'LAuthority.AuthorityIdDown = ?', $this->authority_id);
                        $lAuthList->condition("b2",'b.AuthorityType= ?', $cond);
                        $lAuthList->combine(array("b1","b2"),"and","b12");

                        $lAuthList->condition("c1",'LAuthority.AuthorityIdUp = ?', $this->authority_id);
                        $lAuthList->condition("c2",'a.AuthorityType= ?', $cond);
                        $lAuthList->combine(array("c1","c2"),"and","c12");

                        $lAuthList->where(array("b12","c12"),"or");
                        break;
                    case "FullText":
                        $lAuthList->condition("b1",'LAuthority.AuthorityIdDown = ?', $this->authority_id);
                        $lAuthList->condition("b2",'b.FullText LIKE ?', "%{$cond}%");
                        $lAuthList->combine(array("b1","b2"),"and","b12");

                        $lAuthList->condition("c1",'LAuthority.AuthorityIdUp = ?', $this->authority_id);
                        $lAuthList->condition("c2",'a.FullText LIKE ?', "%{$cond}%");
                        $lAuthList->combine(array("c1","c2"),"and","c12");

                        $lAuthList->where(array("b12","c12"),"or");
                        break;

                    case "LinkType":
                        $lAuthList->condition("b1",'LAuthority.AuthorityIdDown = ?', $this->authority_id);
                        $lAuthList->condition("b2",'LAuthority.LinkType= ?', $cond);
                        $lAuthList->combine(array("b1","b2"),"and","b12");

                        $lAuthList->condition("c1",'LAuthority.AuthorityIdUp = ?', $this->authority_id);
                        $lAuthList->condition("c2",'LAuthority.LinkType= ?', strrev($cond));
                        $lAuthList->combine(array("c1","c2"),"and","c12");

                        $lAuthList->where(array("b12","c12"),"or");
                        break;
                    case "RelatorCodeType":
                        $lAuthList->condition("b1",'LAuthority.AuthorityIdDown = ?', $this->authority_id);
                        $lAuthList->condition("b2",'LAuthority.RelatorCode= ?', $cond);
                        $lAuthList->combine(array("b1","b2"),"and","b12");

                        $lAuthList->condition("c1",'LAuthority.AuthorityIdUp = ?', $this->authority_id);
                        $lAuthList->condition("c2",'LAuthority.RelatorCode= ?', $cond);
                        $lAuthList->combine(array("c1","c2"),"and","c12");

                        $lAuthList->where(array("b12","c12"),"or");
                        break;
                }
        }

        if($startPage > 0) {
            $lAuthListRS = $lAuthList->paginate($startPage,$pageSize);
        } else {
            $lAuthListRS = $lAuthList->find();
        }


        /*
         * Search all links to this authority
         */
        foreach ($lAuthListRS as $lAuth) {
            /* @var $lAuth LAuthority */
            // the following condition is there to save a query to retrieve $this

            //Check if this lAuth have real links to other authority
            $lRelative = null;
            if ($lAuth->getAuthorityIdDown() == $this->authority_id) {
                $lRelative = $lAuth->getAuthorityRelatedByAuthorityIdUp();
                $mutual = false;
            } else {
                $lRelative = $lAuth->getAuthorityRelatedByAuthorityIdDown();
                $mutual = true;
            }


            /*
             * $lRelative is null if no Authority was found, so I can delete lAuth
             * because point to a non existent Authority then continue search
             */
            if (!($lRelative instanceof Authority)) {
                $lAuth->delete();
                continue;
            }

            /*
             * If link is valid keep all information needed
             */
            $other_id = $lRelative->getAuthorityId();
            $other_txt = $lRelative->getFullText();
            $other_sorttxt = $lRelative->getSortText();
            $other_rectype = $lRelative->getAuthorityRectype();
            $other_type = $lRelative->getAuthorityType();

            $rclookup = ((AuthorityPeer::TYPE_WORK == $this->authority_type && $lRelative->hasWorkRelatorCode()) ||
                (AuthorityPeer::TYPE_WORK == $other_type && $this->hasWorkRelatorCode()))
                ? 'RELATORCODE' : 'AUTHRELATORCODEMUTUAL';


            if (AuthorityPeer::RECTYPE_VARIANT == $this->authority_rectype ||
                AuthorityPeer::RECTYPE_VARIANT == $other_rectype
            ) {
                $linkTypeLabel = LookupValuePeer::getLookupValue('AUTHLINKTYPEMUTUAL', $lAuth->getLinkType(), $mutual);
            } else {
                $linkTypeLabel = LookupValuePeer::getLookupValue('AUTHLINKTYPE', $lAuth->getLinkType(), $mutual);
            }

            $relatorCodeLabel = LookupValuePeer::getLookupValue($rclookup, $lAuth->getRelatorCode(), 'RELATORCODE' == $rclookup ? false : $mutual);    // don't get mutual relator code when treating works (#1680)

            if (!array_key_exists($linkTypeLabel, $links)) {
                $links[$linkTypeLabel] = array();
            }

            $links[$linkTypeLabel][] = array(
                'AuthorityId' => $other_id,
                'AuthClass' => get_class($lAuth),
                'PrimaryKey' => implode('|', $lAuth->getPrimaryKey()),
                'SortText' => htmlentities($other_sorttxt, ENT_COMPAT, 'UTF-8'),
                'FullText' => "(${other_type}) " . htmlentities($other_txt, ENT_COMPAT, 'UTF-8'),
                'RelatorCode' => $relatorCodeLabel,
                'LinkType' => $lAuth->getLinkType(),
                'LinkTypeLabel' => $linkTypeLabel,
                'LinkSequence' => "",
                'LinkNote' => $lAuth->getLinkNote(),
                'Mutual' => $mutual,
            );
        }//foreach lauth

        uksort($links, array('LAuthorityPeer', 'sortAuthorityLinks'));

        if ($sortByTerm) {
            foreach ($links as $linkType => &$linkTerms)
                uasort($linkTerms, 'self::sortByTerm');
        }

        if($startPage > 0)
            $links['TotRows'] = $lAuthListRS->count();

        return $links;
    }

    private function sortByTerm($a, $b)
    {
        return strcasecmp(trim($a['SortText'], '* '), trim($b['SortText'], '* '));
    }

    /**
     * Updates links to $this redirecting them to $dst, and deletes $this or make it variant for $dst.
     * Does NOT call save() on $dst for performance reasons.
     *
     * @param Authority $dst destination Authority
     * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
     * @return boolean (transaction result)
     */
    public function variantizeWith(Authority $dst, $clavisLibrarian = null)
    {
        if ($this->authority_id == $dst->getAuthorityId()) {
            Prado::log('Error in ' . __CLASS__ . '::' . __FUNCTION__ . '(): source is the same as destination');
            return false;
        }
        if (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian) {
            Prado::log('Error in ' . __CLASS__ . '::' . __FUNCTION__ . '(): not a librarian');
            return false;
        }

        $arrRowsAffected = $this->mergeLinks($dst, $clavisLibrarian);
        if ($arrRowsAffected !== false) {
            $this->setAuthorityRectype('y');
            $this->save();
            $links = LAuthorityQuery::create()
                ->condition('down_id', 'LAuthority.AuthorityIdDown = ?', $this->authority_id)
                ->condition('down_ltype', 'LAuthority.LinkType = ?', LAuthorityPeer::VARIANTLINK_DOWN)
                ->combine(array('down_id', 'down_ltype'), 'and', 'down')
                ->condition('up_id', 'LAuthority.AuthorityIdUp = ?', $this->authority_id)
                ->condition('up_ltype', 'LAuthority.LinkType = ?', LAuthorityPeer::VARIANTLINK_UP)
                ->combine(array('up_id', 'up_ltype'), 'and', 'up')
                ->where(array('down', 'up'), 'or')
                ->count();
            if ($links < 1) {
                $l = new LAuthority();
                $l->setAuthorityRelatedByAuthorityIdUp($dst);
                $l->setAuthorityIdDown($this->authority_id);
                $l->setLinkType(LAuthorityPeer::VARIANTLINK_DOWN);
                $l->save();
            }
        }
        return $arrRowsAffected;
    }

    /**
     * Updates links to $this redirecting them to $dst, and deletes $this or make it variant for $dst.
     * Does NOT call save() on $dst for performance reasons.
     *
     * @param Authority $dst destination Authority
     * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
     * @return boolean (transaction result)
     */
    public function replaceWith(Authority $dst, $clavisLibrarian = null)
    {
        if ($this->authority_id == $dst->getAuthorityId()) {
            Prado::log('Error in ' . __CLASS__ . '::' . __FUNCTION__ . '(): source is the same as destination');
            return false;
        }
        if (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian) {
            Prado::log('Error in ' . __CLASS__ . '::' . __FUNCTION__ . '(): not a librarian');
            return false;
        }

        $arrRowsAffected = $this->mergeLinks($dst, $clavisLibrarian);
        if ($arrRowsAffected !== false)
            $this->delete();
        return $arrRowsAffected;
    }

    private function mergeLinks(Authority $dst, $clavisLibrarian = null)
    {
        $dst_id = $dst->getAuthorityId();

        $arrRowsAffected = array(); //associative array (key: db table, value: num of rows affected by update)

        /* @var $_connection Connection */
        $_connection = Propel::getConnection();
        try {
            $_connection->beginTransaction();

            //attachment
            $arrRowsAffected['attachment'] = AttachmentQuery::create()
                ->filterByObjectType('Authority')
                ->filterByObjectId($this->authority_id)
                ->update(array('ObjectId' => $dst_id), $_connection);

            //changelog
            /*
             *
$arrRowsAffected['changelog'] = ChangelogQuery::create()
    ->filterByObjectClass('Authority')
    ->filterByObjectId($this->authority_id)
    ->update(array('ObjectId' => $dst_id),$_connection);
             *
             */

            $arrRowsAffected['l_subject'] = 0;

            if (AuthorityPeer::TYPE_SUBJECT == $this->authority_type) {
                // do nothing as we don't want to change dst authority
                //LSubjectQuery::create()->filterBySubjectId($this->authority_id)->delete($_connection);
            } else {
                /*
    $ls = $this->getLSubjectsRelatedByAuthorityId();
    foreach ($ls as $link) {
        /** @var $newlink LSubject * /
        $newLink = LSubjectQuery::create()->findPk(array($dst_id,$link->getSubjectId(),$link->getPosition()));
        if (! $newLink instanceof LSubject) {
            $newLink = new LSubject();
            $newLink->setSubjectId($link->getSubjectId());
            $newLink->setAuthorityId($dst_id);
            $newLink->setPosition($link->getPosition());
            $newLink->setType($link->getType());
            $newLink->setConnector($link->getConnector());
            $newLink->save();
            ++$arrRowsAffected['l_subject'];
        }
        $link->delete();
    }*/

                /*
                 * Update all l_subject owner (authority)
                 */
                $query = "update ignore l_subject set authority_id={$dst_id} where authority_id={$this->authority_id}";
                $arrRowsAffected['l_subject'] = $_connection->exec($query);

                /*
                 * Update parent authority
                 */
                $query = "update authority set parent_id={$dst_id} where parent_id={$this->authority_id}";
                $arrRowsAffected['authority_parent_id'] = $_connection->exec($query);

                /*
                 * Force revision of works, subjects, manifestations links
                 * @see postSave
                 */
                $dst->setNeedLinkUpdate(TRUE);
            }

            $arrRowsAffected['l_authority'] = 0;
            $arrRowsAffected['l_authority_deleted'] = 0;
            /*
foreach ($this->getLAuthoritysRelatedByAuthorityIdDown() as $link) {
    /* @var $link LAuthority * /
    $pk = $link->getPrimaryKey();
    // avoid newlinking authority with itself
    if ($dst_id != $pk[1]) {
        // substitute AuthorityIdDown with destination id
        // pk is array(AuthorityIdDown,AuthorityIdUp,LinkType)
        $pk[0] = $dst_id;
        $newlink = LAuthorityQuery::create()
            ->filterByPrimaryKey($pk)
            ->findOneOrCreate();
        if ($newlink->isNew()) {
            $newlink->setRelatorCode($link->getRelatorCode());
            $newlink->setLinkNote($link->getLinkNote());
            $newlink->save();
            ++$arrRowsAffected['l_authority'];
        }
    }
    $link->delete();
}*/

            /*
             * If destination authority is a work, no authority (down) must be inherit.
             */
            if ($dst->authority_type != AuthorityPeer::TYPE_WORK) {
                $query = "update ignore l_authority set authority_id_down={$dst_id} where authority_id_down={$this->authority_id}";
                $arrRowsAffected['l_authority'] = $_connection->exec($query);
            }
            $query = "delete from l_authority where authority_id_down={$this->authority_id}";
            $arrRowsAffected['l_authority_deleted'] = $_connection->exec($query);


            /*
foreach ($this->getLAuthoritysRelatedByAuthorityIdUp() as $link) {
    /* @var $link LAuthority * /
    $pk = $link->getPrimaryKey();
    // avoid newlinking authority with itself
    if ($dst_id != $pk[0]) {
        // substitute AuthorityIdUp with destination id
        // pk is array(AuthorityIdDown,AuthorityIdUp,LinkType)
        $pk[1] = $dst_id;
        $newlink = LAuthorityQuery::create()
            ->filterByPrimaryKey($pk)
            ->findOneOrCreate();
        if ($newlink->isNew()) {
            $newlink->setRelatorCode($link->getRelatorCode());
            $newlink->setLinkNote($link->getLinkNote());
            $newlink->save();
            ++$arrRowsAffected['l_authority'];
        }
    }
    $link->delete();
}*/

            /*
             * If destination authority is a work, no authority (up) must be inherit.
             */
            if ($dst->authority_type != AuthorityPeer::TYPE_WORK) {
                $query = "update ignore l_authority set authority_id_up={$dst_id} where authority_id_up={$this->authority_id}";
                $arrRowsAffected['l_authority'] += $_connection->exec($query);
            }
            $query = "delete from l_authority where authority_id_up={$this->authority_id}";
            $arrRowsAffected['l_authority_deleted'] += $_connection->exec($query);


            //l_authority_item
            $arrRowsAffected['l_authority_item'] = 0;
            $arrRowsAffected['l_authority_item_deleted'] = 0;
            /*
foreach ($this->getLAuthorityItems() as $link) {
    /* @var $link LAuthorityItem * /
    $pk = $link->getPrimaryKey();
    // pk is array(AuthorityId,ItemId,LinkType,RelatorCode)
    $pk[0] = $dst_id;
    $newlink = LAuthorityItemQuery::create()
        ->filterByPrimaryKey($pk)
        ->findOneOrCreate();
    if ($newlink->isNew()) {
        $newlink->setLinkSequence($link->getLinkSequence());
        $newlink->setLinkNote($link->getLinkNote());
        $newlink->save();
    }
    $link->delete();
    ++$arrRowsAffected['l_authority_items'];
}*/

            $query = "update ignore l_authority_item set authority_id={$dst_id} where authority_id={$this->authority_id}";
            $arrRowsAffected['l_authority_item'] = $_connection->exec($query);
            $query = "delete from l_authority_item where authority_id={$this->authority_id}";
            $arrRowsAffected['l_authority_item_deleted'] = $_connection->exec($query);


            //l_authority_manifestation
            $arrRowsAffected['l_authority_manifestation'] = 0;
            $arrRowsAffected['l_authority_manifestation_deleted'] = 0;
            /*
foreach ($this->getLAuthorityManifestations() as $link) {
    /* @var $link LAuthorityManifestation * /
    $pk = $link->getPrimaryKey();
    // pk is array(AuthorityId,ManifestationId,LinkType,RelatorCode)
    $pk[0] = $dst_id;
    $newlink = LAuthorityManifestationQuery::create()
        ->filterByPrimaryKey($pk)
        ->findOneOrCreate();
    if ($newlink->isNew()) {
        $newlink->setLinkSequence($link->getLinkSequence());
        $newlink->setLinkNote($link->getLinkNote());
        $newlink->save();
    }
    $link->delete();
    ++$arrRowsAffected['l_authority_manifestation'];
}*/
            $query = "update ignore l_authority_manifestation set authority_id={$dst_id} where authority_id={$this->authority_id}";
            $arrRowsAffected['l_authority_manifestation'] = $_connection->exec($query);
            $query = "delete from l_authority_manifestation where authority_id={$this->authority_id}";
            $arrRowsAffected['l_authority_manifestation_deleted'] = $_connection->exec($query);


            $arrRowsAffected['shelf_item'] = 0;
            $arrRowsAffected['shelf_item_deleted'] = 0;
            /*
$links = ShelfItemQuery::create()
    ->filterByObjectClass(ShelfPeer::TYPE_AUTHORITY)
    ->filterByObjectId($this->authority_id)
    ->find();
foreach ($links as $link) {
    /* @var $link ShelfItem * /
    $newlink = ShelfItemQuery::create()
        ->filterByPrimaryKey(array(
            $link->getShelfId(),
            $dst_id,
            ShelfPeer::TYPE_AUTHORITY))
        ->findOneOrCreate();
    if ($newlink->isNew()) {
        $newlink->setItemStatus($link->getItemStatus());
        $newlink->save();
    }
    $link->delete();
    ++$arrRowsAffected['shelf_item'];
}*/
            $query = "update ignore shelf_item set object_id={$dst_id} where object_id={$this->authority_id}";
            $arrRowsAffected['shelf_item'] = $_connection->exec($query);
            $query = "delete from shelf_item where object_id={$this->authority_id}";
            $arrRowsAffected['shelf_item_deleted'] = $_connection->exec($query);

            /* extract notes and copy them on dst authority */
            $dsttm = $dst->getTurboMarc();
            $this->getTurboMarc();
            foreach (array('300', '330', '340', '390', '830') as $field)
                foreach ($this->_tmarc->$field as $fld)
                    $dsttm->appendNode($fld);
            $dst->setUnimarc($dsttm->asXML());

            $_connection->commit();

            $srcSortTxt = "";
            $dstSortTxt = "";

            if (strlen($this->sort_text) < 15) {
                $srcSortTxt = $this->sort_text;
            } else {
                $srcSortTxt = substr($this->sort_text, 0, 15) . "...";
            }


            if (strlen($dst->sort_text) < 15) {
                $dstSortTxt = $dst->sort_text;
            } else {
                $dstSortTxt = substr($dst->sort_text, 0, 15) . "...";
            }

            if (count($arrRowsAffected) > 0) {
                $description = "Authority {$srcSortTxt} con id={$this->authority_id}";
                foreach ($arrRowsAffected as $table => $count)
                    if ($count > 0)
                        $description .= " [$table : $count entry]";
                $description .= " schiacciata su Authority {$dstSortTxt} con id={$dst_id}";
                ChangelogPeer::logAction($dst, ChangelogPeer::LOG_UPDATE, $clavisLibrarian, $description);
            }
        } catch (PropelException $e) {
            $_connection->rollback();
            Prado::log('Error in ' . __CLASS__ . '::' . __FUNCTION__ . '(): .' . $e);
            return false;
        }
        return $arrRowsAffected;
    }

} // Authority
