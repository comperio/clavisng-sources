<?php

  // include base peer class
  require_once 'clavis/om/BaseContactPeer.php';
  
  // include object class
  include_once 'clavis/Contact.php';

class ContactPeer extends BaseContactPeer {

	const TYPE_EMAIL	= 'E';
	const TYPE_MOBILE	= 'C';
	const TYPE_PHONE	= 'T';
	const TYPE_FAX		= 'F';
	const TYPE_ICQ		= 'I';
	const TYPE_MSN		= 'M';
	const TYPE_JABBER	= 'J';
	const TYPE_YAHOO	= 'Y';
	const TYPE_AOL		= 'A';
	const TYPE_SKYPE	= 'S';
	
} // ContactPeer
