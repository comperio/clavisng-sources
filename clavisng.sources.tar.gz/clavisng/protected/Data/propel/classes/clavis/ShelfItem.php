<?php
/**
 * ShelfItem class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseShelfItem.php';

/**
 * ShelfItem class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class ShelfItem extends BaseShelfItem
{
	public function postSave(PropelPDO $conn = null)
	{
		if (ShelfPeer::TYPE_MANIFESTATION == $this->object_class
				|| ShelfPeer::TYPE_MANIFESTATION_BUY == $this->object_class)
			$this->invalidateManifestationCache();
		
		return true;
	}

	public function postDelete(PropelPDO $conn = null)
	{
		if (ShelfPeer::TYPE_MANIFESTATION == $this->object_class
				|| ShelfPeer::TYPE_MANIFESTATION_BUY == $this->object_class)
			$this->invalidateManifestationCache();
		
		return true;
	}

	private function invalidateManifestationCache()
	{
		TurbomarcCachePeer::invalidate($this->object_id);
	}

	/**
	 * It returns the id of the object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->shelf_id;
	}

	/**
	 * It returns the complete name, in string, of the object
	 * described by this shelfitem.
	 *
	 * NB: must be completed for all types which can constitute
	 * a shelfitem.
	 *
	 * @return string
	 */
	public function getName()
	{
		$name = '';
		$type = $this->getObjectClass();
		$id = intval($this->getObjectId());

		if ($id > 0)
		{
			switch ($type)
			{
				case ShelfPeer::TYPE_PATRON:
					$patron = PatronQuery::create()
								->findPk($id);
					
					if ($patron instanceof Patron)
						$name = $patron->getCompleteName();
					
					break;

				case ShelfPeer::TYPE_MANIFESTATION:
				case ShelfPeer::TYPE_MANIFESTATION_BUY:
					$manifestation = ManifestationQuery::create()
										->findPk($id);
					
					if ($manifestation instanceof Manifestation)
						$name = $manifestation->getTitle();

					break;

				case ShelfPeer::TYPE_AUTHORITY:
					$authority = AuthorityQuery::create()
									->findPk($id);
					
					if ($authority instanceof Authority)
						$name = $authority->getCompleteText();
					
					break;

				case ShelfPeer::TYPE_ITEM:
					$item = ItemQuery::create()
								->findPk($id);
					
					if ($item instanceof Item)
						$name = $item->getTitle();
					
					break;
			}
		}
		
		return $name;
	}

	/**
	 * It returns, in string, the type of the object.
	 *
	 * @return string
	 */
	public function getType()
	{
		$type = $this->getObjectClass();
		return $type;
	}

	public function getTypeName()
	{
		$type = $this->getType();
		return LookupValuePeer::getLookupValue('SHELFITEMTYPE', $type);
	}

	public function getObjectPeerClass($class = null)
	{
		$pearClass = null;
		$class = $this->object_class;

		if (is_null($class))
			$class = $this->getObjectClass();

		if (!is_null($class) && (is_string($class)))
			switch ($class)
			{
				case ShelfPeer::TYPE_PATRON:
					$peerClass = new PatronPeer();
					break;

				case ShelfPeer::TYPE_MANIFESTATION:
				case ShelfPeer::TYPE_MANIFESTATION_BUY:
					$peerClass = new ManifestationPeer();
					break;

				case ShelfPeer::TYPE_AUTHORITY:
					$peerClass = new AuthorityPeer();
					break;

				case ShelfPeer::TYPE_ITEM:
					$peerClass = new ItemPeer();
					break;

				case ShelfPeer::TYPE_LIBRARIAN:
					$peerClass = new LibrarianPeer();
					break;

				case ShelfPeer::TYPE_LIBRARY:
					$peerClass = new LibraryPeer();
					break;

				case ShelfPeer::TYPE_LOAN:
					$peerClass = new LoanPeer();
					break;

				default:
					$peerClass = null;
			}

		return $peerClass;
	}

	public function getPackedPK()
	{
		$shelfId = $this->getShelfId();
		if (is_null($shelfId) || $shelfId == 0)
			$shelfId = 'NULL';
		$objectId = $this->getObjectId();
		if (is_null($objectId) || $objectId == 0)
			$objectId = 'NULL';
		$objectClass = $this->getObjectClass();
		if (is_null($objectClass) || $objectClass == '')
			$objectClass = 'NULL';

		return $shelfId . ':!:' . $objectId . ':!:' . $objectClass;
	}

	public function setPackedPk($packed)
	{

	}

	/**
	 * @return mixed
	 */
	public function getObject()
	{
		$returnObject = null;
		
		$objectId = $this->getObjectId();
		$objectClass = $this->getObjectClass();
		
		if ((trim($objectClass) != '')
				&& (intval($objectId) > 0) )
		{
			$objectPeerClass = $this->getObjectPeerClass($objectClass);
			if (!is_null($objectPeerClass))
			{
				try
				{
					$returnObject = $objectPeerClass->retrieveByPk($objectId);
				}
				catch (PropelException $exception)
				{
					//Prado::log($exception);
				}
			}
		}
		
		return $returnObject;
	}
	
	public function exists()
	{
		return (!is_null($this->getObject()));
	}

} // ShelfItem