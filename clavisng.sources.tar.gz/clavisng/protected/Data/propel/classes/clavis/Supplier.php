<?php

require_once 'clavis/om/BaseSupplier.php';

class Supplier extends BaseSupplier {

	/**
	 * It returns the id of the supplier (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->supplier_id;
	}
	
	public function getNavigateUrl() 
	{
		return 'index.php?page=Acquisition.SupplierPage&supplierId=';
	}
	
} // Supplier
