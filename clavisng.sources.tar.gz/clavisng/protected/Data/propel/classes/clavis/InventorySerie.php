<?php

require_once 'clavis/om/BaseInventorySerie.php';

class InventorySerie extends BaseInventorySerie {

	/**
	 * It returns the id of the item (for compatibility).
	 *
	 * @return string
	 */
	public function getId()
	{
		return $this->inventory_serie_id;
	}

} // InventorySerie
