<?php

require 'clavis/om/BasePatronWallet.php';


/**
 * Skeleton subclass for representing a row from the 'patron_wallet' table.
 *
 * 
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 * @package    clavis
 */
class PatronWallet extends BasePatronWallet {


    const STATUS_OPEN   = "A";
    const STATUS_CLOSED = "B";

	/**
	 * Initializes internal state of PatronWallet object.
	 * @see        parent::__construct()
	 */
	public function __construct()
	{
		// Make sure that parent constructor is always invoked, since that
		// is where any default values for this object are set.
		parent::__construct();
	}

    public function createReceiptId()
    {
        $countWallet = PatronWalletQuery::create()
            ->filterByLibraryId($this->getLibraryId())
            ->filterByWalletType($this->getWalletType())
            ->where("patron_wallet.receipt_id IS NOT NULL")
            ->where("YEAR(patron_wallet.date_closed) = ". date("Y"))
            ->count();
        $this->setReceiptId($countWallet + 1 . "/" . date("Y") . "/". $this->getWalletType());
        $this->setDateClosed(time());
    }

} // PatronWallet
