<?php

require_once 'clavis/om/BaseBudget.php';

class Budget extends BaseBudget 
{
	/**
	 * It returns the id of the item (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->budget_id;
	}

	/**
	 * Helper method to return the budget library label.
	 *
	 * @return string The library label, empty string if budget isn't associated to a library
	 */
	public function getLibraryLabel()
	{
		$library = $this->getLibrary();
		return ($library instanceof Library) ? $library->getLabel() : '';
	}

	public function getNavigateUrl($idFillFlag = false)
	{
		if ($idFillFlag)
			$subfix = $this->getId();
		else
			$subfix = "";

		$peer = $this->getPeer();
		return 'index.php?page=' . $peer::getViewPage() . '&id=' . $subfix;
	}
		
	public function getInvoicedCombo()
	{
		$items = ItemQuery::create()
					->filterByBudgetId($this->getBudgetId())
					//->select(array('BudgetId'))
					->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
				->find();//->toArray();

		$totalAllocated = 0.0;
		$totalInvoiced = 0.0;
		foreach ($items as $item) 
		{
			if ($item->getItemOrderStatus() == ItemStatus::ITEMORDERSTATUS_INORDER)
				$totalAllocated += floatval($item->getInventoryValue());
			elseif (($item->getInvoice() instanceof Invoice) && $item->getItemOrderStatus() != ItemStatus::ITEMORDERSTATUS_ORDERNULL)
				$totalInvoiced += floatval($item->getInventoryValue());
			
			$item->clearAllReferences(true);
			unset($item);
		}

		$restAllocated = floatval($this->getTotalAmount()) - floatval($totalInvoiced) - floatval($totalAllocated);
        $restInvoiced = floatval($this->getTotalAmount()) - floatval($totalInvoiced);
		
		return array(	'TotalAllocated' => $totalAllocated,
						'TotalInvoiced'	=> $totalInvoiced,
						'RestAllocated' => $restAllocated,
						'RestInvoiced' => $restInvoiced);
	}
		
	public function getCompleteBudgetTitle()
	{
		return (($title = $this->getBudgetTitle()) != ""
					? $title
					: '---')
				. (intval($year = $this->getBudgetYear()) > 0
						? " (" . $year . ")"
						: "");
	}
	
	public function getCurrencies()
	{
		$statement = Propel::getConnection()->prepare(	"SELECT SUM(" . ItemPeer::CURRENCY_VALUE . "), "
														. "SUM(" . ItemPeer::INVENTORY_VALUE . ") FROM " . ItemPeer::TABLE_NAME .
															" WHERE " . ItemPeer::BUDGET_ID . " = :value" .
															" AND "	. ItemPeer::ITEM_ORDER_STATUS . " != '" . ItemStatus::ITEMORDERSTATUS_ORDERNULL . "'");
			$statement->execute(array(':value' => $this->getBudgetId()));

			$result = $statement->fetch();
			return array(	InvoicePeer::CURRENCY_AMOUNT_VALUE => $result[0], 
							InvoicePeer::INVENTORY_AMOUNT_VALUE => $result[1]);
	}
	
	public function getInventoryAmountValue()
	{
		$currencies = $this->getCurrencies();
		
		if (array_key_exists(InvoicePeer::INVENTORY_AMOUNT_VALUE, $currencies))
			return $currencies[InvoicePeer::INVENTORY_AMOUNT_VALUE];
	}
	
} // Budget
