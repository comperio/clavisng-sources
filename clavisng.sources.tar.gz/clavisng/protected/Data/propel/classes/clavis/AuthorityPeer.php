<?php
/**
 * AuthorityPeer class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once 'clavis/om/BaseAuthorityPeer.php';
include_once 'clavis/Authority.php';

/**
 * AuthorityPeer Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class AuthorityPeer extends BaseAuthorityPeer {

	const TYPE_ARGUMENT			= 'A';
	const TYPE_CLASS			= 'C';
	const TYPE_SERIE			= 'D';
	const TYPE_CORPORATEBODYNAME = 'E';
	const TYPE_FAMILYNAME		= 'F';
	const TYPE_PLACE			= 'G';
	const TYPE_PUBPLACE			= 'L';
	const TYPE_TRADEMARK		= 'M';
	const TYPE_WORK				= 'O';
	const TYPE_PERSONALNAME		= 'P';
	const TYPE_SUBJECT			= 'S';
	const TYPE_PRINTERSDEVICE	= 'H';
	const TYPE_CHRONOLOGICAL	= 'T';

	const SUBTYPE_THINGS_OBJECTS	= 'Y';
	const SUBTYPE_THING_FORM		= 'B';
	const SUBTYPE_THINGS_MATTER	= 'X';
	const SUBTYPE_THINGS_TOOLS		= 'W';
	const SUBTYPE_THINGS_SPACE		= 'I';
	const SUBTYPE_THINGS_STRUCT	= 'K';
	const SUBTYPE_ACTIONS_DISC		= 'V';
	const SUBTYPE_ACTIONS_ACT		= 'U';
	const SUBTYPE_ACTIONS_PROC		= 'Z';
	const SUBTYPE_AGENTS_PEOPLE	= 'R';
	const SUBTYPE_AGENTS_ORG		= 'Q';
	const SUBTYPE_AGENTS_ORGANISMS	= 'J';
	const SUBTYPE_TIME				= 'N';

	const RECTYPE_ACCEPTED	= 'x';
	const RECTYPE_VARIANT	= 'y';
	const RECTYPE_NODE		= 'z';
	const RECTYPE_TOPTERM	= 'k';

	const INTERNALSTATUS_NOTAPPLICABLE	= 'x';
	const INTERNALSTATUS_FINAL			= 'a';
	const INTERNALSTATUS_PROVISIONAL	= 'c';
	const INTERNALSTATUS_THESAURUS		= 's';
	const INTERNALSTATUS_REVIEW			= 'r';

	const NOTETYPE_GENERAL		= 'a';
	const NOTETYPE_SCOPENOTE	= 'c';
	const NOTETYPE_BIOGRAPHIC	= 'b';
	const NOTETYPE_EDITORIAL	= 'r';

	const SRCHTXTMODE_EXACT		= 1;
	const SRCHTXTMODE_LIKE		= 2;
	const SRCHTXTMODE_BEGINS	= 3;
	const SRCHTXTMODE_FULLEXACT	= 4;

	private static $_unimarcTypeMap = array(
		self::TYPE_ARGUMENT			=> 'x',
		self::TYPE_CLASS			=> 's',
		self::TYPE_SERIE			=> ' ',
		self::TYPE_CORPORATEBODYNAME => 'b',
		self::TYPE_FAMILYNAME		=> 'e',
		self::TYPE_PLACE			=> 'c',
		self::TYPE_PUBPLACE			=> 'k',
		self::TYPE_TRADEMARK		=> 'd',
		self::TYPE_WORK				=> 'f',
		self::TYPE_PERSONALNAME		=> 'a',
		self::TYPE_SUBJECT			=> 'j',
		self::TYPE_PRINTERSDEVICE	=> 'y',
		self::TYPE_CHRONOLOGICAL	=> ' ',
	);

	private static $_unimarcLinkFieldSeeTypeMap = array(
		self::TYPE_PERSONALNAME		=> '400',
		self::TYPE_CORPORATEBODYNAME => '410',
		self::TYPE_PLACE			=> '415',
		self::TYPE_TRADEMARK		=> '416',
		self::TYPE_FAMILYNAME		=> '420',
		self::TYPE_WORK				=> '430',
		self::TYPE_SUBJECT			=> '450',
		self::TYPE_PUBPLACE			=> '460',
		//self::TYPE_FORM				=> '480',
		self::TYPE_CLASS			=> '489',
		self::TYPE_ARGUMENT			=> '490',
		self::TYPE_SERIE			=> '491',
		self::TYPE_CHRONOLOGICAL	=> '492',
		//self::TYPE_TIME				=> '493',
		self::TYPE_PRINTERSDEVICE	=> '499',
	);


	/**
	 * Get a list of patrons based on a start string and optional criterions.
	 *
	 * @param string $token The string to use as a base search.
	 * @param integer $limit The maximum of patrons to return (defaults to 10).
	 * @param Array $types Optional criterions to further filter the results.
	 * @param bool $excludeTypes
	 * @return PropelObjectCollection A list of Patrons.
	 */
	public static function doSuggest($token,$limit=10,Array $types=array(),$excludeTypes=false) {
		// uncomment to enable search in solr index.
		//return self::searchAuthority($token,self::SRCHTXTMODE_BEGINS,null,0,$limit);

		$q = AuthorityQuery::create()
			->condition('st1','Authority.SortText LIKE ?',"{$token}%")
			->condition('st2','Authority.SortText LIKE ?',"*{$token}%")
			->where(array('st1','st2'),'or');
		if ($types)
			$q->filterByAuthorityType($types,$excludeTypes ? Criteria::NOT_IN : Criteria::IN);
		$q->addAscendingOrderByColumn('REPLACE('.self::SORT_TEXT.',\'*\',\'\')');
		$authList = $q->limit($limit)->find();
		return $authList;
	}

	public static function searchAuthority($text='',$textMod=self::SRCHTXTMODE_BEGINS,$type=null,$offset=0, $limit=300, $sort='score')
	{
		$queryParams = $aids = array();
		if ($text)
			switch ($textMod) {
				case self::SRCHTXTMODE_EXACT:
					$queryParams[] = "fldin_str_text:\"{$text}\"";
					break;
				case self::SRCHTXTMODE_LIKE:
					$queryParams[] = "fldin_str_srchtext:\"{$text}\"";
					break;
				case self::SRCHTXTMODE_FULLEXACT:
					$queryParams[] = "fldin_str_fulltext:\"{$text}\"";
					break;
				case self::SRCHTXTMODE_BEGINS:
				default:
					$queryParams[] = "fldin_str_srchtext:[\"{$text}\" TO \"{$text}Z\"]";
					break;
			}
		if ($type)
			$queryParams[] = "fldin_str_auth_type:\"$type\"";

		/* @var $search ISearchModule */
		$search = Prado::getApplication()->getModule('search');
		$data = $search->searchAuthority(implode(' AND ',$queryParams),$offset,$limit,$sort);
		if ($data['response']['numFound'] > 0) {
			foreach ($data['response']['docs'] as $key => $authdoc)
				$aids[] = $authdoc['Id'];
		}
		return AuthorityQuery::create()->findByAuthorityId($aids);
	}

	/**
	 * Takes a subject string, checks if it exists, if not import it.
	 *
	 * @param string $value The subject to process.
	 * @param string $subject_class The subject class
	 * @return Authority The subject
	 */
	public static function getSubject($value,$subject_class = null) {
		// search for existing subject
		$subjectQuery = AuthorityQuery::create()
			->filterByAuthorityType(self::TYPE_SUBJECT);
		if ($subject_class)
			$subjectQuery->filterBySubjectClass($subject_class);
		$subject = $subjectQuery->findOneByFullText($value);
		if ($subject instanceof Authority)
			return $subject;
		// if not found, create it
		$subject = new Authority();
		$subject->setAuthorityType(self::TYPE_SUBJECT);
		$subject->setAuthorityRectype(self::RECTYPE_ACCEPTED);
		$subject->setAuthorityCodLevel(05);
		$subject->setAuthorityStatus(self::INTERNALSTATUS_PROVISIONAL);
		if ($subject_class)
			$subject->setSubjectClass($subject_class);
		$subject->save();
		$tm = $subject->getTurboMarc();
		$f250 = $tm->addField('250');
		if ($subject_class)
			$f250->addSubField('2',$subject_class);
		$pos = 0;
		foreach (explode(' - ',$value) as $e) {
			if (trim($e) == '')
				continue;
			$auth = AuthorityQuery::create()
				->filterByAuthorityType(array(self::TYPE_SUBJECT, self::TYPE_CORPORATEBODYNAME, self::TYPE_PUBPLACE),Criteria::NOT_IN)
				->findOneByFullText(trim($e));
			if (!$auth instanceof Authority) {
				$auth = new Authority();
				$auth->setAuthorityType(self::TYPE_ARGUMENT);
				$auth->setAuthorityRectype(self::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodLevel(05);
				$auth->setAuthorityStatus(self::INTERNALSTATUS_PROVISIONAL);
				$auth->setSortText(trim($e));
				$desctm = $auth->getTurboMarc();
				$f931 = $desctm->addField(931);
				$f931->addSubField('a',trim($e));
				$auth->setUnimarc($desctm->asXML());
				$auth->save();
			}
			$aST = $auth->getFullText();
			if ($auth->getAuthorityType() == self::TYPE_PLACE) {
				$type = 'L';
			} else if ($auth->getAuthoritySubtype() == self::SUBTYPE_THING_FORM) {
				$type = 'F';
			} else if ($auth->getAuthoritySubtype() == self::SUBTYPE_TIME) {
				$type = 'T';
			} else {
				$type = 'A';
			}
			$l = new LSubject();
			$l->setAuthorityRelatedBySubjectId($subject);
			$l->setAuthorityRelatedByAuthorityId($auth);
			$l->setPosition($pos);
			$l->setType($type);
			$l->setConnector('- ');
			$l->save();
			if (0 == $pos) {
				$f250->addSubField('a',$aST);
			} else {
				$f250->addSubField('c','- ');
				$f250->addSubField('x',$aST);
			}
			++$pos;
			$l->clearAllReferences(true);
			unset($l);
			$auth->clearAllReferences(true);
			unset($auth);
		}
		$subject->setUnimarc($tm->asXML());
		$subject->save();
		return $subject;
	}

	public static function mapTypeClavisToUnimarc($type)
	{
		return (array_key_exists($type,self::$_unimarcTypeMap)) ?
			self::$_unimarcTypeMap[$type] : '9';
	}

	public static function mapTypeUnimarcToClavis($type)
	{
		return array_search($type,self::$_unimarcTypeMap);
	}

	/**
	 * Retrieves an authority by its bid_source / bid couple.
	 *
	 * @param string $bid_source
	 * @param string $bid
	 * @return Authority|null
	 */
	public static function getOneByBid($bid_source,$bid)
	{
		return AuthorityQuery::create()
			->filterByBidSource($bid_source)
			->findOneByBid($bid);
	}

	/**
	 * Checks if an authority exists with bid_source / bid couple.
	 *
	 * @param string $bid_source
	 * @param string $bid
	 * @return int
	 */
	public static function bidExists($bid_source,$bid) {
		$aid = AuthorityQuery::create()
			->select('AuthorityId')
			->filterByBidSource($bid_source)
			->findOneByBid($bid);
		return $aid;
	}

	/**
	 * @param $link
	 * @param TurboMarc $authLinkFld
	 * @param bool $bid_source
	 * @param bool $create
	 * @param bool $dummy
	 * @return Authority|null|Authority
	 */
	public static function getLinkedAuthority($link, TurboMarc $authLinkFld, $bid_source=null, $create=true, $dummy=false)
	{
		$auth = $bid = null;
		if ($bid_source) {
			$sbid = 's'.strtolower($bid_source);
			if (isset($authLinkFld->$sbid)) {
				$bid = trim((string)$authLinkFld->$sbid);
				$auth = self::getOneByBid($bid_source,$bid);
			}
		}
		// if not found try to fallback on internal id, if exists
		if (!$auth && isset($authLinkFld->s3)) {
			$auth = AuthorityQuery::create()->findPk((string)$authLinkFld->s3);
		}

		if ($auth instanceof Authority) {
			// authority found, return it
			return $auth;
		}

		if (in_array($link,array(500,430,530))) // work
		{
			$title = preg_replace('!\s+!', ' ', (string)$authLinkFld->sa);
			$titparts = explode('*', $title, 1);
			$sort_text = trim(array_pop($titparts));
			$auth = AuthorityQuery::create()
				->filterByAuthorityType(AuthorityPeer::TYPE_WORK)
				->findOneBySortText(array($sort_text));
				// array argument is required to prevent wildcard substitution by Propel
			if (! $auth instanceof Authority && $create) {
				// create it
				if ($dummy)
					return array("Opera [{work}] NON trovata, verrà creata.", array('work' => htmlspecialchars($title)));
				$auth = new Authority();
				$tm = $auth->getTurboMarc();
				$tm->addField('230');
				$tm->d230->addSubField('a',$title);
				$tm->d230->addSubField('w','text');
				$auth->setUnimarc($tm->asXML());
				$auth->setAuthorityType(AuthorityPeer::TYPE_WORK);
				$auth->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodLevel(05);
				$auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
				$auth->setSortText($title);
			}
		}
		else if (($link >= 600 && $link <= 610) || in_array($link,array(699,450,550)))	// subject
		{
			$subj = (string)$authLinkFld->sa;
			foreach ($authLinkFld->sx as $sf)
				$subj .= ' - '.trim($sf);
			$subjtype = null;
			if (isset($authLinkFld->s9)) {	// try to guess subjtype from string
				$lv = LookupValueQuery::create()
					->filterByValueClass('SUBJECTTYPE')
					->filterByValueLabel((string)$authLinkFld->s9)
					->findOne();
				if ($lv instanceof LookupValue)
					$subjtype = $lv->getValueKey();
			}
			if (!$subjtype)
				$subjtype = isset($authLinkFld->s2) ? (string)$authLinkFld->s2 : null;
			if ($dummy)
				return array("Soggetto [{type}/{auth}] NON trovato, verrà creato", array('type' => $subjtype, 'auth' => $subj));
			$auth = AuthorityPeer::getSubject($subj,$subjtype);
		}
		else if (in_array($link,array(480,580,930,931)))	// subject term
		{
			$auth = AuthorityQuery::create()
				->filterByAuthorityType(self::TYPE_ARGUMENT)
				->findOneBySortText(array((string)$authLinkFld->sa));
			if (! $auth instanceof Authority && $create) {
				// create it
				if ($dummy)
					return array("Termine [{term}] NON trovato, verrà creato.", array('term' => htmlspecialchars($authLinkFld->sa)));
				$auth = new Authority();
				$tm = $auth->getTurboMarc();
				$f931 = $tm->addField(931);
				$f931->addSubField('a',(string)$authLinkFld->sa);
				$f931->addSubField('2',(string)$authLinkFld->s2);
				$auth->setUnimarc($tm->asXML());
				$auth->setAuthorityType(AuthorityPeer::TYPE_ARGUMENT);
				$auth->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodLevel(05);
				$auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
				$auth->setSortText((string)$authLinkFld->sa);
				$auth->setSubjectClass((string)$authLinkFld->s2);
			}
		}
		else if (616 == $link)	// trademark
		{
			$auth = AuthorityQuery::create()
				->filterByAuthorityType(AuthorityPeer::TYPE_TRADEMARK)
				->findOneByFullText(array((string)$authLinkFld->sa));
			if (! $auth instanceof Authority) {
				// create it
				if ($dummy)
					return array("Trademark [{auth}] NON trovato, verrà creato.",array('auth' => htmlspecialchars($authLinkFld->sa)));
				$auth = new Authority();
				$tm = $auth->getTurboMarc();
				$auth->setUnimarc($tm->asXML());
				$auth->setAuthorityType(AuthorityPeer::TYPE_TRADEMARK);
				$auth->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodLevel(05);
				$auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
				$auth->setSortText((string)$authLinkFld->sa);
			}
		}
		else if (in_array($link,array(620,415,515))) // pubplace
		{
			$auth = AuthorityQuery::create()
				->filterByAuthorityType(AuthorityPeer::TYPE_PUBPLACE)
				->findOneBySortText((string)$authLinkFld->sd);
			if (! $auth instanceof Authority) {
				// create it
				if ($dummy)
					return array("Luogo [{auth}] NON trovato, verrà creato.",array('auth' => htmlspecialchars($authLinkFld->sd)));
				$auth = new Authority();
				$tm = $auth->getTurboMarc();
				$f200 = $tm->addField('260');
				if (isset($authLinkFld->sa)) {
					$f200->addSubField('a',(string)$authLinkFld->sa);
					$tm->addField('102')->addSubField('a',(string)$authLinkFld->sa);
				}
				$f200->addSubField('d',(string)$authLinkFld->sd);
				if ($v = (string)$authLinkFld->sb)
					$tm->addField('090')->addSubField('r',$v);
				$auth->setUnimarc($tm->asXML());
				$auth->setAuthorityType(AuthorityPeer::TYPE_PUBPLACE);
				$auth->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodLevel(05);
				$auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
				$auth->setSortText((string)$authLinkFld->sd);

			}
		}
		else if (($link >= 675 && $link < 700) || in_array($link,array(476,576)))	// classification
		{
			$auth = AuthorityQuery::create()
				->filterByAuthorityType(AuthorityPeer::TYPE_CLASS)
				->findOneByClassCode((string)$authLinkFld->sa);
			if (! $auth instanceof Authority) {
				// create it
				if ($dummy)
					return array("Classe [{auth}] NON trovata, verrà creata.", array('auth' => htmlspecialchars($authLinkFld->sa)));
				$auth = new Authority();
				$auth->setAuthorityType(AuthorityPeer::TYPE_CLASS);
				$auth->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodlevel(05);
				$auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
				$auth->setClassCode((string)$authLinkFld->sa);
				$tm = $auth->getTurbomarc();
				switch ($link) {
					case '676':
					case '680':
						$fld = $tm->addField($link);
						break;
					default:
						$fld = $tm->addField('686');
						$fld->addSubField('2',$authLinkFld->s2);
						break;
				}
				if (isset($authLinkFld->sv))
					$fld->addSubField('v',(string)$authLinkFld->sv);
				if (isset($authLinkFld->sc))
					$fld->addSubField('c',(string)$authLinkFld->sc);
				$auth->setUnimarc($tm->asXML());
			}
		}
		else if (($link >= 700 && $link < 722) || in_array($link,array(400,410,501,510)))	// authors
		{
			$nameTypes = array(
				self::TYPE_PERSONALNAME,
				self::TYPE_CORPORATEBODYNAME,
				self::TYPE_FAMILYNAME,
				self::TYPE_TRADEMARK,
			);
			// if exists $b and/or $c subfields, the unimarc splits name/lastname, so
			// join them in $a for Clavis

            $name = $authLinkFld->getAuthorField();

            /*
			$name = (string)$authLinkFld->sa;
			foreach ($authLinkFld->sb as $token)
				if (trim($token))
					$name .= trim($token);
			foreach (array('sc','sd','sf') as $sf)
				foreach ($authLinkFld->$sf as $token)
					if (trim($token,' <>'))
						$name .= ' <'.trim($token,' <>').'>';

			$name = str_replace(array('<>','< >','> <',' , ',', , ',',,',', <','; ;'),array('','','; ',', ',', ',',',' <',';'),$name);
            */

			// remove extra spaces
			$name = preg_replace(array('!\s+!', '!\s(,)!'), array(' ','$1'), $name);
			$auth = AuthorityQuery::create()
				->filterByAuthorityType($nameTypes)
				->findOneByFullText($name);
			if (! $auth instanceof Authority) {
				// create it
				if ($dummy)
					return array("Nome [{auth}] NON trovato, verrà creato.", array('auth' => htmlspecialchars($name)));

				$auth = new Authority();
				if (716 == $link) {
					$fnum = '216';
					$auth->setAuthorityType(AuthorityPeer::TYPE_TRADEMARK);
				} else if (in_array($link,array(700,701,702,400,501))) {
					$fnum = '200';
					$auth->setAuthorityType(AuthorityPeer::TYPE_PERSONALNAME);
				} else if (in_array($link,array(710,711,712,410,510))) {
					$fnum = '210';
					$auth->setAuthorityType(AuthorityPeer::TYPE_CORPORATEBODYNAME);
				} else if (in_array($link,array(720,721,722))) {
					$fnum = '220';
					$auth->setAuthorityType(AuthorityPeer::TYPE_FAMILYNAME);
				}
				$auth->setSortText($name);
				$auth->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodLevel(05);
				$auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
				$tm = $auth->getTurboMarc();
				$f200 = $tm->addField($fnum);
				$f200->addSubField('a',$name);
				$auth->setUnimarc($tm->asXML());
			}
		}
		else if (in_array($link,array(921,421,521))) 	// printers device
		{
			$auth = AuthorityQuery::create()
				->filterByAuthorityType(AuthorityPeer::TYPE_PRINTERSDEVICE)
				->findOneByFullText((string)$authLinkFld->sa);
			if (! $auth instanceof Authority) {
				// create it
				if ($dummy)
					return array("Marca tipografica [{auth}] NON trovata, verrà creata.", array('auth' => htmlspecialchars($authLinkFld->sa)));
				$auth = new Authority();
				$auth->setAuthorityType(AuthorityPeer::TYPE_PRINTERSDEVICE);
				$auth->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
				$auth->setAuthorityCodLevel(05);
				$auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
				$tm = $auth->getTurboMarc();
				$f921 = $tm->addField('921');
				$f921->addSubField('a',(string)$authLinkFld->sa);
				$f921->addSubField('e',(string)$authLinkFld->se);
				if ($index = (string)$authLinkFld->sc) {
					$f921->addSubField('c',(string)$authLinkFld->sc);
					$idx = substr($index,0,1);
					$lv = LookupValuePeer::getLookupValue('PRINTERSDEVICEINDEX', $idx);
					if (!$lv) {
						$lv = new LookupValue();
						$lv->setValueKey($idx);
						$lv->setValueLabel($idx);
						$lv->setValueClass('PRINTERSDEVICEINDEX');
						$lv->setValueLanguage('it_IT');
						$lv->save();
						$lv_en = $lv->copy();
						$lv_en->setValueLanguage('en_US');
						$lv_en->save();
					}
				}
				foreach ($authLinkFld->sb as $kw)
					$f921->addSubField('b',(string)$kw);
				if ($note = trim((string)$authLinkFld->sd))
					$tm->addField('300')->addSubField('a',$note);
				$auth->setUnimarc($tm->asXML());
			}
		}
		if ($auth instanceof Authority) {
			if (!$auth->getBid() && $bid_source && $bid) {
				$auth->setBidSource($bid_source);
				$auth->setBid($bid);
			}
			$auth->save();
		}
		return $auth;
	}

	/**
	 * Builds and saves an Authority object upon a given TurboMarc record.
	 * THIS METHOD DOES NOT INDEX THE RECORD CREATED!!!
	 *
	 * @param TurboMarc $tm A TurboMarc record
	 * @param boolean $dummy If true, manifestation will not be created and the function will return
	 *						an array listing all the actions that would be taken (defaults to false)
	 * @param array $linkbucket The array to be filled with not imported links.
	 * @return Authority|Array The authority created or actionLog array.
	 */
	public static function createFromTurbomarc(TurboMarc $tm, $dummy=false, &$linkbucket=array())
	{
		$a = new Authority();
		$a = $a->updateFromTurbomarc($tm,$dummy,$linkbucket);
		if (!$dummy) {
			$a->setAuthorityStatus(self::INTERNALSTATUS_PROVISIONAL);
		}
		return $a;
	}

	/**
	 * Returns the full TurboMarc (i.e. with linked fields) for the record id supplied.
	 *
	 * @param integer|Authority $a
	 * @param boolean $asXML
	 * @param boolean $getCollection
	 * @return TurboMarc or string
	 * @throws Exception
	 */
    public static function getFullTurboMarc($a, $asXML = true, $getCollection = true)
    {
		$adb = array();
		if ($a instanceof Authority) {
			$aid = $a->getAuthorityId();
			$adb = $a->toArray();
		}
		else
		{
            $aid = intval($a);
            $adb = AuthorityQuery::create()
                ->findPk($aid);
            if($adb instanceof Authority)
                $adb = $adb->toArray();
        }

		if (!$adb)
			return null;

		if (!$adb['Unimarc'])
			$adb['Unimarc'] = '<r></r>';

		$tm = TurboMarc::createRecord(Clavis::html2xmlEntities($adb['Unimarc']));

		$c001 = $tm->setControlField('001',$aid);
		unset($tm->d035);
		$f035 = $tm->addField('035');
		$f035->addSubField('a', $adb['Bid']);
		$f035->addSubField('9', $adb['BidSource']);


        $f299 = $tm->addField("299");
        $f299->addSubField("a",str_replace("*"," ",$adb['FullText']));
        $f299->addSubField('b',$adb['NonSortText']);
        $f299->addSubField('c',$adb['SortText']);

        // BT Terms list to build full path
        $btTerms = array();

		$conn = Propel::getConnection();

		// process authority links
		$authLinksByDown = $conn->query(
			'SELECT 0 AS inverse,'.self::AUTHORITY_ID.','.self::AUTHORITY_TYPE.','.self::NON_SORT_TEXT.','.
            self::SORT_TEXT.','. self::FULL_TEXT.','.self::UNIMARC.','.self::BID_SOURCE.','.self::BID.','.self::AUTHORITY_RECTYPE.','.
			LAuthorityPeer::LINK_TYPE.','.LAuthorityPeer::LINK_NOTE.','.LAuthorityPeer::RELATOR_CODE.
			' FROM '.LAuthorityPeer::TABLE_NAME.' LEFT JOIN '.self::TABLE_NAME.
			' ON '.self::AUTHORITY_ID.'='.LAuthorityPeer::AUTHORITY_ID_UP.
			' WHERE '.LAuthorityPeer::AUTHORITY_ID_DOWN.'='.intval($aid))->fetchAll(PDO::FETCH_ASSOC);
		$authLinksByUp = $conn->query(
			'SELECT 1 AS inverse,'.self::AUTHORITY_ID.','.self::AUTHORITY_TYPE.','.self::NON_SORT_TEXT.','.
			self::SORT_TEXT.','. self::FULL_TEXT.','.self::UNIMARC.','.self::BID_SOURCE.','.self::BID.','.self::AUTHORITY_RECTYPE.','.
			LAuthorityPeer::LINK_TYPE.','.LAuthorityPeer::LINK_NOTE.','.LAuthorityPeer::RELATOR_CODE.
			' FROM '.LAuthorityPeer::TABLE_NAME.' LEFT JOIN '.self::TABLE_NAME.
			' ON '.self::AUTHORITY_ID.'='.LAuthorityPeer::AUTHORITY_ID_DOWN.
			' WHERE '.LAuthorityPeer::AUTHORITY_ID_UP.'='.intval($aid))->fetchAll(PDO::FETCH_ASSOC);
		$authLinks = array_merge($authLinksByDown,$authLinksByUp);
		foreach($authLinks as $alnk)
		{
            if(trim($alnk['link_type']) == "") continue;

			$flnk = null;
			$authtm = $alnk['unimarc'] ? TurboMarc::createRecord($alnk['unimarc']) : null;

			if ($alnk && $alnk['link_type'][0] > substr($alnk['link_type'],-1)) {
				$alnk['inverse'] = !$alnk['inverse'];
				$alnk['link_type'] = strrev($alnk['link_type']);
			}
            // Work to Work Link
            if($adb['AuthorityType'] == 'O' && $alnk['authority_type'] == 'O' && strlen($alnk['link_type']) == 3)
            {
                $flnk = $tm->addField('463');
                $flnk->addSubField("l",($alnk['inverse'])?strrev($alnk['link_type']):$alnk['link_type']);
            }
            else if( $alnk['authority_type'] == 'O' && $adb['AuthorityType'] != 'O')
                continue;
            else
                switch ($alnk['link_type'])
                {
                    case 'KL':
                        // Class - Auth link
                        if (self::TYPE_CLASS == $adb['AuthorityType']) {
                            $flnk = $tm->addField('976');
                        } else {
                            $fld = $authtm->getAuthorityMainField();
                            if ($fld)
                                $flnk = $tm->addField($fld->getTag());
                        }
                        break;
                    case 'AB':	// Main author
                        $flnk = $tm->addField('970');
                        break;
                    case 'CD':	// Alternative author
                        $flnk = $tm->addField('971');
                        break;
                    case 'EF':	// Secondary author
                        $flnk = $tm->addField('972');
                        break;
                    case 'GH':	// Subject
                        $flnk = $tm->addField('968');
                        break;
                    case 'IJ':	// Fictional subject
                        $flnk = $tm->addField('969');
                        break;
                    case 'KP':	// Keyword
                        $flnk = $tm->addField('967');
                        break;
                    case 'MN':	// Place
                        $flnk = $tm->addField('961');
                        break;
                    case 'OP':	// Publishing place
                        $flnk = $tm->addField('960');
                        break;
                    case 'QR':	// Serie
                        $flnk = $tm->addField('962');
                        break;
                    case '23':	// BT (broader term) or NT (narrower term)
                        $flnk = $tm->addField($alnk['inverse'] ? '965' : '966');
                        $btTerms[] = $alnk;
                        break;
                    case '11':	// RT (see also)
                        $flnk = $tm->addField('491');
                        break;
                    case '45':	// USE (54)
                        $flnk = $tm->addField($alnk['inverse'] ? '493':'490');
                        break;
                    case '67':	// USE+
                        $flnk = $tm->addField('492');
                        break;
                    default:
                        $flnk = $tm->addField('999');
                        $flnk->addSubField("l",$alnk['link_type']);
                        break;
                }
			if ($flnk) {
				$fld = $authtm->getAuthorityMainField();
				foreach ($fld->children() as $sf)
				   $flnk->appendNode($sf);

				if (self::TYPE_CLASS != $alnk['authority_type'])
					$flnk->addSubField('2',$alnk['authority_type']);

				$flnk->addSubField('6',$alnk['authority_rectype']);
				$flnk->addSubField('3',$alnk['authority_id']);
				if ($alnk['relator_code'])
					$flnk->addSubField('4',$alnk['relator_code']);
				if ($alnk['link_note'])
					$flnk->addSubField('7',$alnk['link_note']);
				$flnk->addSubField('9',str_replace("*"," ",trim($alnk['full_text'])));
				if (trim($alnk['bid_source']) != '')
					$flnk->addSubField(strtolower($alnk['bid_source']),$alnk['bid']);
			}
		}

        foreach(self::getBTPaths($adb) as $thpath)
        {
                $f973 = $tm->addField("973");
                $f973->addSubField("a",$thpath);
        }

		// add 931s (descriptors) for subject
		if (self::TYPE_SUBJECT == $adb['AuthorityType']) {
			$lsubj = $conn->query('SELECT * FROM ' . LSubjectPeer::TABLE_NAME .
				' JOIN ' . AuthorityPeer::TABLE_NAME . ' ON ' . LSubjectPeer::AUTHORITY_ID .
				'=' . AuthorityPeer::AUTHORITY_ID . ' WHERE ' . LSubjectPeer::SUBJECT_ID .
				'=' . $aid . ' ORDER BY ' . LSubjectPeer::POSITION)->fetchAll(PDO::FETCH_ASSOC);
			foreach ($lsubj as $term) {
				$f931 = $tm->addField('931');
				$f931->addSubField('a',$term['full_text']);
				$f931->addSubField('2',$term['subject_class']);
				$f931->addSubField('3',$term['authority_id']);
				if ($term['bid_source'])
					$f931->addSubField(strtolower($term['bid_source']),$term['bid']);
			}
		}
		if (isset($tm->d901))
			unset($tm->d901);

		$f901 = $tm->addField('901');
		$f901->addSubField('e', $adb['AuthorityCodlevel']);
		$f901->addSubField('f', $adb['AuthorityStatus']);
		$f901->addSubField('m', $adb['AuthorityType']);
        $f901->addSubField('q', $adb['AuthoritySubtype']);
		$f901->addSubField('n', $adb['AuthorityRectype']);
        $f901->addSubField('s', $adb['SubjectClass']);
        $f901->addSubField('w', $adb['ClassCode']);
        $f901->addSubField('r', $adb['DateUpdated']);
		$f901->addSubField('u', $adb['DateCreated']);
        $f901->addSubField('p', $adb['ParentId']);

		$attachs = Propel::getConnection()->query('SELECT * FROM ' . AttachmentPeer::TABLE_NAME .
			' WHERE ' . AttachmentPeer::OBJECT_TYPE . '=\'authority\' AND ' .
			AttachmentPeer::OBJECT_ID . '=' . $aid);
		$application = Prado::getApplication();
		if ($application instanceof TShellApplication) {
			$baseUrl = ClavisParamQuery::getParam('CLAVISPARAM','BaseUrl').'index.php?file=';
		} else {
			$req = Prado::getApplication()->getRequest();
			$baseUrl = $req->getBaseUrl() . $req->constructUrl('file', null);
		}
        
		foreach ($attachs as $attach) {
			if (self::TYPE_SUBJECT == $adb['AuthorityType'] && AttachmentPeer::TYPE_IMAGE == $attach['attachment_type']) {
				$f856 = $tm->addField('856');
				$f856->addSubField('a',$attach['file_label']);
				$f856->addSubField('9',base64_encode(file_get_contents(
					AttachmentPeer::getRealStoragePath().$attach['file_path'])));
			} else {
				$f955 = $tm->addField('955');
				$f955->addSubField('a', $attach['attachment_type']);
				$f955->addSubField('b', $attach['mime_type']);
				$f955->addSubField('c', $attach['file_size']);
				$f955->addSubField('d', $baseUrl . $attach['attachment_id']);
				$f955->addSubField('e', $attach['file_name']);
				$f955->addSubField('f', $attach['license']);
				$f955->addSubField('l', $attach['file_label']);
				$f955->addSubField('n', $attach['file_description']);
				$f955->addSubField('3', $attach['attachment_id']);
			}
		}


		$ret = ($getCollection) ? TurboMarc::createCollection()->appendNode($tm) : $tm;
		try {
			return ($asXML) ? $ret->asXML() : $ret;
		} catch (Exception $e) {
			if (class_exists('Prado') && (Prado::getApplication()->getMode() == 'Debug' ||
				(Prado::getApplication()->getUser() instanceof ClavisLibrarian && Prado::getApplication()->getUser()->getIsAdmin())))
				file_put_contents('/tmp/clavis_failauthdump.xml',print_r($ret,true));
			throw $e;
		}
	}

    /**
     * @param null $paths
     * @return array
     */
    public static function getBTPaths($a, $deep = 0)
    {
        if($deep > 20) return array("LOOPLOOPLOPP");

        $retPaths = array();

        $btTerms = Propel::getConnection()->query("
            SELECT
              IF(la.link_type = '23',au.authority_id,ad.authority_id) as AuthorityId,
              IF(la.link_type = '23',au.full_text,ad.full_text) as 'FullText'
            FROM l_authority la
            JOIN authority ad ON ad.authority_id = la.authority_id_down
            JOIN authority au ON au.authority_id = la.authority_id_up
            WHERE (la.link_type = '23' AND la.authority_id_down = {$a['AuthorityId']} )
            OR (la.link_type = '32' AND la.authority_id_up = {$a['AuthorityId']} )")->fetchAll();

        if(count($btTerms) == 0)
        {
            $retPaths[0] = " {$a['AuthorityId']} ";
        }
        else
        {
            /** @var $bt LAuthority */
            foreach($btTerms as $bt)
            {
                $btPaths = self::getBTPaths($bt,$deep + 1);

                for($i=0; $i < count($btPaths); $i++)
                    $btPaths[$i] = $btPaths[$i] . " \\ {$a['AuthorityId']} ";

                $retPaths = array_merge($retPaths,  $btPaths);
            }
        }

        return $retPaths;
    }

	/**
	 *
	 * @param int $authorityId
	 * @param boolean $onlyDirty
	 * @return string The turbomarc cache
	 */
	public static function cacheTurboMarc($authorityId,$onlyDirty=true) {
		$cache = TurbomarcauthorityCacheQuery::create()->findPk($authorityId);
		if (!$cache instanceof TurbomarcauthorityCache) {
			$cache = new TurbomarcauthorityCache();
			$cache->setAuthorityId($authorityId);
		}
		if ($onlyDirty && !$cache->isNew() && !$cache->getDirty())
			return $cache->getTurbomarc();
		$cache->setTurbomarc(self::getFullTurboMarc($authorityId,true, false));
		$cache->setIndexed($cache->getIndexed() && !$cache->getDirty());
		$cache->setDirty(false);
		$cache->save();
		$turbomarc = $cache->getTurbomarc();
		$cache->clearAllReferences(true);
		return $turbomarc;
	}

	public static function invalidateCache($authorityId) {
		TurbomarcauthorityCachePeer::invalidate($authorityId);
	}

} // AuthorityPeer
