<?php
/**
 * Manifestation class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseManifestation.php';

/**
 * Manifestation class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class Manifestation extends BaseManifestation
{
	/* @var TurboMarc */
	private $_tmarc;

	public function preSave(PropelPDO $conn = null)
	{
		$this->calculateHierarchicalLevel();
		$this->setUnimarc($this->_tmarc->asXML());
		return true;
	}

	public function postInsert(PropelPDO $conn = null)
	{
		$cache = $this->getTurbomarcCache();

		if (!$cache instanceof TurbomarcCache)
		{
			$cache = new TurbomarcCache();
			$cache->setManifestationId($this->manifestation_id);
			$cache->setIndexed(false);
			$cache->setDirty(true);
			$cache->save();
		}

		return true;
	}

	public function postUpdate(PropelPDO $conn = null)
	{
		if (defined('NO_REALTIME_INDEX'))
			return true;

		// invalidate cache
		$this->invalidateCache();

		if (class_exists('Prado') && TPropertyValue::ensureBoolean(Prado::getApplication()->getModule('search')->getRealtimeIndexing()))
			$this->doIndex();

		return true;
	}

	public function preDelete(PropelPDO $conn = null)
	{
		// delete cache on predelete to avoid constraint complaints
		TurbomarcCacheQuery::create()
			->filterByManifestationId($this->manifestation_id)
			->delete();

		return true;
	}

	public function postDelete(PropelPDO $conn = null)
	{
		// unindex immediately to prevent errors in subsequent searches.
		$this->deIndex();

		return true;
	}

	public function doIndex()
	{
		// TBD here are lions
		$search = Prado::getApplication()->getModule('search');
		$this->cacheTurboMarc(true);
		$search->indexSingle($this, $this->manifestation_id);
	}

	public function deIndex()
	{
		// TBD here are lions
		$search = Prado::getApplication()->getModule('search');
		$search->deIndex($this->manifestation_id);
	}

	/**
	 * Returns the TurboMarc for manifestation's unimarc.
	 *
	 * @return TurboMarc
	 * @throws Exception
	 */
	public function getTurboMarc()
	{
		if (!class_exists('TurboMarc'))
			throw new Exception('TurboMarc class doesn\'t exists', 1);

		if (!$this->_tmarc instanceof TurboMarc)
		{
			try
			{
				$xml = $this->getUnimarc() ? Clavis::html2xmlEntities($this->getUnimarc()) : '<r></r>';
				$this->_tmarc =  TurboMarcUtility::sanitize(TurboMarc::createRecord($xml));
			}
			catch (Exception $e)
			{
				throw new Exception("Unimarc is {$this->getUnimarc()} - Exception throwed: $e");
			}
		}

		return $this->_tmarc;
	}

	/**
	 * Override parent implementation to force Turbomarc reload.
	 *
	 * @param string $v
	 * @return none
	 */
	public function setUnimarc($v)
	{
		if ($v instanceof TurboMarc)
			$v = $v->asXML();

		parent::setUnimarc($v);

		$this->reloadTurboMarc();
	}

	/**
	 * Returns the TurboMarc for manifestation's unimarc, forcing its reload.
	 *
	 * @return TurboMarc
	 */
	public function reloadTurboMarc()
	{
		$this->_tmarc = null;

		return $this->getTurboMarc();
	}

	/**
	 *
	 * @param boolean $onlyDirty
	 * @param boolean $asXML
	 * @return TurboMarc|string The turbomarc.
	 */
	public function cacheTurboMarc($onlyDirty=true,$asXML=true)
	{
		$cache = $this->getTurbomarcCache();

		if (!$cache instanceof TurbomarcCache)
		{
			$cache = new TurbomarcCache();
			$cache->setManifestationId($this->manifestation_id);
		}

		if ($onlyDirty && !$cache->isNew() && !$cache->getDirty())
			return $asXML ? $cache->getTurbomarc() : TurboMarc::createRecord($cache->getTurbomarc());

		$cache->setTurbomarc($this->getFullTurboMarc(true, false, true));
		$cache->setIndexed($cache->getIndexed() && !$cache->getDirty());
		$cache->setDirty(false);
		$cache->save();

		$turbomarc = $cache->getTurbomarc();
		$cache->clearAllReferences(true);

		if (!$asXML)
			$turbomarc = TurboMarc::createRecord($turbomarc);

		return $turbomarc;
	}

	public function invalidateCache()
	{
		if (defined('NO_CACHE_DIRTY'))
			return true;

		TurbomarcCachePeer::invalidate($this->manifestation_id);
	}

	public function isDeleteable()
	{
		$countItems = $this->countItems();
		$countAuthorities = $this->countLAuthorityManifestations();
		$countManifestationUp = $this->countLManifestationsRelatedByManifestationIdUp();
		$countManifestationDown = $this->countLManifestationsRelatedByManifestationIdDown();

		return ($countItems + $countAuthorities + $countManifestationUp + $countManifestationDown) == 0;
	}

	/**
	 * Wrapper: we return the id of the object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->manifestation_id;
	}

	/**
	 * Returns the full TurboMarc (i.e. with linked fields) for the record.
	 *
	 * @param boolean $asXML
	 * @param boolean $getCollection
     * @param boolean $mergeWork
	 * @return TurboMarc or string
	 */

	/// maybe to change: see the Query object new course of things .......
	public function getFullTurboMarc(	$asXML = true,
										$getCollection = true,
										$mergeWork = false )
	{
		// call peer's function to ensure we have a single codebase for the function
		return ManifestationPeer::getFullTurboMarc(	$this,
														$asXML,
														$getCollection,
														$mergeWork );
	}

	/**
	 * Builds and saves a Manifestation object upon a given TurboMarc record.
	 * THIS METHOD DOES NOT INDEX THE CREATED RECORD !!!
	 *
	 * @param TurboMarc $tm A TurboMarc record
	 * @param boolean $dummy If true, manifestation will not be created and the function will return
	 *						an array listing all the actions that would be taken (defaults to false)
	 * @param array $linkbucket The array to be filled with not imported links.
	 * @return Manifestation The manifestation created
	 */
	public function updateFromTurbomarc(TurboMarc $tm, $dummy=false, &$linkbucket=array())
	{
		// actionLog contains all actions taken as arrays like
		// array(field,field_idx,skippable,action_description,description_params)
		$actionLog = array();
		if (isset($tm->r))
			$tm = $tm->r;
		$leader = $tm->getLeader();
		// ensure type and level are lower-case
		$leader->type = strtolower($leader->type);
		$leader->biblevel = strtolower($leader->biblevel);
		if (!in_array($leader->biblevel,array(ManifestationPeer::LVL_MONOGRAPHIC,ManifestationPeer::LVL_SERIAL,ManifestationPeer::LVL_ANALYTIC,ManifestationPeer::LVL_COLLECTION))) {
			$leader->biblevel = ManifestationPeer::LVL_MONOGRAPHIC;
			$actionLog[] = array('l',0,false,'Livello bibliografico non trovato, impostato a monografia.',array());
		}

		$this->setBibLevel($leader->biblevel);
		$this->setBibTypeFirst(ManifestationPeer::Bibtype2Bibtypefirst($leader->type));
		$this->setBibType($leader->type.'01');

		$this->setCatalogationLevel('05');
		if (isset($tm->d901))
		{
			$sf_actions = array();

			if (isset($tm->d901->sa))
			{
				$this->setBibType((string)$tm->d901->sa);
				$sf_actions[] = 'bibtype: ['.(string)$tm->d901->sa.']';
				$leader->type = substr($tm->d901->sa,0,1);
			}

			if (isset($tm->d901->sb))
			{
				$this->setBibLevel((string)$tm->d901->sb);
				$sf_actions[] = 'biblevel: ['.(string)$tm->d901->sb.']';
				$leader->biblevel = (string)$tm->d901->sb;
			}

			if (isset($tm->d901->sc))
			{
				$this->setBibTypeFirst((string)$tm->d901->sc);
				$sf_actions[] = 'bibtype_first: ['.(string)$tm->d901->sc.']';
			}

			if (isset($tm->d901->se))
			{
				$this->setCatalogationLevel((string)$tm->d901->se);
				$sf_actions[] = 'catalog_level: ['.(string)$tm->d901->se.']';
			}

			if (isset($tm->d901->sg))
			{
				$this->setRating((string)$tm->d901->sg);
				$sf_actions[] = 'target: ['.(string)$tm->d901->sg.']';
			}

			if (isset($tm->d901->sl))
			{
				$this->setLoanableSince((string)$tm->d901->sl);
				$sf_actions[] = 'loanable_since: ['.(string)$tm->d901->sl.']';
			}

			$actionLog[] = array('901',0,true,"Recuperate informazioni codificate ClavisNG (901):\n{info}",
				array('info' => implode("\n",$sf_actions)));
		}

		$actionLog[] = array('l',0,false,"Livello bibliografico impostato a [{biblevel}]; tipo impostato a [{bibtype}]",
			array('biblevel' => $leader->biblevel, 'bibtype' => $leader->type));

		if (isset($tm->d010))
			$this->setIsbnissn((string)$tm->d010->sa);

		if (isset($tm->d011))
			$this->setIsbnissn((string)$tm->d011->sa);

		if (isset($tm->d012))
			foreach ($tm->d012 as $fingerprint)
			{
				if (!isset($fingerprint->ss))
					$fingerprint->addSubField('s',substr($fingerprint->sa,0,4));
				if (!isset($fingerprint->st))
					$fingerprint->addSubField('t',substr($fingerprint->sa,5,4));
				if (!isset($fingerprint->su))
					$fingerprint->addSubField('u',substr($fingerprint->sa,10,4));
				if (!isset($fingerprint->sv))
					$fingerprint->addSubField('v',substr($fingerprint->sa,15,4));
				if (!isset($fingerprint->sw))
					$fingerprint->addSubField('w',substr($fingerprint->sa,20,12));
			}

		if (isset($tm->d035))
		{
			$this->setBid((string)$tm->d035->sa);
			$this->setBidSource((string)$tm->d035->s9);
			$actionLog[] = array('035',0,false,"Sorgente import [{source} - {bid}]",
				array('source' => (string)$tm->d035->s9, 'bid' => (string)$tm->d035->sa));
		}

		if (isset($tm->d073)) {
			$this->setEan((string)$tm->d073->sa);
			$actionLog[] = array('073',0,true,"EAN [{ean}]",
				array('ean' => (string)$tm->d073->sa));
		}

		if (isset($tm->d100))
			$this->setEditionDate(intval($tm->d100->getCDF('a',9)));

		if (isset($tm->d101))
		{
			foreach ($tm->d101->children() as $sf)
				if ((string)$sf != '')
				{
					$this->setEditionLanguage((string)$sf);

					break;
				}
		}

		$this->syncTitle();
		$this->setPublisher(isset($tm->d210) ? (string)$tm->d210->sc : '');
		$this->setAuthor($tm->getAuthor());

		if (!$dummy)
			$this->save();

		$bid_source = $this->getBidSource();
		$sbid = 's'.strtolower($bid_source);

		// build unimarc and resave
		// skip autogenerated fields and item notes
		$skip_fields = array('001','005','035','316','317','318','398','399');

		$uni = TurboMarc::createRecord();

		foreach ($tm->children() as $field)
		{
			/* @var $field TurboMarc */
			$fnum = $field->getTag();

			if ($fnum == '330' && isset($uni->d330))
			{
				// for multiple 330, join them in a single entry
				$uni->d330->sa .= "\n".(string)$field->sa;
				$actionLog[] = array($fnum,0,false,"Abstract aggiunto: [{field}]",array('field' => htmlspecialchars($field->getTXT())));
			}
			elseif ($fnum > 0 &&
					($fnum < 400 || ($fnum > 500 && $fnum < 600) || ($fnum > 920 && $fnum < 930) || '801'==$fnum) &&
					!in_array($fnum,$skip_fields))
			{
				$uni->appendNode($field);
				$actionLog[] = array($fnum,0,false,"Campo importato: [{field}]",array('field' => htmlspecialchars($field->getTXT())));
			}
			elseif ('856' == $fnum)
			{
				if (!trim($field['i1']))
					$field['i1'] = 4;
				$uni->appendNode($field);
				$actionLog[] = array($fnum,0,false,"Campo importato: [{field}]", array('field' => htmlspecialchars($field->getTXT())));
			}
		}

		$uni->setLeader($leader);
		$actionLog[] = array('l',0,false,"Leader importato: [{field}]",array('field' => $leader->getLeader()));
		$uni->setControlField('001',$this->getManifestationId());
		$actionLog[] = array('001',0,false,"Campo generato: [{field}]",array('field' => $uni->c001->getTXT()));
		$uni->setControlField('005',date('Ymdhms.0'));
		$actionLog[] = array('005',0,false,"Campo generato: [{field}]",array('field' => $uni->c005->getTXT()));
		$this->setUnimarc(TurboMarcUtility::sortFields($uni,true));

		$pending4xx = array();
		// manifestation links
		for ($i=400; $i<500; ++$i)
		{
			$xmlTag = "d{$i}";
			$idx = -1;

			foreach ($tm->$xmlTag as $thisLinkFld)
			{
				++$idx;
				// process link: firstly try to find manifestation by bid
				$lman = null;

				if ($bid_source && isset($thisLinkFld->$sbid))
					$lman = ManifestationQuery::create()
						->filterByBidSource($bid_source)
						->findOneByBid((string)$thisLinkFld->$sbid);
				elseif (isset($thisLinkFld->s3))
					$lman = ManifestationQuery::create()->findPk((string)$thisLinkFld->s3);
				elseif (isset($thisLinkFld->st))
					// search by title
					$lman = ManifestationQuery::create()->findOneByTitle(array((string)$thisLinkFld->st));
				else
					// we don't have title nor bid, so skip this one
					continue;

				if (! $lman instanceof Manifestation)
				{
					$title = (string)$thisLinkFld->st;

					foreach ($thisLinkFld->sb as $v)
						$title .= " [$v]";

					foreach ($thisLinkFld->sl as $v)
						$title .= " = $v";

					foreach ($thisLinkFld->sf as $v)
						$title .= " / $v";

					foreach ($thisLinkFld->sg as $v)
						$title .= " ; $v";

					foreach ($thisLinkFld->sh as $v)
						$title .= " . $v";

					foreach ($thisLinkFld->si as $v)
						$title .= ", $v";

					foreach ($thisLinkFld->se as $v)
						$title .= ". - $v";

					foreach ($thisLinkFld->sd as $v)
						$title .= ", $v";

					foreach ($thisLinkFld->sc as $v)
						$title .= " ($v)";

					foreach ($thisLinkFld->sn as $v)
						$title .= " : $v";

					foreach ($thisLinkFld->sp as $v)
						$title .= ". - $v";

					foreach ($thisLinkFld->so as $v)
						$title .= ". - $v";

					foreach ($thisLinkFld->ss as $v)
						$title .= " / $v";

					foreach ($thisLinkFld->sv as $v)
						$title .= " - $v";

					foreach ($thisLinkFld->s9 as $v)
						$title .= " // $v";

					$actionLog[] = array($i,$idx,true,"Notizia [{manifestation}] NON trovata, verrà aggiunta all'elenco \"legami non importati\"",
						array('manifestation' => htmlspecialchars($title)));

					$pending4xx[] = array(	'link' => $i,
											'bid_source' => $bid_source,
											'bid' => (string)$thisLinkFld->$sbid,
											'title' => htmlspecialchars($title) );

					if ($dummy)	continue;
				}
				else
				{
					$actionLog[] = array($i,$idx,true,"Notizia [{manifestation}] trovata con ID [{manid}].",
						array('manifestation' => htmlspecialchars($lman->getTitle()), 'manid' => $lman->getManifestationId()));

					if ($dummy)
						continue;

					try
					{
						$ltype = $i;
						$seq = trim((string)$thisLinkFld->sv);
						if (!$seq && isset($uni->d225))
							$seq = (string)$uni->d225->sv;

						$l = LManifestationQuery::create()->findPk(array($this->getManifestationId(),$lman->getManifestationId()));

						if (!$l instanceof LManifestation)
						{
							// try inverted
							$l = LManifestationQuery::create()->findPk(array($lman->getManifestationId(),$this->getManifestationId()));

							if ($l instanceof LManifestation)
							{
								// invert link (special handling for 410)
								if ('410' != $ltype || $this->getBibLevel() == ManifestationPeer::LVL_COLLECTION)
									$ltype = TurboMarcMappings::$reverseLinkType[$i];
							}
							else
							{
								// create
								$l = new LManifestation();
								$l->setManifestationIdUp($this->getManifestationId());
								$l->setManifestationIdDown($lman->getManifestationId());
							}
						}

						$l->setLinkType($ltype);

						if ($seq)
							$l->setLinkSequence($seq);

						if (isset($thisLinkFld->sn))
							$l->setLinkNote((string)$thisLinkFld->sn);

						if (isset($thisLinkFld->si))
							$l->setIssueId((string)$thisLinkFld->si);

						if (isset($thisLinkFld->sdiff) && TurboMarcUtility::FIELDS_TM1ONLY != $thisLinkFld->sdiff)
							$l->setSourceSync(LAuthorityPeer::SRCSYNC_TRUE);
						else
							$l->setSourceSync(LAuthorityPeer::SRCSYNC_FALSE);

						$l->save();
					}
					catch (PropelException $e)
					{
						// duplicate, skip
					}
				}
			}
		}

		if (!$dummy)
		{
			$this->syncTitle();
			$this->save();
			$this->invalidateCache();
		}

		if (count($pending4xx))
		{
			$mid = $this->getManifestationId();
			$linkbucket[$mid] = array('id'	=> $mid, 'links' => $pending4xx);
		}

		// authority links
		$f792 = isset($tm->d792) ? (string)$tm->d792->sa : '';
		$f793 = isset($tm->d793) ? (string)$tm->d793->sa : '';

		$linkFields = array(	'500',	// link to work
								'600','601','602','603','604','605','606','607','608','609','610','699',	// link to subjects/term
								'616',	// printers device as subject
								'620',	// place
								'676', '680', '686',	// class
								'700', '701', '702',	// personalname
								'710', '711', '712',	// corporatebodyname
								'716',	// printersdevice
								'720', '721', '722',	// familyname
								'792', '793',
								'921',	// printersdevice
								'931',	// subject-term
							);

		$skip_relatorcodes = array('320','390');

		foreach ($linkFields as $i)
		{
			$xmlTag = "d{$i}";
			$idx = -1;

			foreach ($tm->$xmlTag as $authLinkFld)
			{
				if (isset($authLinkFld->s4) && in_array((string)$authLinkFld->s4,$skip_relatorcodes))
					continue;

				++$idx;
				$auth = AuthorityPeer::getLinkedAuthority($i,$authLinkFld,$bid_source,true,$dummy);

				if (!$auth instanceof Authority && $dummy)
				{
					$actionLog[] = array($i,$idx,true,$auth[0],$auth[1]);

					continue;
				}

				$rc = isset($authLinkFld->s4)
					? str_pad((string)$authLinkFld->s4,3,'0',STR_PAD_LEFT) : '000';

				$lt = $i;

				if ('7' == $lt[0])
					$lt = $lt[0].'0'.$lt[2];

				$l = LAuthorityManifestationQuery::create()
						->findPk(array(	$auth->getAuthorityId(),
										$this->manifestation_id,$lt,$rc ));

				if (!$l instanceof LAuthorityManifestation)
					if ('000' == $rc)
						$l = LAuthorityManifestationQuery::create()
								->filterByAuthority($auth)
								->filterByManifestation($this)
								->filterByLinkType($lt)
								->findOne();
					else
						$l = LAuthorityManifestationQuery::create()->findPk(array(
							$auth->getAuthorityId(), $this->manifestation_id, $lt, '000'));

				if (!$l instanceof LAuthorityManifestation)
				{
					$l = new LAuthorityManifestation();
					$l->setManifestation($this)
						->setAuthority($auth)
						->setLinkType($i)
						->setRelatorCode($rc);
				}

				if (isset($authLinkFld->sn))
					$l->setLinkNote((string)$authLinkFld->sn);

				if (isset($authLinkFld->sdiff) && TurboMarcUtility::FIELDS_TM1ONLY != $authLinkFld->sdiff)
					$l->setSourceSync(LAuthorityPeer::SRCSYNC_TRUE);
				else
					$l->setSourceSync(LAuthorityPeer::SRCSYNC_FALSE);

				// special types management
				if ($i >= 676 & $i < 700)
				{	// classification
					$l->setLinkType('676');
				}
				elseif ($i >= 700 & $i < 722)
				{	// authors
					$lt = $i;
					// reduce to common linktype.

					while ($lt >= 710 && $lt <= 722)
						$lt -= 10;

					$l->setLinkType($lt);
				}

				if ($auth && $l)
				{
					$actionLog[] = array($i,$idx,true,"Authority [{auth}] TROVATA con ID [{authId}].",
						array(	'authId' => $auth->getAuthorityId(),
								'auth' => htmlspecialchars($auth->getFullText()) ));

					if ($dummy)
						continue;

					try
					{
						if ($f792 && $auth->getFullText() == $f792)
							$l->setLinkType(620);
						elseif ($f793 && $auth->getFullText() == $f793)
							$l->setRelatorCode(650);

						$l->save();
					}
					catch (PropelException $e)
					{
						// duplicate entry, update existing one
						$upl = LAuthorityManifestationQuery::create()
									->findPk($l->getPrimaryKey());

						$upl->setLinkSequence($l->getLinkSequence())
								->setSourceSync($l->getSourceSync())
								->setLinkNote($l->getLinkNote());

						$upl->save();
					}
				}
			}
		}

		// custom links (issue, item, attachment, etc.)
		// item notes
		$idx = -1;
		foreach (ManifestationPeer::$item_note_types as $fldnum)
		{
			$tag = "d{$fldnum}";

			foreach ($tm->$tag as $in)
			{
				++$idx;
				$actionLog[] = array(	$fldnum,
										$idx,
										true,
										"Nota esemplare {num} [{note}] creata",

										array(	'num' => $fldnum,
												'note' => (string)$in->sa ) );

				if ($dummy)
					continue;

				$i = ItemNoteQuery::create()
						->filterByNoteType($fldnum)
						->filterByItemId((string)$in->s5)
						->filterByNote((string)$in->sa)
						->findOneOrCreate();

				if ($i->isNew())
					$i->save();
			}
		}

		// issues
		foreach ($tm->d940 as $idx => $issue)
		{
			$actionLog[] = array(	'940',
									$idx,
									true,
									"Fascicolo [{number}] creato",

									array('number' => (string)$issue->sn) );

			if ($dummy)
				continue;

			$i = new Issue();
			$i->setManifestation($this);
			$i->setStartNumber((string)$issue->ss);
			$i->setEndNumber((string)$issue->se);
			$i->setIssueYear((string)$issue->sy);
			$i->setIssueNumber((string)$issue->sn);
			$i->save();
		}

		foreach ($tm->d955 as $idx => $attach)
		{
			// manage attachment creation
			$actionLog[] = array(	'955',
									$idx,
									true,
									"Nuovo allegato [{name}] creato",

									array('name' => (string)$attach->sd) );

			if ($dummy)
				continue;

			try
			{
				$tmpfname = tempnam('/tmp','clavis');
				if (copy((string)$attach->sd,$tmpfname))
				{
					$a = new Attachment();
					$a->setAttachmentType((string)$attach->sa)
							->setFileSize(filesize($tmpfname))
							->setObjectType('manifestation')
							->setObjectId($this->geManifestationId())
							->setFileLabel((string)$attach->sl)
							->setFileDescription((string)$attach->sn)
							->setLicense((string)$attach->sf)
							->storeFile($tmpfname, (string)$attach->se);

					unlink($tmpfname);
				}
			}
			catch (Exception $e)
			{
				unlink($tmpfname);
				Prado::log(__CLASS__.'::'.__FUNCTION__.' errore di inserimento: '.$e->getMessage());
			}
		}

		foreach ($tm->d907 as $shelf)
		{
			$s = isset($shelf->s3)
					? ShelfQuery::create()
						->findPk((string)$shelf->s3)
					: ShelfQuery::create()
						->filterByShelfName((string)$shelf->sa)
						->filterByLibrarianId((string)$shelf->se)
						->filterByLibraryId((string)$shelf->sf)
						->findOne();

			if (!$s instanceof Shelf)
			{
				// create it
				$s = new Shelf();
				$s->setShelfName((string)$shelf->sa);
				$s->setShelfDescription((string)$shelf->sb);
				$s->setShelfStatus((string)$shelf->sc);
				$s->setLibrarianId((string)$shelf->se);
				$s->setLibraryId((string)$shelf->sf);
				$s->save();
			}

			$si = new ShelfItem();
			$si->setObjectId($this->getManifestationId());
			$si->setObjectClass(ShelfPeer::TYPE_MANIFESTATION);
			$si->setShelf($s);
			$si->save();

			ShelfPeer::checkShelfItemTypes($s, true);
		}

		if ($dummy)
			return $actionLog;
		else
			// do you want to take some action with our action log?
			return $this;
	}

	/**
	 * Duplicates a manifestation resetting all sensible turbomarc fields and copying only authority links.
	 *
	 * @param int $librarianId
	 * @return Manifestation
	 */
	public function duplicate($librarianId = 0)
	{
		$new = $this->copy();
		$new->setCatalogationLevel('05');
		$new->setManifestationStatus(ManifestationPeer::STATUS_DUP);
		$new->setBid(null);
		$new->setBidSource(null);
		$new->setLastSbnSync(null);
		$new->setDateCreated(new DateTime());
		$new->setDateUpdated(new DateTime());

		if ($librarianId)
		{
			$new->setCreatedBy($librarianId);
			$new->setModifiedBy($librarianId);
		}

		$tm = $new->getTurboMarc();
		// remove SBN specific fields on duplication

		unset($tm->d035);
		unset($tm->d099);

		$new->setUnimarc($tm->asXML());
		$new->save();

		ChangelogPeer::logAction(	$new,
									ChangelogPeer::LOG_CREATE,
									$librarianId,
									'duplicazione manifestation: SOURCE['.$this->manifestation_id.'] TARGET['.$new->getManifestationId().']');

		$l_authority_manifs = LAuthorityManifestationQuery::create()
								->findByManifestationId($this->manifestation_id);

		/* @var $link LAuthorityManifestation */
		foreach ($l_authority_manifs as $link)
		{
			try
			{
				$linkCopy = $link->copy(false);
				$linkCopy->setAuthorityId($link->getAuthorityId());
				$linkCopy->setManifestationId($new->getManifestationId());
				$linkCopy->setLinkType($link->getLinkType());
				$linkCopy->setRelatorCode($link->getRelatorCode());
				$linkCopy->save();
			}
			catch (PropelException $e)
			{
				// do nothing on duplicate
			}
		}

		// index new manifestation
		$new->doIndex();

		return $new;
	}

	/**
	 * It reinitializes a property in case we want to reset
	 * the item collection which is returned after a search
	 * with criteria.
	 *
	 */
	public function forceReloadItems()
	{
		$this->collItems = null;
	}

	/**
	 * It returns the complete title of this manifestation.
	 *
	 * @param $separator string The separator between title and publisher.
	 * @return string
	 */
	public function getCompleteTitle($separator = '<br />')
	{
		return htmlentities($this->getTitle(), ENT_QUOTES, 'UTF-8')
				. $separator
				. htmlentities($this->getPublisher(), ENT_QUOTES, 'UTF-8');
	}

	public function getTrimmedTitle(	$count = null,
										$separator = '<br />')
	{
		$title = $this->getTitle();

		if (!is_null($count))
		{
			if (strlen($title) > $count)
				$title = mb_substr($title, 0, $count, 'utf8') . '...';
		}

		if ($separator !== false)
			return $title . $separator . $this->getPublisher();
		else
			return $title;
	}

	public function getShortTitle($trunc = null)
	{
		$title = $this->getTitle();
		$length = strpos($title, ' /');
		$shorttitle = ($length === false) ? $title : substr($title, 0, $length);

		if ($trunc && strlen($shorttitle) > $trunc)
			$shorttitle = substr($title, 0, $trunc - 4) . ' ...';

		$author = ($this->getAuthor())
					? Prado::localize(' <em>di {author}</em>', array('author' => $this->getAuthor()))
					: '';

		return $shorttitle . $author;
	}

	public function isLoanableByMyLibrary($myLibraryId = null)
	{
		if ($myLibraryId == null)
			$myLibraryId = Prado::getApplication()->getUser()->getActualLibraryId();

		$itemCount = ItemQuery::create()
						->filterByManifestationId($this->manifestation_id)
						->filterByActualLibraryId($myLibraryId)
						->filterByLoanClass(ItemPeer::getLoanClassesAvailable())
						->filterByLoanStatus(ItemPeer::getLoanStatusAvailable())
						->count();

		return ($itemCount > 0);
	}

	public function isLoanableByAll()
	{
		$itemCount = ItemQuery::create()
						->filterByManifestationId($this->manifestation_id)
						->filterByLoanClass(ItemPeer::getLoanClassesAvailable())
						->filterByLoanStatus(ItemPeer::getLoanStatusAvailable())
						->count();

		return ($itemCount > 0);
	}

	public function getShelfDescription()
	{
		$completeTitle = $this->getTrimmedTitle(80);

		return ($completeTitle !== '')
					? $this->getShelfDescriptionLabel() . $completeTitle
					: '';
	}

	public function getShelfDescriptionLabel()
	{
		return Prado::localize('titolo') . ': ';
	}

	public function getShelfDescriptionText()
	{
		return $this->getTrimmedTitle(80);
	}

	/**
	 * It returns the Portlet.Page which will be used in the
	 * url of the grid row, to hyper-transport ourselves to the
	 * right visualization page of the object.
	 *
	 * @return string
	 */
	public function getShelfUrl()
	{
		return 'Catalog.Record&manifestationId=';
	}

	public function getNavigateUrl($param = null)
	{
		return ManifestationPeer::getNavigateUrl($param);
	}

	public function getObjectTypeString()
	{
		return Prado::localize('notizia');
	}

	public function getEnsuredEan()
	{
		$ean = trim($this->getEan());
		if ($ean == "")
		{
			$isbn = trim($this->getIsbnissn());
			if ($isbn != "")
				$ean = Clavis::IsbnToEan13($isbn);
		}

		return $ean;
	}

	/**
	 * Returns if the manifestation has at least an attachment of type 'cover'.
	 *
	 * @param string $coverserver
	 * @return bool True if there's an attachment of type 'cover', false elsewhere.
	 */
	public function hasCoverImage($coverserver = null)
	{
		$c = AttachmentQuery::create()
				->filterByAttachmentType(AttachmentPeer::TYPE_COVER)
				->filterByObjectType('Manifestation')
				->filterByObjectId($this->manifestation_id)
				->count();

		if ($c > 0)
			return true;

		// if there isn't a cover, search coverserver, if specified
		if ($coverserver)
		{
			$ean = $this->getEnsuredEan();
			$ean = urlencode($ean);
			$key = 'c24160fecc46e71ece61914511fc044f9dee40ac';
			if ($ean && file_get_contents("{$coverserver}/getcover.php?key={$key}&ean={$ean}&act=check") == 'OK')
				return true;
		}

		return false;
	}

	/**
	 * Checks if the manifestation can have items attached.
	 *
	 * @return boolean true if manifestation can have items, false elsewhere.
	 */
	public function canHaveItems()
	{
		return ManifestationPeer::canHaveItems(	$this->bib_level,
													$this->hierarchical_level );
	}

	public function getCDFs()
	{
		$this->getTurboMarc();
		$cdflist = array();

		// generic CDFs starts from 103
		// (100-102 are mandatory and managed in other sections)
		for ($fld = 103; $fld <= 199; ++$fld)
		{
			$field = 'd' . $fld;

			if (isset($this->_tmarc->$field))
				foreach ($this->_tmarc->$field as $f)
					$cdflist[] = array(	'fieldnum' => $fld,
										'fieldlabel' => UnimarcLabelsPeer::getFieldLabel($fld),
										'subfields' => $f->getCDFArray() );
		}

		return $cdflist;
	}

	public function getYear()
	{
		$this->getTurboMarc();
		$year = array();

		if (isset($this->_tmarc->d100))
		{
			$yearFld = $this->_tmarc->d100;
			$year['type'] = $yearFld->getCDF('a', 8);
			$year1 = trim($yearFld->getCDF('a', 9));
			$year2 = trim($yearFld->getCDF('a', 13));

			switch ($year['type'])
			{
				case 'j':
				case 'z':
					$year['date'] = $year1 . '-' . substr($year2, 0, 2) . '-' . substr($year2, 2, 2);

					break;

				default:
					if ($year1)
					{
						$year['date'] = $year1;

						if ($year2)
							$year['date'] .= '-' . $year2;
					}
					else
					{
						$year = array();
					}

					break;
			}
		}

		return $year;
	}

	public function getLanguages()
	{
		$this->getTurboMarc();
		$lang = array();

		if (isset($this->_tmarc->d101))
			foreach ($this->_tmarc->d101->children() as $sf)
				$lang[] = (string) $sf;

		return $lang;
	}

	public function getTarget()
	{
		$this->getTurboMarc();
		$target = '';

		if (isset($this->_tmarc->d100)) {
			$fld = $this->_tmarc->d100;
			$target = $fld->getCDF('a', 17) . '-' .
				$fld->getCDF('a', 18) . '-' .
				$fld->getCDF('a', 19);
		}

		return $target;
	}

	/**
	 * @return Array
	 */
	public function getAreas()
	{
		$this->getTurboMarc();
		$areas = array();
		if (isset($this->_tmarc->d206))
			foreach ($this->_tmarc->d206 as $fld)
				$areas[] = array(	'field' => 206,
									'value' => (string) $fld->sa );

		if (isset($this->_tmarc->d207))
			foreach ($this->_tmarc->d207 as $fld)
				$areas[] = array(	'field' => 207,
									'value' => (string) $fld->sa );

		if (isset($this->_tmarc->d208))
			foreach ($this->_tmarc->d208 as $fld)
				$areas[] = array(	'field' => 208,
									'value' => (string) $fld->sa );

		if (isset($this->_tmarc->d230))
			foreach ($this->_tmarc->d230 as $fld)
				$areas[] = array(	'field' => 230,
									'value' => (string) $fld->sa );

		return $areas;
	}

	public function getProperTitle()
	{
		$this->getTurboMarc();

		return (string) $this->_tmarc->d200->sa;
	}

	public function getAltTitles()
	{
		$this->getTurboMarc();
		$alttitles = array();

		for ($field = 501; $field < 600; ++$field)
		{
			$xmlTag = "d{$field}";

			if (isset($this->_tmarc->$xmlTag))
				foreach ($this->_tmarc->$xmlTag as $fld)
					$alttitles[] = array(	'field' => $field,
											'value' => (string) $fld->sa );
		}

		return $alttitles;
	}

	/**
	 * Returns the manifestation abstract, if any.
	 *
	 * @return string The manifestation abstract.
	 */
	public function getAbstract()
	{
		$this->getTurboMarc();

		return (isset($this->_tmarc->d330)) ?
			(string) $this->_tmarc->d330->sa : '';
	}

	/**
	 * Returns all manifestation's 3XX notes as array elements.
	 * Each element has 'code' and 'text' keys.
	 *
	 * @return array The 3XX notes' array.
	 */
	public function getNotes()
	{
		$this->getTurboMarc();
		$notes = array();

		for ($fld = 300; $fld < 400; ++$fld)
		{
			if ($fld == 330)
				continue;

			$xmlTag = "d{$fld}";

			if (isset($this->_tmarc->$xmlTag))
				foreach ($this->_tmarc->$xmlTag as $n)
				{
					$note['code'] = $fld;
					$note['text'] = (string) $n->sa;
					$notes[] = $note;
				}
		}

        $sbnNotes = $this->getSBNNotes();

		return array_merge($notes,$sbnNotes);
	}


    /**
     * Returns all Notes related to SBN and structured:
     */

    public function getSBNNotes()
    {
        $sbnNotes = array();

        foreach(array("d922",'d923','d926','d927','d928') as $n)
            if(isset($this->_tmarc->$n))
                foreach($this->_tmarc->$n as $nsbn)
                {
                    $noteText = "";
                    foreach($nsbn->children() as $nc)
                        if(trim((string)$nc) != '')
                            $noteText .= "<[" . substr($nc->getName(),1) ."] " . $nc['l'] .">\n:" .(string)$nc ."\n";

                    $sbnNotes[] = array(
                        'code'=>intval(substr($n,1)),
                        'text'=>trim($noteText)
                    );
                }

        if(isset($this->_tmarc->d926))
        {

        }

        if(isset($this->_tmarc->d927))
        {

        }
        return $sbnNotes;
    }


	/**
	 * Returns the first 676 link, if there's any.
	 *
	 * @return int The class code if link exists, null elsewhere.
	 */
	public function getClass()
	{
		$class = AuthorityQuery::create()
					->filterByAuthorityType(AuthorityPeer::TYPE_CLASS)
					->useLAuthorityManifestationQuery()
					->filterByManifestationId($this->manifestation_id)
					->filterByLinkType(676)
					->endUse()
					->findOne();

		return ($class instanceof Authority)
					? $class->getClassCode()
					: null;
	}

	public function getBibType()
	{
		$bt = trim(parent::getBibType());

		return (!$bt || $bt == '-1')
					? 'a01'
					: $bt;
	}

	/**
	 * Returns a human-readable label for bibliographic type.
	 *
	 * @return string The human-readable bibtype.
	 */
	public function getBibTypeLabel()
	{
		require_once('clavis/LookupValuePeer.php');

		$map = array(	'a' => 1,
						'b' => 2,
						'c' => 1,
						'd' => 2,
						'e' => 1,

						'f' => 2,
						'g' => 3,
						'i' => 5,
						'j' => 4,
						'k' => 6,

						'l' => 7,
						'm' => 9,
						'r' => 8 );

		$bt = $this->getBibType();

		return ($bt && array_key_exists($bt,$map))
					? LookupValuePeer::getLookupValue('OGGBIBL_' . $map[$bt{0}], $bt)
					: '';
	}

	/**
	 * Returns a human-readable label for bibliographic level.
	 *
	 * @return string The human-readable biblevel.
	 */
	public function getBibLevelLabel()
	{
		require_once('clavis/LookupValuePeer.php');

		return LookupValuePeer::getLookupValue('LIVBIBL', $this->getBibLevel());
	}

	/**
	 * Returns the shelves the object is contained in (or not in).
	 *
	 * @param ClavisLibrarian $user
	 * @param ShelfQuery $baseQuery
	 * @param int $limit
	 * @param int $offset
	 * @param bool $except If true, returns all shelves the object is NOT contained in.
	 * @return array|int|mixed|PropelObjectCollection
	 */
	public function getShelvesIn(	ClavisLibrarian $user,
									ShelfQuery $baseQuery,
									$limit=null,
									$offset=null,
									$except = false )
	{
		if (!$baseQuery)
			$baseQuery = ShelfQuery::create();

		if ($except)
			$sideQuery = clone $baseQuery;

		$baseQuery->useShelfItemQuery()
						->filterByObjectClass(ShelfPeer::TYPE_MANIFESTATION)
						->filterByObjectId($this->manifestation_id)
						->endUse();

		if ($except)
		{
			$shelvesIds = array_keys(ShelfPeer::getVisibleShelvesArray(	$user,
																			null,
																			null,
																			null,
																			$baseQuery ));

			$sideQuery->filterByShelfId(	$shelvesIds,
											Criteria::NOT_IN );

			$shelves = ShelfPeer::getVisibleShelves(	$user,
														null,
														$limit,
														$offset,
														$baseQuery );
		}
		else
		{
			$shelves = ShelfPeer::getVisibleShelves(	$user,
														null,
														$limit,
														$offset,
														$baseQuery);
		}

		return $shelves;
	}

	public function syncTitle($parent_title = '')
	{
		$tm = $this->getTurboMarc();
		$title = $tm->getTitle();
		$fulltitle = $tm->getFullTitle();

		if ($title['ind'][0] == '0')
		{	// not standalone title, search & prepend parent's
			if ($parent_title)
			{
				$fulltitle = $parent_title.' - '.$fulltitle;
			}
			else
			{
				// upper/lower
				$upper = LManifestationQuery::create()
							->condition('up1','LManifestation.ManifestationIdUp = ?',$this->manifestation_id)
							->condition('up2','LManifestation.LinkType = ?',461)
							->combine(array('up1','up2'), 'and', 'up')
							->condition('down1','LManifestation.ManifestationIdDown = ?',$this->manifestation_id)
							->condition('down2','LManifestation.LinkType = ?',463)
							->combine(array('down1','down2'), 'and', 'down')
							->where(array('down','up'),'or')
							->find();

				if ($upper->count() > 0)
				{
					$parent = ($upper[0]->getLinkType() == 461)
									? $upper[0]->getManifestationRelatedByManifestationIdDown()
									: $upper[0]->getManifestationRelatedByManifestationIdUp();

					if ($parent instanceof Manifestation)
						$fulltitle = $parent->getTitle().' - '.$fulltitle;
				}
			}
		}

		$this->setTitle($fulltitle);
		$this->setNonSortText($title['nst']);
		$this->setSortText(implode('. ',$title['txt']));
	}

	/**
	 * Syncs DB author with link-calculated one.
	 */
	public function syncAuthor()
	{
		$aq = LAuthorityManifestationQuery::create()
				->filterByManifestationId($this->manifestation_id)
				->filterByLinkType(array('700','701','710','711','720','721'))
				->orderByLinkType();

		if ($aq->count() < 0)
		{
			$this->setAuthor(null);

			return;
		}
		else
		{
			$st = array();

			foreach ($aq->find() as $lauthor)
				if (($author = $lauthor->getAuthority()) instanceof Authority)
					$st[] = $author->getCompleteText();

			$this->setAuthor((count($st) > 0)
								? implode(' - ',$st)
								: '');
		}
	}

	/**
	 * Parses turbomarc and decodes encoded entities.
	 */
	public function syncDecodedEntities()
	{
		foreach ($this->_tmarc->children() as $field)
			foreach ($field->children() as $index => $subfield)
				$subfield = html_entity_decode($subfield);

		$this->setUnimarc($this->_tmarc->asXML());
	}

	/**
	 * It replaces all the references to the current manifestation with $dst and deletes this.
	 *
	 * @param Manifestation $dst: destination Manifestation
	 * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
	 * @return boolean (transaction result)
	 * @throws Exception
	 */
	public function replaceWith(	Manifestation $dst,
									$clavisLibrarian = null )
	{
		$arrRowsAffected = array(); //associative array (key: db table, value: num of rows affected by update)
		$dst_id = $dst->getManifestationId();
		if ($this->manifestation_id == $dst_id)
			return false;

		if (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian)
			throw new Exception('Wrong ClavisLibrarian');

		/* @var $_connection Connection */
		$_connection = Propel::getConnection();
		try
		{
			$_connection->beginTransaction();

			//attachment
			$arrRowsAffected['attachment'] = AttachmentQuery::create()
												->filterByObjectType('Manifestation')
												->filterByObjectId($this->manifestation_id)
												->update(array('ObjectId' => $dst_id), $_connection);

			//changelog
                        /*
			$arrRowsAffected['changelog'] = ChangelogQuery::create()
				->filterByObjectClass('Manifestation')
				->filterByObjectId($this->manifestation_id)
				->update(array('ObjectId' => $dst_id),$_connection);*/

			//issue
			$arrRowsAffected['issue'] = IssueQuery::create()
											->filterByManifestationId($this->manifestation_id)
											->update(array('ManifestationId' => $dst_id), $_connection,true);

			//loan
			$arrRowsAffected['loan'] = LoanQuery::create()
											->filterByManifestationId($this->manifestation_id)
											->update(array('ManifestationId' => $dst_id), $_connection);

			//item (update AFTER loan to propagate title update)
			$arrRowsAffected['item'] = 0;
			$destDewey = $dst->getClass();
                        
                        
                        
                        
                        /*
			foreach ($this->getItems() as $item) {
				$item->setManifestationId($dst_id);
				$item->setManifestationDewey($destDewey);
				$item->save();

				ChangelogPeer::logAction(	$item,
											ChangelogPeer::LOG_UPDATE,
											$clavisLibrarian,
											"Modifica item su schiacciamento notizia: OldId={$this->manifestation_id} NewId={$dst_id}");

				++$arrRowsAffected['item'];
                                $item->clearAllReferences(TRUE);
			}*/
                        $query = "update item set manifestation_id={$dst_id},manifestation_dewey='{$destDewey}' where manifestation_id={$this->manifestation_id}";
                        $arrRowsAffected['item'] = $_connection->exec($query);

			//item_request
			$arrRowsAffected['item_request'] = ItemRequestQuery::create()
													->filterByManifestationId($this->manifestation_id)
													->update(array('ManifestationId' => $dst_id), $_connection);

                        //l_authority_manifestation
			$arrRowsAffected['l_authority_manifestation'] = 0;

                        $arrRowsAffected['l_authority_manifestation_deleted'] = 0;
                        /*
			foreach ($this->getLAuthorityManifestations() as $link) {
				// @var $link LAuthorityManifestation 
				$pk = $link->getPrimaryKey();
				$pk[1] = $dst_id;
				$newlink = LAuthorityManifestationQuery::create()
										->filterByPrimaryKey($pk)
										->findOneOrCreate();

				if ($newlink->isNew())
				{
					$newlink->setLinkSequence($link->getLinkSequence());
					$newlink->setLinkNote($link->getLinkNote());
					$newlink->save();
				}
                                $link->clearAllReferences(TRUE);
				$link->delete();
                                
				++$arrRowsAffected['l_authority_manifestation'];
			}
                        */
                        $query = "update ignore l_authority_manifestation set manifestation_id={$dst_id} where manifestation_id={$this->manifestation_id}";
                        $arrRowsAffected['l_authority_manifestation'] = $_connection->exec($query);
                        $query = "delete from l_authority_manifestation where manifestation_id={$this->manifestation_id}";
                        $arrRowsAffected['l_authority_manifestation_deleted'] = $_connection->exec($query);

			//l_manifestation
			$arrRowsAffected['l_manifestation'] = 0;
                        $arrRowsAffected['l_manifestation_deleted'] = 0;
                        /*
			foreach ($this->getLManifestationsRelatedByManifestationIdDown() as $link) {
				// @var $link LManifestation 
				// ensure link is valid
				if ($link->getManifestationRelatedByManifestationIdUp() instanceof Manifestation)
				{
					$pk = $link->getPrimaryKey();
					// substitute ManifestationIdDown with destination id
					// pk is array(ManifestationIdUp,ManifestationIdDown)
					$pk[1] = $dst_id;
					$newlink = LManifestationQuery::create()
									->filterByPrimaryKey($pk)
									->findOneOrCreate();

					if ($newlink->isNew())
					{
						$newlink->setLinkType($link->getLinkType());
						$newlink->setLinkSequence($link->getLinkSequence());
						$newlink->setLinkNote($link->getLinkNote());
						$newlink->setIssueId($link->getIssueId());
						$newlink->save();
					}
				}
                                $link->clearAllReferences(TRUE);
				$link->delete();
                                
				++$arrRowsAffected['l_manifestation'];
			}
			foreach ($this->getLManifestationsRelatedByManifestationIdUp() as $link) {
				// @var $link LManifestation 
				// ensure link is valid
				if ($link->getManifestationRelatedByManifestationIdDown() instanceof Manifestation)
				{
					$pk = $link->getPrimaryKey();
					// substitute ManifestationIdUp with destination id
					// pk is array(ManifestationIdUp,ManifestationIdDown)
					$pk[0] = $dst_id;
					$newlink = LManifestationQuery::create()
								->filterByPrimaryKey($pk)
								->findOneOrCreate();

					if ($newlink->isNew())
					{
						$newlink->setLinkType($link->getLinkType());
						$newlink->setLinkSequence($link->getLinkSequence());
						$newlink->setLinkNote($link->getLinkNote());
						$newlink->setIssueId($link->getIssueId());
						$newlink->save();
					}
				}
                                $link->clearAllReferences(TRUE);
				$link->delete();
                                
				++$arrRowsAffected['l_manifestation'];
			}*/
                        

                        /*
                         * WARNING: old code also clean l_manifestation from ophan rows.
                         * This may be done into cron script.
                         */
                        
                        
                        $query = "update ignore l_manifestation set manifestation_id_down={$dst_id} where manifestation_id_down={$this->manifestation_id}";
                        $arrRowsAffected['l_manifestation'] = $_connection->exec($query);
                        $query = "delete from l_manifestation where manifestation_id_down={$this->manifestation_id}";
                        $arrRowsAffected['l_manifestation_deleted'] = $_connection->exec($query);
                        
                        
                        $query = "update ignore l_manifestation set manifestation_id_up={$dst_id} where manifestation_id_up={$this->manifestation_id}";
                        $arrRowsAffected['l_manifestation'] += $_connection->exec($query);
                        $query = "delete from l_manifestation where manifestation_id_up={$this->manifestation_id}";
                        $arrRowsAffected['l_manifestation_deleted'] += $_connection->exec($query);
                        
                        
                        
                        
                        //shelf_item
			$arrRowsAffected['shelf_item'] = 0;
                        $arrRowsAffected['shelf_item_deleted'] = 0;
                        /*
			$links = ShelfItemQuery::create()
				->filterByObjectClass(ShelfPeer::TYPE_MANIFESTATION)
				->filterByObjectId($this->manifestation_id)
				->find();
			foreach ($links as $link) {
				// @var $link ShelfItem 
				$newlink = ShelfItemQuery::create()
							->filterByPrimaryKey(array(	$link->getShelfId(),
														$dst_id,
														ShelfPeer::TYPE_MANIFESTATION ))
							->findOneOrCreate();

				if ($newlink->isNew())
				{
					$newlink->setItemStatus($link->getItemStatus());
					$newlink->save();
				}

						 *                 $link->clearAllReferences(TRUE);
				$link->delete();
                                
				++$arrRowsAffected['shelf_item'];

			}*/
                        $mClass = ShelfPeer::TYPE_MANIFESTATION;
                        $query = "update ignore shelf_item set object_id={$dst_id} where object_id={$this->manifestation_id} AND object_class='{$mClass}'";
                        $arrRowsAffected['shelf_item'] = $_connection->exec($query);
                        $query = "delete from shelf_item where object_id={$this->manifestation_id}  AND object_class='{$mClass}'";
                        $arrRowsAffected['shelf_item_deleted'] = $_connection->exec($query);
                        
                        
                        //consistency_note
                        $arrRowsAffected['consistency_note'] = ConsistencyNoteQuery::create()
                                ->filterByManifestationId($this->manifestation_id)
                                ->update(array('ManifestationId' => $dst_id),$_connection);
                        
			$this->delete();
			$_connection->commit();

			if (count($arrRowsAffected) >0) {
				$description = "Manifestation {$this->title} con id={$this->manifestation_id}";
				foreach ($arrRowsAffected as $table => $count)
					if ($count > 0)
						$description .= " [$table : $count entry]";
				$description .= " schiacciata su '{$dst->getTrimmedTitle(60, '/')}con id={$dst_id}";
				ChangelogPeer::logAction($dst, ChangelogPeer::LOG_UPDATE, $clavisLibrarian, $description);

			}
		}
		catch (PropelException $e)
		{
			$_connection->rollback();
			Prado::log('Error in '.__CLASS__.'::'.__FUNCTION__.'(): .'.$e);

			return false;
		}

		return true;
	}

	public function calculateHierarchicalLevel()
	{
		$this->getTurboMarc();
		$l = $this->_tmarc->getLeader();
		$foundnotetxt = 'Attenzione: livello superiore con esemplari, risolvere manualmente.';

		foreach ($this->_tmarc->d319 as $note)
			if ($foundnotetxt == (string)$note->sa)
				$note->remove();

		switch ($this->bib_level)
		{
			case ManifestationPeer::LVL_ANALYTIC:
			case ManifestationPeer::LVL_SERIAL:
				$this->setHierarchicalLevel(ManifestationPeer::HIER_LOWER);
				$l->hiercode = '0';

				break;

			case ManifestationPeer::LVL_COLLECTION:
				$this->setHierarchicalLevel(ManifestationPeer::HIER_TOP);
				$l->hiercode = '1';

				break;

			case ManifestationPeer::LVL_MONOGRAPHIC:
			default:
				if ($this->countLManifestationsRelatedByManifestationIdDown() +
						$this->countLManifestationsRelatedByManifestationIdUp() == 0)
				{
						$this->setHierarchicalLevel(ManifestationPeer::HIER_LOWER);
						$l->hiercode = '0';
				}
				else
				{
					$itemcount = $this->countItems();
					$amitop = LManifestationQuery::create()
									->filterByManifestationIdDown($this->manifestation_id)
									->filterByLinkType(461)
									->useManifestationRelatedByManifestationIdUpQuery()
										->filterByBibLevel(ManifestationPeer::LVL_ANALYTIC, Criteria::NOT_EQUAL)
										->filterByBibLevel(ManifestationPeer::LVL_SERIAL, Criteria::NOT_EQUAL)
									->endUse()
									->count() +
								LManifestationQuery::create()
									->filterByManifestationIdUp($this->manifestation_id)
									->filterByLinkType(463)
									->useManifestationRelatedByManifestationIdDownQuery()
										->filterByBibLevel(ManifestationPeer::LVL_ANALYTIC, Criteria::NOT_EQUAL)
										->filterByBibLevel(ManifestationPeer::LVL_SERIAL, Criteria::NOT_EQUAL)
									->endUse()
									->count();

					if ($amitop && !$itemcount)
					{
						$this->setHierarchicalLevel(ManifestationPeer::HIER_TOP);
						$l->hiercode = '1';
					}
					else
					{
						$this->setHierarchicalLevel(ManifestationPeer::HIER_LOWER);
						$l->hiercode = '2';

						if ($amitop)
						{
							// has top links but items too, make a note and save as lower
							$this->setManifestationStatus(ManifestationPeer::STATUS_VERIFY);
							$notefound = false;

							foreach ($this->_tmarc->d319 as $note)
								if ($foundnotetxt == (string)$note->sa)
									$notefound = true;

							if (!$notefound)
								$this->_tmarc->addField('319')->addSubField('a',$foundnotetxt);
						}
					}
				}

				break;
		}

		$this->_tmarc->setLeader($l);
	}
	
	public function setQuick($flag = true)
	{
		$this->setBidSource($flag ? ManifestationPeer::BIDSOURCE_QUICKLABEL : null);
		$this->setBid($this->getManifestationId());
	}
	
	public function getQuickId()
	{
		if ($this->getBidSource() == ManifestationPeer::BIDSOURCE_QUICKLABEL)
			return $this->getBid();
		else
			return null;
	}
	
	public function isQuickEditable()
	{
		return ($this->getBidSource() == ManifestationPeer::BIDSOURCE_QUICKLABEL);
	}
	
} // Manifestation