<?php

require_once 'clavis/om/BaseUnimarcCodesPeer.php';
include_once 'clavis/UnimarcCodes.php';

/**
 * UnimarcCodesPeer class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */

class UnimarcCodesPeer extends BaseUnimarcCodesPeer {

	const FALLBACK_LANGUAGE = 'it_IT';
	
	static public function getGroupLabel($field,$tag,$pos)
	{
		$c = new Criteria();

		$c->add(self::FIELD_NUMBER, $field);
		$c->add(self::SUBFIELD_TAG, $tag);
		$c->add(self::POS, $pos);
		$c->add(self::LANGUAGE, Prado::getApplication()->getGlobalization()->getCulture());
		$c->addGroupByColumn(self::GROUP_LABEL);
		$values = self::doSelect($c);

		/* if not found, try fallback on default language */
		if (count($values) == 0) {
			$c->add(self::LANGUAGE, self::FALLBACK_LANGUAGE);
			$values = self::doSelect($c);
		}
		return count($values) >0 ? $values[0]->getGroupLabel() : '' ;
	}

	static public function getValueLabel($field,$tag,$pos,$value)
	{
		$query = UnimarcCodesQuery::create()
			->filterByFieldNumber($field)
			->filterBySubfieldTag($tag)
			->filterByPos($pos)
			->filterByCodeValue($value)
			->filterByLanguage(Prado::getApplication()->getGlobalization()->getCulture());
		/* if not found, try fallback on default language */
		if ($query->count() < 1)
			$query->filterByLanguage(self::FALLBACK_LANGUAGE);
		$code = $query->findOne();
		return ($code instanceof UnimarcCodes) ? $code->getLabel() : $value;
	}
	
	static public function getValueKeyFromLabel($field,$tag,$pos,$label)
	{
		// don't filter by language, we assume that key-labels are mapped 1-N
		$code = UnimarcCodesQuery::create()
			->filterByFieldNumber($field)
			->filterBySubfieldTag($tag)
			->filterByPos($pos)
			->filterByLabel($label)
			->findOne();
		return ($code instanceof UnimarcCodes) ? $code->getCodeValue() : null;
	}
	
} // UnimarcCodesPeer
