<?php

require_once 'clavis/om/BaseUnimarcCodes.php';

class UnimarcCodes extends BaseUnimarcCodes {

} // UnimarcCodes
