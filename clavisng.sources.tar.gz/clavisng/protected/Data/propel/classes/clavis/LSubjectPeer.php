<?php

require 'clavis/om/BaseLSubjectPeer.php';


class LSubjectPeer extends BaseLSubjectPeer {

	/**
	 * Get a list of connectors based on an optional start string and optional criterions.
	 *
	 * @param string $token The string to use as a base search (if empty, all connectors will be returned).
	 * @param integer $limit The maximum of connectors to return (defaults to 0=unlimited).
	 * @param Array $criterions Optional criterions to further filter the results.
	 * @return Array A list of connectors (strings).
	 */
	public function getConnectors($token='',$limit=0,Array $criterions=array())
	{
		Prado::log(Prado::varDump($token));
		$list = array();
		$c = new Criteria();
		foreach ($criterions as $crit)
			$c->addAnd($crit);
		if ($token)
			$c->add(self::CONNECTOR,$token.'%',Criteria::LIKE);
		if ($limit > 0)
			$c->setLimit($limit);
		$c->setDistinct();
		$c->addAscendingOrderByColumn(self::CONNECTOR);
		$c->clearSelectColumns()->addSelectColumn(self::CONNECTOR);
		$cList = self::doSelectStmt($c);
		return $cList->fetchAll(PDO::FETCH_COLUMN,0);
	}
	
} // LSubjectPeer
