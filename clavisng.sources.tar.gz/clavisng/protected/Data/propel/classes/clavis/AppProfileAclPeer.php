<?php

require_once 'clavis/om/BaseAppProfileAclPeer.php';

include_once 'clavis/AppProfileAcl.php';

class AppProfileAclPeer extends BaseAppProfileAclPeer {

} // AppProfileAclPeer
