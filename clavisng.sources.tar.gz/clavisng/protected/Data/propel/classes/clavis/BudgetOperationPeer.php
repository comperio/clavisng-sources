<?php

require_once 'clavis/om/BaseBudgetOperationPeer.php';
include_once 'clavis/BudgetOperation.php';

class BudgetOperationPeer extends BaseBudgetOperationPeer {

} // BudgetOperationPeer
