<?php
/**
 * ManifestationPeer class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

/**
 * ManifestationPeer class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class ManifestationPeer extends BaseManifestationPeer {

    const HIER_LOWER = 0;
    const HIER_TOP = 1;

    const LVL_ANALYTIC = 'a';
    const LVL_MONOGRAPHIC = 'm';
    const LVL_SERIAL = 's';
    const LVL_COLLECTION = 'c';

    const STATUS_INCOMPLETE = 'A';
    const STATUS_COMPLETE = 'B';
    const STATUS_VERIFY = 'C';
    const STATUS_IMPORT = 'D';
    const STATUS_DUP = 'E';
    const STATUS_WORKING = 'F';
    const STATUS_ERROR = 'X';
	
	const BIDSOURCE_QUICKLABEL = 'Quick';

    static private $_type_to_first = array(
        'a' => 1, 'b' => 2, 'c' => 1, 'd' => 2, 'e' => 1, 'f' => 2, 'g' => 3,
        'i' => 5, 'j' => 4, 'k' => 6, 'l' => 7, 'm' => 9, 'r' => 8);

    static private $_area_map = array(
        '206' => 'Materiale cartografico: dati matematici',
        '207' => 'Numerazione della risorsa in continuazione',
        '208' => 'Musica a stampa',
        '230' => 'Risorsa elettronica');

    //static public $item_note_types = array(316,317,318,398,399);
	static public $item_note_types = array(	ItemNotePeer::NOTETYPE_ITEMRELATED,
											ItemNotePeer::NOTETYPE_POSSESSION,
											ItemNotePeer::NOTETYPE_INTERVENTION,
											ItemNotePeer::NOTETYPE_ITEMOWNER,
											ItemNotePeer::NOTETYPE_OLDSIGNATURE);
	
    /**
     * Returns the correct bib_type_first mapping for bibtype provided.
     *
     * @param string $bibtype The bib_type
     * @return int The corresponding bib_type_first
     */
    public static function Bibtype2Bibtypefirst($bibtype)
    {
        return (array_key_exists($bibtype, self::$_type_to_first)) ?
            self::$_type_to_first[$bibtype] : null;
    }

    public static function getRequestIndex($limitByIndex = 1.0, $limitResults = 300, $orderBy='idx')
    {
        require_once 'clavis/ItemRequestPeer.php';
        require_once 'clavis/ItemPeer.php';

        /* 	SELECT r.manifestation_id,
                count(DISTINCT r.request_id) as rcount,
                count(DISTINCT i.item_id) as icount,
                count(DISTINCT r.request_id) / count(DISTINCT i.item_id) as idx
            FROM item_request r
                JOIN item i ON i.manifestation_id = r.manifestation_id
            WHERE r.request_status = 'A'
            GROUP BY r.manifestation_id
            HAVING idx > 1.0
            ORDER BY idx DESC */
        $con = Propel::getConnection();

        $avail = ItemStatus::getItemStatusOpacVisible();

        $sql = 'SELECT '.ItemRequestPeer::MANIFESTATION_ID.',
				count(DISTINCT '.ItemRequestPeer::REQUEST_ID.') as rcount,
				count(DISTINCT '.ItemPeer::ITEM_ID.') as icount,
				count(DISTINCT '.ItemRequestPeer::REQUEST_ID.') / count(DISTINCT '.ItemPeer::ITEM_ID.') as idx
			FROM '.ItemRequestPeer::TABLE_NAME.'
				JOIN '.ItemPeer::TABLE_NAME.' ON '.ItemPeer::MANIFESTATION_ID.'='.ItemRequestPeer::MANIFESTATION_ID.'
			WHERE '.ItemRequestPeer::REQUEST_STATUS.' = \''.ItemRequestPeer::STATUS_PENDING.'\'
				AND '.ItemPeer::ITEM_STATUS.' IN (\''.implode('\',\'',$avail).'\')
			GROUP BY '.ItemRequestPeer::MANIFESTATION_ID;
        if (floatval($limitByIndex) > 0)
            $sql .= ' HAVING idx > '.floatval($limitByIndex);
        $sql .= ' ORDER BY '.$orderBy.' DESC';
        $sql .= ' LIMIT '.intval($limitResults);

        try {
            $stmt = $con->prepare($sql);
            $stmt->execute();
            $res = array();
            while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
                $m = ManifestationPeer::retrieveByPK($row[0]);
                $res[] = array(
                    'man_id'		=> $m->getManifestationId(),
                    'man_title'		=> $m->getTitle(),
                    'requests'		=> $row[1],
                    'items'			=> $row[2],
                    'index'			=> $row[3],
                    'manifestation'	=> $m,
                );
            }
            $stmt = null;
        } catch (PDOException $e) {
            throw new Exception($e->getMessage());
        }
        return $res;
    }

    /**
     *
     * @param integer $area
     * @return string
     */
    public static function getAreaName($area) {
        return (array_key_exists($area, self::$_area_map)) ?
            self::$_area_map[$area] : '';
    }

    /**
     * Retrieves a manifestation by its bid_source / bid couple.
     *
     * @param string $bid_source
     * @param string $bid
     * @return Manifestation|null
     */
    public static function getOneByBid($bid_source,$bid)
    {
        return ManifestationQuery::create()
            ->filterByBidSource($bid_source)
            ->findOneByBid($bid);
    }

    /**
     * Checks if a manifestation exists with bid_source / bid couple.
     *
     * @param string $bid_source
     * @param string $bid
     * @return int|false
     */
    public static function bidExists($bid_source,$bid)
    {
        $q = ManifestationQuery::create()
            ->filterByBidSource($bid_source)
            ->filterByBid($bid);
        if ($q->count() > 0)
            return $q->select('ManifestationId')->findOne();
        else
            return false;
    }

	/**
	 * Checks if the manifestation can have items attached.
	 *
	 * @param $bib_level
	 * @param $hier_level
	 * @return bool true if manifestation can have items, false elsewhere.
	 */
	public static function canHaveItems($bib_level,$hier_level)
    {
        $level = ($bib_level == ManifestationPeer::LVL_MONOGRAPHIC);
        $hierarchy = ($hier_level == ManifestationPeer::HIER_LOWER);

        return $level && $hierarchy;
    }

	/**
	 * Returns the number of loanable items.
	 *
	 * @param $manifestation_id
	 * @param null $issue_id
	 * @return int
	 */
	public static function countItemsWithLoanClass($manifestation_id,$issue_id=null)
    {
        $q =  ItemQuery::create()
            ->filterByManifestationId($manifestation_id)
            ->filterByLoanClass(array_merge(ItemPeer::getLoanClassesAvailable(),ItemPeer::getLoanClassesLocallyAvailable()));
        if ($issue_id)
            $q->filterByIssueId($issue_id);
        return $q->count();
    }

	/**
	 * Returns the number of loanable items.
	 *
	 * @param $manifestation_id
	 * @param null $issue_id
	 * @return int
	 */
	public static function countAvailableItems($manifestation_id,$issue_id=null)
	{
		$q =  ItemQuery::create()
			->filterByManifestationId($manifestation_id)
			->filterByLoanClass(array_merge(ItemPeer::getLoanClassesAvailable(),ItemPeer::getLoanClassesLocallyAvailable()));
		if ($issue_id)
			$q->filterByIssueId($issue_id);
		return $q->count();
	}

    /**
     * Builds and saves a Manifestation object upon a given TurboMarc record.
     * THIS METHOD DOES NOT INDEX THE RECORD CREATED!!!
     *
     * @param TurboMarc $tm A TurboMarc record
     * @param boolean $dummy If true, manifestation will not be created and the function will return
     *						an array listing all the actions that would be taken (defaults to false)
     * @param array $linkbucket The array to be filled with not imported links.
     * @return Manifestation|Array The manifestation created or actionLog array.
     */
    public static function createFromTurbomarc(TurboMarc $tm, $dummy=false, &$linkbucket=array())
    {
        $man = new Manifestation();
        $man = $man->updateFromTurbomarc($tm,$dummy,$linkbucket);
        if (!$dummy) {
            $man->setManifestationStatus(self::STATUS_IMPORT);
        }
        return $man;
    }

    public static function getNavigateUrl($param = null)
    {
        $param = intval($param);
        $subfix = '';
        if ($param > 0)
            $subfix = $param;

        return 'index.php?page=Catalog.Record&manifestationId=' . $subfix;
    }

    /**
     * Returns the full TurboMarc (i.e. with linked fields) for the record id supplied.
     *
     * @param integer|Manifestation $m
     * @param boolean $asXML
     * @param boolean $getCollection
     * @param boolena $mergeWork Merge work authority inside.
     * @return TurboMarc or string
	 * @throws Exception
     */
    public static function getFullTurboMarc($m, $asXML = true, $getCollection = true, $mergeWork = false)
    {
		$mandb = array();
		if ($m instanceof Manifestation) {
			$manifestationId = $m->getManifestationId();
			$mandb = array('Unimarc'	=> $m->getUnimarc(),
				'BibType'				=> $m->getBibType(),
				'BibLevel'				=> $m->getBibLevel(),
				'Bid'					=> $m->getBid(),
				'BidSource'				=> $m->getBidSource(),
				'BibTypeFirst'			=> $m->getBibTypeFirst(),
				'HierarchicalLevel'		=> $m->getHierarchicalLevel(),
				'CatalogationLevel'		=> $m->getCatalogationLevel(),
				'ManifestationStatus'	=> $m->getManifestationStatus(),
				'Rating'				=> $m->getRating(),
				'LoanableSince'			=> $m->getLoanableSince(),
				'DateUpdated'			=> $m->getDateUpdated(),
				'DateCreated'			=> $m->getDateCreated());
		} else {
			$manifestationId = intval($m);
			$mandb = ManifestationQuery::create()
            	->select(array('Unimarc','BibType','BibLevel','Bid','BidSource','BibTypeFirst',
	            'HierarchicalLevel','CatalogationLevel','ManifestationStatus','Rating',
    	        'LoanableSince','DateUpdated','DateCreated'))
        	    ->findPk($manifestationId);
		}
		if (!$mandb)
			return null;

        $tm = TurboMarc::createRecord(Clavis::html2xmlEntities($mandb['Unimarc']));

        $c001 = $tm->setControlField('001', $manifestationId);
        $c009 = $tm->setControlField('009', $mandb['BibType'].' '.$mandb['BibLevel']);
        $f035 = $tm->addField('035');
        $f035->addSubField('a', $mandb['Bid']);
        $f035->addSubField('9', $mandb['BidSource']);

        // clean link fields, we're going to rebuild them
        for ($i = 400; $i < 999; $i++) {
            if ($i >= 920 && $i <= 930) // SBN Notes for Music
                continue;
            if (501 == $i)
                $i = 600; // leave alone 5xx fields.
            if (801 == $i)
                continue; // leave alone 801
            if (856 == $i)
                continue; // leave alone 856
            $fld = "d{$i}";
            unset($tm->$fld);
        }
        foreach (ManifestationPeer::$item_note_types as $i) {
            $fld = "d{$i}";
            unset($tm->$fld);
        }

        $conn = Propel::getConnection();

		$lmanauth = $conn->query('SELECT * FROM ' . LAuthorityManifestationPeer::TABLE_NAME .
			' JOIN ' . AuthorityPeer::TABLE_NAME . ' ON ' . LAuthorityManifestationPeer::AUTHORITY_ID .
			'=' . AuthorityPeer::AUTHORITY_ID . ' WHERE ' . LAuthorityManifestationPeer::MANIFESTATION_ID .
			'=' . $manifestationId)->fetchAll(PDO::FETCH_ASSOC);

		$litemauth = $conn->query('SELECT ' . LAuthorityItemPeer::TABLE_NAME . '.*,' . AuthorityPeer::TABLE_NAME . '.*' .
			' FROM ' . ItemPeer::TABLE_NAME .
			' JOIN ' . LAuthorityItemPeer::TABLE_NAME . ' ON ' . LAuthorityItemPeer::ITEM_ID . '=' . ItemPeer::ITEM_ID .
			' JOIN ' . AuthorityPeer::TABLE_NAME . ' ON ' . LAuthorityItemPeer::AUTHORITY_ID . '=' . AuthorityPeer::AUTHORITY_ID .
			' WHERE ' . ItemPeer::MANIFESTATION_ID . '=' . $manifestationId)->fetchAll(PDO::FETCH_ASSOC);

		$lauth = array_merge($lmanauth,$litemauth);

        foreach ($lauth as $link) {
            $linkType = $link['link_type'];
            $linkNote = trim($link['link_note']);
			$relatorCode = str_pad($link['relator_code'],3,'0',STR_PAD_LEFT);
            if ($linkType == '620') {
                // Luogo di manifattura
                $f792 = $tm->addField('792');
                $f792->addSubField('a', $link['full_text']);
                $f792->addSubField('3', $link['authority_id']);
            } else if ($relatorCode == '650' || $relatorCode == '610') {
                // Editore stampatore
                $f793 = $tm->addField('793');
                $f793->addSubField('a', $link['full_text']);
                $f793->addSubField('3', $link['authority_id']);
            }

            $useFor = array();
            $f7xx = null;
			$authtm = $link['unimarc'] ? TurboMarc::createRecord($link['unimarc']) : null;
			switch ($link['authority_type']) {
                case AuthorityPeer::TYPE_PRINTERSDEVICE:
					if ($authtm instanceof TurboMarc)
						$tm->appendNode($authtm->d921);
					$f7xx = $tm->d921;
                    break;
                case AuthorityPeer::TYPE_CLASS:
                    try {
						if (isset($authtm->d676)) {
							$ctype = '676';
							$fld = $authtm->d676;
						} else if (isset($authtm->d680)) {
							$ctype = '680';
							$fld = $authtm->d680;
						} else if (isset($authtm->d686)) {
							$ctype = '686';
							$fld = $authtm->d686;
						} else {
							$fld = null;
							$ctype = '676';
						}
						if ($fld) {
                            $f7xx = $tm->addField($ctype);
							foreach ($fld->children() as $sf)
								$f7xx->appendNode($sf);
                        }
                    } catch (Exception $e) {
                        // most likely unserialize failed, so skip Edition and Description
                        Prado::log('Malformed unimarc on authority ' . $link['authority_id']);
                    }
                    break;
                case AuthorityPeer::TYPE_WORK:
                    $f7xx = $tm->addField($linkType);
                    $f7xx['i1'] = ($link['authority_rectype'] == AuthorityPeer::RECTYPE_VARIANT) ? 0 : 1;
                    $f7xx['i2'] = 0;
                    $f7xx->addSubField('a', $link['full_text']);

                    if ($link['authority_lang'])
                        $f7xx->addSubField('m', $link['authority_lang']);

                   foreach($authtm->children() as $ff)
                       if(substr($ff->getName(),0,2) == "d5")
                           $f7xx->addSubField('t', trim((string)$ff->sa));


                   if($mergeWork && ClavisParamQuery::getParam("CLAVISPARAM","SBNActive") != "true" && $linkType == "500")
                   {
                       if(isset($authtm->d340) && !isset($tm->d330))
                           $tm->addField("330")->addSubField("a",(string)$authtm->d340->sa);

                        // Embedding into manifestation TMarc all work linked entities
                        $lwork = $conn->query("SELECT * FROM " . LAuthorityPeer::TABLE_NAME . ', ' . AuthorityPeer::TABLE_NAME .
                            ' WHERE (' . LAuthorityPeer::AUTHORITY_ID_DOWN . '=' . $link['authority_id'] . " AND " .
                            LAuthorityPeer::AUTHORITY_ID_UP . '=' . AuthorityPeer::AUTHORITY_ID .
                            ") OR (" .
                            LAuthorityPeer::AUTHORITY_ID_UP . '=' . $link['authority_id'] ." AND " .
                            LAuthorityPeer::AUTHORITY_ID_DOWN . '=' . AuthorityPeer::AUTHORITY_ID .
                            ") AND " . AuthorityPeer::AUTHORITY_TYPE . "!= 'O'"
                        )->fetchAll(PDO::FETCH_ASSOC);

                        foreach($lwork as $lw) {
                            switch($lw['link_type']) {

                                case "AB": // Main Author
                                case "BA":
                                    $fwork = $tm->addField("700");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("4",$lw['relator_code']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "CD": // Other author
                                case "DC":
                                    $fwork = $tm->addField("701");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("4",$lw['relator_code']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "EF": // Secondary author
                                case "FE":
                                    $fwork = $tm->addField("702");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("4",$lw['relator_code']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "KP":
                                case "PK":
                                case "GH": // Soggetto
                                case "HG":
                                    $fwork = $tm->addField("610");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("2",$lw['subject_class']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "IJ": // Soggetto fiction
                                case "JI":
                                    $fwork = $tm->addField("610");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("2",$lw['subject_class']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "KL": // Classe
                                case "LK":
                                    $fwork = $tm->addField("676");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "MN": // Luogo
                                case "NM":
                                    $fwork = $tm->addField("620");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "OP": // Luogo pubblic
                                case "PO":
                                    $fwork = $tm->addField("620");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "QR": // Serie
                                case "RQ":
                                    $fwork = $tm->addField("410");
                                    $fwork->addSubField("t",$lw['full_text']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                case "11": // Vedi anche
                                    $fwork = $tm->addField("591");
                                    $fwork->addSubField("a",$lw['full_text']);
                                    $fwork->addSubField("3",$lw['authority_id']);
                                    $fwork->addSubField("9",$link['authority_id']);
                                    break;
                                default:
                                    $fwork = null;
                            }

                        }
                    }
                    break;
                case AuthorityPeer::TYPE_SUBJECT:
                    $f7xx = $tm->addField($linkType);
                    $f7xx->addSubField('a', $link['sort_text']);
                    $f7xx->addSubField('2', $link['subject_class']);
                    $f7xx->addSubField('9', LookupValuePeer::getLookupValue('SUBJECTTYPE', $link['subject_class']));
                    break;
                case AuthorityPeer::TYPE_PUBPLACE:
                    try {
                        $f7xx = $tm->addField($linkType);
                        $f7xx->addSubField('d', $link['full_text']);
						if (isset($authtm->d260->sa))
                            $f7xx->addSubField('a', (string)$authtm->d260->sa);
						if (isset($authtm->d260->sc))
							$f7xx->addSubField('b', (string)$authtm->d260->sc);
                    } catch (Exception $e) {
                        // most likely unserialize failed, so skip Edition and Description
                        Prado::log('Malformed unimarc on authority ' . $link['authority_id']);
                    }
                    break;
                case AuthorityPeer::TYPE_FAMILYNAME:
                    if($linkType >= 700)
                        $linkType += 10; // only 10 cause it's cascading on the following 10 (actually makes 20)
                case AuthorityPeer::TYPE_CORPORATEBODYNAME:
                    if($linkType >= 700)
                        $linkType += 10;
                case AuthorityPeer::TYPE_PERSONALNAME:
                    $stmtUseFor = $conn->prepare("
							SELECT a.authority_type,a.*,l.* FROM l_authority l, authority a
							WHERE (l.link_type = '".LAuthorityPeer::VARIANTLINK_DOWN."'
									AND l.authority_id_up = ?
									AND l.authority_id_down=a.authority_id)
								OR
									(l.link_type = '".LAuthorityPeer::VARIANTLINK_UP."'
									AND l.authority_id_down = ?
									AND l.authority_id_up=a.authority_id)");
                    $stmtUseFor->execute(array($link['authority_id'], $link['authority_id']));
                    $useFor = $stmtUseFor->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($useFor as $af) {
                        if (!in_array($af['authority_type'],array(
                            AuthorityPeer::TYPE_FAMILYNAME,
                            AuthorityPeer::TYPE_CORPORATEBODYNAME,
                            AuthorityPeer::TYPE_PERSONALNAME)))
                            continue;
                        $f790 = $tm->addField('790');
                        $f790->addSubField('a', $af['full_text']);
                        $f790->addSubField('3', $af['authority_id']);
                        $f790->addSubField('9', $af['authority_id']);
                        if ($relatorCode)
                            $f790->addSubField('4', $relatorCode);
                    }
					$f7xx = $tm->addField($linkType);
					if (isset($authtm->d200)) {
						$fulltextfield = $authtm->d200;
					} else if (isset($authtm->d210)) {
						$fulltextfield = $authtm->d210;
					} else if (isset($authtm->d220)) {
						$fulltextfield = $authtm->d220;
					} else {
						$fulltextfield = TurboMarc::createRecord(
							TurboMarcUtility::encodeXML('<d200 i1=" " i2=" "><sa>'
								.htmlentities($link['full_text']).'</sa></d200>'));
					}
					foreach ($fulltextfield->children() as $authsf)
						if ('-' != (string)$authsf)	// hack to prevent empty $f
							$f7xx->addSubField($authsf->getTag(), (string)$authsf);
					break;

                default:
                    $f7xx = $tm->addField($linkType);
                    $f7xx->addSubField('a', $link['full_text']);
                    break;
            }
            if ($f7xx instanceof TurboMarc) {
				$f7xx->addSubField('3', $link['authority_id']);
                if ($relatorCode != 0)
                    $f7xx->addSubField('4', $relatorCode);
                if ($linkNote)
                    $f7xx->addSubField('n', $linkNote);
				if (isset($link['item_id']) && $link['item_id'] > 0)
					$f7xx->addSubField('5', $link['item_id']);
				if ($link['bid'])
					$f7xx->addSubField(str_replace(' ','_',strtolower($link['bid_source'])),$link['bid']);
            }
        }

		$stmtGetManifestation = $conn->prepare('SELECT '.ManifestationPeer::MANIFESTATION_ID.', '.
			ManifestationPeer::BID.', '.ManifestationPeer::BID_SOURCE.', '.ManifestationPeer::UNIMARC.', '.
			ManifestationPeer::AUTHOR . ', ' . ManifestationPeer::TITLE .
			' FROM ' . ManifestationPeer::TABLE_NAME .
			' WHERE ' . ManifestationPeer::MANIFESTATION_ID . '=?');
		$lmansSQL = 'SELECT * FROM ' . LManifestationPeer::TABLE_NAME .
            ' WHERE ' . LManifestationPeer::MANIFESTATION_ID_DOWN . '=' . $manifestationId .
            ' OR ' . LManifestationPeer::MANIFESTATION_ID_UP . '=' . $manifestationId .
            ' ORDER BY ' . LManifestationPeer::LINK_TYPE . ',' . LManifestationPeer::LINK_SEQUENCE;
        foreach ($conn->query($lmansSQL) as $lman) {
            if ($lman['manifestation_id_up'] == $manifestationId) {
                $stmtGetManifestation->execute(array($lman['manifestation_id_down']));
                $linkType = $lman['link_type'];
            } else {
                $stmtGetManifestation->execute(array($lman['manifestation_id_up']));
                $linkType = TurboMarcMappings::$reverseLinkType[$lman['link_type']];
            }
            $m = $stmtGetManifestation->fetch(PDO::FETCH_ASSOC);
            if (intval($m['manifestation_id']) > 0) {
				$linkedmantm = TurboMarc::createRecord($m['unimarc']);
                $f = $tm->addField($linkType);
				$f->addSubField('0', $m['manifestation_id']);
                $f->addSubField('3', $m['manifestation_id']);

                $f->addSubField('t', $m['title']);

                if ($m['author'])
                	$f->addSubField('a', $m['author']);
				if (isset($linkedmantm->d210->sc))
					$f->addSubField('e', (string)$linkedmantm->d210->sc);
				if (isset($linkedmantm->d210->sd))
					$f->addSubField('d', (string)$linkedmantm->d210->sd);
				if ($ls = trim($lman['link_sequence']))
                    $f->addSubField('v', $ls);
                if ($ls = trim($lman['link_note']))
                    $f->addSubField('n', $ls);
                if ($ls = trim($lman['issue_id'])) {
                    $i = IssueQuery::create()->findPk($ls);
                    if ($i instanceof Issue) {
                        $f->addSubField('i', $ls);
                        $f->addSubField('j', $i->getIssueCombo());
                    }
                }
				$f->addSubField(str_replace(array(' ','\\','/'),'_',strtolower($m['bid_source'])),$m['bid']);
			}
        }

        $f901 = $tm->addField('901');
        $f901->addSubField('a', $mandb['BibType']);
        $f901->addSubField('b', $mandb['BibLevel']);
        $f901->addSubField('c', $mandb['BibTypeFirst']);
        $f901->addSubField('d', $mandb['HierarchicalLevel']);
        $f901->addSubField('e', $mandb['CatalogationLevel']);
        $f901->addSubField('f', $mandb['ManifestationStatus']);
        $f901->addSubField('g', $mandb['Rating']);
        $f901->addSubField('l', $mandb['LoanableSince']);
        $f901->addSubField('r', $mandb['DateUpdated']);
        $f901->addSubField('u', $mandb['DateCreated']);

        $issues = 'SELECT * FROM ' . IssuePeer::TABLE_NAME .
            ' WHERE ' . IssuePeer::MANIFESTATION_ID . '=' . $manifestationId;
        foreach ($conn->query($issues) as $issue) {
            /* @var $issue Issue */
            $f940 = $tm->addField('940');
            $f940->addSubField('s', $issue['start_number']);
            $f940->addSubField('e', $issue['end_number']);
            $f940->addSubField('y', $issue['issue_year']);
            $f940->addSubField('n', $issue['issue_number']);
            $f940->addSubField('t', $issue['issue_note']);
            $f940->addSubField('3', $issue['issue_id']);
            $f940->addSubField('f', intval(self::countAvailableItems($manifestationId,$issue['issue_id'])));
        }
        $notes = 'SELECT * FROM ' . ConsistencyNotePeer::TABLE_NAME . ' JOIN ' .
            LibraryPeer::TABLE_NAME . ' ON ' . ConsistencyNotePeer::LIBRARY_ID . '=' . LibraryPeer::LIBRARY_ID .
            ' WHERE ' . ConsistencyNotePeer::MANIFESTATION_ID . '=' . $manifestationId;
        foreach ($conn->query($notes) as $note) {
            /* @var $note ConsistencyNote */
            $f945 = $tm->addField('945');
            $f945->addSubField('a', $note['collocation']);
            $f945->addSubField('c', $note['closed']);
            $f945->addSubField('l', $note['library_id']);
            $f945->addSubField('n', $note['text_note']);
            $f945->addSubField('y', $note['label']);
            $f945->addSubField('3', $note['consistency_note_id']);
        }

        $last_inv_date = new DateTime('1903-01-01');
        $due_date_next = new DateTime('1903-01-01');
        $opac_visible_count = $onloan_count = $total_usage = 0;
        $onloan_status = ItemPeer::getLoanStatusActive();
        $stmtItemNote = $conn->prepare('SELECT * FROM ' . ItemNotePeer::TABLE_NAME .
            ' WHERE ' . ItemNotePeer::ITEM_ID . '=?');
        $items = $conn->query('SELECT * FROM ' . ItemPeer::TABLE_NAME . ' JOIN ' .
            LibraryPeer::TABLE_NAME . ' ON ' . ItemPeer::HOME_LIBRARY_ID . '=' . LibraryPeer::LIBRARY_ID .
            ' WHERE ' . ItemPeer::MANIFESTATION_ID . '=' . $manifestationId);
        $visibleStatus = ItemPeer::getItemStatusVisible();
        foreach ($items as $item) {
            // item notes
            $stmtItemNote->execute(array($item['item_id']));
            foreach ($stmtItemNote->fetchAll() as $in) {
				if (!trim($in['note']))
					continue;
                $noteType = intval($in['note_type']);
                if (!in_array($noteType,ManifestationPeer::$item_note_types))
                    continue;
                $f3xx = $tm->addField(intval($in['note_type']));
                $f3xx->addSubField('a', $in['note']);
                $f3xx->addSubField('5', $in['item_id']);
            }
            // item
            if (intval($item['library_id']) > 0) {
                $field = in_array($item['item_status'],$visibleStatus) ? '950' : '951';
                $f950 = $tm->addField($field);
                $f950->addSubField('5', $item['item_id']);
                $f950->addSubField('a', $item['home_library_id']);
                $f950->addSubField('b', $item['inventory_serie_id']);
                $f950->addSubField('c', $item['inventory_number']);
                $f950->addSubField('d', $item['section']);
                $f950->addSubField('e', $item['height']);
                $f950->addSubField('f', $item['collocation']);
                $f950->addSubField('g', $item['specification']);
                $f950->addSubField('h', $item['sequence1']);
                $f950->addSubField('i', $item['sequence2']);
                $f950->addSubField('j', $item['item_status']);
                $f950->addSubField('k', $item['opac_visible']);
                $combo = trim(implode(' ', array(
                    trim($item['section']),
                    trim($item['collocation']),
                    trim($item['specification']),
                    trim($item['sequence1']),
                    trim($item['sequence2']))));
                $f950->addSubField('l', $combo);
                $f950->addSubField('m', $item['inventory_value']);
                $f950->addSubField('n', $item['actual_library_id']);
                $f950->addSubField('o', $item['owner_library_id']);
                $f950->addSubField('p', $item['loan_class']);
                $f950->addSubField('q', $item['physical_status']);
                $f950->addSubField('r', $item['barcode']);
                $f950->addSubField('s', $item['item_media']);
                $inv_date = new DateTime($item['inventory_date']);
                $f950->addSubField('t', $inv_date->format('U'));
                if ($inv_date > $last_inv_date)
                    $last_inv_date = $inv_date;
                $f950->addSubField('u', $item['item_source']);
                $f950->addSubField('w', $item['item_icon']);
                $f950->addSubField('y', $item['label']);
                if ($item['issue_id'] > 0) {
                    $f950->addSubField('x', $item['issue_status']);
                    $f950->addSubField('z', $item['issue_id']);
                }
                if ($item['due_date']) {
                    $due_date = new DateTime($item['due_date']);
                    if ($due_date_next > $due_date)
                        $due_date_next = $due_date;
                    $due_date = $due_date->format('U');
                } else {
                    $due_date = '';
                }
                $f950->addSubField('1', LookupValuePeer::getLookupValue('LOANSTATUS', $item['loan_status']));
                $f950->addSubField('2', $item['loan_status']);
                $f950->addSubField('3', $due_date);
                $f950->addSubField('6', $item['patron_id']);
                $f950->addSubField('7', $item['usage_count']);
                $f950->addSubField('8', $item['reprint']);
                if (intval($item['consistency_note_id']) > 0)
                    $f950->addSubField('9', $item['consistency_note_id']);
                if (intval($item['usage_count']) > 0)
                    $total_usage += $item['usage_count'];
                if ($item['opac_visible']) {
                    ++$opac_visible_count;
                    if (in_array($item['loan_status'], $onloan_status))
                        ++$onloan_count;
                }
            }
        }
        $f901->addSubField('i', $last_inv_date->format('U'));
        $f901->addSubField('t', $total_usage);

        $shelves = $conn->query('SELECT '.ShelfPeer::TABLE_NAME.'.* FROM '.ShelfItemPeer::TABLE_NAME.
            ' LEFT JOIN '.ShelfPeer::TABLE_NAME.
            ' ON '.ShelfItemPeer::SHELF_ID.'='.ShelfPeer::SHELF_ID.
            ' WHERE '.ShelfItemPeer::OBJECT_CLASS.'=\''.ShelfPeer::TYPE_MANIFESTATION.
				'\' AND '.ShelfItemPeer::OBJECT_ID.'='.$manifestationId);
        foreach ($shelves as $shelf) {
            $f907 = $tm->addField('907');
            $f907->addSubField('3',$shelf['shelf_id']);
            $f907->addSubField('a',$shelf['shelf_name']);
            $f907->addSubField('b',$shelf['shelf_description']);
            $f907->addSubField('c',$shelf['shelf_status']);
            $f907->addSubField('d',$shelf['shelf_itemtype']);
            $f907->addSubField('e',$shelf['librarian_id']);
            $f907->addSubField('f',$shelf['library_id']);
        }

        $ircount = ItemRequestQuery::create()
            ->filterByManifestationId($manifestationId)
            ->filterByRequestStatus(array(ItemRequestPeer::STATUS_PENDING,ItemRequestPeer::STATUS_WORKING))
            ->count();
        $f909 = $tm->addField('909');
        $f909->addSubField('a',$ircount);
        $f909->addSubField('b',$opac_visible_count);
        $f909->addSubField('c',$onloan_count);
        $f909->addSubField('d',$due_date_next->format('U'));
        $f909->addSubField('f',intval(self::canHaveItems($mandb['BibLevel'],$mandb['HierarchicalLevel']) && self::countAvailableItems($manifestationId)));

        $attachs = $conn->query('SELECT * FROM ' . AttachmentPeer::TABLE_NAME .
            ' WHERE ' . AttachmentPeer::OBJECT_TYPE . '=\'manifestation\' AND ' .
            AttachmentPeer::OBJECT_ID . '=' . $manifestationId);
        $application = Prado::getApplication();
        if ($application instanceof TShellApplication) {
            $baseUrl = rtrim(ClavisParamQuery::getParam('CLAVISPARAM','BaseUrl'),'/') . '/index.php?file=';
        } else {
            $req = Prado::getApplication()->getRequest();
            $baseUrl = $req->getBaseUrl() . $req->constructUrl('file', null);
        }
        foreach ($attachs as $attach) {
            $f955 = $tm->addField('955');
            $f955->addSubField('a', $attach['attachment_type']);
            $f955->addSubField('b', $attach['mime_type']);
            $f955->addSubField('c', $attach['file_size']);
            $f955->addSubField('d', $baseUrl . $attach['attachment_id']);
            $f955->addSubField('e', $attach['file_name']);
            $f955->addSubField('f', $attach['license']);
            $f955->addSubField('l', $attach['file_label']);
            $f955->addSubField('n', $attach['file_description']);
			$f955->addSubField('p', $attach['file_path']);
            $f955->addSubField('3', $attach['attachment_id']);
        }

        // Clean double 6xx or 7xx
        $fieldMap = array();
        $children = $tm->children();
        for($i = count($children)-1; $i >= 0 ; $i--)
        {

            $fname = $children[$i]->getName();
            $fnum = substr($fname,0,2);
            if( $fnum == "d6" || $fnum == "d7" ) {
                $aid = (string)$children[$i]->s3;
                $rc  = (string)$children[$i]->s4;
                $uid = "{$fname}-{$aid}-{$rc}";
                if(!isset($fieldMap[$uid]))
                {
                    $fieldMap[$uid][] = true;
                } else {
                    unset($children[$i]); // Delete del doppione
                }
            }

        }

		$ret = ($getCollection) ? TurboMarc::createCollection()->appendNode($tm) : $tm;
        try {
            return ($asXML) ? $ret->asXML() : $ret;
        } catch (Exception $e) {
            if (class_exists('Prado') && (Prado::getApplication()->getMode() == 'Debug' ||
                (Prado::getApplication()->getUser() instanceof ClavisLibrarian && Prado::getApplication()->getUser()->getIsAdmin())))
                file_put_contents('/tmp/clavis_failmandump.xml',print_r($ret,true));
            throw $e;
        }
    }

    /**
     *
	 * @param int $manifestationId
     * @param boolean $onlyDirty
     * @return string The turbomarc cache
     */
    public static function cacheTurboMarc($manifestationId,$onlyDirty=true) {
        $cache = TurbomarcCacheQuery::create()->findPk($manifestationId);
        if (!$cache instanceof TurbomarcCache) {
            $cache = new TurbomarcCache();
            $cache->setManifestationId($manifestationId);
        }
        if ($onlyDirty && !$cache->isNew() && !$cache->getDirty())
            return $cache->getTurbomarc();
        $cache->setTurbomarc(self::getFullTurboMarc($manifestationId,true, false,true));
        $cache->setIndexed($cache->getIndexed() && !$cache->getDirty());
        $cache->setDirty(false);
        $cache->save();
        $turbomarc = $cache->getTurbomarc();
        $cache->clearAllReferences(true);
        return $turbomarc;
    }

    public static function invalidateCache($manifestationId) {
        TurbomarcCachePeer::invalidate($manifestationId);
    }

} // ManifestationPee
