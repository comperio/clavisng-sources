<?php

  // include base peer class
  require_once 'clavis/om/BaseSubscriptionPeer.php';

  // include object class
  include_once 'clavis/Subscription.php';


class SubscriptionPeer extends BaseSubscriptionPeer {

} // SubscriptionPeer
