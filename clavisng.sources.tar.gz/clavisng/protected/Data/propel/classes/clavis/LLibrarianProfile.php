<?php

require_once 'clavis/om/BaseLLibrarianProfile.php';

class LLibrarianProfile extends BaseLLibrarianProfile {

} // LLibrarianProfile
