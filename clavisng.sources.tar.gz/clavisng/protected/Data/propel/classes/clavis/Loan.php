<?php

require_once 'clavis/om/BaseLoan.php';

class Loan extends BaseLoan {

	/**
	 * Get the [loan_id] column value.
	 * Alias for getLoanId().
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->loan_id;
	}

	/**
	 * Get the associated Item object.
	 * Alias for getItemRelatedByItemId().
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Item The associated Item object.
	 * @throws     PropelException
	 */
	public function getItem(PropelPDO $con = null)
	{
		return $this->getItemRelatedByItemId($con);
	}

	/**
	 * Force a resync with copyfields from Item/Patron.
	 */
	public function syncWithItemPatron()
	{
		$i = $this->getItem();
		if ($i instanceof Item) {
			$this->setItemOwnerLibraryId($i->getOwnerLibraryId());
			$this->setItemHomeLibraryId($i->getHomeLibraryId());
			$this->setItemInventoryDate($i->getInventoryDate());
			$this->setTitle($i->getCompleteTitle());
			$this->setCollocation($i->getCollocation());
			$this->setItemMedia($i->getItemMedia());
			$this->setMediapackageSize($i->getMediapackageSize());
			$this->setClassCode($i->getManifestationDewey());
		}
		$p = $this->getPatron();
		if ($p instanceof Patron) {
			$patron_age = $p->getPatronAge();
			if (!is_null($patron_age))
				$this->setPatronAge($patron_age);
			$this->setPatronCity($p->getPatronCity());
		}
	}


	/***** METHODS BELOW THIS LINE HAS NOT YET BEEN CHECKED AND OPTIMIZED *****/
	/*****  PLEASE DON'T DELETE AND DON'T PUT NOT-CHECKED METHODS ABOVE   *****/


	/**
	 * It subclasses the getLoanStatus() method of the OM of
	 * this object, and looks at the patron_id field in case
	 * the loan_status field is null (as due to an incomplete
	 * import).
	 * And it returns default values, according to this analysis.
	 *
	 * @return string
	 */
	public function getLoanStatus()
	{
		$loanStatus = $this->loan_status;
		$patronId = $this->patron_id;

		if (is_null($loanStatus) || $loanStatus == '')
		{
			if (!is_null($patronId) && is_numeric($patronId))
			{
				if ($patronId > 0)
					$loanStatus = ItemPeer::LOANSTATUS_INLOAN; //'B';
				else
					$loanStatus = ItemPeer::LOANSTATUS_AVAILABLE; //'A';
			}
			else
				$loanStatus = ItemPeer::LOANSTATUS_AVAILABLE; //'A';
		}
		return $loanStatus;
	}

	/**
	 * It returns a string with the value, taken from lookupvalue
	 * table, relative to the loan_status of this item.
	 * If a string parameter is passed, we assume that string
	 * as the value key for the right string to extract.
	 *
	 * @param string $value
	 * @return string
	 */
	public function getLoanStatusString($value = null)
	{
		if (is_null($value))
			$status = $this->getLoanStatus();
		else
			$status = $value;

		if (!is_null($status))
		{
			$label = LookupValuePeer::getLookupValue('LOANSTATUS', $status);
			return $label;
		}
		else
		{
			return null;
		}
	}


	public function getRenewCount()
	{
		$count = parent::getRenewCount();
		if (!is_null($count) && is_numeric($count) && $count > 0)
			return $count;
		else
			return 0;
	}

	public function getShelfDescription()
	{
		$completeText = $this->getShelfDescriptionText();
		if ($completeText !== '')
			return $this->getShelfDescriptionLabel() . $completeText;
		else
			return '';
	}

	public function getShelfDescriptionLabel()
	{
		return Prado::localize('titolo esemplare: ');
	}

	public function getShelfDescriptionText()
	{
		//return $this->getCompleteName();
		return $this->getTrimmedTitle(80);
	}

	public function getShelfUrl()
	{
		return 'Catalog.ItemViewPage&id=';
	}

	public function getShelfObjectId()
	{
		return $this->item_id;
	}

	public function getTrimmedTitle($count = null)
	{
		$title = $this->getTitle();
		if (!is_null($count))
		{
			if (strlen($title) > $count)
				$title = substr($title, 0, $count) . '...';
		}

		$output = $title; // . $separator . $this->getPublisher();
		return $output;
	}

	public function getTitle($force = false)
	{
		$title = trim(parent::getTitle());

		if ($title == '' && $force)
		{
			$item = $this->getItem();
			if ($item instanceof Item)
				$title = $item->getTitle();
		}

		return $title;
	}

	public function getPatronName($separator = ' ')
	{
		$output = '';
		$patron = $this->getPatron();
		if (!is_null($patron))
		{
			$name = $patron->getName();

			$lastname = $patron->getLastname();
			if (($name != '') && ($lastname != ''))
				$name .= $separator;

			$output = $name . $lastname;
		}

		return $output;
	}

	public function getFruitorName()
	{
		$output = '';

		if (intval($this->getPatronId()) > 0)
			$output = $this->getPatronName();
		elseif (intval($this->getExternalLibraryId()) > 0)
			$output = $this->getExternalLibraryString(true, true, true, true);

		return $output;
	}

	public function getFruitorPhone()
	{
		$output = '';

		if (intval($this->getPatronId()) > 0)
		{
			$patron = $this->getPatron();
			if ($patron instanceof Patron)
				$output = $patron->getPhone2String();
		}
			
		elseif (intval($this->getExternalLibraryId()) > 0)
		{
			$library = $this->getExternalLibrary();
			if ($library instanceof Library)
				$output = trim($library->getPhone());
		}

		return $output;
	}

	public function getObjectTypeString()
	{
		return Prado::localize("prestito");
	}

	public function getFromLibraryLabel($multiRow = false, $stripTags = false, $appendExternal = true, $appendConsortia = true)
	{
		if ($appendExternal !== false)
			$appendExternal = true;

		if ($appendConsortia !== false)
			$appendConsortia = true;

		$return = '';
		$library = $this->getLibraryRelatedByFromLibrary();
		if ($library instanceof Library)
		{
			$return  = $library->getLabel(null, $stripTags, null);

			if ($multiRow)
				$sep = "\n";
			else
				$sep = "";

			$consortia = trim($library->getConsortiaId());
			if ($consortia != '' && $appendConsortia && $library->isExternal())
				$return .= $sep . ' (' . $consortia . ')';

			$extra = '';
			if ($library->isExternal() && $appendExternal)
			{
				if ($stripTags)
					$extra = "[" . Prado::localize("esterna") . "] " . $sep;
				else
					$extra = "<span style='color: red'>[" . Prado::localize("esterna") . "]</span>&nbsp;" . $sep;
			}

			$return = $extra . $return;
		}
		
		return $return;
	}

	public function getToLibraryLabel($multiRow = false, $stripTags = false, $appendExternal = true, $appendConsortia = true)
	{
		if ($appendExternal !== false)
			$appendExternal = true;

		if ($appendConsortia !== false)
			$appendConsortia = true;

		$return = '';
		$library = $this->getLibraryRelatedByToLibrary();
		if ($library instanceof Library)
		{
			$return  = $library->getLabel(null, $stripTags, null);

			if ($multiRow)
				$sep = "\n";
			else
				$sep = "";

			$consortia = trim($library->getConsortiaId());
			if ($consortia != '' && $appendConsortia && $library->isExternal())
				$return .= $sep . ' (' . $consortia . ')';

			$extra = '';
			if ($library->isExternal() && $appendExternal)
			{
				if ($stripTags)
					$extra = "[" . Prado::localize("esterna") . "] " . $sep;
				else
					$extra = "<span style='color: red'>[" . Prado::localize("esterna") . "]</span>&nbsp;" . $sep;
			}

			$return = $extra . $return;
		}

		return $return;
	}

	public function setExternalLibrary($library = null)
	{
		if (!is_null($library) && ($library instanceof Library))
		{
			$this->setExternalLibraryId($library->getLibraryId());
		}
	}

	public function getExternalLibraryString($multiRow = false, $stripTags = false, $appendExternal = true, $appendConsortia = true)
	{
		if ($appendExternal !== false)
			$appendExternal = true;

		if ($appendConsortia !== false)
			$appendConsortia = true;

		$return = '';
		$library = $this->getExternalLibrary();
		if ($library instanceof Library)
		{
			$return  = $library->getLabel(null, $stripTags, null);

			if ($multiRow)
				$sep = "\n";
			else
				$sep = "";

			$consortia = trim($library->getConsortiaId());
			if ($consortia != '' && $appendConsortia && $library->isExternal())
				$return .= $sep . ' (' . $consortia . ')';

			$extra = '';
			if ($library->isExternal() && $appendExternal)
			{
				if ($stripTags)
					$extra = "[" . Prado::localize("esterna") . "] " . $sep;
				else
					$extra = "<span style='color: red'>[" . Prado::localize("esterna") . "]</span>&nbsp;" . $sep;
			}
			
			$return = $extra . $return;
		}
		
		return $return;
	}

	public function getExternalLibrary()
	{
		$library = (object) null;

		$libraryId = intval($this->getExternalLibraryId());
		if ($libraryId > 0)
			$library = LibraryPeer::retrieveByPK($libraryId);

		return $library;
	}

	public function getItemHomeLibrary()
	{
		$library = (object) null;

		$libraryId = intval($this->getItemHomeLibraryId());
		if ($libraryId > 0)
			$library = LibraryPeer::retrieveByPK($libraryId);

		return $library;
	}
	
	public function getItemOwnerLibrary()
	{
		$library = (object) null;

		$libraryId = intval($this->getItemOwnerLibraryId());
		if ($libraryId > 0)
			$library = LibraryPeer::retrieveByPK($libraryId);

		return $library;
	}
	
	public function getRenewCountLabel($str = null)
	{
		$count = parent::getRenewCount();
		$count = $count < 0
			? '('.ItemPeer::decodeRenew($count).')'
			: intval($count);
		return (string) $count;
	}

} // Loan
