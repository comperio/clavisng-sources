<?php

/**
 *
 * @version 2.7
 */

require_once 'clavis/om/BaseUnimarcLabelsPeer.php';
include_once 'clavis/UnimarcLabels.php';

class UnimarcLabelsPeer extends BaseUnimarcLabelsPeer {

	const FALLBACK_LANGUAGE = 'it_IT';
	static public $_cache = array();

	static public function getFieldLabel($fieldNum)
	{
		$c = new Criteria();
		$c->add(self::FIELD_NUMBER, $fieldNum);
		$c->add(self::LANGUAGE, Prado::getApplication()->getGlobalization()->getCulture());

		$values = self::doSelect($c);

		/* if not found, try fallback on default language */
		if (count($values) == 0) {
			$c->add(self::LANGUAGE, self::FALLBACK_LANGUAGE);
			$values = self::doSelect($c);
		}
		return (count($values) > 0) ? $values[0]->getLabel() : '';
	}

} // UnimarcLabelsPeer
