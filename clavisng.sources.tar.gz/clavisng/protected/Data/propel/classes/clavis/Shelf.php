<?php
/**
 * Shelf class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseShelf.php';

/**
 * Shelf class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.1
 */
class Shelf extends BaseShelf
{
	public function preSave(PropelPDO $con = null)
	{
		ShelfPeer::checkShelfItemTypes($this); // shelf class check and eventual correction
		return true;
	}

	/** It initializes the collected items found by any "get..." function
	 * when using criteria.
	 * NB: 2nd version. Working.

	 */
	public function forceReloadShelf()
	{
		$this->collShelfItems = null;
	}

	/**
	 * It returns a string made containing, in words, the
	 * status of the shelf, according to the lookupvalue table.
	 *
	 * @return string
	 */
	public function getShelfStatusString($lang = null)
	{
		return LookupValuePeer::getLookupValue('SHELFSTATUS', $this->getShelfStatus());
	}

	/**
	 * It returns the id of the object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->shelf_id;
	}

	/** It performs an extraction of all shelf items according to the
	 * given parameters:
	 *
	 * @param int $currentPage                current page of grid
	 * @param int $pageSize                    size of page (10, 20, ....)
	 * @param Criteria $crit                    optional propel criteria
	 * @return array
	 */
	public function extractItemShelves($currentPage, $pageSize, $crit = null)
	{ //$searchString = '', $shelfItemtype = null)
		$this->forceReloadShelf();

		if (!($crit instanceof Criteria))
			$crit = new Criteria();

		$crit->addAscendingOrderByColumn(ShelfPeer::SHELF_NAME);
		if (!is_null($currentPage) && !is_null($pageSize)) {
			$crit->setLimit($pageSize);
			$crit->setOffset($currentPage * $pageSize);
		}

		$crit->addJoin(ShelfItemPeer::SHELF_ID, ShelfPeer::SHELF_ID);

		$shelfItems = $this->getShelfItems($crit);
		return $shelfItems;
	}

	/**
	 * It returns a count of the total number of shelf items
	 * according to the given parameters:
	 *
	 * @param Criteria $crit                optional propel criteria
	 * @return int
	 */
	public function countItemShelves($crit = null)
	{ //$searchString = '', $shelfItemtype = null)
		if (!$crit instanceof Criteria)
			$crit = new Criteria();
		$crit->addJoin(ShelfItemPeer::SHELF_ID, ShelfPeer::SHELF_ID);
		$count = $this->countShelfItems($crit);
		return $count;
	}

	public function isVisible(ClavisLibrarian $user)
	{
		$visible = false;

		$librarian = LibrarianPeer::retrieveByPK($this->getLibrarianId());
		if (!$librarian instanceof Librarian)
			return false;

		$userId = $user->getId();
		switch ($this->getShelfStatus()) {
			case ShelfPeer::VISIBILITY_OWNER:
				if ($userId == $librarian->getLibrarianId())
					$visible = true;
				break;
			case ShelfPeer::VISIBILITY_LIBRARYOPS:
			case ShelfPeer::VISIBILITY_OPAC:
				if ($this->getLibraryId() == $user->getActualLibraryId())
					$visible = true;
				break;
			case ShelfPeer::VISIBILITY_ADMINS:
				$visible = $user->getIsAdmin();
				break;
			case ShelfPeer::VISIBILITY_ALLOPS:
			case ShelfPeer::VISIBILITY_ALLREADONLY:
				$visible = true;
				break;
		}

		return $visible;
	}

	public function isEditable(ClavisLibrarian $user)
	{
		$editable = false;
		$librarian = LibrarianPeer::retrieveByPK($this->getLibrarianId());
		if (!$librarian instanceof Librarian)
			return false;

		$userId = $user->getId();
		if ($user->getIsAdmin())
			return true;

		$shelfStatus = $this->getShelfStatus();
		switch ($shelfStatus) {
			case ShelfPeer::VISIBILITY_OWNER:
			case ShelfPeer::VISIBILITY_ALLREADONLY:
				if ($userId == $librarian->getLibrarianId())
					$editable = true;
				break;
			case ShelfPeer::VISIBILITY_LIBRARYOPS:
			case ShelfPeer::VISIBILITY_OPAC:
				if (in_array($this->getLibraryId(), $user->getLibraryIds()))
					$editable = true;
				break;
			case ShelfPeer::VISIBILITY_ADMINS:
				$editable = $user->getIsAdmin();
				break;
			case ShelfPeer::VISIBILITY_ALLOPS:
				$editable = true;
		}

		return $editable;
	}

	public function addItemToShelf($objectClass = null, $objectId = null)
	{
		return ShelfPeer::addItemToShelf($this->getShelfId(), $objectClass, $objectId);
	}

	public function getEnsuredLibraryId()
	{
		$libraryId = intval($this->getLibraryId());
		if ($libraryId == 0)
		{
			$librarianId = intval($this->getLibrarianId());
			if ($librarianId > 0)
				$librarian = LibrarianQuery::create()
								->findPk($librarianId);
			else
				$librarian = Prado::getApplication()->getUser();

			$libraryId = $librarian->getDefaultLibraryId();

			if (!is_null($libraryId))
			{
				$this->setLibraryId($libraryId);
				$this->save();
			}
		}

		return $libraryId;
	}

	public function getEnsuredLibraryLabel()
	{
		$libraryId = intval($this->getEnsuredLibraryId());
		if ($libraryId > 0) {
			$library = LibraryPeer::retrieveByPK($libraryId);
			$label = '';
			if (!is_null($library))
				$label = TPropertyValue::ensureString($library->getLabel());

			if ($label != '')
				return $library->getLabel();
			else
				// XXX: get rid of Prado!!
				return Prado::localize('(senza nome)');
		}
		else
			return '';
	}

	public function getEnsuredShelfName()
	{
		$shelfName = trim($this->shelf_name);
		
		if ($shelfName == '')
			// XXX: get rid of Prado!!
			$shelfName = Prado::localize('(senza nome)');
		
		return $shelfName;
	}

	public function getShelfName()
	{
		$shelfName = strip_tags($this->shelf_name);
		$trimmedShelfName = trim($shelfName);
		
		if (is_null($shelfName) || ($trimmedShelfName == ''))
			$trimmedShelfName = '(senza nome)';
		
		return $trimmedShelfName;
	}

	public function getShelfDescription()
	{
		$shelfDescription = strip_tags($this->shelf_description);
		$trimmedShelfDescription = trim($shelfDescription);
		if (is_null($shelfDescription) || ($trimmedShelfDescription == ''))
			$trimmedShelfDescription = '(senza descrizione)';
		return $trimmedShelfDescription;
	}

	public function getShelfCompleteName($separator = ' ')
	{
		$shelfName = trim($this->getShelfName());
		$shelfDescription = trim($this->getShelfDescription());

		if ($shelfDescription != '')
			$shelfDescription = '(' . $shelfDescription . ')';

		if ($shelfName == '' || $shelfDescription == '')
			$separator = '';

		return $shelfName . $separator . $shelfDescription;
	}

	public function getShelfItemtypeString($force = false)
	{
		$type = $this->getShelfItemtype();
		if (!$force && ($type == ShelfPeer::NOTYPE || is_null($type) || $type == ''))
			$output = '';
		else
			$output = LookupValuePeer::getLookupValue("SHELFITEMTYPE", $type);

		return $output;
	}
	
	/**
	 * It returns an array with all the real itemshelf types currently
	 * present in this shelf
	 *
	 * @return array
	 */
	public function getShelfItemTypes()
	{
		return ShelfPeer::getShelfItemTypes($this->getShelfId());
	}
	
}
// Shelf