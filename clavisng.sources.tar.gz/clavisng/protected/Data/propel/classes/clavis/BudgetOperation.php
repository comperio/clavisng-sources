<?php

require_once 'clavis/om/BaseBudgetOperation.php';


class BudgetOperation extends BaseBudgetOperation {

} // BudgetOperation
