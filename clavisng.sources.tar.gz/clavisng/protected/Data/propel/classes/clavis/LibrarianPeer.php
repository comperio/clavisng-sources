<?php

  // include base peer class
  require_once 'clavis/om/BaseLibrarianPeer.php';

  // include object class
  include_once 'clavis/Librarian.php';


class LibrarianPeer extends BaseLibrarianPeer {

	const EXCP_USERNAME_DUP = 773;

	public static function getLibrarianNameByPk($librarian_id) {
		$librarian = LibrarianPeer::retrieveByPK($librarian_id);
		return ($librarian->getName() .' ' .$librarian->getLastname());
	}

	/**
 	 * Performs an extraction of librarian objects according to the
	 * given parameters:
	 *
	 * @param int $currentPage			current page of grid
	 * @param int $pageSize				size of page (10, 20, ....)
	 * @param string $searchName		optional string which have to match a librarian.name
	 * @param string $searchLastname	optional string which have to match a librarian.lastname
	 * @param Library $library			if not null, the librarians extracted have to have
	 * 									these library assigned only (see l_library_librarian table)
	 * @return array
	 */
	public static function extractLLibraryLibrarian(	$currentPage = null, 
														$pageSize = null, 
														$searchName = '', 
			
														$searchLastname = '', 
														$library = null, 
														$activeOnly = 0,
			
														$excludedIds = array())
	{
		$c = new Criteria();
		$c->addAscendingOrderByColumn(self::LASTNAME);
		$c->addAscendingOrderByColumn(self::NAME);

		if ($searchName !== '')
			$c->add(self::NAME, "%" . $searchName . "%", Criteria::LIKE );
		if ($searchLastname !== '')
			$c->add(self::LASTNAME, "%" . $searchLastname . "%", Criteria::LIKE );

		if ($activeOnly == 1)
			$c->add(self::ACTIVATION_STATUS, 1);
		
		if (is_array($excludedIds) && (count($excludedIds) > 0))
			$c->add(self::LIBRARIAN_ID, $excludedIds, Criteria::NOT_IN);

		if (!is_null($currentPage) && !is_null($pageSize))
		{
			$c->setLimit($pageSize);
			$c->setOffset($currentPage * $pageSize);
		}

		if (!is_null($library) && ($library instanceof Library))
		{
			$lLibraryLibrarian = $library->getLLibraryLibrariansJoinLibrarian($c);

			$librarians = array();
			foreach ($lLibraryLibrarian as $lL)
			{
				$librarianId = intval($lL->getLibrarianId());
				if ($librarianId > 0)
				{
					$librarian = self::retrieveByPK($librarianId);
					if (!is_null($librarian) && $librarian instanceof Librarian)
						$librarians[] = $librarian;
				}
			}
		}
		else
			$librarians = self::doSelect($c);

		return $librarians;
	}

	/**
	 * Performs an extraction of the total number of library objects
	 * according to the given parameters:
	 *
	 * @param string $searchName		optional string which have to match a librarian.name
	 * @param string $searchLastname	optional string which have to match a librarian.lastname
	 * @param Library $library			if not null, the librarians extracted have to have
	 * 									assigned to librarian only (see l_library_librarian table)
	 * @return array
	 */
	public static function countLLibraryLibrarian(	$searchName = '', 
														$searchLastname = '', 
														$library = null,
			
														$activeOnly = 0 )
	{
		$c = new Criteria();

		if ($searchName !== '')
			$c->add(self::NAME, "%" . $searchName . "%", Criteria::LIKE );
		if ($searchLastname !== '')
			$c->add(self::LASTNAME, "%" . $searchLastname . "%", Criteria::LIKE );

		if ($activeOnly == 1)
			$c->add(self::ACTIVATION_STATUS, 1);
				
		if ($library)
		{
			$lLibraryLibrarian = $library->getLLibraryLibrariansJoinLibrarian($c);
			$count = count($lLibraryLibrarian);
		}
		else
			$count = self::doCount($c);

		return $count;
	}

	/**
 	 * Performs an extraction of librarian objects according to the
	 * given parameters:
	 *
	 * @return array
	 */
	public static function extractLibrarianProfiles($librarian)
	{
		$critProf = new Criteria();
		$critProf->addAscendingOrderByColumn(LLibrarianProfilePeer::SORT_ORDER);

		$lLibrarianProfiles = $librarian->getLLibrarianProfilesJoinAppProfile($critProf);

		return $lLibrarianProfiles;
	}


	/**
	 * Retrieves a Librarian object searching it by its username.
	 *
	 * @param string $username The username to search by.
	 * @return Librarian The librarian that has the specified username, nul if it doesn't exist.
	 */
	public static function retrieveByUsername($username)
	{
		$result = null;
		if ($username != '')
		{
			$criteria = new Criteria();
			$criteria->add(LibrarianPeer::USERNAME, $username);
			$result = LibrarianPeer::doSelectOne($criteria);
		}
		return $result;
	}

	/**
	 * Get a list of librarians based on a start string and optional criterions.
	 *
	 * @param string $token The string to use as a base search.
	 * @param integer $limit The maximum of librarians to return (defaults to 10).
	 * @return Array A list of Librarians.
	 */
	public static function doSuggest($token,$limit=10) {
		$list = array();
		$c = new Criteria();
		if (strpos($token,',') !== false) {
			$parts = explode(', ',$token);
			$c->add(self::NAME,$parts[1].'%',Criteria::LIKE);
			$token = $parts[0];
		}
		$c->add(self::LASTNAME,$token.'%',Criteria::LIKE);
		$c->addAscendingOrderByColumn(self::LASTNAME);
		$c->addAscendingOrderByColumn(self::NAME);
		$c->setLimit($limit);
		$list = self::doSelect($c);
		return $list;
	}

} // LibrarianPeer
