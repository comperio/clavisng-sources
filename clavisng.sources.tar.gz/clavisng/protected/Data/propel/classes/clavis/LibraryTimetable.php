<?php
/**
 * LibraryTimetable class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseLibraryTimetable.php';

/**
 * LibraryTimetable class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.4.3
 */
class LibraryTimetable extends BaseLibraryTimetable {
	
	public function convertTimes2String(	$from = "", 
											$to = "-", 
											$connector = '&nbsp; -- &nbsp;' )
	{
		$timeRawArray = array();
		$timeRawArray[] = array($this->getTime1Start(LibraryTimetablePeer::TIMEFORMAT),
								$this->getTime1End(LibraryTimetablePeer::TIMEFORMAT));

		$timeRawArray[] = array($this->getTime2Start(LibraryTimetablePeer::TIMEFORMAT),
								$this->getTime2End(LibraryTimetablePeer::TIMEFORMAT));

		$timeRawArray[] = array($this->getTime3Start(LibraryTimetablePeer::TIMEFORMAT),
								$this->getTime3End(LibraryTimetablePeer::TIMEFORMAT));

		$timeArray = array();
		foreach ($timeRawArray as $index => $row)
		{
			list($t_start, $t_end) = $row;
			if (($t_start != "") && ($t_end != "") && ($t_start < $t_end))
			$timeArray[] = "$from $t_start $to $t_end";
		}

		return implode($connector, $timeArray);
	}

	/**
	 * @param string $time
	 * @return int  (	-1 if library is closed today,
	 *					0 if library is open today, but is closed now,
	 *					1 if library is open now) 
	 */
	public function isLibraryOpen($time = null)
	{
		if (!$this->getTimetableOpen())
			return LibraryPeer::CLOSED;
		
		if (is_null($time))
			$time = date('H:i');  // now in hours:minutes format
		
		$t1Start = $this->getTime1Start(LibraryTimetablePeer::TIMEFORMAT);
		$t1End = $this->getTime1End(LibraryTimetablePeer::TIMEFORMAT);
		if (!is_null($t1Start) && !is_null($t1End) && ($t1Start != "") && ($t1End != "") && ($t1Start <= $time) && ($time <= $t1End))
			return LibraryPeer::OPEN;

		$t2Start = $this->getTime2Start(LibraryTimetablePeer::TIMEFORMAT);
		$t2End = $this->getTime2End(LibraryTimetablePeer::TIMEFORMAT);
				if (!is_null($t2Start) && !is_null($t2End) && ($t2Start != "") && ($t2End != "") && ($t2Start <= $time) && ($time <= $t2End))
			return LibraryPeer::OPEN;

		$t3Start = $this->getTime3Start(LibraryTimetablePeer::TIMEFORMAT);
		$t3End = $this->getTime3End(LibraryTimetablePeer::TIMEFORMAT);
				if (!is_null($t3Start) && !is_null($t3End) && ($t3Start != "") && ($t3End != "") && ($t3Start <= $time) && ($time <= $t3End))
			return LibraryPeer::OPEN;
		
		return LibraryPeer::PAUSE;
	}

} // LibraryTimetable
