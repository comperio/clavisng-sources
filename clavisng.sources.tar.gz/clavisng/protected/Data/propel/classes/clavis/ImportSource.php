<?php

/**
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.5.0
 */
class ImportSource extends BaseImportSource {

	/**
	 * Returns the driver's optional parameters.
	 * Overrides parent implementation for transparently support serialization.
	 *
	 * @return array
	 */
	public function getOptions()
	{
		$options = @unserialize(parent::getOptions());
		return ($options === false) ? array() : $options;
	}

	/**
	 * Sets the driver's optional parameters.
	 * Overrides parent implementation for transparently support serialization.
	 *
	 * @param array $v
	 * @return ImportSource The current object (for fluent API support)
	 */
	public function setOptions($v = array())
	{
		if (!is_array($v))
			$v = array();
		$v = serialize($v);
		return parent::setOptions($v);
	}

	public function getDriverLabel() {
		return $this->getDriver() == 'SBNDriver' ?
				'SBN' : ClavisParamPeer::getParam('IMPORT_DRIVER', $this->getDriver());
	}

} // ImportSource
