<?php
/**
 * Library class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseLibrary.php';

/**
 * Library class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class Library extends BaseLibrary
{
	 /** It initializes the criteria collection which are used when
	 * we call the function "getLLibraryLibrarian()", in case we
	 * update the table l_library_librarian and one "library"
	 * object gets stuck with the old set of links to it.
	 *
	 */

	public function forceReloadLLibraryLibrarian()
	{
		$this->lastLLibraryLibrarianCriteria = null;
	}

	// ALIAS
	/**
	 * It returns the id of the object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->getLibraryId();
	}

	public function getTimetable($date = null)
	{
		if (is_null($date))
			$date = date('U');  // today
		
		$timeTable = LibraryTimetableQuery::create()
						->filterByLibraryId($this->getLibraryId())
						->filterByTimetableDay($date)
						->filterByTimetableOpen(true)
						->findOne();
		
		if (!($timeTable instanceof LibraryTimetable))
			return "";
		
		return $timeTable->convertTimes2String();
	}
	
	public function getTimeTableNextOpen($limit = 7, $from = null)
	{
		if (intval($limit) == 0)
			$limit = 7;
		
		if (is_null($from))
			$from = date('U');  // today
		
		$timeTables = LibraryTimetableQuery::create()
						->filterByLibraryId($this->getLibraryId())
						->filterByTimetableOpen(true)	
						->filterByTimetableDay($from, Criteria::GREATER_EQUAL)
						->limit($limit)
						->find();
		
		$timings = "";
		foreach ($timeTables as $row)
			$timings .= $row->getTimetableDay('D d-m-y') . "  (" . $row->convertTimes2String() . " )\n";
		
		return $timings;
	}
	
	public function getTrimmedDescription($count = null)
	{
		$description = $this->getDescription();
		$count = intval($count);
		if (!($count > 0))
			return $description;

		if (strlen($description) > $count)
			$description = mb_substr($description, 0, $count, 'utf8') . '...';

		return $description;
	}

	public function getShelfDescription()
	{
		$text = $this->getShelfDescriptionText();
		if ($text !== '')
			return $this->getShelfDescriptionLabel() . $text;
		else
			return '';
	}

	public function getShelfDescriptionLabel()
	{
		return Prado::localize('descrizione: ');
	}

	public function getShelfDescriptionText()
	{
		return $this->getTrimmedDescription(40);
	}

	public function getShelfUrl()
	{
		return LibraryPeer::getViewPage() . '&id=';
	}

	public function getNavigateUrl($idFillFlag = false)
	{
		if ($idFillFlag)
			$id = $this->getLibraryId();
		else
			$id = 0;
			
		return LibraryPeer::getNavigateUrl($id);
	}

	public function getObjectTypeString()
	{
		return Prado::localize("biblioteca");
	}

	public function addLibrarian($librarianId = null, $role = 'B', $opac_visible=true)
	{
		$returnCode = false;
		$librarianId = intval($librarianId);
		$role = TPropertyValue::ensureString(trim($role));
		if (($librarianId > 0) && ($role != ''))
		{
			try
			{
				/* 
				 * Modified by mbrancalion, 2014-06-25, error in later profile editing (duplicate)
				 */
				$librarian_lnk = LLibraryLibrarianQuery::create()
									->filterByLibrarianId($librarianId)
									->filterByLibraryId($this->library_id)
									->findOneOrCreate();
				
//				$librarian_lnk = new LLibraryLibrarian();
//				$librarian_lnk->setLibraryId($this->library_id);
//				$librarian_lnk->setLibrarianId($librarianId);
				$librarian_lnk->setLinkRole($role);
				$librarian_lnk->setOpacVisible($opac_visible);
				$librarian_lnk->save();
				$this->addLLibraryLibrarian($librarian_lnk);

				$returnCode = true;
			}
			catch (PropelException $e)
			{
				Prado::Log(Prado::varDump($e->getMessage()));
			}
		}
		return $returnCode;
	}

	private function getActualSMSParam() {
		$c = new Criteria();
		$c->add(ClavisParamPeer::PARAM_CLASS,'SMSACCOUNT');
		$c->add(ClavisParamPeer::PARAM_NAME,'ACTUAL');
		$c->add(ClavisParamPeer::LIBRARY_ID,$this->library_id);
		$smsrow = ClavisParamPeer::doSelect($c);
		if (count($smsrow) == 1) {
			return $smsrow[0];
		} else {
			// init parameter for library
			$smstot = new ClavisParam();
			$smstot->setParamName('TOTAL');
			$smstot->setLibraryId($this->library_id);
			$smstot->setLibrarianId(0);
			$smstot->setParamClass('SMSACCOUNT');
			$smstot->setParamValue(0);
			$smstot->save();
			$smsrow = new ClavisParam();
			$smsrow->setParamName('ACTUAL');
			$smsrow->setLibraryId($this->library_id);
			$smsrow->setLibrarianId(0);
			$smsrow->setParamClass('SMSACCOUNT');
			$smsrow->setParamValue(0);
			$smsrow->save();
			return $smsrow;
		}
	}

	public function getActualSMS() {
		return $this->getActualSMSParam()->getParamValue();
	}

	public function setActualSMS($value) {
		try {
			$actualSMS = $this->getActualSMSParam();
			$actualSMS->setParamValue($value);
			$actualSMS->save();
		} catch (Exception $e) {
			throw new Exception($e);
		}
	}

	public function getLibraryTypeString($appendInternal = true)
	{
		$libraryTypeString = LookupValuePeer::getLookupValue('LIBTYPE',  $this->getLibraryType());

//		if ($this->getLibraryInternal() != "1" && ($appendInternal === true))
//			$libraryTypeString .= $this->getExternalConst();
		$subfix = $this->getExternalString();

		return $libraryTypeString . $subfix;
	}

	public function getConsortiaString($trim = null)
	{
		$trim = intval($trim);
		$output = '';
		$consortia = $this->getConsortia();
		if (!is_null($consortia))
		{
			$output = $consortia->getDescription();
			if (($trim > 0) && (strlen($output) > $trim))
				$output = mb_substr($output, 0, $trim, 'utf8') . '...';
		}
		return $output;
	}

	public function getExternalConst()
	{
		return " <span style='color: red'>[" . Prado::localize("esterna") . "]</span>";
	}

	public function isExternal()
	{
		return (intval($this->getLibraryInternal()) != 1);
	}

	public function getExternalString()
	{
		if ($this->isExternal())
			return $this->getExternalConst();
		else
			return '';
	}

	public function getTrimmedLabel($num = null)
	{
		$label = parent::getLabel();
		$num = intval($num);
		if ($num > 0 && $num < strlen($label))
			$label = mb_substr($label, 0, $num, 'utf8') . '...';

		return $label;
	}

	public function getLabel(	$appendExternal = false, 
								$stripTags = false, 
								$appendConsortia = false, 
								$trim = null)
	{
		if ($appendExternal !== true)
			$appendExternal = false;

		if ($appendConsortia !== true)
			$appendConsortia = false;

		if ($appendExternal)
			$subfix = $this->getExternalString();
		else
			$subfix = '';

		if ($stripTags)
			$subfix = strip_tags($subfix);
		
		$output = $this->getTrimmedLabel($trim) . $subfix;

		if ($appendConsortia)
		{
			$consortia = trim($this->getConsortiaId());
			if ($consortia != '')
				$output .= " (" . $consortia . ")";
		}
		return $output;
	}

	public function getLabelConsortia($numCar)
	{
		$subfix = trim($this->getConsortiaString($numCar));

		if ($subfix != '')
			$subfix = " [$subfix]";

		return parent::getLabel() . $subfix;
	}

	public function getCompleteAddress($sep = '-')
	{
		$output = '';

		$address = trim($this->getAddress());
		if ($address != '')
			$output = $address;

		$city = trim($this->getCity());
		if ($city != '')
		{
			if ($output !=  '')
				$output .= ',&nbsp;' . $city;
			else
				$output = $city;
		}

		$province = trim($this->getProvince());
		if ($province != '')
		{
			if ($output !=  '')
				$output .= '&nbsp;(' . $province . ')';
			else
				$output = $province;
		}

		return $output;
	}

	public function countLoans(Criteria $criteria = null)
	{
		if (is_null($criteria))
			$criteria = new Criteria();
		else
			$criteria = clone $criteria;

		$count = 0;

		$criteria->add(LoanPeer::EXTERNAL_LIBRARY_ID, $this->getLibraryId());
		$count = LoanPeer::doCount($criteria);
		
		return $count;
	}

	public function reload($deep = false, PropelPDO $con = null)
	{
		if (!$this->isNew())
			parent::reload ($deep, $con);
	}
	
	/**
	 * @param int $date
	 * @param string $time
	 * @return enum  (	LibraryPeer::NOTSETOPEN if timetible for this day does not exist
	 *					LibraryPeer::CLOSED if library is closed today,
	 *					LibraryPeer::PAUSE if library is open today, but is closed now,
	 *					LibraryPeer::OPEN if library is open now) 
	 */	
	public function isLibraryOpen($date = null, $time = null)
	{
		return LibraryTimetablePeer::isLibraryOpen($this->getLibraryId(), $date, $time);
	}
	
	public function getInventorySeries2Array($criteria = null, PropelPDO $con = null) 
	{
		$inventorySeriesArray = array();
		$inventorySeries = $this->getInventorySeries($criteria, $con);
		if ($inventorySeries->count() > 0)
		{
			foreach ($inventorySeries as $serie)
				$inventorySeriesArray[$serie->getInventorySerieId()] = $serie->getDescription();
		}

		return $inventorySeriesArray;
	}
	
	public function getDistanceHashFromLibrary(	$distanceFilter = null,
													$toLibraryIdFilter = null )
	{
		$output = array();
				
		$queryStart = "SELECT group_concat(to_library_id order by to_library_id) AS libraries, distance FROM l_library WHERE from_library_id = " .
						$this->getLibraryId() . " ";
		$queryEnd = " group by distance order by distance;";

		if (!is_null($distanceFilter) && ($distanceFilter >= 0))
			$queryStart .= " AND distance = " . $distanceFilter . " ";

		if (!is_null($toLibraryIdFilter) && ($toLibraryIdFilter > 0))
			$queryStart .= " AND to_library_id = " . $toLibraryIdFilter . " ";
		
		$connection = Propel::getConnection();
		
		// for preventing the limiting of char number to 1024, in mysql
		$stmt = $connection->prepare('SET SESSION group_concat_max_len=15000;');
		$stmt->execute();
		
		$stmt = $connection->prepare($queryStart . $queryEnd);
		$stmt->execute();
		
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$output[$row['distance']] = $row['libraries'];
			
		return $output;
	}
	
	public function getDistanceHashToLibrary(	$distanceFilter = null,
													$fromLibraryIdFilter = null)
	{
		$output = array();
				
		$queryStart = "SELECT group_concat(from_library_id order by from_library_id) AS libraries, distance FROM l_library WHERE to_library_id = " .
						$this->getLibraryId() . " ";
		$queryEnd = " group by distance order by distance;";

		if (!is_null($distanceFilter) && ($distanceFilter >= 0))
			$queryStart .= " AND distance = " . $distanceFilter . " ";

		if (!is_null($fromLibraryIdFilter) && ($fromLibraryIdFilter > 0))
			$queryStart .= " AND from_library_id = " . $fromLibraryIdFilter . " ";
		
		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryStart . $queryEnd);
		$stmt->execute();
		
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$output[$row['distance']] = $row['libraries'];
			
		return $output;
	}
	
	public function getLibraryIdsFromDeliveryLibrary(	$distanceFilter = null,
															$excludedLibraryId = null)
	{
		return LLibraryPeer::getLibraryIdsFromDeliveryLibrary(	$this->getLibraryId(),
																$distanceFilter = null,
																$excludedLibraryId = null);
	}	
	
	public function getLibraryIdsToDeliveryLibrary(	$distanceFilter = null,
														$excludedLibraryId = null)
	{
		return LLibraryPeer::getLibraryIdsToDeliveryLibrary(	$this->getLibraryId(),
																$distanceFilter = null,
																$excludedLibraryId = null);
	}
	
} // Library
