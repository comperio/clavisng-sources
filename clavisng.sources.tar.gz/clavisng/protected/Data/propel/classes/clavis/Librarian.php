<?php
/**
 * Librarian class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

require_once 'clavis/om/BaseLibrarian.php';

/**
 * Librarian class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class Librarian extends BaseLibrarian {

	public function postSave(PropelPDO $conn = null) {
		if ($this->patron_id > 0) {
			$p = $this->getPatron($conn);
			if ($p->getOpacUsername() != $this->username) {
				$p->setOpacUsername($this->username);
				$p->save();
			}
		}
	}

	/**
	 * Set the value of [username] column, checking uniqueness among Librarians and Patrons.
	 *
	 * @param	string $v new value
	 * @return	Librarian The current object (for fluent API support)
	 * @throws	Exception if value is duplicated.
	 */
	public function setUsername($v) {
		// overrides parent checking uniqueness among patrons too.
		if (!$this->allowedUsername($v))
			throw new Exception('Username is already in use.',LibrarianPeer::EXCP_USERNAME_DUP);
		return parent::setUsername($v);
	}

	/**
	 * Checks if a username is allowed (i.e. not already in use by a Librarian or a Patron).
	 *
	 * @param string $username The username to search for.
	 * @return boolean true if username is in use, false elsewhere.
	 */
	public function allowedUsername($username)
	{
		$librarian = LibrarianQuery::create()
			->prune($this)
			->filterByUsername($username);
		$patron = PatronQuery::create()
			->filterByPatronId($this->patron_id,Criteria::NOT_EQUAL)
			->filterByOpacUsername($username);
		return ($librarian->count() < 1 && $patron->count() < 1);
	}

	public function isAdministrator()
	{
		foreach($this->getLLibrarianProfiles() as $lprofile)
			if ($lprofile->getProfileId() == 1)
				return true;
		return false;
	}

	/**
	 * It gets from acl tables all infos about ACL on the application.
	 *
	 * @return array
	 */
	public function getACLInfos() {

		$librarianAcls = array();

		$lprofiles = $this->getLLibrarianProfiles();
		foreach ($lprofiles as $lprofile) {
			$acls = AppProfileAclQuery::create()
				->useAppModuleQuery()
				->orderBySortOrder()
				->endUse()
				->useAppActionQuery()
				->orderBySortOrder()
				->endUse()
				->findByProfileId($lprofile->getProfileId());

			foreach ($acls as $acl) {
				$permission = $acl->getAction();
				if (strtoupper($permission) === 'ALLOW') {
					$action = $acl->getAppAction();
					if ($action instanceof AppAction) {
						$module = $acl->getAppModule();
						$librarianAcls['modules'][$module->getModuleId()] =
							array('label' => $module->getLabel(),
								'page' => $module->getPage(),
								'always_view' => $module->getAlwaysView());
						$librarianAcls['acls'][$module->getModuleId()][$action->getActionId()] =
							array('label' => $action->getLabel(),
								'page' => $action->getPage(),
								'menu_visible' => $action->getMenuVisible());
					}
				}
			}
		}
		return $librarianAcls;
	}

	public function getAuthPages()
	{
		$librarianAuthPages = array();

		$lprofiles = $this->getLLibrarianProfiles();
		foreach ($lprofiles as $lprofile) {
			/* @var $lprofile LLibrarianProfile */
			$acls = AppProfileAclQuery::create()
				->joinAppAction()
				->findByProfileId($lprofile->getProfileId());
			foreach ($acls as $acl) {
				$permission = $acl->getAction();
				if (strtoupper($permission) === 'ALLOW') {
					$action = $acl->getAppAction();
					if ($action instanceof AppAction)
						$librarianAuthPages[$action->getPage()] = true;
				}
			}
		}
		return $librarianAuthPages;
	}

	/**
	 * It returns an array of libraries which are related
	 * to this librarian.
	 * It's an "escamotage" in case the "getLibraries" function
	 * of the object doesn't work well ...
	 *
	 * @return array
	 */
	public function getLibraries($onlyInternal = true)
	{
		$libraries = array();
		$libraryLinks = $this->getLLibraryLibrarians();
		foreach ($libraryLinks as $link)
		{
			$lib = $link->getLibrary();
            if (!is_null($lib))
            {
            	if ($onlyInternal)
            	{
  					if ($lib->getLibraryInternal() == "1")
  						$libraries[] = $lib;
            	}
            	else
            		$libraries[] = $lib;
            }
		}

		return $libraries;
	}

	/**
	 * It returns a hash with all the libraries related to a librarian.
	 * The indexes are the ids of libraries, while the elements are
	 * their descriptions.
	 *
	 * @return array
	 */
	public function getLibrariesHash($addedLibraryIds = array(), $onlyInternal = true)
	{
		$libraries = array();

		if (count($addedLibraryIds) > 0)
		{
			$addedLibraries = LibraryPeer::retrieveByPKs($addedLibraryIds);
			foreach ($addedLibraries as $addedLibrary)
				$libraries[$addedLibrary->getLibraryId()] = $addedLibrary->getLabel();
		}

        $libraryList = LibraryQuery::create()
                        ->filterByLibraryInternal($onlyInternal)
                        ->useLLibraryLibrarianQuery()
                            ->filterByLibrarian($this)
                        ->endUse()
                        ->orderByLabel()
                        ->find();

		foreach ($libraryList as $l)
		    $libraries[$l->getId()] = $l->getLabel();


		return $libraries;
	}

	/**
	 * It returns an array of library ids which are related
	 * to this librarian.
	 *
	 * @return array
	 */
	public function getLibraryIds($onlyInternal = true)
	{
		$libraryIds = array();
		$libraryLinks = $this->getLLibraryLibrarians();
		/* @var $link LLibrarianLibrary */
		foreach ($libraryLinks as $link)
		{
			$library = $link->getLibrary();
			if (!is_null($library))
			{
				if ($onlyInternal)
				{
					if ($library->getLibraryInternal() == "1")
						$libraryIds[] = $library->getLibraryId();
				}
				else
					$libraryIds[] = $library->getLibraryId();
			}

		}

		return $libraryIds;
	}

	public function getRoles()
	{
		$q = AppProfileQuery::create()
			->useLLibrarianProfileQuery()
				->filterByLibrarianId($this->librarian_id)
			->endUse()
			->select('Role')
			->setFormatter('PropelSimpleArrayFormatter')
			->find();
		return $q->toArray();
	}

	public function getMinProfileId()
	{
		$profilesIds = $this->getProfileIds();
		if (is_array($profilesIds) && count($profilesIds) > 0)
			return min($profilesIds);
		else
			return '999';
	}

	/**
	 * It returns an array of profiles which are related to the librarian.
	 *
	 * @return array
	 */
	public function getProfileIds()
	{
		$profileIds = array();
		$criteria = new Criteria();
		$criteria->addAscendingOrderByColumn(LLibrarianProfilePeer::SORT_ORDER);
		$linkProfiles = $this->getLLibrarianProfiles($criteria);

		foreach ($linkProfiles as $linkProfile)
		{
			$profileId = $linkProfile->getProfileId();
			if ($profileId > 0)
				$profileIds[] = $profileId;
		}

		return $profileIds;
	}

	public function getProfileLabels()
	{
		$profileLabels = '';

		$criteria = new Criteria();
		$criteria->addAscendingOrderByColumn(LLibrarianProfilePeer::SORT_ORDER);
		$linkProfiles = $this->getLLibrarianProfiles($criteria);
		foreach ($linkProfiles as $linkProfile)
		{
			$pr = $linkProfile->getAppProfile();
			if (is_null($pr))
				return null;

			$label = $pr->getName();
			if ($label != '')
				$profileLabels .= $label . '/';
		}

		return rtrim($profileLabels, '/');
	}

	/**
	 *
	 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
	 * @link http://www.e-portaltech.it/
	 * @copyright Copyright &copy; 2006 ePortal Technologies
	 * @license http://www.e-portaltech.it/license/
	 *
	 *
	 */

	/**
	 * It initializes the criteria collection which are used when
	 * we call the function "getLLibraryLibrarian()", in case we
	 * update the table l_library_librarian and one "librarian"
	 * object gets stuck with the old set of links to it.
	 *
	 */
	public function forceReloadLLibraryLibrarian()
	{
		$this->lastLLibraryLibrarianCriteria = null;
	}

	/**
 	 * It performs an extraction of library objects according to the
	 * given parameters:
	 *
	 * @param int $currentPage			current page of grid
	 * @param int $pageSize				size of page (10, 20, ....)
	 * @param string $searchString		optional string which have to match a library.description
	 * @param boolean $except			if false, all libraries related to librarian are extracted,
	 * 									if true, we extract only the libraries which are NOT related
	 * 									to the librarian
	 * @param array $excludedIds		optional array of libraries whose ids are to be excluded
	 * @return array
	 */
	public function extractLLibraryLibrarian($currentPage,
												$pageSize,
												$searchString = '',

												$active = null,
												$external = null,
												$except = false,

												$excludedIds = null)
	{
		$c = new Criteria();
		$c->addAscendingOrderByColumn(LibraryPeer::LABEL);

		if ($pageSize > 0)
		{
			$c->setLimit($pageSize);
			$c->setOffset($currentPage * $pageSize);
		}
		if ($searchString)
			$c->add(LibraryPeer::DESCRIPTION, "%" . $searchString . "%", Criteria::LIKE);

		if (!is_null($active))
			$c->add(LibraryPeer::LIBRARY_STATUS , $active);

		if (!is_null($external))
		{
			if ($external === "1")
				$c->add(LibraryPeer::LIBRARY_INTERNAL, 1);

			if ($external === "0")
				$c->add(LibraryPeer::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);
		}

		if (is_array($excludedIds))
			$c->add(LibraryPeer::LIBRARY_ID, $excludedIds, Criteria::NOT_IN);

		$myLinks = $this->getLLibraryLibrarians();
		$myLibIds = array();

		foreach ($myLinks as $l)
			$myLibIds[] = $l->getLibraryId();

		$c->add(LibraryPeer::LIBRARY_ID, $myLibIds, ($except) ? Criteria::NOT_IN : Criteria::IN);
		$c->setDistinct();
		$libraries = LibraryPeer::doSelect($c);

		return $libraries;
	}

	/**
 	 * It performs a count of library objects according to the
	 * given parameters:
	 *
	 * @param string $searchString		optional string which have to match a library.description
	 * @param boolean $except			if false, all libraries related to librarian are counted,
	 * 									if true, we count only the libraries which are NOT related
	 * 									to the librarian
	 * @param array $excludedIds		optional array of libraries whose ids are to be excluded
	 * @return int
	 */
	public function countLLibraryLibrarian(	$searchString = '',
												$active = null,
												$external = null,

												$except = false,
												$excludedIds = null)
	{
		$c = new Criteria();
		//$criterion = $c->getNewCriterion(LibraryPeer::LIBRARY_ID, 0, Criteria::GREATER_THAN);

		if ($searchString !== '')
			$c->add(LibraryPeer::DESCRIPTION, "%" . $searchString . "%", Criteria::LIKE);

		if (!is_null($active))
			$c->add(LibraryPeer::LIBRARY_STATUS , $active);

		if (!is_null($external))
		{
			if ($external === "1")
				$c->add(LibraryPeer::LIBRARY_INTERNAL, 1);

			if ($external === "0")
				$c->add(LibraryPeer::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);
		}

		if ((is_array($excludedIds)) && (count($excludedIds) > 0))
			$c->add(LibraryPeer::LIBRARY_ID, $excludedIds, Criteria::NOT_IN);

		if ($except == true)
		{
			$excludedLibrariesObjects = $this->getLibraries();
			$excludedLibraries = array();
			foreach ($excludedLibrariesObjects as $library)
				$excludedLibraries[] = $library->getLibraryId();
			$c->add(LibraryPeer::LIBRARY_ID, $excludedLibraries, Criteria::NOT_IN );

			//$count = LibraryPeer::doCount($c, true);	// distinct
		}
		//else
		
		$lLibraryLibrarian = $this->getLLibraryLibrariansJoinLibrary($c, null, Criteria::INNER_JOIN);
		$count = count($lLibraryLibrarian);
		
		return $count;
	}

	/**
	 * It returns the id of the object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->librarian_id;
	}

	/**
	 * It returns the name+lastname of this object.
	 * If they are both existing, they'll be separated
	 * by a comma.
	 *
	 * @return string
	 */
	public function getCompleteName()
	{
		$name = trim($this->getName());
		$lastname = trim($this->getLastname());

		if ($name == '' && $lastname == '')
			return '(senza nome e cognome)';
		if ($name !== '' && $lastname !== '')
			$name = $name.' ';

		return $name . $lastname;
	}

	public function savePreferences($array = array())
	{
		if (count($array) > 0)
		{
			$value = serialize($array);
			$this->setPreferences($value);
		}
	}

	public function addToPreferences($index, $value)
	{
		$preferences = $this->getPreferences();
		if (is_array($preferences))
		{
			if (isset($preferences[$index]))
				$index = ((string) $index) . "bis";
			$preferences[$index] = $value;
			$this->savePreferences($preferences);
		}
	}

	public function loadPreferences()
	{
		if (count($preferences = $this->getPreferences()) > 0)
			$value = unserialize($this->getPreferences());
		else
			$value = array();
		return $value;
	}

	public function getLibrarianNote()
	{
		$preferences = $this->loadPreferences();
		if (isset($preferences['librarian_note']))
			return $preferences['librarian_note'];
		else
			return null;
	}


	public function setLibrarianNote($note)
	{
		$preferences = $this->loadPreferences();
		$preferences['librarian_note'] = $note;
		$this->savePreferences($preferences);
	}

	public function getShelfDescription()
	{
		$text = $this->getShelfDescriptionText();
		if ($text !== '')
			return $this->getShelfDescriptionLabel() . $text;
		else
			return '';
	}

	public function getShelfDescriptionLabel()
	{
		return 'nome: ';
	}

	public function getShelfDescriptionText()
	{
		return $this->getCompleteName();
	}

	public function getShelfUrl()
	{
		return 'Library.LibrarianViewPage&id=';
	}

	public function getNavigateUrl()
	{
		return 'index.php?page=Library.LibrarianViewPage&id=';
	}

	public function getObjectTypeString()
	{
		return "operatore";
	}

	public function getUrlPage()
	{
		return $this->getNavigateUrl();
	}

	public function getUrlName()
	{
		return $this->getShelfDescriptionText();
	}

	public function getPhotoFileId()
	{
		$photo = AttachmentQuery::create()
			->filterByObjectType('Librarian')
			->filterByObjectId($this->librarian_id)
			->filterByAttachmentType(AttachmentPeer::TYPE_PHOTO)
			->findOne();

		return ($photo instanceof Attachment) ? $photo->getAttachmentId() : '';
	}

	/**
	 * Get the associated Patron object (alias for getPatronRelatedByPatronId())
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Patron The associated Patron object.
	 * @throws     PropelException
	 */
	public function getPatron(PropelPDO $con = null)
	{
		return parent::getPatronRelatedByPatronId($con);
	}

	/**
	 * Declares an association between this object and a Patron object.
	 * (alias for setPatronRelatedByPatronId())
	 *
	 * @param      Patron $v
	 * @return     Librarian The current object (for fluent API support)
	 * @throws     PropelException
	 */
	public function setPatron(Patron $v = null)
	{
		return parent::setPatronRelatedByPatronId($v);
	}
} // Librarian
