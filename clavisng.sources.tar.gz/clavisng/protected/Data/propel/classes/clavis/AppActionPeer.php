<?php

  // include base peer class
  require_once 'clavis/om/BaseAppActionPeer.php';
  
  // include object class
  include_once 'clavis/AppAction.php';


class AppActionPeer extends BaseAppActionPeer {

} // AppActionPeer
