<?php

class AppProfileAclQuery extends BaseAppProfileAclQuery {

} // AppProfileAclQuery
