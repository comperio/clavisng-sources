<?php

  // include base peer class
  require_once 'clavis/om/BaseNotificationPeer.php';

  // include object class
  include_once 'clavis/Notification.php';

class NotificationPeer extends BaseNotificationPeer {

	const STATUS_PENDING	= 'A';
	const STATUS_SENT		= 'B';
	const STATUS_DELIVERED	= 'C';
	const STATUS_ERROR		= 'D';
	const STATUS_UNKNOWN	= 'E';

	const CHANNEL_SNAILMAIL = 'A';
	const CHANNEL_MOBILE = 'B';
	const CHANNEL_EMAIL = 'C';
	const CHANNEL_PHONE = 'D';
	const CHANNEL_FAX = 'E';
	const CHANNEL_IM = 'F';
	const CHANNEL_PORTAL = 'G';
	const CHANNEL_SMS = 'H';

	const OBJECTTYPE_LIBRARY	= 'library';
	const OBJECTTYPE_LIBRARIAN	= 'librarian';
	const OBJECTTYPE_PATRON		= 'patron';
	const OBJECTTYPE_SUPPLIER	= 'supplier';

	/**
	 * Adds a notification.
	 *
	 * @param string $channel
	 * @param int $sender_library_id
	 * @param string $receiver_class
	 * @param int $receiver_id
	 * @param string $description
	 * @param array $notes
	 * @return Notification The notification object.
	 */
	public static function addNewNotification($channel, $sender_library_id, $receiver_class,
			$receiver_id, $description = '', Array $notes = array())
	{
		$n = new Notification();
		$n->setNotificationState(self::STATUS_PENDING);
		$n->setSenderLibraryId($sender_library_id);
		$n->setObjectClass($receiver_class);
		$n->setObjectId(intval($receiver_id));
		$n->setNotificationChannel($channel);
		$n->setDeliveryDate(time());
		if ($description)
			$n->setMessage($description);
		if ($notes)
			$n->setNotes(serialize($notes));
		$n->save();
		/* further logic on specific notification channels */
		switch ($channel) {
			case self::CHANNEL_SMS:
				$notes['smsid'] = $n->getNotificationId() % 2147483647;
				$n->setNotes(serialize($notes));
				$n->save();
				break;
			default:
				break;
		}
		return $n;
	}

} // NotificationPeer
