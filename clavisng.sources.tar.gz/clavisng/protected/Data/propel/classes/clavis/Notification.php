<?php

require_once 'clavis/om/BaseNotification.php';


class Notification extends BaseNotification {

	/**
	 * It returns the id of the object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->notification_id;
	}

} // Notification
