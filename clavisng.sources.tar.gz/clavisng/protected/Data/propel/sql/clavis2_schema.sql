
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- address
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `address`;

CREATE TABLE `address`
(
    `address_id` INTEGER NOT NULL AUTO_INCREMENT,
    `patron_id` INTEGER NOT NULL,
    `address_type` CHAR(1),
    `address_pref` CHAR(1),
    `address_note` VARCHAR(255),
    `street_type` VARCHAR(255),
    `street` VARCHAR(255),
    `street_num` VARCHAR(255),
    `village` VARCHAR(255),
    `city` VARCHAR(255),
    `zip` VARCHAR(16),
    `province` VARCHAR(255),
    `country` VARCHAR(255),
    PRIMARY KEY (`address_id`),
    INDEX `address_FI_1` (`patron_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- app_action
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `app_action`;

CREATE TABLE `app_action`
(
    `action_id` INTEGER NOT NULL AUTO_INCREMENT,
    `sort_order` INTEGER NOT NULL,
    `label` VARCHAR(32),
    `page` VARCHAR(255),
    `module_id` VARCHAR(32),
    `menu_visible` CHAR(1) DEFAULT '1' NOT NULL,
    PRIMARY KEY (`action_id`),
    INDEX `app_action_FI_1` (`module_id`),
    CONSTRAINT `app_action_FK_1`
        FOREIGN KEY (`module_id`)
        REFERENCES `app_module` (`module_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- app_module
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `app_module`;

CREATE TABLE `app_module`
(
    `module_id` VARCHAR(32) NOT NULL,
    `sort_order` INTEGER NOT NULL,
    `label` VARCHAR(32) NOT NULL,
    `page` VARCHAR(255) NOT NULL,
    `always_view` TINYINT(1) DEFAULT 1 NOT NULL,
    PRIMARY KEY (`module_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- app_profile
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `app_profile`;

CREATE TABLE `app_profile`
(
    `profile_id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(32),
    `role` VARCHAR(32),
    `note` VARCHAR(255),
    PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- app_profile_acl
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `app_profile_acl`;

CREATE TABLE `app_profile_acl`
(
    `module_id` VARCHAR(32) NOT NULL,
    `action_id` INTEGER NOT NULL,
    `profile_id` INTEGER NOT NULL,
    `action` VARCHAR(32),
    PRIMARY KEY (`module_id`,`action_id`,`profile_id`),
    INDEX `app_profile_acl_FI_1` (`profile_id`),
    INDEX `app_profile_acl_FI_2` (`action_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- attachment
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `attachment`;

CREATE TABLE `attachment`
(
    `attachment_id` INTEGER NOT NULL AUTO_INCREMENT,
    `attachment_type` VARCHAR(8),
    `object_id` INTEGER,
    `object_type` VARCHAR(32),
    `mime_type` VARCHAR(128),
    `file_size` INTEGER,
    `file_path` VARCHAR(255),
    `file_label` VARCHAR(255),
    `license` CHAR(3),
    `file_description` TEXT,
    `file_name` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`attachment_id`),
    INDEX `attachment_idx` (`object_id`, `object_type`),
    INDEX `attachment_FI_1` (`created_by`),
    INDEX `attachment_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- authority
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `authority`;

CREATE TABLE `authority`
(
    `authority_id` INTEGER NOT NULL AUTO_INCREMENT,
    `non_sort_text` VARCHAR(255),
    `sort_text` VARCHAR(2000),
    `full_text` VARCHAR(2000),
    `authority_type` VARCHAR(5),
    `authority_subtype` CHAR(1),
    `authority_rectype` CHAR(1),
    `authority_status` CHAR(1),
    `unimarc` TEXT,
    `ext_data` TEXT,
    `authority_lang` CHAR(3),
    `authority_codlevel` CHAR(2),
    `parent_id` INTEGER,
    `subject_class` VARCHAR(32),
    `class_code` VARCHAR(32),
    `bid_source` VARCHAR(64),
    `bid` VARCHAR(64),
    `last_sbn_sync` DATETIME,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`authority_id`),
    UNIQUE INDEX `authority_U_1` (`bid_source`, `bid`),
    INDEX `sort_text_index` (`sort_text`(255)),
    INDEX `authority_type_index` (`authority_type`),
    INDEX `authority_fulltext` (`full_text`(255), `subject_class`),
    INDEX `class_code` (`class_code`),
    INDEX `authority_FI_3` (`parent_id`),
    INDEX `authority_FI_1` (`created_by`),
    INDEX `authority_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- budget
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `budget`;

CREATE TABLE `budget`
(
    `budget_id` INTEGER NOT NULL AUTO_INCREMENT,
    `library_id` INTEGER,
    `budget_title` VARCHAR(255),
    `budget_year` INTEGER,
    `start_validity` DATE,
    `end_validity` DATE,
    `total_amount` DECIMAL(10,2),
    `tolerance` DECIMAL(10,2),
    `budget_notes` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`budget_id`),
    INDEX `budget_FI_3` (`library_id`),
    INDEX `budget_FI_1` (`created_by`),
    INDEX `budget_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- budget_operation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `budget_operation`;

CREATE TABLE `budget_operation`
(
    `budget_id` INTEGER NOT NULL,
    `amount` DECIMAL(10,2),
    `operation_note` VARCHAR(255),
    `operation_date` DATE,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`budget_id`),
    INDEX `budget_operation_FI_1` (`created_by`),
    INDEX `budget_operation_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- bulletin
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `bulletin`;

CREATE TABLE `bulletin`
(
    `bulletin_id` INTEGER NOT NULL AUTO_INCREMENT,
    `publish_start_date` DATE,
    `publish_end_date` DATE,
    `title` VARCHAR(255),
    `body` TEXT,
    `scope` CHAR(1),
    `sticky` TINYINT(1) DEFAULT 0 NOT NULL,
    `protected_message` TINYINT(1) DEFAULT 0 NOT NULL,
    `librarian_id` INTEGER,
    `library_id` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`bulletin_id`),
    INDEX `bulletin_FI_3` (`library_id`),
    INDEX `bulletin_FI_4` (`librarian_id`),
    INDEX `bulletin_FI_1` (`created_by`),
    INDEX `bulletin_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- changelog
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `changelog`;

CREATE TABLE `changelog`
(
    `event_id` INTEGER NOT NULL AUTO_INCREMENT,
    `event_date` DATETIME,
    `event_description` VARCHAR(255),
    `event_type` VARCHAR(8),
    `object_id` INTEGER,
    `object_class` VARCHAR(64),
    `user_id` INTEGER,
    `user_class` VARCHAR(64),
    `session_id` INTEGER,
    `library_id` INTEGER,
    PRIMARY KEY (`event_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- clavis_param
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `clavis_param`;

CREATE TABLE `clavis_param`
(
    `param_name` VARCHAR(64) NOT NULL,
    `library_id` INTEGER DEFAULT 0 NOT NULL,
    `librarian_id` INTEGER DEFAULT 0 NOT NULL,
    `param_class` VARCHAR(64) NOT NULL,
    `param_value` VARCHAR(255),
    PRIMARY KEY (`param_name`,`library_id`,`librarian_id`,`param_class`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- consistency_note
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `consistency_note`;

CREATE TABLE `consistency_note`
(
    `consistency_note_id` INTEGER NOT NULL AUTO_INCREMENT,
    `collocation` VARCHAR(255) NOT NULL,
    `text_note` TEXT NOT NULL,
    `closed` TINYINT(1) DEFAULT 0 NOT NULL,
    `library_id` INTEGER NOT NULL,
    `manifestation_id` INTEGER NOT NULL,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`consistency_note_id`),
    INDEX `consistency_note_FI_3` (`library_id`),
    INDEX `consistency_note_FI_4` (`manifestation_id`),
    INDEX `consistency_note_FI_1` (`created_by`),
    INDEX `consistency_note_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- consortia
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `consortia`;

CREATE TABLE `consortia`
(
    `consortia_id` CHAR(7) NOT NULL,
    `description` VARCHAR(255),
    `label` VARCHAR(255),
    `token` VARCHAR(255),
    `info` TEXT,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`consortia_id`),
    INDEX `consortia_FI_1` (`created_by`),
    INDEX `consortia_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- contact
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `contact`;

CREATE TABLE `contact`
(
    `contact_id` INTEGER NOT NULL AUTO_INCREMENT,
    `patron_id` INTEGER NOT NULL,
    `contact_type` CHAR(1),
    `contact_value` VARCHAR(255),
    `contact_pref` CHAR(1),
    `contact_note` VARCHAR(255),
    PRIMARY KEY (`contact_id`),
    INDEX `contact_FI_1` (`patron_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- document_template
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `document_template`;

CREATE TABLE `document_template`
(
    `document_template_id` INTEGER NOT NULL AUTO_INCREMENT,
    `template_media` CHAR(1),
    `template_description` TEXT,
    `template_title` VARCHAR(255),
    `template_subject` VARCHAR(255),
    `template_body` TEXT,
    `template_class` VARCHAR(255),
    `template_lang` VARCHAR(16),
    `library_id` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`document_template_id`),
    INDEX `document_template_I_1` (`template_class`, `template_lang`, `library_id`),
    INDEX `document_template_FI_3` (`library_id`),
    INDEX `document_template_FI_1` (`created_by`),
    INDEX `document_template_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- ill_request
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ill_request`;

CREATE TABLE `ill_request`
(
    `ill_request_id` INTEGER NOT NULL AUTO_INCREMENT,
    `request_status` CHAR(1),
    `request_date` DATETIME,
    `from_library_id` INTEGER,
    `to_library_id` INTEGER,
    `patron_id` INTEGER,
    `request_key` VARCHAR(32),
    `librarian_id` INTEGER,
    `item_location` VARCHAR(64),
    `item_title` VARCHAR(2000),
    `start_loan_date` DATE,
    `due_date` DATE,
    `title` VARCHAR(2000),
    `unimarc` TEXT,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`ill_request_id`),
    INDEX `ill_request_FI_1` (`created_by`),
    INDEX `ill_request_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- import_source
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `import_source`;

CREATE TABLE `import_source`
(
    `name` VARCHAR(255) NOT NULL COMMENT 'The name (id) for the source',
    `label` VARCHAR(255) NOT NULL COMMENT 'The label to display to identify source',
    `driver` VARCHAR(255) NOT NULL COMMENT 'The driver the source will be using',
    `address` VARCHAR(255) COMMENT 'The URL to connect to',
    `enabled` TINYINT(1) DEFAULT 1 COMMENT 'Whether the source is enabled for use or not',
    `selected` TINYINT(1) DEFAULT 1 COMMENT 'Whether the source is selected by default',
    `timeout` INTEGER COMMENT 'The timeout for external answer',
    `encoding` VARCHAR(32) COMMENT 'The char encoding the source is using',
    `search_fields` TEXT COMMENT 'The fields enabled for searching',
    `syntax` VARCHAR(32) COMMENT 'The syntax for the source (if applicable)',
    `format` VARCHAR(32) COMMENT 'The format for the source (if applicable)',
    `turbomarc_conversion` TEXT COMMENT 'The turbomarc conversions to be applied (if applicable)',
    `options` TEXT COMMENT 'Driver\'s optional parameters, if needed',
    `default_catlevel` CHAR(2) COMMENT 'The default catlevel for new records imported',
    `sortable_rank` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`name`),
    INDEX `import_source_FI_1` (`created_by`),
    INDEX `import_source_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- inventory_serie
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `inventory_serie`;

CREATE TABLE `inventory_serie`
(
    `inventory_serie_id` VARCHAR(128) NOT NULL,
    `library_id` INTEGER NOT NULL,
    `description` VARCHAR(255),
    `inventory_counter` INTEGER,
    `closed` TINYINT(1),
    `readonly` TINYINT(1),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`inventory_serie_id`,`library_id`),
    INDEX `inventory_serie_FI_3` (`library_id`),
    INDEX `inventory_serie_FI_1` (`created_by`),
    INDEX `inventory_serie_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- invoice
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice`
(
    `invoice_id` INTEGER NOT NULL AUTO_INCREMENT,
    `invoice_status` CHAR(1),
    `supplier_id` INTEGER NOT NULL,
    `library_id` INTEGER NOT NULL,
    `budget_id` INTEGER NOT NULL,
    `invoice_date` DATE,
    `invoice_number` VARCHAR(64),
    `currier_price` DECIMAL(10,2),
    `accounted` TINYINT(1),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`invoice_id`),
    INDEX `invoice_FI_3` (`supplier_id`),
    INDEX `invoice_FI_4` (`library_id`),
    INDEX `invoice_FI_5` (`budget_id`),
    INDEX `invoice_FI_1` (`created_by`),
    INDEX `invoice_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- issue
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `issue`;

CREATE TABLE `issue`
(
    `issue_id` INTEGER NOT NULL AUTO_INCREMENT,
    `issue_number` VARCHAR(64),
    `start_number` INTEGER,
    `end_number` INTEGER,
    `issue_year` VARCHAR(4),
    `issue_volume` VARCHAR(255),
    `issue_note` VARCHAR(255),
    `issue_type` CHAR(1),
    `issue_date` DATE,
    `manifestation_id` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`issue_id`),
    INDEX `issue_FI_3` (`manifestation_id`),
    INDEX `issue_FI_1` (`created_by`),
    INDEX `issue_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- item
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item`
(
    `item_id` INTEGER NOT NULL AUTO_INCREMENT,
    `title` TEXT,
    `manifestation_id` INTEGER,
    `manifestation_dewey` CHAR(16),
    `item_media` CHAR(1),
    `item_status` CHAR(1),
    `item_order_status` CHAR(1),
    `item_icon` CHAR(3),
    `physical_status` CHAR(1),
    `item_source` CHAR(1),
    `opac_visible` TINYINT(1),
    `inventory_serie_id` VARCHAR(128) NOT NULL,
    `inventory_number` INTEGER,
    `inventory_date` DATE,
    `owner_library_id` INTEGER NOT NULL,
    `home_library_id` INTEGER NOT NULL,
    `collocation` VARCHAR(128),
    `section` VARCHAR(128),
    `sequence1` VARCHAR(128),
    `sequence2` VARCHAR(128),
    `specification` VARCHAR(128),
    `reprint` VARCHAR(64),
    `width` INTEGER,
    `height` INTEGER,
    `weight` DECIMAL(5,2),
    `volume_number` INTEGER,
    `volume_text` VARCHAR(128),
    `mediapackage_size` INTEGER DEFAULT 1 NOT NULL,
    `current_loan_id` INTEGER,
    `loan_class` CHAR(3),
    `last_seen` DATE,
    `loan_status` CHAR(1),
    `loan_alert` CHAR(1),
    `loan_alert_note` TEXT,
    `usage_count` INTEGER DEFAULT 0,
    `delivery_library_id` INTEGER,
    `due_date` DATE,
    `patron_id` INTEGER,
    `external_library_id` INTEGER,
    `renewal_count` INTEGER,
    `notify_count` INTEGER DEFAULT 0,
    `check_out` DATETIME,
    `check_in` DATETIME,
    `ill_timestamp` DATETIME,
    `supplier_id` INTEGER,
    `invoice_id` INTEGER,
    `order_id` INTEGER,
    `budget_id` INTEGER,
    `currency` VARCHAR(3),
    `currency_value` DECIMAL(10,2),
    `discount_value` DECIMAL(4,2),
    `inventory_value` DECIMAL(10,2),
    `issue_inventory_number` INTEGER,
    `issue_id` INTEGER,
    `issue_year` VARCHAR(4),
    `issue_number` INTEGER,
    `issue_description` VARCHAR(128),
    `issue_arrival_date` DATE,
    `issue_arrival_date_expected` DATE,
    `issue_status` CHAR(1),
    `subscription_id` INTEGER,
    `consistency_note_id` INTEGER,
    `actual_library_id` INTEGER,
    `barcode` VARCHAR(64),
    `rfid_code` VARCHAR(64),
    `custom_field1` VARCHAR(255),
    `custom_field2` VARCHAR(128),
    `custom_field3` VARCHAR(128),
    `unimarc` TEXT,
    `last_sbn_sync` DATETIME,
    `date_discarded` DATETIME,
    `discard_note` VARCHAR(256),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`item_id`),
    INDEX `Man_lastdate` (`inventory_date`, `manifestation_id`),
    INDEX `Igm_idx` (`inventory_date`, `item_media`, `item_source`, `owner_library_id`),
    INDEX `ownlib_status_idx` (`owner_library_id`, `item_status`),
    INDEX `idx_item_loanstatus` (`loan_status`),
    INDEX `item_issue_year_idx` (`issue_year`),
    INDEX `item_issue_number_idx` (`issue_number`),
    INDEX `item_barcode_idx` (`barcode`),
    INDEX `item_rfidcode_idx` (`rfid_code`),
    INDEX `item_request_speedup` (`manifestation_id`, `actual_library_id`, `loan_class`, `loan_status`),
    INDEX `item_FI_3` (`issue_id`),
    INDEX `item_FI_5` (`consistency_note_id`),
    INDEX `item_FI_7` (`home_library_id`),
    INDEX `item_FI_8` (`delivery_library_id`),
    INDEX `item_FI_9` (`actual_library_id`),
    INDEX `item_FI_10` (`inventory_serie_id`),
    INDEX `item_FI_11` (`order_id`),
    INDEX `item_FI_12` (`invoice_id`),
    INDEX `item_FI_13` (`supplier_id`),
    INDEX `item_FI_14` (`patron_id`),
    INDEX `item_FI_15` (`external_library_id`),
    INDEX `item_FI_16` (`current_loan_id`),
    INDEX `item_FI_17` (`budget_id`),
    INDEX `item_FI_1` (`created_by`),
    INDEX `item_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- item_action
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `item_action`;

CREATE TABLE `item_action`
(
    `item_action_id` INTEGER NOT NULL AUTO_INCREMENT,
    `library_id` INTEGER NOT NULL,
    `item_id` INTEGER,
    `patron_id` INTEGER,
    `external_library_id` INTEGER,
    `librarian_id` INTEGER,
    `action_type` CHAR(3),
    `action_date` DATETIME,
    `from_library_id` INTEGER,
    `to_library_id` INTEGER,
    `action_note` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`item_action_id`),
    INDEX `item_action_FI_3` (`item_id`),
    INDEX `item_action_FI_4` (`patron_id`),
    INDEX `item_action_FI_5` (`external_library_id`),
    INDEX `item_action_FI_6` (`library_id`),
    INDEX `item_action_FI_7` (`from_library_id`),
    INDEX `item_action_FI_8` (`to_library_id`),
    INDEX `item_action_FI_1` (`created_by`),
    INDEX `item_action_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- item_note
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `item_note`;

CREATE TABLE `item_note`
(
    `note_id` INTEGER NOT NULL AUTO_INCREMENT,
    `note_type` CHAR(3),
    `item_id` INTEGER,
    `note` TEXT,
    PRIMARY KEY (`note_id`),
    INDEX `item_note_FI_1` (`item_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- item_request
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `item_request`;

CREATE TABLE `item_request`
(
    `request_id` INTEGER NOT NULL AUTO_INCREMENT,
    `request_status` CHAR(1),
    `manifestation_id` INTEGER NOT NULL,
    `item_id` INTEGER,
    `issue_id` INTEGER,
    `patron_id` INTEGER,
    `external_library_id` INTEGER,
    `delivery_library_id` INTEGER,
    `max_distance` INTEGER,
    `librarian_id` INTEGER,
    `request_date` DATETIME,
    `expire_date` DATETIME,
    `request_note` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`request_id`),
    INDEX `item_request_I_1` (`request_status`, `expire_date`),
    INDEX `item_request_FI_3` (`librarian_id`),
    INDEX `item_request_FI_4` (`patron_id`),
    INDEX `item_request_FI_5` (`external_library_id`),
    INDEX `item_request_FI_6` (`manifestation_id`),
    INDEX `item_request_FI_7` (`item_id`),
    INDEX `item_request_FI_8` (`issue_id`),
    INDEX `item_request_FI_9` (`delivery_library_id`),
    INDEX `item_request_FI_1` (`created_by`),
    INDEX `item_request_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- librarian
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `librarian`;

CREATE TABLE `librarian`
(
    `librarian_id` INTEGER NOT NULL AUTO_INCREMENT,
    `patron_id` INTEGER,
    `name` VARCHAR(64),
    `lastname` VARCHAR(64),
    `birthdate` DATE,
    `phone` VARCHAR(16),
    `email` VARCHAR(64),
    `username` VARCHAR(32) NOT NULL,
    `secret` VARCHAR(32),
    `preferences` TEXT,
    `default_library_id` INTEGER,
    `cat_level` CHAR(2),
    `activation_status` CHAR(1),
    `note` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`librarian_id`),
    UNIQUE INDEX `librarian_U_1` (`username`),
    INDEX `librarian_FI_3` (`default_library_id`),
    INDEX `librarian_FI_4` (`patron_id`),
    INDEX `librarian_FI_1` (`created_by`),
    INDEX `librarian_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- librarian_session
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `librarian_session`;

CREATE TABLE `librarian_session`
(
    `librarian_session_id` INTEGER NOT NULL AUTO_INCREMENT,
    `librarian_id` INTEGER,
    `current_library_id` INTEGER,
    `session_id_string` VARCHAR(128),
    `start_date` DATETIME,
    `last_action_date` DATETIME,
    `end_date` DATETIME,
    `public_ip` VARCHAR(15),
    `local_ip` VARCHAR(15),
    PRIMARY KEY (`librarian_session_id`),
    INDEX `librarian_end_date` (`librarian_id`, `end_date`),
    INDEX `librarian_session_FI_2` (`current_library_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- librarian_task
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `librarian_task`;

CREATE TABLE `librarian_task`
(
    `task_id` INTEGER NOT NULL AUTO_INCREMENT,
    `task_title` VARCHAR(255),
    `task_note` TEXT,
    `library_id` INTEGER,
    `assigned_librarian_id` INTEGER,
    `due_date` DATETIME,
    `start_date` DATETIME,
    `end_date` DATETIME,
    `task_status` CHAR(1),
    `done_percent` INTEGER DEFAULT 0,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`task_id`),
    INDEX `task_duedate_idx` (`due_date`),
    INDEX `librarian_task_FI_3` (`assigned_librarian_id`),
    INDEX `librarian_task_FI_4` (`library_id`),
    INDEX `librarian_task_FI_1` (`created_by`),
    INDEX `librarian_task_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- library
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `library`;

CREATE TABLE `library`
(
    `library_id` INTEGER NOT NULL AUTO_INCREMENT,
    `library_class` VARCHAR(4),
    `consortia_id` CHAR(7) NOT NULL,
    `description` VARCHAR(255),
    `label` VARCHAR(255),
    `shortlabel` CHAR(16),
    `library_code` VARCHAR(8),
    `ill_code` VARCHAR(64),
    `sbn_code` CHAR(2),
    `library_type` CHAR(1),
    `library_internal` CHAR(1) DEFAULT '1' NOT NULL,
    `library_status` CHAR(1),
    `address` VARCHAR(255),
    `phone` VARCHAR(16),
    `fax` VARCHAR(16),
    `email` VARCHAR(128),
    `billing_address` VARCHAR(255),
    `website` VARCHAR(255),
    `city` VARCHAR(255),
    `province` VARCHAR(255),
    `country` VARCHAR(128),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`library_id`),
    INDEX `library_FI_3` (`consortia_id`),
    INDEX `library_FI_1` (`created_by`),
    INDEX `library_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- library_timetable
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `library_timetable`;

CREATE TABLE `library_timetable`
(
    `timetable_id` INTEGER NOT NULL AUTO_INCREMENT,
    `library_id` INTEGER NOT NULL,
    `timetable_day` DATE NOT NULL,
    `timetable_open` TINYINT(1) DEFAULT 0,
    `timetable_holiday` TINYINT(1) DEFAULT 0,
    `time1_start` TIME,
    `time1_end` TIME,
    `time2_start` TIME,
    `time2_end` TIME,
    `time3_start` TIME,
    `time3_end` TIME,
    `timetable_note` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`timetable_id`),
    INDEX `library_day` (`library_id`, `timetable_day`),
    INDEX `library_timetable_FI_1` (`created_by`),
    INDEX `library_timetable_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- library_value
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `library_value`;

CREATE TABLE `library_value`
(
    `value_key` VARCHAR(64) NOT NULL,
    `value_class` VARCHAR(64) NOT NULL,
    `value_library_id` INTEGER DEFAULT 0 NOT NULL,
    `value_label` VARCHAR(255),
    PRIMARY KEY (`value_key`,`value_class`,`value_library_id`),
    INDEX `library_value_FI_1` (`value_library_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- loan
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `loan`;

CREATE TABLE `loan`
(
    `loan_id` INTEGER NOT NULL AUTO_INCREMENT,
    `loan_status` CHAR(1),
    `loan_type` CHAR(1),
    `loan_class` CHAR(3),
    `manifestation_id` INTEGER,
    `item_id` INTEGER,
    `item_owner_library_id` INTEGER,
    `item_home_library_id` INTEGER,
    `itemrequest_id` INTEGER,
    `patron_id` INTEGER,
    `external_library_id` INTEGER,
    `destination_name` VARCHAR(255),
    `patron_age` INTEGER,
    `patron_city` VARCHAR(255),
    `patron_stat1` VARCHAR(16),
    `patron_stat2` VARCHAR(16),
    `patron_stat3` VARCHAR(16),
    `item_inventory_date` DATETIME,
    `item_stat1` VARCHAR(16),
    `item_stat2` VARCHAR(16),
    `item_stat3` VARCHAR(16),
    `loan_date1` DATETIME,
    `loan_date2` DATETIME,
    `loan_date3` DATETIME,
    `title` TEXT,
    `class_code` VARCHAR(16),
    `inv_number` VARCHAR(16),
    `collocation` VARCHAR(16),
    `item_media` CHAR(3),
    `mediapackage_size` INTEGER DEFAULT 1,
    `loan_date_begin` DATETIME,
    `loan_date_end` DATETIME,
    `due_date` DATETIME,
    `from_library` INTEGER,
    `to_library` INTEGER,
    `end_library` INTEGER,
    `renew_count` INTEGER DEFAULT 0,
    `notify_count` INTEGER DEFAULT 0,
    `notify_auto_count` INTEGER DEFAULT 0,
    PRIMARY KEY (`loan_id`),
    INDEX `FI__to_library` (`to_library`),
    INDEX `loan_loantype_idx` (`loan_type`),
    INDEX `idx_loan_loanstatus` (`loan_status`),
    INDEX `FI__loan_date_begin` (`loan_date_begin`),
    INDEX `loan_FI_1` (`manifestation_id`),
    INDEX `loan_FI_2` (`item_id`),
    INDEX `loan_FI_3` (`itemrequest_id`),
    INDEX `loan_FI_4` (`patron_id`),
    INDEX `loan_FI_5` (`external_library_id`),
    INDEX `loan_FI_6` (`from_library`),
    INDEX `loan_FI_8` (`end_library`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- loan_fee
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `loan_fee`;

CREATE TABLE `loan_fee`
(
    `fee_id` INTEGER NOT NULL AUTO_INCREMENT,
    `loan_id` INTEGER NOT NULL,
    `patron_id` INTEGER NOT NULL,
    `wallet_id` INTEGER,
    `fee_status` CHAR(1),
    `grace_days` INTEGER DEFAULT 0,
    `grace_note` VARCHAR(255),
    `note` VARCHAR(1024),
    `fee_class` CHAR(1),
    `total_ammount` DECIMAL,
    `real_ammount` DECIMAL,
    `library_id` INTEGER NOT NULL,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`fee_id`),
    INDEX `loan_fee_FI_3` (`loan_id`),
    INDEX `loan_fee_FI_4` (`patron_id`),
    INDEX `loan_fee_FI_5` (`wallet_id`),
    INDEX `loan_fee_FI_6` (`library_id`),
    INDEX `loan_fee_FI_1` (`created_by`),
    INDEX `loan_fee_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- lookup_value
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `lookup_value`;

CREATE TABLE `lookup_value`
(
    `value_key` VARCHAR(64) NOT NULL,
    `value_language` VARCHAR(6) NOT NULL,
    `value_class` VARCHAR(64) NOT NULL,
    `value_label` VARCHAR(255),
    `sortable_scope` VARCHAR(128),
    `sortable_rank` INTEGER,
    PRIMARY KEY (`value_key`,`value_language`,`value_class`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_authority
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_authority`;

CREATE TABLE `l_authority`
(
    `authority_id_down` INTEGER NOT NULL,
    `authority_id_up` INTEGER NOT NULL,
    `link_type` CHAR(3) NOT NULL,
    `relator_code` CHAR(3) NOT NULL,
    `link_sequence` VARCHAR(16),
    `link_note` TEXT,
    `source_sync` CHAR(1) DEFAULT '0',
    PRIMARY KEY (`authority_id_down`,`authority_id_up`,`link_type`,`relator_code`),
    INDEX `l_authority_FI_2` (`authority_id_up`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_authority_item
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_authority_item`;

CREATE TABLE `l_authority_item`
(
    `authority_id` INTEGER NOT NULL,
    `item_id` INTEGER NOT NULL,
    `link_type` INTEGER NOT NULL,
    `relator_code` CHAR(3) NOT NULL,
    `link_sequence` INTEGER,
    `link_note` VARCHAR(255),
    PRIMARY KEY (`authority_id`,`item_id`,`link_type`,`relator_code`),
    INDEX `l_authority_item_FI_2` (`item_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_authority_manifestation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_authority_manifestation`;

CREATE TABLE `l_authority_manifestation`
(
    `authority_id` INTEGER NOT NULL,
    `manifestation_id` INTEGER NOT NULL,
    `link_type` INTEGER NOT NULL,
    `relator_code` CHAR(3) NOT NULL,
    `link_sequence` INTEGER,
    `link_note` VARCHAR(255),
    `source_sync` CHAR(1) DEFAULT '0',
    PRIMARY KEY (`authority_id`,`manifestation_id`,`link_type`,`relator_code`),
    INDEX `l_authority_manifestation_FI_2` (`manifestation_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_librarian_profile
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_librarian_profile`;

CREATE TABLE `l_librarian_profile`
(
    `profile_id` INTEGER NOT NULL,
    `librarian_id` INTEGER NOT NULL,
    `sort_order` INTEGER,
    PRIMARY KEY (`profile_id`,`librarian_id`),
    INDEX `l_librarian_profile_FI_2` (`librarian_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_library_librarian
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_library_librarian`;

CREATE TABLE `l_library_librarian`
(
    `library_id` INTEGER NOT NULL,
    `librarian_id` INTEGER NOT NULL,
    `link_role` CHAR(3),
    `opac_visible` TINYINT(1),
    PRIMARY KEY (`library_id`,`librarian_id`),
    INDEX `l_library_librarian_FI_2` (`librarian_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_library
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_library`;

CREATE TABLE `l_library`
(
    `from_library_id` INTEGER NOT NULL,
    `to_library_id` INTEGER NOT NULL,
    `distance` INTEGER,
    PRIMARY KEY (`from_library_id`,`to_library_id`),
    INDEX `l_library_FI_2` (`to_library_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_manifestation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_manifestation`;

CREATE TABLE `l_manifestation`
(
    `manifestation_id_up` INTEGER NOT NULL,
    `manifestation_id_down` INTEGER NOT NULL,
    `link_type` INTEGER,
    `link_sequence` VARCHAR(16),
    `link_note` VARCHAR(255),
    `issue_id` INTEGER,
    `source_sync` CHAR(1) DEFAULT '0',
    PRIMARY KEY (`manifestation_id_up`,`manifestation_id_down`),
    INDEX `l_manifestation_FI_1` (`issue_id`),
    INDEX `l_manifestation_FI_3` (`manifestation_id_down`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_patron
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_patron`;

CREATE TABLE `l_patron`
(
    `parent_patron_id` INTEGER NOT NULL,
    `child_patron_id` INTEGER NOT NULL,
    `link_type` CHAR(2),
    PRIMARY KEY (`parent_patron_id`,`child_patron_id`),
    INDEX `l_patron_FI_2` (`child_patron_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- l_subject
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `l_subject`;

CREATE TABLE `l_subject`
(
    `authority_id` INTEGER NOT NULL,
    `subject_id` INTEGER NOT NULL,
    `position` INTEGER NOT NULL,
    `type` CHAR(1),
    `connector` VARCHAR(32),
    PRIMARY KEY (`authority_id`,`subject_id`,`position`),
    INDEX `lsubject_connector_idx` (`connector`),
    INDEX `l_subject_FI_2` (`subject_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- manifestation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `manifestation`;

CREATE TABLE `manifestation`
(
    `manifestation_id` INTEGER NOT NULL AUTO_INCREMENT,
    `bib_level` CHAR(1),
    `bib_type` CHAR(3),
    `bib_type_first` CHAR(3),
    `hierarchical_level` INTEGER,
    `catalogation_level` CHAR(2),
    `manifestation_status` CHAR(1),
    `edition_language` CHAR(3),
    `edition_date` INTEGER,
    `unimarc` MEDIUMTEXT,
    `bid_source` VARCHAR(64),
    `bid` VARCHAR(64),
    `ISBNISSN` VARCHAR(32),
    `EAN` VARCHAR(32),
    `non_sort_text` VARCHAR(128),
    `sort_text` VARCHAR(255),
    `title` VARCHAR(2000),
    `author` VARCHAR(1000),
    `publisher` VARCHAR(1000),
    `loanable_since` DATETIME,
    `rating` INTEGER,
    `last_sbn_sync` DATETIME,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`manifestation_id`),
    INDEX `man_bid_idx` (`bid_source`, `bid`),
    INDEX `edition_language_idx` (`edition_language`),
    INDEX `man_isbn_idx` (`ISBNISSN`),
    INDEX `man_ean_idx` (`EAN`),
    INDEX `man_sort_text_idx` (`sort_text`),
    INDEX `manifestation_FI_1` (`created_by`),
    INDEX `manifestation_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- notification
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification`
(
    `notification_id` INTEGER NOT NULL AUTO_INCREMENT,
    `notification_state` CHAR(1),
    `notification_channel` CHAR(1),
    `object_class` VARCHAR(64),
    `object_id` INTEGER,
    `sender_library_id` INTEGER,
    `delivery_date` DATETIME,
    `acknowledge_date` DATETIME,
    `internal_status` VARCHAR(32),
    `message` TEXT,
    `notes` TEXT,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`notification_id`),
    INDEX `notification_FI_3` (`sender_library_id`),
    INDEX `notification_FI_1` (`created_by`),
    INDEX `notification_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- patron
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `patron`;

CREATE TABLE `patron`
(
    `patron_id` INTEGER NOT NULL AUTO_INCREMENT,
    `registration_library_id` INTEGER NOT NULL,
    `preferred_library_id` INTEGER NOT NULL,
    `gender` CHAR(1),
    `title` VARCHAR(64),
    `name` VARCHAR(255),
    `lastname` VARCHAR(255 ),
    `civil_status` CHAR(1),
    `national_id` VARCHAR(64),
    `document_type` VARCHAR(64),
    `document_number` VARCHAR(64),
    `document_emitter` VARCHAR(64),
    `document_expiry` DATE,
    `citizenship` VARCHAR(64),
    `patron_status` CHAR(1),
    `birth_date` DATE,
    `birth_city` VARCHAR(255),
    `birth_province` VARCHAR(255),
    `birth_country` VARCHAR(255),
    `patron_note` TEXT,
    `loan_class` CHAR(1),
    `card_code` VARCHAR(64),
    `barcode` VARCHAR(64),
    `rfid_code` VARCHAR(64),
    `card_expire` DATE,
    `max_loans` INTEGER,
    `surf_enable` CHAR(1),
    `opac_username` VARCHAR(64),
    `opac_secret` CHAR(40),
    `voice_enable` CHAR(1),
    `voice_pin` VARCHAR(8),
    `opac_enable` CHAR(1),
    `privacy_approve` CHAR(1),
    `areas_of_interest` TEXT,
    `biography` TEXT,
    `access_note` VARCHAR(255),
    `access_alert` CHAR(1),
    `statistic_study` CHAR(1),
    `statistic_work` CHAR(1),
    `last_seen` DATETIME,
    `custom1` VARCHAR(255),
    `custom2` VARCHAR(255),
    `custom3` VARCHAR(255),
    `check_in` DATETIME,
    `check_out` DATETIME,
    `check_library` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`patron_id`),
    UNIQUE INDEX `patron_U_1` (`barcode`),
    INDEX `patron_barcode_idx` (`barcode`),
    INDEX `patron_crdcode_idx` (`card_code`),
    INDEX `patron_rfidcode_idx` (`rfid_code`),
    INDEX `patron_username_idx` (`opac_username`),
    INDEX `patron_firstname_idx` (`name`),
    INDEX `patron_lastname_idx` (`lastname`),
    INDEX `check_out_idx` (`check_out`),
    INDEX `patron_FI_3` (`registration_library_id`),
    INDEX `patron_FI_4` (`preferred_library_id`),
    INDEX `patron_FI_5` (`check_library`),
    INDEX `patron_FI_1` (`created_by`),
    INDEX `patron_FI_2` (`modified_by`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- patron_action
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `patron_action`;

CREATE TABLE `patron_action`
(
    `action_id` INTEGER NOT NULL AUTO_INCREMENT,
    `patron_id` INTEGER NOT NULL,
    `library_id` INTEGER,
    `action_type` CHAR(3),
    `action_date` DATETIME,
    `action_note` TEXT,
    `action_key` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`action_id`),
    INDEX `patron_action_FI_3` (`patron_id`),
    INDEX `patron_action_FI_4` (`library_id`),
    INDEX `patron_action_FI_1` (`created_by`),
    INDEX `patron_action_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- patron_property
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `patron_property`;

CREATE TABLE `patron_property`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `patron_id` INTEGER NOT NULL,
    `property_class` CHAR(1) NOT NULL,
    `property_value` VARCHAR(255) NOT NULL,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`id`),
    INDEX `patron_idx` (`patron_id`),
    INDEX `class_idx` (`property_class`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- patron_wallet
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `patron_wallet`;

CREATE TABLE `patron_wallet`
(
    `wallet_id` INTEGER NOT NULL AUTO_INCREMENT,
    `patron_id` INTEGER,
    `library_id` INTEGER NOT NULL,
    `wallet_action` CHAR(1),
    `wallet_type` CHAR(1),
    `wallet_status` CHAR(1),
    `amount` DECIMAL(10,2) NOT NULL,
    `wallet_note` VARCHAR(255),
    `date_closed` DATE,
    `receipt_id` VARCHAR(16),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`wallet_id`),
    UNIQUE INDEX `receipt_idx` (`receipt_id`, `library_id`),
    INDEX `patron_wallet_FI_3` (`patron_id`),
    INDEX `patron_wallet_FI_4` (`library_id`),
    INDEX `patron_wallet_FI_1` (`created_by`),
    INDEX `patron_wallet_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- purchase_order
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `purchase_order`;

CREATE TABLE `purchase_order`
(
    `order_id` INTEGER NOT NULL AUTO_INCREMENT,
    `library_id` INTEGER,
    `supplier_id` INTEGER,
    `account_id` VARCHAR(32),
    `order_title` VARCHAR(255),
    `order_date` DATE,
    `delivery_date` DATE,
    `order_discount` DECIMAL(4,2),
    `order_type` CHAR(1),
    `order_status` CHAR(1),
    `order_note` TEXT,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`order_id`),
    INDEX `purchase_order_FI_3` (`library_id`),
    INDEX `purchase_order_FI_4` (`supplier_id`),
    INDEX `purchase_order_FI_1` (`created_by`),
    INDEX `purchase_order_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- purchase_proposal
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `purchase_proposal`;

CREATE TABLE `purchase_proposal`
(
    `proposal_id` INTEGER NOT NULL AUTO_INCREMENT,
    `patron_id` INTEGER NOT NULL,
    `author` VARCHAR(255),
    `title` VARCHAR(255),
    `publisher` VARCHAR(255),
    `year` INTEGER,
    `notes` VARCHAR(255),
    `librarian_notes` VARCHAR(255),
    `status` CHAR(1),
    `ean` VARCHAR(255),
    `rda` VARCHAR(255),
    `item_id` INTEGER,
    `proposal_date` DATETIME,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`proposal_id`),
    INDEX `proposal_patron_index` (`patron_id`),
    INDEX `purchase_proposal_FI_4` (`item_id`),
    INDEX `purchase_proposal_FI_1` (`created_by`),
    INDEX `purchase_proposal_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- resource
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `resource`;

CREATE TABLE `resource`
(
    `resource_id` INTEGER NOT NULL AUTO_INCREMENT,
    `resource_id1` VARCHAR(3),
    `resource_id2` VARCHAR(3),
    `resource_label` VARCHAR(255),
    `library_id` INTEGER NOT NULL,
    `resource_class` CHAR(1),
    `resource_status` CHAR(1),
    `resource_free` TINYINT(1),
    `sessiontime_max` INTEGER,
    `sessiontime_max_day` INTEGER,
    `sessiontime_max_week` INTEGER,
    `sessiontime_between` INTEGER,
    `resource_note` VARCHAR(255),
    PRIMARY KEY (`resource_id`),
    INDEX `resource_FI_1` (`library_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- resource_request
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `resource_request`;

CREATE TABLE `resource_request`
(
    `resource_request_id` INTEGER NOT NULL AUTO_INCREMENT,
    `resource_id` INTEGER NOT NULL,
    `resource_action` CHAR(1),
    `patron_id` INTEGER,
    `request_note` VARCHAR(255),
    `request_start` DATETIME,
    `request_end` DATETIME,
    `time_tolerance` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`resource_request_id`),
    INDEX `resource_request_FI_3` (`resource_id`),
    INDEX `resource_request_FI_4` (`patron_id`),
    INDEX `resource_request_FI_1` (`created_by`),
    INDEX `resource_request_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- resource_session
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `resource_session`;

CREATE TABLE `resource_session`
(
    `resource_session_id` INTEGER NOT NULL AUTO_INCREMENT,
    `resource_id` INTEGER NOT NULL,
    `resource_action` CHAR(1),
    `patron_id` INTEGER,
    `session_note` VARCHAR(255),
    `session_start` DATETIME,
    `session_end` DATETIME,
    PRIMARY KEY (`resource_session_id`),
    INDEX `resource_session_FI_1` (`resource_id`),
    INDEX `resource_session_FI_2` (`patron_id`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- robot
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `robot`;

CREATE TABLE `robot`
(
    `robot_id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(32),
    `note` VARCHAR(255),
    `object` VARCHAR(255),
    `robot_state` CHAR(1),
    `script` VARCHAR(255),
    `sort_order` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`robot_id`),
    INDEX `robot_FI_1` (`created_by`),
    INDEX `robot_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- shelf
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `shelf`;

CREATE TABLE `shelf`
(
    `shelf_id` INTEGER NOT NULL AUTO_INCREMENT,
    `shelf_name` VARCHAR(255),
    `shelf_description` TEXT,
    `shelf_status` CHAR(1),
    `shelf_itemtype` VARCHAR(64),
    `librarian_id` INTEGER NOT NULL,
    `library_id` INTEGER NOT NULL,
    `sortable_rank` INTEGER,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`shelf_id`),
    INDEX `itemtype_idx` (`shelf_itemtype`),
    INDEX `shelf_FI_3` (`library_id`),
    INDEX `shelf_FI_4` (`librarian_id`),
    INDEX `shelf_FI_1` (`created_by`),
    INDEX `shelf_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- shelf_item
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `shelf_item`;

CREATE TABLE `shelf_item`
(
    `shelf_id` INTEGER NOT NULL,
    `object_id` INTEGER NOT NULL,
    `object_class` VARCHAR(32) NOT NULL,
    `item_status` CHAR(1),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`shelf_id`,`object_id`,`object_class`),
    INDEX `object_idx` (`object_id`, `object_class`, `shelf_id`),
    INDEX `shelf_item_FI_1` (`created_by`),
    INDEX `shelf_item_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- subscription
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `subscription`;

CREATE TABLE `subscription`
(
    `subscription_id` INTEGER NOT NULL AUTO_INCREMENT,
    `library_id` INTEGER NOT NULL,
    `manifestation_id` INTEGER NOT NULL,
    `supplier_id` INTEGER,
    `budget_id` INTEGER,
    `year` INTEGER,
    `volume` INTEGER,
    `frequence` CHAR(1),
    `tolerance` INTEGER,
    `start_date` DATE,
    `end_date` DATE,
    `subscription_status` CHAR(1),
    `subscription_type` CHAR(1),
    `ejournal_provider` INTEGER,
    `management` CHAR(1),
    `payment` TEXT,
    `notes` VARCHAR(255),
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`subscription_id`),
    INDEX `subscription_FI_3` (`library_id`),
    INDEX `subscription_FI_4` (`manifestation_id`),
    INDEX `subscription_FI_5` (`supplier_id`),
    INDEX `subscription_FI_6` (`budget_id`),
    INDEX `subscription_FI_1` (`created_by`),
    INDEX `subscription_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- supplier
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier`
(
    `supplier_id` INTEGER NOT NULL AUTO_INCREMENT,
    `supplier_name` VARCHAR(255),
    `supplier_code` VARCHAR(32),
    `vat_code` VARCHAR(64),
    `supplier_status` CHAR(1),
    `payment_mode` CHAR(1),
    `cc` VARCHAR(255),
    `phone_number` VARCHAR(24),
    `phone_number2` VARCHAR(24),
    `fax_number` VARCHAR(24),
    `email` VARCHAR(128),
    `contact_name` VARCHAR(255),
    `address` VARCHAR(255),
    `province` VARCHAR(255),
    `city` VARCHAR(255),
    `country` VARCHAR(64),
    `zipcode` INTEGER,
    `discount` DECIMAL(5,2),
    `notes` TEXT,
    `date_created` DATETIME,
    `date_updated` DATETIME,
    `created_by` INTEGER,
    `modified_by` INTEGER,
    PRIMARY KEY (`supplier_id`),
    INDEX `supplier_FI_1` (`created_by`),
    INDEX `supplier_FI_2` (`modified_by`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- turbomarc_cache
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `turbomarc_cache`;

CREATE TABLE `turbomarc_cache`
(
    `manifestation_id` INTEGER NOT NULL,
    `turbomarc` LONGTEXT,
    `dirty` TINYINT(1),
    `indexed` TINYINT(1),
    `deleted` TINYINT(1),
    PRIMARY KEY (`manifestation_id`),
    INDEX `dirty_idx` (`dirty`),
    INDEX `indexed` (`indexed`),
    INDEX `deleted` (`deleted`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- turbomarcauthority_cache
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `turbomarcauthority_cache`;

CREATE TABLE `turbomarcauthority_cache`
(
    `authority_id` INTEGER NOT NULL,
    `turbomarc` LONGTEXT,
    `dirty` TINYINT(1),
    `indexed` TINYINT(1),
    `deleted` TINYINT(1),
    PRIMARY KEY (`authority_id`),
    INDEX `dirty_idx` (`dirty`),
    INDEX `indexed` (`indexed`),
    INDEX `deleted` (`deleted`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- unimarc_codes
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `unimarc_codes`;

CREATE TABLE `unimarc_codes`
(
    `language` VARCHAR(8) NOT NULL,
    `field_number` INTEGER NOT NULL,
    `subfield_tag` CHAR(1) NOT NULL,
    `pos` DECIMAL(2) NOT NULL,
    `group_label` VARCHAR(128) NOT NULL,
    `code_value` VARCHAR(4) NOT NULL,
    `unimarc_type` CHAR(1) NOT NULL,
    `field_length` CHAR(3) NOT NULL,
    `label` VARCHAR(128) NOT NULL,
    `help` TEXT NOT NULL,
    PRIMARY KEY (`language`,`field_number`,`subfield_tag`,`pos`,`code_value`,`unimarc_type`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

-- ---------------------------------------------------------------------
-- unimarc_labels
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `unimarc_labels`;

CREATE TABLE `unimarc_labels`
(
    `language` VARCHAR(8) NOT NULL,
    `field_number` INTEGER NOT NULL,
    `subfield_tag` CHAR(1) NOT NULL,
    `unimarc_type` CHAR(1) NOT NULL,
    `label` VARCHAR(128) NOT NULL,
    `note` TEXT NOT NULL,
    `maxlength` INTEGER,
    `mandatory` TINYINT(1),
    `multiple` TINYINT(1),
    `cdf` TINYINT(1),
    PRIMARY KEY (`language`,`field_number`,`subfield_tag`,`unimarc_type`)
) ENGINE=InnoDB CHARACTER SET='utf8' COLLATE='utf8_unicode_ci';

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
