<?php
/**
 * site-conf-default.php
 *
 * This file is for extending and customizing ClavisNG behaviors.
 * Copy into sites/<site>/site-conf.php for per-site customizations.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2013 Comperio srl
 * @package Core
 */