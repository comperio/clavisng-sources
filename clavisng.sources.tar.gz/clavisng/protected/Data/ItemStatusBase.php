<?php
/**
 * ItemStatusBase file class
 *
 * Extend this class to ItemStatus in custom sites/<site>/site-conf.php
 * for per-site customizations.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2012 Comperio srl
 * @version 2.7
 * @package Core
 * @since 2.6.5
 */
require_once('protected/Interfaces/ItemStatusInterface.php');

/**
 * ItemStatusBase class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @package Core
 * @since 2.6
*/
class ItemStatusBase implements ItemStatusInterface
{
	const ITEMSTATUS_INORDER		= 'A';
	const ITEMSTATUS_INCATALOGATION	= 'B';
	const ITEMSTATUS_CORRUPTED		= 'C';
	const ITEMSTATUS_TODISCARD		= 'D';
	const ITEMSTATUS_DISCARDED		= 'E';
	const ITEMSTATUS_ONSHELF		= 'F';
	const ITEMSTATUS_INDEPOSIT		= 'G';
	const ITEMSTATUS_LOST			= 'H';
	const ITEMSTATUS_NEW				= 'K';
	const ITEMSTATUS_ORDERDONE			= 'L';
	const ITEMSTATUS_ORDERNULL			= 'M';
	const ITEMSTATUS_LOSTTOCHANGE		= 'N';
	const ITEMSTATUS_LOSTTODROP			= 'O';
	const ITEMSTATUS_TODISCARDANDCHANGE	= 'P';
	const ITEMSTATUS_TOCOPY				= 'Q';
	const ITEMSTATUS_CONSERVATION		= 'R';
	const ITEMSTATUS_NOTFOUNDTOSEARCH	= 'S';
	const ITEMSTATUS_EXPOSED			= 'V';
	const ITEMSTATUS_ONDELIVER			= 'W';
	
	const ITEMORDERSTATUS_INORDER		= 'A';
	const ITEMORDERSTATUS_ORDERDONE		= 'L';
	const ITEMORDERSTATUS_ORDERNULL		= 'M';
	const ITEMORDERSTATUS_NOORDER		= 'N';

	public static function getItemStatusLost()
	{
		return array(
			self::ITEMSTATUS_LOST,
			self::ITEMSTATUS_LOSTTOCHANGE,
			self::ITEMSTATUS_LOSTTODROP,
			self::ITEMSTATUS_NOTFOUNDTOSEARCH);
	}

	public static function getItemStatusVisible()
	{
		return array(
			self::ITEMSTATUS_INORDER,
			self::ITEMSTATUS_INCATALOGATION,
			self::ITEMSTATUS_CORRUPTED,
			self::ITEMSTATUS_TODISCARD,
			self::ITEMSTATUS_ONSHELF,
			self::ITEMSTATUS_INDEPOSIT,
			self::ITEMSTATUS_LOST,
			self::ITEMSTATUS_NEW,
			self::ITEMSTATUS_ORDERDONE,
			self::ITEMSTATUS_ORDERNULL,
			self::ITEMSTATUS_LOSTTOCHANGE,
			self::ITEMSTATUS_LOSTTODROP,
			self::ITEMSTATUS_TODISCARDANDCHANGE,
			self::ITEMSTATUS_TOCOPY,
			self::ITEMSTATUS_CONSERVATION,
			self::ITEMSTATUS_NOTFOUNDTOSEARCH,
            self::ITEMSTATUS_EXPOSED,
			self::ITEMSTATUS_ONDELIVER);
	}

	public static function getItemStatusOpacVisible() {
		return array(
			self::ITEMSTATUS_INORDER,
			self::ITEMSTATUS_INCATALOGATION,
			self::ITEMSTATUS_CORRUPTED,
			self::ITEMSTATUS_TODISCARD,
			self::ITEMSTATUS_ONSHELF,
			self::ITEMSTATUS_INDEPOSIT,
			self::ITEMSTATUS_NEW,
			self::ITEMSTATUS_ORDERDONE,
			self::ITEMSTATUS_TODISCARDANDCHANGE,
			self::ITEMSTATUS_TOCOPY,
			self::ITEMSTATUS_CONSERVATION,
			self::ITEMSTATUS_EXPOSED);
	}

	public static function getItemStatusManageable()
	{
		return array(
			self::ITEMSTATUS_ONSHELF,
			self::ITEMSTATUS_INDEPOSIT,
			self::ITEMSTATUS_NEW,
			self::ITEMSTATUS_EXPOSED);
	}

	public static function getItemStatusNotAvailable()
	{
		return array(
			self::ITEMSTATUS_INORDER,
			self::ITEMSTATUS_INCATALOGATION,
			self::ITEMSTATUS_DISCARDED,
			self::ITEMSTATUS_LOST,
			self::ITEMSTATUS_ORDERDONE,
			self::ITEMSTATUS_ORDERNULL,
			self::ITEMSTATUS_LOSTTOCHANGE,
			self::ITEMSTATUS_LOSTTODROP,
			self::ITEMSTATUS_NOTFOUNDTOSEARCH,
			self::ITEMSTATUS_ONDELIVER);
	}
}