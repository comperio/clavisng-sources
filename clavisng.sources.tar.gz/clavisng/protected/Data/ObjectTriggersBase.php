<?php
/**
 * ObjectTriggersBase file class
 *
 * Extend this class to ObjectTriggers in custom sites/<site>/site-conf.php
 * for per-site customizations.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2012 Comperio srl
 * @version 2.7
 * @package Core
 * @since 2.5.2
 */

/**
 * ObjectTriggersBase class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @package Core
 * @since 2.5.2
 */
class ObjectTriggersBase {

	public static $_issue_nestId = array();

	public static function onItemUpdate(Item $item)
	{
		// update cascade related issues
		if ($item->getIssueId() > 0)
		{
			if (array_key_exists('issueStatus', $item->_oldValues) &&
				in_array($item->_oldValues['issueStatus'], array(ItemPeer::ISSUESTATUS_EXPECTED, ItemPeer::ISSUESTATUS_NEXT)) &&
				in_array($item->getIssueStatus(), array(ItemPeer::ISSUESTATUS_ARRIVED, ItemPeer::ISSUESTATUS_LAST)))
			{
				// an expected issue arrived, so
				// 1. set all issues expecting early as "missing"
				// 2. set the last arrived in the year as "last arrived"
				// 3. set the next expected in the year as "next"
				// 4. set all "arrived" but the last to loan class "not available"

				$selectCriteria = new Criteria();
				$updateCriteria = new Criteria();

				$arrivalDate = $item->getIssueArrivalDate('U');
				if (!$arrivalDate)
					$arrivalDate = time();
				$updateCriteria->add(ItemPeer::ISSUE_STATUS, ItemPeer::ISSUESTATUS_MISSING);

				$selectCriteria->add(ItemPeer::MANIFESTATION_ID, $item->getManifestationId());
				$selectCriteria->addAnd(ItemPeer::ISSUE_YEAR, $item->getIssueYear());
				$selectCriteria->addAnd(ItemPeer::ISSUE_STATUS, array(ItemPeer::ISSUESTATUS_EXPECTED, ItemPeer::ISSUESTATUS_NEXT), Criteria::IN);
				$selectCriteria->add(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED, $arrivalDate, Criteria::LESS_THAN);
				BasePeer::doUpdate($selectCriteria, $updateCriteria, Propel::getConnection());

				$selectCriteria->clear();
				$selectCriteria->add(ItemPeer::MANIFESTATION_ID, $item->getManifestationId());
				$selectCriteria->addAnd(ItemPeer::ISSUE_YEAR, $item->getIssueYear());
				$selectCriteria->addAnd(ItemPeer::ISSUE_STATUS, array(ItemPeer::ISSUESTATUS_ARRIVED, ItemPeer::ISSUESTATUS_LAST), Criteria::IN);
				$updateCriteria->clear();
				$updateCriteria->add(ItemPeer::ISSUE_STATUS, ItemPeer::ISSUESTATUS_ARRIVED);
				$updateCriteria->add(ItemPeer::LOAN_CLASS, 'B');
				BasePeer::doUpdate($selectCriteria, $updateCriteria, Propel::getConnection());

				$selectCriteria->addDescendingOrderByColumn(ItemPeer::ISSUE_ARRIVAL_DATE);
				$last = ItemPeer::doSelectOne($selectCriteria);
				if ($last instanceof Item)
				{
					$last->setIssueStatus(ItemPeer::ISSUESTATUS_LAST);
					$last->setLoanClass('A');
					$last->save();
				}

				$selectCriteria->clear();
				$selectCriteria->add(ItemPeer::MANIFESTATION_ID, $item->getManifestationId());
				$selectCriteria->addAnd(ItemPeer::ISSUE_YEAR, $item->getIssueYear());
				$selectCriteria->addAnd(ItemPeer::ISSUE_STATUS, array(ItemPeer::ISSUESTATUS_NEXT, ItemPeer::ISSUESTATUS_EXPECTED), Criteria::IN);
				$updateCriteria->clear();
				$updateCriteria->add(ItemPeer::ISSUE_STATUS, ItemPeer::ISSUESTATUS_EXPECTED);
				BasePeer::doUpdate($selectCriteria, $updateCriteria, Propel::getConnection());

				$selectCriteria->addAscendingOrderByColumn(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED);
				$next = ItemPeer::doSelectOne($selectCriteria);
				if ($next instanceof Item)
				{
					$next->setIssueStatus(ItemPeer::ISSUESTATUS_NEXT);
					$next->save();
				}
			}
		}
		return true;
	}

	public function onIssueUpdate(Issue $issue)
	{
		self::$_issue_nestId[] = $issue->getIssueId();
		/* if start number has changed, chain update */
		if (array_key_exists('startNumber',$issue->_oldValues) &&
			$issue->getStartNumber() > $issue->_oldValues['startNumber']) {
			$delta = $issue->getStartNumber() - $issue->_oldValues['startNumber'];
			$issueQuery = IssueQuery::create()
				->filterByIssueId(self::$_issue_nestId, Criteria::NOT_IN)
				->filterByManifestationId($issue->getManifestationId())
				->filterByIssueYear($issue->getIssueYear())
				->filterByStartNumber($issue->_oldValues['startNumber'], Criteria::GREATER_THAN);
			if ($issue->getIssueVolume())
				$issueQuery->filterByIssueVolume($issue->getIssueVolume());
			$i = $issueQuery->orderByStartNumber()->findOne();
			if ($i instanceof Issue) {
				$sn = $i->getStartNumber();
				$en = $i->getEndNumber();
				$i->setStartNumber($sn + $delta);
				$i->setEndNumber($en + $delta);
				$i->save();
				$i->clearAllReferences(true);
			}
		}

		/* update issue, delete middle ones */
		/// DEACTIVATED
		/*$toDelete = IssueQuery::create()
			->filterByManifestationId($issue->getManifestationId())
			->filterByIssueYear($issue->getIssueYear())
			->filterByStartNumber($issue->getStartNumber(),Criteria::GREATER_EQUAL)
			->filterByStartNumber($issue->getEndNumber(),Criteria::LESS_EQUAL)
			->prune($issue);
		if ($issue->getIssueVolume())
			$toDelete->filterByIssueVolume($issue->getIssueVolume());

		$issues = $toDelete->find();
		foreach ($issues as $i) {
			try {
				$i->delete();
				if ($i->isDeleted())
					ChangelogPeer::logAction($i, ChangelogPeer::LOG_DELETE,
						null, '[AUTO] eliminato fascicolo '.$i->getIssueCombo());
				$i->clearAllReferences(true);
			} catch (Exception $e) {
				Prado::log(Prado::varDump($e));
			}
		}*/

		$issue->updateLinkedItems();
		return true;
	}
}