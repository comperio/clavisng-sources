<?php

/**
 * Acquisition.InvoiceListPage Page class Module Acquisition
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class InvoiceListPage extends ClavisPage {
	
	public $_module = 'ACQUISITION';
	
	
	public function globalRefresh()
	{
		$this->InvoiceList->populate();
	}

	public function globalEditCancel()
	{

		
	}
	
}
