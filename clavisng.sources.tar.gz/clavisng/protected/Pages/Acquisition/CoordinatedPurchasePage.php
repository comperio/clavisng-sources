<?php

/**
 * CoordinatedPurchasePage
 *
 * Page intended for coordinate purchases of items through orders of manifestations.
 * Its purpose is to see what other librarians (in other biblios)
 * are ordering, and the numbers .........
 * 
 * And here we can modify, for a proposed manifestation, the number of items we want
 * to order.
 
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.4.3
 */

class CoordinatedPurchasePage extends ClavisPage
{
	public $_module = 'ACQUISITION';
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$clavisLibrarian = $this->getUser();

			$buyShelves = ShelfPeer::getVisibleShelvesArray($clavisLibrarian, ShelfPeer::TYPE_MANIFESTATION_BUY, null, null, null, 20);
			$buyShelves = array('0' => '---') + $buyShelves;	// blank label
			$this->PurchaseShelf->setDataSource($buyShelves);
			$this->PurchaseShelf->dataBind();
		}
	}

	public function onLoad($param) 
	{
		parent::onLoad($param);
		
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			//$this->globalRefresh();
		}
	}
	
	public function onCleanFilters($sender, $param)
	{
		$this->PurchaseShelf->setSelectedIndex(0);
		$this->WithRequestCheckBox->setChecked(false);
		$this->VirginCheckBox->setChecked(false);

		$this->globalRefresh(true);  // reset mode
	}
	
	public function globalRefresh($reset = false)
 	{
		$purchaseShelfId = intval($this->PurchaseShelf->getSelectedValue());
		if ($purchaseShelfId == 0 && !$reset)
		{
			$this->Grid->resetDataSource();
			$this->writeMessage(Prado::localize("Selezionare uno scaffale con acquisti coordinati dalla lista valori"), ClavisMessage::WARNING);
			return false;
		}

		$withRequest = $this->WithRequestCheckBox->getChecked();
		$virgin = $this->VirginCheckBox->getChecked();
		
		$this->Grid->setFilters($purchaseShelfId, $withRequest, $virgin);
		$this->Grid->resetDataSource();
		
		$this->populateOrderGrid();
 	}

	public function globalRedraw($manifestationId, $orderId)
	{
		$this->Grid->populate($manifestationId, $orderId);
		
		$this->populateOrderGrid();
	}
	
	/**
	 * Callback from update button in the page.
	 * It performs retrieving of filters and next it populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}	
	
	/**
	 * Begin methods for ordergrid, which is not a widget but is in the flow of the page itself 
	 */
	
	public function onChangePageGrid($sender,$param) 
	{
		$this->OrderGrid->setCurrentPage($param->NewPageIndex);
		$this->populateOrderGrid();
	}
	
	private function populateOrderGrid()
	{
		$myLibraryId = $this->getUser()->getActualLibraryId();
        //$myLibraries = $this->getUser()->getLibraries();

		$pageSize = $this->OrderGrid->getPageSize();
		$currentIndexPage = $this->OrderGrid->getCurrentPage();

		$criteria = new Criteria();

		$criteria->add(PurchaseOrderPeer::ORDER_STATUS, PurchaseOrderPeer::STATUS_OPEN);
		$criteria->add(PurchaseOrderPeer::LIBRARY_ID, $myLibraryId, Criteria::IN);

		$recCount = PurchaseOrderPeer::doCount($criteria);
		$this->OrderGrid->setVirtualItemCount($recCount);

		$this->GridRecCounter->setText($recCount);
		$this->GridRecCounterPanel->setVisible($recCount > 0);

        $criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		$data = array();
		$currencyAmountTot = 0.0;
		$inventoryAmountTot = 0.0;
		foreach (PurchaseOrderPeer::doSelect($criteria) as $order)
		{
			/* @var $order PurchaseOrder */
			$orderId = $order->getOrderId();
			$orderTitle = $order->getOrderTitle();
			$orderDate = $order->getOrderDate('U');
			$supplierName = $order->getSupplierName();
			$accountId = $order->getAccountId();
			
			$c = new Criteria();
			$c->add(ItemPeer::ORDER_ID, $orderId);
			$items = ItemPeer::doSelect($c);
			$numberItems = ItemPeer::doCount($c);
			unset($c);
			
			$currencyAmount = 0.0;
			$inventoryAmount = 0.0;
			foreach ($items as $item) 
			{
				$currencyAmount += (float) $item->getCurrencyValue();
				$inventoryAmount += (float) $item->getInventoryValue();
			}
			
			$currencyAmountTot += (float) $currencyAmount;
			$inventoryAmountTot += (float) $inventoryAmount;
			
			if ($currencyAmount > 0)
				$totDiscountValue = 100 - ($inventoryAmount * 100 / $currencyAmount);
			else
				$totDiscountValue = 0;
			
			$data[] = array('OrderId' => $orderId,
							'OrderTitle' => $orderTitle,
							'SupplierName' => $supplierName,
							'AccountId' => $accountId,
							'OrderDate' => $orderDate,
				
							'TotNumber' => $numberItems,
							'TotCurrencyValue' => $currencyAmount,
							'TotDiscountValue' => ClavisBase::numberFormat($totDiscountValue, '#.00%'),
							'TotInventoryValue' => $inventoryAmount,		//sprintf("%01.2f€", $inventoryAmount),
									
							'SystemCurrency' => ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency') );
		}
		
		$this->InventoryAmount->setValue($inventoryAmountTot);  //setText(sprintf("%01.2f€", $inventoryAmountTot));
				
		$this->OrderGrid->setDataSource($data);
		$this->OrderGrid->dataBind();
	}
	
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}
	
}
