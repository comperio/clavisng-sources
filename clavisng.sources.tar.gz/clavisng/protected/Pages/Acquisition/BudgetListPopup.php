<?php

/**
 * BudgetListPopup Page class Module Acquisizioni
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class BudgetListPopup extends ClavisPagePopup
{
	public $_module = 'ACQUISITION';
	
	protected $_library;

	public function onInit($param)
	{
		parent::onInit($param);
		
		if(!$this->getIsPostBack() )
		{
			$library = null;
			$libraryId = intval($this->getRequest()->itemAt('libraryId'));
			
			if ($libraryId == 0)
			{
				if ($this->getRequest()->itemAt('objectType') == 'library')
					$libraryId = intval($this->getRequest()->itemAt('param'));
			}

			if ($libraryId > 0)
				$library = LibraryQuery::create()->findPK($libraryId);
			
			if (!($library instanceof Library))
				$library = $this->getPage()->getUser()->getActualLibrary();
				
			$this->setLibrary($library);
		}
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->BudgetList->setLibrary($this->getLibrary());
		}
	}
	
	/**
	 * setter
	 *
	 * @param Library $library
	 */
	public function setLibrary($library) 
	{
		$this->_library = $library;
		$this->setViewState('library', $library, null);
	}

	/**
	 * getter
	 *
	 * @return Library
	 *
	 */
	public function getLibrary()
	{
		if (!$this->_library)
			$this->_library = $this->getViewState('library',null);
		return $this->_library;
	}
}
