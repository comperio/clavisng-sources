<?php

/**
 * InvoiceListPopup Test Page class Module Library
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class OrderListPopup extends ClavisPagePopup
{

	public $_module = 'ACQUISITION';
		
	public function globalRefresh()
	{
		$this->OrderList->populate();
	}

	public function globalEditCancel()
	{

		
	}

}
