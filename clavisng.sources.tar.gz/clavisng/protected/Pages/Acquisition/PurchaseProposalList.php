<?php

/**
 * Acquisition.PurchaseProposalList Page class Module Acquisition
 *
 * @author Ciro Mattia Gonano <cmgonano@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class PurchaseProposalList extends ClavisPage {
	
	public $_module = 'ACQUISITION';
	
	public function globalRefresh() {
		$this->PurchaseProposalList->populate();
	}

	public function globalEditCancel() {
	}
}
