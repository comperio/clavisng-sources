<?php

/**
 * ChangelogPopup class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Popups.Core
 * @since 2.0
 */

class ChangelogPopup extends ClavisPagePopup
{
	public $_module = 'MYHOME';

	private $_userId;
	private $_userClass;
	private $_objectId;
	private $_objectClass;

	public function onInit($param)
	{
		parent::onInit($param);

		if(!$this->getIsPostBack() )
		{
		   $object_id = intval($this->getRequest()->itemAt('objectId'));
			if($object_id > 0)
				$this->setObjectId($object_id);

			$object_class = TPropertyValue::ensureString($this->getRequest()->itemAt('objectClass'));
			if ($object_class != null)
				$this->setObjectClass($object_class);

			$user_id = intval($this->getRequest()->itemAt('userId'));
			if ($user_id >0)
				$this->setUserId($user_id);

			$user_class = TPropertyValue::ensureString($this->getRequest()->itemAt('userClass'));
			if ($user_class != null)
				$this->setUserClass($user_class);

			$eventType = TPropertyValue::ensureString($this->getRequest()->itemAt('eventType'));
			if ($eventType != null)
				$this->setEventType($eventType);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->ChangelogList->setObjectId($this->getObjectId());
			$this->ChangelogList->setObjectClass($this->getObjectClass());
			$this->ChangelogList->setUserId($this->getUserId());
			$this->ChangelogList->setUserClass($this->getUserClass());
			$this->ChangelogList->setEventType($this->getEventType());
			$this->ChangelogList->populate();
			$this->ChangelogPrint->setObjectId($this->ChangelogList->getEventIds());
		}
	}

	public function setUserId($user_id)
	{
		$this->_userId = $user_id;
		$this->setViewState("user_id", $user_id, null);
	}

	public function getUserId()
	{
		if (is_null($this->_userId))
			$this->_userId = $this->getViewState("user_id", null);
		return $this->_userId;
	}

	public function setUserClass($user_class)
	{
		$this->_userClass = $user_class;
		$this->setViewState("user_class", $user_class, null);
	}

	public function getUserClass()
	{
		if(is_null($this->_userClass))
			$this->_userClass = $this->getViewState("user_class", null);
		return $this->_userClass;

	}

	public function setObjectId($object_id)
	{
		$this->_objectId = $object_id;
		$this->setViewState("object_id", $object_id, null);
	}

	public function getObjectId()
	{
		if(is_null($this->_objectId))
			$this->_objectId = $this->getViewState("object_id", null);
		return $this->_objectId;
	}

	public function setObjectClass($object_class)
	{
		$this->_objectClass = $object_class;
		$this->setViewState("object_class", $object_class, null);
	}

	public function getObjectClass()
	{
		if(is_null($this->_objectClass))
			$this->_objectClass = $this->getViewState("object_class", null);
		return $this->_objectClass;
	}

	public function setEventType($param)
	{
		$this->setViewState("event_type", $param, null);
	}

	public function getEventType()
	{
		return $this->getViewState("event_type", null);
	}
	
	public function onCancel($sender, $param)
	{

	}

	public function globalRefresh()
	{
		$this->ChangelogList->populate();
	}

	public function isUnlink()
	{
		return false;
	}
}
