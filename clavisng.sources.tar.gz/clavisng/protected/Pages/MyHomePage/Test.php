<?php

/**
 * Test Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @package Pages.MyHome
 * @since 2.0
 */
class Test extends ClavisPage
{
	public $_module='MYHOME';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if(!$this->getPage()->getIsPostBack()) {
			$this->populate();
		}
	}

	public function populate()
	{
		Prado::using('Application.Services.SOAP.*');
		$service = new CatalogFunctions();
		$ret = $service->getRecordsInShelf(1542);
		return $ret;
	}
}
