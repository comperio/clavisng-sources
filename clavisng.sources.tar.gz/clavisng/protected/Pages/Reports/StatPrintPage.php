<?php
/**
 * StatPrintPage Page class Module Reports
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 */

class StatPrintPage extends ClavisPage
{
	public $_module = 'REPORTS';

	public function onLoad($param) {
		parent::onLoad($param);

		$cnt = DocumentTemplateQuery::create()
			->filterByTemplateMedia('J')
			->filterByTemplateClass('JR_STATISTICS')
			->condition('libraryNull', 'DocumentTemplate.LibraryId IS NULL')
			->condition('libraryMine', 'DocumentTemplate.LibraryId = ?', $this->getUser()->getActualLibraryId())
			->orWhere(array('libraryNull','libraryMine'))
			->count();
		if ($cnt>0) {
			$this->PrintPanel->setVisible(true);
			$this->NoTplWarning->setVisible(false);
		} else {
			$this->PrintPanel->setVisible(false);
			$this->NoTplWarning->setVisible(true);
		}
	}
}

