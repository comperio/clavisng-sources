<?php

/**
 * CircHome Page class Module Circulation
 *
 * @author Dario Rigolin <drigolin@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class Home extends ClavisPage {
	
	public $_module = "REPORTS";
	
	
}

?>