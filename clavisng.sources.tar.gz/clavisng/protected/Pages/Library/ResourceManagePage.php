<?php

/**
 * Page for managing the resources in a library
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2009 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 *
 */

class ResourceManagePage extends ClavisPage
{
	public $_module = "LIBRARY";

	protected $_loanmanager;

	/**
	 *
	 * @param TEventParameter $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		$this->getClasses();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{

		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{

		}
	}

 	/**
 	 * It loads some things and modules.
 	 *
 	 */
 	public function getClasses()
 	{
 		$this->_loanmanager = $this->getApplication()->getModule("loan");
 	}

  	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
 	public function isPopup()
 	{
 		return false;
 	}

 	/**
 	 * It refreshes all the components (grids) in the page,
 	 * altogether.
 	 *
 	 */
 	public function globalRefresh()
 	{

 	}

	public function onCleanSearch($sender, $param)
	{

		$this->globalRefresh();
	}
	
}