<?php

/**
 * ResourceEditPage
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 */

class ResourceEditPage extends ClavisPage
{
	public $_module = 'LIBRARY';

	public function onInit($param)
	{
		parent::onInit($param);
	
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$resource = null;
		   $id = intval($this->getRequest()->itemAt('id'));
			if ($id > 0)
			{
				$resource = ResourcePeer::retrieveByPK($id);
				if (is_null($resource) || !($resource instanceof Resource))
				{
					$this->writeMessage(Prado::localize('La risorsa con id = {id} non esiste', array('id' => $id)),
											ClavisMessage::ERROR);
					$resource = null;
					$this->gotoPage('Library.ResourceManagePage');
				}
			}
			$this->UpdateData->setObject($library);
			if (!($resource instanceof Library))
				$resource = new Resource();
			$this->setResource($resource);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->populate();
		}

		////////$this->UpdateData->setObject($this->getLibrary());
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$allow = true;
		$resource = $this->getResource();

		if (!is_null($resource) && ($resource instanceof Resource))
			$allow = $this->getUser()->getEditPermission($resource);
		parent::checkAuth($allow);
	}

	public function setResource($value)
	{
		$this->setViewState("resourceViewstate", $value, null);
	}

	public function getResource()
	{
		return $this->getViewState("resourceViewstate", null);
	}

	public function getIsNew()
	{
		$resource = $this->getResource();
		if (!is_null($resource) && ($resource instanceof Resource))
			return $resource->isNew();
		else
			return false;
	}

	public function onSave($sender, $param)
	{
		/** @var $resource Resource */

		$resource = $this->getResource();
		$isNew = $resource->isNew();
		if (is_null($resource) || !($resource instanceof Resource))
		{
			$this->writeMessage(Prado::localize("Errore nel passaggio dei parametri. Ricaricare la pagina e riprovare"), ClavisMessage::ERROR);
			return false;
		}

		$affectedCount = $resource->save();
		$this->setResource($resource);

		if ($affectedCount == 0)
		{
			$this->writeMessage(Prado::localize("Errore, risorsa con id: {id} e nome '{label}' non salvata",
														array('id' => $resource->getResourceId(), 'label' => $resource->getResourceLabel())),
										ClavisMessage::ERROR);
			return false;
		}

		if ($isNew)
		{
			ChangelogPeer::logAction($resource, ChangelogPeer::LOG_CREATE, $this->getUser(),
					"Creata risorsa con id: {$resource->getResourceId()}");
			$this->writeMessage(Prado::localize("Creata risorsa con id: {id} e nome '{label}'",
														array('id' => $resource->getResourceId(), 'label' => $resource->getResourceLabel())),
										ClavisMessage::CONFIRM);
		}
		else
		{
			ChangelogPeer::logAction($resource, ChangelogPeer::LOG_UPDATE, $this->getUser(),
					"Modificata risorsa con id: " . $resource->getResourceId());
			$this->writeMessage(Prado::localize("Modificata risorsa con id: {id} e nome '{label}'",
														array('id' => $resource->getResourceId(), 'label' => $resource->getResourceLabel())),
										ClavisMessage::CONFIRM);
		}

		$this->gotoPage("Library.LibraryViewPage", array("id"=>$this->_library->getLibraryId()));
	}

	public function populate()
	{
		$resource = $this->getResource();
		if (is_null($resource) || !($resource instanceof Resource))
		{
			$this->writeMessage(Prado::localize("Errore nel passaggio dei parametri. Ricaricare la pagina e riprovare"), ClavisMessage::ERROR);
			return false;
		}




	}

	/**
	 * Exits the editing, without doing anything.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$object = $this->getResource();
		if (!is_null($object) && ($object instanceof Resource))
			$objectId = intval($object->getResourceId());
		else
			$objectId = 0;

		if (!$this->getIsNew() && ($objectId > 0))
			$this->gotoPage("Library.ResourceViewPage", array("id" => $objectId));
		else
			$this->gotoPage("Library.ResourceViewPage");
	}
}

