<?php

/**
 * LibrarianListPage Page class Module Library
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class LibrarianListPage extends ClavisPage {

	public $_module = "LIBRARY";

	public function globalRefresh()
	{
		$this->LibrarianList->populate();
	}

	public function onAddToShelf($sender, $param)
	{
		$shelfId = $this->ShelfResultValue->getValue();
		if (is_numeric($shelfId) and !is_null($shelfId))
		{
			$shelf = ShelfPeer::retrieveByPK($shelfId);
			if (!is_null($shelf) and ($shelf instanceof Shelf))
			{
				$checkedId = $this->LibrarianList->getCheckedId();
				$done = $shelf->addItemToShelf('librarian', $checkedId);
				$failed = count($checkedId) - $done;
				if ($done > 0) {
					$this->getPage()->writeMessage($done == 1 ?
							Prado::localize('1 elemento processato') :
							Prado::localize('{count} elementi processati',array('count' => $done)),
						ClavisMessage::INFO);
				}
				if ($failed > 0)
					$this->writeMessage($failed == 1 ?
						Prado::localize('1 elemento non processato') :
						Prado::localize('{count} elementi non processati',array('count' => $failed)),
						ClavisMessage::ERROR);
			}
		}

		$this->globalRefresh();
	}
}
