<?php

/**
 * InventorySerieListPage class
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Library
 * @since 2.0
 */

class InventorySerieListPage extends ClavisPage {

	public $_module = 'LIBRARY';

	public function globalRefresh()
	{
		$this->InventorySerieList->populate();
	}

}
