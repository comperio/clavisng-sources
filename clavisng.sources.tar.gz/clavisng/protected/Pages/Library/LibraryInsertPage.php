<?php
/**
 * LibraryInsertPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Library
 */

/**
 * LibraryInsertPage Class
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Library
 * @since 2.0
 */
class LibraryInsertPage extends ClavisPage {

	public $_module = 'LIBRARY';

	private $_wasNew;
	private $_updateGrid;
	private $_colorizeRowSessionName;

	private function initVars()
	{
		$this->_colorizeRowSessionName = 'ColorizeRowSessionName'.$this->getUniqueID();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
		$this->_updateGrid = true;
		
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->resetColorizeRow();
			
			$library = null;
			$id = intval($this->getRequest()->itemAt('id'));
			if ($id > 0)
			{
				$library = LibraryPeer::retrieveByPK($id);
			}
			else
			{
				//Only admin can create
				if($this->getUser()->getIsAdmin())
					$library = new Library();
			}

			if (!$library instanceof Library)
			{
				$this->writeMessage(Prado::localize('La biblioteca con id = {id} non esiste',
							array('id' => $id)),
							ClavisMessage::ERROR);

				$this->gotoPage('Library.LibraryList');
			}
			else
			{
				$this->UpdateData->setObject($library);
				$this->setLibrary($library);
				$this->setLibraryId($library->getLibraryId());
			}
			
			$this->_updateGrid = false;
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->Timetable->setLibraryId($this->getLibraryId());
			$this->setSingleDayMode(false);
			$this->HolidayColumn->setVisible(false);

			$this->writeGrid($this->calculateMultipleRow());

			$this->populate();  // all the rest

			/* tabview selection by request parameter */
			try
			{
				$selectTab = $this->getRequest()->itemAt('selectTab');
				if (is_numeric($selectTab) && $selectTab > 0)
					$this->TabPanel->setActiveViewIndex($selectTab);
				elseif (is_string($selectTab) && $selectTab != "")
					$this->TabPanel->setActiveViewID($selectTab);
			}
			catch (Exception $e)
			{
				//Prado::log($e);
			}
		}

		if ($this->getLibrary()->getLibraryId()) {
			$this->AttachmentManager->setObjectClass('Library');
			$this->AttachmentManager->setObjectId($this->getLibrary()->getLibraryId());
		}
	}

	public function onPreRender($param) 
	{
		parent::onPreRender($param);

		if ($this->getIsNewLibrary()) {
			$this->TimeTableTabView->setVisible(false);
			$this->AttachmentTab->setVisible(false);
		} else {
			/*
			 * Repopulation (refresh) of timetable input grid.
			 * We need it, or after any postback the inserted textfields and weekdays
			 * get lost.
			 */
			$this->AttachmentTab->setVisible(true);
			$this->TimeTableTabView->setVisible(true);
			if ($this->getPage()->getIsPostBack())
			{
				if ($this->_updateGrid)
				{
					$grid = $this->readGrid();

					if (!is_null($grid) && (count($grid) > 0))
						$this->writeGrid($grid);

					$this->_updateGrid = false;
				}
			}
		}
	}
	
	public function checkAuth($addedCheck = true, $force = null)
	{
		$addedCheck = false;
		$clavisLibrarian = $this->getUser();
		if ($clavisLibrarian instanceof ClavisLibrarian)
		{
			$library = $this->getLibrary();
			if ($library instanceof Library)
				$addedCheck = $clavisLibrarian->getEditPermission($library);
		}
		parent::checkAuth($addedCheck,$force);
	}

	public function resetColorizeRow()
	{
		$this->setColorizeRow(array());
	}
	
	public function setColorizeRow($param = null)
	{
		$this->getApplication()->getSession()->add($this->_colorizeRowSessionName, $param, array());
	}

	public function getColorizeRow()
	{
		return $this->getApplication()->getSession()->itemAt($this->_colorizeRowSessionName, array());
	}
	
	private function pushColorizeRow($param = null)
	{
		if (is_null($param))
			return false;

		$colorized = $this->getColorizeRow();
		$colorized[$param] = true;
		$this->setColorizeRow($colorized);
	}
	
	private function popColorizeRow($param = null)
	{
		if (is_null($param))
			return false;

		$colorized = $this->getColorizeRow();
		if (array_key_exists($param, $colorized) && $colorized[$param])
		{
			unset ($colorized[$param]);
			$this->setColorizeRow($colorized);
			return true;
		}
		else
			return false;
	}
	
	public function setActualTableSource($param = null)
	{
		$this->setControlState("ActualTableSource", $param);
	}

	public function getActualTableSource()
	{
		return $this->getControlState("ActualTableSource", null);
	}
	
	public function setAlternateTableSource($param = null)
	{
		$this->setControlState("AlternateTableSource", $param);
	}

	public function getAlternateTableSource()
	{
		return $this->getControlState("AlternateTableSource", null);
	}

	public function setSingleDayMode($param = null)
	{
		$this->setControlState("SingleDayMode", $param, false);
	}

	public function getSingleDayMode()
	{
		return $this->getControlState("SingleDayMode", false);
	}

	public function setLibrary(Library $library)
	{
		$this->setViewState('library', $library, null);
	}

	/**
	 *
	 * @return Library
	 */
	public function getLibrary()
	{
		return $this->getViewState('library', null);
	}

	public function setLibraryId($param)
	{
		$this->setViewState('library_id', $param, null);
	}

	public function getLibraryId()
	{
		return $this->getViewState('library_id', null);
	}

	public function getIsNewLibrary()
	{
		$library = $this->getLibrary();
		return ($library instanceof Library && $library->isNew());
	}

	/**
	 * Exits the editing, without doing anything.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$library = $this->getLibrary();
		if (!$this->getIsNewLibrary() && $library instanceof Library)
			$this->gotoPage('Library.LibraryViewPage', array('id' => $library->getLibraryId()));
		else
			$this->gotoPage('Library.LibraryList');
	}
	
	public function onSave($sender, $param)
	{
		if ($this->getIsValid()) {
			$this->saveLibrary();
			$this->gotoPage('Library.LibraryViewPage', array('id' => $this->getLibrary()->getLibraryId()));
		}
	}

	public function onApply($sender, $param)
	{
		if ($this->getIsValid()) {
			$this->saveLibrary();
			if ($this->_wasNew)
				$this->gotoPage($this->getPagePath(), array('id' => $this->getLibrary()->getLibraryId()));
		}
	}
	
	public function saveLibrary()
	{
		$library = $this->getLibrary();
		if (!$library instanceof Library) {
			$this->getPage()->writeMessage(Prado::localize("Errore: biblioteca non esistente."),ClavisMessage::ERROR);
			return false;
		}
		$this->_wasNew = $library->isNew();

		$library->setLibraryClass($this->Libraryclass->getSelectedValue());
		$library->setConsortiaId($this->Consortia->getSelectedValue());
		$library->setDescription($this->Description->getSafeText());
		$library->setLabel($this->Label->getSafeText());
		$library->setLibraryCode(trim($this->Librarycode->getSafeText()));
		$library->setIllCode(trim($this->IllCode->getSafeText()));
		$library->setSbnCode(trim($this->SbnCode->getSafeText()));
		$library->setShortlabel(trim($this->Shortlabel->getSafeText()));
		$library->setLibraryType($this->Librarytype->getSelectedValue());
		$library->setLibraryInternal($this->LibraryInternal->getChecked());
		$library->setLibraryStatus($this->Librarystatus->getSelectedValue());
		$library->setAddress($this->Address->getSafeText());
		$library->setCountry($this->Country->getSafeText());
		$library->setProvince($this->Province->getSafeText());
		$library->setCity($this->City->getSafeText());
		$library->setPhone($this->Phone->getSafeText());
		$library->setFax($this->Fax->getSafeText());
		$library->setEmail($this->Email->getSafeText());
		$library->setWebsite($this->Website->getSafeText());
		$library->setBillingAddress($this->Billingaddress->getSafeText());
		$library->save();
		ChangelogPeer::logAction($library, ($this->_wasNew) ? ChangelogPeer::LOG_CREATE : ChangelogPeer::LOG_UPDATE, $this->getUser());
		$this->setLibrary($library);
		$this->writeMessage(Prado::localize('Biblioteca "{libraryLabel}" ({libraryDescription}) salvata correttamente',
				array('libraryLabel' => $library->getLabel(),
					'libraryDescription' => $library->getDescription())),
				ClavisMessage::INFO);
	}

	public function populate()
	{
		$consortias = ConsortiaQuery::create()->find();
		$this->Consortia->setDataSource($consortias);
		$this->Consortia->dataBind();

		$library = $this->getLibrary();
		if (!($library instanceof Library))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: biblioteca non esistente. Contattare l'assistenza e specificare i dettagli e le circostanze dell'errore."),
												ClavisMessage::ERROR);
			return false;
		}

		$this->UpdateData->setObject($library);
		$this->Libraryclass->setSelectedValue(strtoupper($library->getLibraryClass()));
		$cid = $library->getConsortiaId();
		if ($cid)
			$this->Consortia->setSelectedValue($cid);
		$this->Description->setText($library->getDescription());
		$this->Label->setText($library->getLabel());
		$this->Librarycode->setText($library->getLibraryCode());
		$this->IllCode->setText($library->getIllCode());
		$this->SbnCode->setText($library->getSbnCode());
		$this->Shortlabel->setText($library->getShortlabel());
		$this->Librarytype->setSelectedValue($library->getLibraryType());
		$this->LibraryInternal->setChecked($library->getLibraryInternal() == "1");
		$this->Librarystatus->setSelectedValue($library->getLibraryStatus());
		$this->Address->setText($library->getAddress());
		$this->Country->setText($library->getCountry());
		$this->Province->setText($library->getProvince());
		$this->City->setText($library->getCity());
		$this->Phone->setText($library->getPhone());
		$this->Fax->setText($library->getFax());
		$this->Email->setText($library->getEmail());
		$this->Website->setText($library->getWebsite());
		$this->Billingaddress->setText($library->getBillingAddress());
	}

	

	private function calculateMultipleRow()  // maybe in the future we can have parameters, for data fill
	{
		$weekdays = LookupValuePeer::getLookupClassValues('DAYSOFWEEKSHORT');
		$newGrid = array();
		foreach ($weekdays as $index => $row)
		{
			$newGrid[$index] = array(	'wdayString' => $row,
										'wdayNum' => $index,
										'day' => 0,
										't1Start' => '',
										't1End' => '',
										't2Start' => '',
										't2End' => '',
										't3Start' => '',
										't3End' => '',

										'open' => '',
										'holiday' => '',
										'note' => '' );
		}
	
		return $newGrid;
	}
	
	private function calculateSingleRow($day = null, $existing = array())
	{
		if (intval($day) == 0)
			return array();
		
		$wDay = date('N', $day) - 1;
		
		$t1Start = '';
		$t1End = '';
		$t2Start = '';
		$t2End = '';
		$t3Start = '';
		$t3End = '';
		$open = '';
		$holiday = '';
		$note = '';

		if (is_array($existing) && count($existing) > 0)
		{
			if (array_key_exists('t1Start', $existing))
				$t1Start = $existing['t1Start'];
			if (array_key_exists('t1End', $existing))
				$t1End = $existing['t1End'];
			if (array_key_exists('t2Start', $existing))
				$t2Start = $existing['t2Start'];
			if (array_key_exists('t2End', $existing))
				$t2End = $existing['t2End'];
			if (array_key_exists('t3Start', $existing))
				$t3Start = $existing['t3Start'];
			if (array_key_exists('t3End', $existing))
				$t3End = $existing['t3End'];
			
			if (array_key_exists('open', $existing))
				$open = $existing['open'];
			if (array_key_exists('holiday', $existing))
				$holiday = $existing['holiday'];
			if (array_key_exists('note', $existing))
				$note = $existing['note'];
		}

		return array(	'wdayString' => LookupValuePeer::getLookupValue('DAYSOFWEEKSHORT', $wDay),
						'wdayNum' => $wDay,
						'day' => $day,
						't1Start' => $t1Start,
						't1End' => $t1End,
						't2Start' => $t2Start,
						't2End' => $t2End,
						't3Start' => $t3Start,
						't3End' => $t3End,

						'open' => $open,
						'holiday' => $holiday,
						'note' => $note );
	}
	
	public function onChangedDayInsertFrom($sender, $param)
	{
		$day = ($this->DayInsertFromTextBox->getSafeText() != ''
							? $this->DayInsertFromTextBox->getTimeStamp()
							: null);
		
		if (intval($day) == 0)
		{
			$this->DayInsertFromTextBox->setText('');
			$this->getPage()->writeMessage(Prado::localize("Specificare una data"), ClavisMessage::WARNING);
			return false;
		}

		if ($this->getSingleDayMode())
		{
			$readGrid = $this->readGrid($param);
			if (array_key_exists('ok', $readGrid))
				unset ($readGrid['ok']);
			if (array_key_exists('notime', $readGrid))
				unset ($readGrid['notime']);

			$newGrid = array();
			$newGrid[] = $this->calculateSingleRow($day, $readGrid[0]);

			$this->writeGrid($newGrid, $param);
		}
	}
	
	public function onSwitchSingleDayMode($sender, $param)
	{
		$singleMode = !$this->getSingleDayMode();
		$storedSource = $this->getAlternateTableSource();
		$onScreenSource = $this->readGrid();

		if ($singleMode && count($storedSource) == 0)
		{
			$day = ($this->DayInsertFromTextBox->getSafeText() != ''
							? $this->DayInsertFromTextBox->getTimeStamp()
							: null);

			if (intval($day) == 0)
			{
				$this->getPage()->writeMessage(Prado::localize("Specificare un giorno"), ClavisMessage::WARNING);
				$this->SingleModeCheckBox->setChecked(false);

				return false;
			}

			$storedSource = array();
			$storedSource[] = $this->calculateSingleRow($day);
		}
		
		if (!$singleMode && (count($storedSource < 2)))
			$storedSource = $this->calculateMultipleRow();
		
		$this->setSingleDayMode($singleMode);
		$this->HolidayColumn->setVisible($singleMode);
		$this->writeGrid($storedSource);
		$this->setAlternateTableSource($onScreenSource);
		$this->_updateGrid = false;
	}

	public function onDayInsertFromChanged($sender, $param)  // prova, da cancellare
	{
		$dayTo = trim($this->DayInsertToTextBox->getSafeText());
		if ($dayTo == "")
		{
			$this->ModifyTimetablePanel->render($param->getNewWriter());
			return false;
		}
	}

	private function isTimesValid($start = "", $end = "")
	{
		if (($start == TClavisTimePicker::TIME_INVALID) || ($end == TClavisTimePicker::TIME_INVALID))
			return false;
		
		if (($start . $end) == "")
			return true;
		
		if (($start == "") || ($end == ""))
			return false;
		
		if ($start >= $end)
			return false;
		
		return true;
	}
	
	private function readGrid($param = null)
	{
		$ok = true;
		$notime = false;
		$readGrid = array();

		foreach ($this->Grid->getItems() as $row)
		{
			$okRow = true;

			$wdayString = $row->DayColumn->WdayString->getText();
			$wdayNum = $row->DayColumn->WdayNum->getText();
			$day = $row->DayColumn->Day->getValue();

			$holiday = $row->HolidayColumn->HolidayCheckBox->getChecked();
						
			$t1Start = $row->Time1Column->T1Start->readTime();
			$t1End = $row->Time1Column->T1End->readTime();
			if (!$this->isTimesValid($t1Start, $t1End) || $holiday)
			{
				$t1Start = "";
				$t1End = "";
				$row->Time1Column->T1Start->resetTime();
				$row->Time1Column->T1End->resetTime();
				$ok = false || $holiday;
			}

			$t2Start = $row->Time2Column->T2Start->readTime();
			$t2End = $row->Time2Column->T2End->readTime();
			if (!$this->isTimesValid($t2Start, $t2End) || $holiday)				
			{
				$t2Start = "";
				$t2End = "";
				$row->Time2Column->T2Start->resetTime();
				$row->Time2Column->T2End->resetTime();
				$ok = false || $holiday;
			}

			$t3Start = $row->Time3Column->T3Start->readTime();
			$t3End = $row->Time3Column->T3End->readTime();
			if (!$this->isTimesValid($t3Start, $t3End) || $holiday)
			{
				$t3Start = "";
				$t3End = "";
				$row->Time3Column->T3Start->resetTime();
				$row->Time3Column->T3End->resetTime();
				$ok = false || $holiday;
			}
						
			if (($t1Start . $t1End . $t2Start . $t2End . $t3Start . $t3End) == "")
				$okRow = false;
			
			$open = $row->OpenColumn->OpenCheckBox->getChecked();
			if (!$okRow || $holiday)
			{
				if (!$okRow && $open)
				{
					$this->pushColorizeRow($row->getItemIndex());
					$notime = true;
				}

				$open = false;
				$row->OpenColumn->OpenCheckBox->setChecked(false);
			}

			$readGrid[$row->getItemIndex()] = array('wdayString' => $wdayString,
													'wdayNum' => $wdayNum,
													'day' => $day,
													't1Start' => $t1Start,
													't1End' => $t1End,
													't2Start' => $t2Start,
													't2End' => $t2End,
													't3Start' => $t3Start,
													't3End' => $t3End,

													'open' => $open,
													'holiday' => $holiday,
													'note' => $row->NoteColumn->Note->getSafeText() );
			
		}  // end of cycle into the grid items

		if (count($readGrid) > 0)
			$readGrid['ok'] = $ok;
		$readGrid['notime'] = $notime;

		if ($this->getPage()->getIsCallback() && !is_null($param))
			$this->GridPanel->render($param->getNewWriter());
		
		return $readGrid;
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $item->ItemIndex;
		
		if ($item->getItemType() != "Item" && $item->getItemType() != "AlternatingItem")
			return false;
	
		if ($this->popColorizeRow($itemIndex))
			$item->setStyle('background: red');	
	}
	
	private function writeGrid($grid = null, $param = null)
	{
		if (!is_array($grid) || count($grid) == 0)
			return false;

		if (array_key_exists('ok', $grid))
			unset ($grid['ok']);
		if (array_key_exists('notime', $grid))
			unset ($grid['notime']);

		$this->Grid->setDataSource($grid);
		$this->Grid->dataBind();
		
		if ($this->getPage()->getIsCallback() && !is_null($param))
			$this->GridPanel->render($param->getNewWriter());
	}
	
	public function onFillSingleDay($sender, $param)
	{
		$day = intval($param->CommandParameter);
		if ($day == 0)
			return false;

		$existing = array();
		$timeRow = LibraryTimetableQuery::create()
			->filterByLibraryId($this->getLibraryId())
			->filterByTimetableDay($day)
			->findOne();
		
		if ($timeRow instanceof LibraryTimetable)
		{		
			$existing = array(	'open' => $timeRow->getTimetableOpen(),
								'holiday' => $timeRow->getTimetableHoliday(),
								'note' => $timeRow->getTimetableNote(),
								't1Start' => $timeRow->getTime1Start(),
								't1End' => $timeRow->getTime1End(),
								't2Start' => $timeRow->getTime2Start(),
								't2End' => $timeRow->getTime2End(),
								't3Start' => $timeRow->getTime3Start(),
								't3End' => $timeRow->getTime3End() );

			$storedSource = $this->getAlternateTableSource();
			$onScreenSource = $this->readGrid();

			$storedSource = array();
			$storedSource[] = $this->calculateSingleRow($day, $existing);

			$this->setSingleDayMode(true);
			$this->HolidayColumn->setVisible(true);
			$this->DayInsertFromTextBox->setTimeStamp($day);
			$this->SingleModeCheckBox->setChecked(true);

			$this->writeGrid($storedSource);
			$this->setAlternateTableSource($onScreenSource);

			$this->_updateGrid = false;
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore sul passaggio dei parametri in modifica orario biblioteca"),
												ClavisMessage::ERROR);
		}
	}
	
	public function onWriteTimetable($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$readGrid = $this->readGrid();

		if (array_key_exists('ok', $readGrid) && !$readGrid['ok'])
		{
			$this->getPage()->enqueueMessage(Prado::localize("Azzeramento degli orari non inseriti in modo corretto. Riprovare."),
												ClavisMessage::WARNING);
		}
		elseif (array_key_exists('notime', $readGrid) && $readGrid['notime'])
		{
			$this->getPage()->enqueueMessage(Prado::localize("Uno o più giorni sono stati considerati chiusi in quanto non è stato indicato alcun orario di apertura. Riprovare."),
												ClavisMessage::WARNING);
		}
		else
		{
			if (array_key_exists('ok', $readGrid))
				unset ($readGrid['ok']);
			if (array_key_exists('notime', $readGrid))
				unset ($readGrid['notime']);
			
			$myLibraryId = $this->getLibraryId();
			if (intval($myLibraryId) > 0)
			{
				// everything seems ok: we're gonna write new timetables in the table .....
				$fromDate = $this->DayInsertFromTextBox->getSafeText() != '' 
									? $this->DayInsertFromTextBox->getTimeStamp() 
									: null;
				
				if (!is_null($fromDate))
				{
					if (count($readGrid) == 7)       // multi case (from starting to ending date)
					{
						$toDate = $this->DayInsertToTextBox->getSafeText() != '' 
											? $this->DayInsertToTextBox->getTimeStamp() 
											: null;
						
						if (!is_null($toDate))
						{
							$ok = 0;
							$failed = 0;
							
							for ($date = $fromDate; $date <= $toDate; $date += 86400)
							{
								// only the right weekday, from the input grid
								$weekDayNumber = date('N', $date) - 1;
								if (!array_key_exists($weekDayNumber, $readGrid))
									continue;
								
								if ($this->doSave($myLibraryId, $date, $readGrid[$weekDayNumber]))
									$ok++;
								else
									$failed++;
							}   // end of 'for' cycle

							if ($ok > 0)
							{
								$this->getPage()->enqueueMessage(Prado::localize("Modificata tabella degli orari dalla data {data1} fino alla data {data2}. Sono stati modificati {num} giorni",
																					array(	'data1' => Clavis::dateFormat($fromDate),
																							'data2' => Clavis::dateFormat($toDate),
																							'num' => $ok)),
																	ClavisMessage::CONFIRM);

								$this->Timetable->populate();
							}
							
							if ($failed > 0)
							{
								$this->getPage()->enqueueMessage(Prado::localize("Numero di giorni non modificati nella tabella orari: {num}",
																					array('num' => $failed)),
																	ClavisMessage::WARNING);
							}

						}
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("Data finale non specificata"),
														ClavisMessage::ERROR);
						}
						
					}  // end of week mode
					elseif (count($readGrid) == 1)   // single case (starting date alone)
					{
						$result = $this->doSave($myLibraryId, $fromDate, array_pop($readGrid), true);   // 4th is singlemode

						if ($result)
						{
							$this->getPage()->enqueueMessage(Prado::localize("Modificato giorno con data {day} nella tabella degli orari",
																				array(	'day' => Clavis::dateFormat($fromDate))),
																ClavisMessage::CONFIRM);

							$this->Timetable->populate();
						}
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("Errore di operazione sul database nella scrittura di orario per giorno singolo"),
																ClavisMessage::ERROR);
						}
					}
					else     // error
					{
						$this->getPage()->enqueueMessage(Prado::localize("Errore interno nella lettura della griglia nuovi orari"),
															ClavisMessage::ERROR);
					}
					
				}
				else
				{
					if ($this->getSingleDayMode())
						$this->getPage()->enqueueMessage(Prado::localize("Data non specificata"),
														ClavisMessage::ERROR);
					else
						$this->getPage()->enqueueMessage(Prado::localize("Data di partenza non specificata"),
													ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio del parametro della biblioteca corrente"),
													ClavisMessage::WARNING);
			}
		}

		$this->getPage()->flushMessage();
	}
	
	private function doSave($myLibraryId, $date, $row = array(), $singleMode = false)
	{
		if (count($row) == 0)
			return false;
		
		$t1Start = $row['t1Start'];
		$t1End = $row['t1End'];
		$t2Start = $row['t2Start'];
		$t2End = $row['t2End'];
		$t3Start = $row['t3Start'];
		$t3End = $row['t3End'];
		$open = $row['open'];
		if (is_null($open))
			$open = false;
		$holiday = $row['holiday'];
		$note = $row['note'];

		try
		{
			$timeRow = LibraryTimetableQuery::create()
						->filterByLibraryId($myLibraryId)
						->filterByTimetableDay($date)
						->findOneOrCreate();

			if (!($singleMode) && ($timeRow->getTimetableHoliday() == true))
				return false;
			
			$timeRow->setTimetableOpen($open);
			$timeRow->setTimetableHoliday($holiday);
			$timeRow->setTimetableNote($note);

			if (!$open || ($singleMode && $holiday))
			{
				$t1Start = null;
				$t1End = null;
				$t2Start = null;
				$t2End = null;
				$t3Start = null;
				$t3End = null;
			}

			$timeRow->setTime1Start($t1Start);
			$timeRow->setTime1End($t1End);
			$timeRow->setTime2Start($t2Start);
			$timeRow->setTime2End($t2End);
			$timeRow->setTime3Start($t3Start);
			$timeRow->setTime3End($t3End);

			$timeRow->save();
			return true;
		}
		catch (Exception $e)
		{
			//Prado::fatalError($e);
			return false;
		}
	}
	
}
