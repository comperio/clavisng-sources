<?php

/**
 * @author Marco Brancalion <marco@comperio.it>, copied from pre-esistent schema
 * @copyright Copyright &copy; 2011 Comperio srl
 */

class ActionListPage extends ClavisPage
{
	public $_module = 'LIBRARY';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			///$this->ItemActionList->populate();
		}
	}

	public function isUnlink()
	{
		return false;  // true
	}

}
