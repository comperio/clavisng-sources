<?php
/**
 * LibrarianInsertPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Library
 */

/**
 * LibrarianInsertPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Library
 * @since 2.0
 */
class LibrarianInsertPage extends ClavisPage
{
	public $_module = 'LIBRARY';
	/* @var Librarian */
	private $_librarian = null;

	public function onInit($param)
	{
		parent::onInit($param);

		if(!$this->getIsPostBack() )
		{
			$librarian = null;
		    $id = intval($this->getRequest()->itemAt('librarianId'));
			if ($id > 0)
			{
				$librarian = LibrarianPeer::retrieveByPK($id);
				if (is_null($librarian) || !($librarian instanceof Librarian ))
				{
					$this->writeMessage(Prado::localize("Il bibliotecario con id = {id} non esiste", array('id' => $id)),
									ClavisMessage::ERROR);
					$this->gotoPage('Library.LibrarianListPage');
				}
			}

			$this->UpdateData->setObject($librarian);

			if (!($librarian instanceof Librarian))
				$librarian = new Librarian();
			$this->setLibrarian($librarian);

			if ($librarian->isNew())
			{
				$this->DefaultLibrary->setDataSource(LibraryPeer::getLibrariesHash(null, null, null, true));  // internal only
				$this->DefaultLibrary->dataBind();
				$this->DefaultLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
			}
			else
			{
				$this->AttachmentManager->setObjectClass('Librarian');
				$this->AttachmentManager->setObjectId($librarian->getLibrarianId());
				$this->DefaultLibrary->setDataSource($librarian->getLibrariesHash(array($this->librarian->getDefaultLibraryId())));  //$this->getUser()->getLibraries());  //   CHI HA MESSO QUESTO?.....    LibraryPeer::getLibrariesHash()
				$this->DefaultLibrary->dataBind();
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);
		if(!$this->getIsPostBack() )
		{
			$this->populateForm();
			$this->dataBind();
		} else {
			//gestione postback da popup di selezione foto
			if ($this->ChangePhotoPopupValue->getValue() == "OK") {
				$this->writeDelayedMessage(Prado::localize('Foto cambiata correttamente'),ClavisMessage::INFO);
				$this->reloadPage();
			} else if ($this->ChangePhotoPopupValue->getValue() == "CANCEL") {
				$this->reloadPage();
			}
		}

		$this->getLibrarian();
		$librarianId = $this->_librarian->getLibrarianId();

		if (is_null($librarianId)) {
			$librarianId = -1;
			$this->Photo->Enabled = false;
		}
		$photoId = $this->_librarian->getPhotoFileId();
		if ($photoId)
			$this->Photo->setImageURL($this->getRequest()->constructUrl('file',$photoId));
	}

	public function onSave($sender, $param)
	{
		if ($this->getIsValid()) {
			$isNew = $this->_librarian->isNew();
			$this->librarianSave();
			$this->writeMessage($isNew ? Prado::localize('Nuovo operatore creato') : Prado::localize('Operatore salvato'), ClavisMessage::CONFIRM);
			$this->gotoPage('Library.LibrarianViewPage', array('id' => $this->_librarian->getLibrarianId()));
		}
	}

	public function saveAndEdit($sender, $param)
	{
		if ($this->getIsValid()) {
			$isNew = $this->_librarian->isNew();
			$this->librarianSave();
			$this->writeMessage($isNew ? Prado::localize('Nuovo operatore creato') : Prado::localize('Operatore salvato'), ClavisMessage::CONFIRM);
		}
	}

	
	public function librarianSave()
	{
		try {
			if (!$this->_librarian instanceof Librarian)
				$this->_librarian = new Librarian();

			$wasNew = $this->_librarian->isNew();

			$username = trim($this->Username->getSafeText());
			$password = trim($this->Password->getSafeText());
			if ($username)
				$this->_librarian->setUsername($username);
			if ($password) {
				$cryptmod = $this->getApplication()->getModule('crypt');
				$this->_librarian->setSecret($cryptmod->LibrarianEncrypt($password));
			}
			$this->_librarian->setName($this->Name->getSafeText());
			$this->_librarian->setLastname($this->Lastname->getSafeText());
			$this->_librarian->setBirthdate($this->BirthDate->getTimeStamp());
			$this->_librarian->setPhone($this->Phone->getSafeText());
			$this->_librarian->setEmail($this->Email->getSafeText());
			$this->_librarian->setLibrarianNote($this->LibrarianNote->getText());
			$this->_librarian->setCatLevel($this->CatLevel->getSelectedValue());
			$this->_librarian->setActivationStatus($this->ActivationStatus->getChecked());
			$this->_librarian->setPatron(PatronQuery::create()->findPk($this->PatronId->getValue()));
			$defaultLibraryId = $this->DefaultLibrary->getSelectedValue();
			if ($defaultLibraryId != '0')
				$this->_librarian->setDefaultLibraryId($defaultLibraryId);
			$this->_librarian->save();

			ChangelogPeer::logAction($this->_librarian, ($wasNew) ? ChangelogPeer::LOG_CREATE : ChangelogPeer::LOG_UPDATE,
				$this->getUser());

			$profiles = LLibrarianProfileQuery::create()
				->filterByLibrarian($this->_librarian)
				->count();
			if ($profiles<1) {
				$profileId = max(ClavisParamQuery::getParam('CLAVISPARAM','DefaultLibrarianProfile'),
					$this->getUser()->getMinProfileId());
				$profile = new LLibrarianProfile();
				$profile->setLibrarian($this->_librarian)
					->setProfileId($profileId)
					->setSortOrder(1)
					->save();
			}
			if ($defaultLibraryId != '0') {
				$link = LLibraryLibrarianQuery::create()
					->filterByLibrarian($this->_librarian)
					->filterByLibraryId($defaultLibraryId)
					->findOneOrCreate();
				if ($link->isNew()) {
					$role = ClavisParamQuery::getParam('CLAVISPARAM','DefaultLibrarianRole');
					if (!$role)
						$role = 'A';
					$link->setLibrarian($this->_librarian)
						->setLibraryId($defaultLibraryId)
						->setLinkRole($role)
						->setOpacVisible(true)
						->save();
				}
			}
			$this->setLibrarian($this->_librarian);
		}
		catch (PropelException $exception)
		{
			$errorMessage = $exception->getCause()->getMessage();
			$dbClass = Propel::getDB();
			if ($dbClass instanceof DBMySQL)
			{
				$duplicateCase = strstr($errorMessage, 'Duplicate entry');
				if ($duplicateCase !== false)
				{
					$usernameArray = sscanf($duplicateCase, "Duplicate entry %s");
					$username = $usernameArray[0];

					$this->writeMessage(Prado::localize("Lo username {username} è già in uso",
						array('username' => (is_null($username) ? '' : $username . ' '))), ClavisMessage::ERROR);
					$this->Username->setText('');
					$this->_librarian->setUsername(null);
				}
				else
					throw ($exception);
			}
			else
				throw ($exception);
		}
	}

	/**
	 *
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$this->writeMessage(Prado::localize('Operazione di modifica operatore: annullata'), ClavisMessage::INFO);
		$this->gotoPage("Library.LibrarianViewPage", array("id"=>$this->_librarian->getLibrarianId()));
	}

	/**
	 * Populates the fields in the page with data of object
	 * librarian which are stored in the database.
	 *
	 */
	public function populateForm()
	{
		if ($this->_librarian === null)
			return;

		if (!$this->_librarian->isNew())
			$this->Photo->setPopupPage('Library.LibrarianChooseImagePopup&librarianId='.$this->_librarian->getLibrarianId());

		$p = $this->_librarian->getPatron();
		if ($p instanceof Patron) {
			$this->PatronId->setValue($p->getPatronId());
			$this->PatronLabel->setText($p->getCompleteName());
		}

		$this->UpdateData->setObject($this->_librarian);

		$username = $this->_librarian->getUsername();
		if ($username != '')
			$this->Username->setText($username);
		$password = $this->_librarian->getSecret();
		if ($password != '')
			$this->Password->setText($password);

		$name = $this->_librarian->getName();
		if ($name != '')
			$this->Name->setText($name);

		$lastname = $this->_librarian->getLastname();
		if ($lastname != '')
			$this->Lastname->setText($lastname);

		$this->BirthDate->setTimeStamp($birthdate = $this->_librarian->getBirthdate('U'));
		$this->Phone->setText($this->_librarian->getPhone());

		$email = $this->_librarian->getEmail();
		if ($email != '')
			$this->Email->setText($email);

		$defaultLibraryId = intval($this->_librarian->getDefaultLibraryId());
		try
		{
			if ($defaultLibraryId > 0)
				$this->DefaultLibrary->setSelectedValue($defaultLibraryId);
		}
		catch (Exception $exception)
		{
			$errorMessage = $exception->getMessage();

			$errorCase = strstr($errorMessage, 'TDropDownList.SelectedValue has an invalid value');
			if ($errorCase != false)
			{
				$library = LibraryPeer::retrieveByPK($defaultLibraryId);
				if (!is_null($library))
				{
					$dataSource = $this->DefaultLibrary->getDataSource();
					$dataSource->add($defaultLibraryId, $library->getLabel());

					$data = $dataSource->toArray();
					$this->DefaultLibrary->setDataSource($dataSource);
					$this->DefaultLibrary->dataBind();
					$this->DefaultLibrary->setSelectedValue($defaultLibraryId);
				}
			}
			else
				throw ($exception);
		}

		$this->LibrarianNote->setText($this->_librarian->getLibrarianNote());

		$catLevel = $this->_librarian->getCatLevel();
		if ($catLevel === '')
			$catLevel = '0';
		$this->CatLevel->setSelectedValue($catLevel);
		$this->ActivationStatus->setChecked($this->_librarian->getActivationStatus());
	}

	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setViewState("librarian", $librarian, null);
	}

	public function getLibrarian()
	{
		if(is_null($this->_librarian))
			$this->_librarian = $this->getViewState("librarian", null);
		return $this->_librarian;
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$this->getLibrarian();
		$auth = ($this->_librarian instanceof Librarian)
			? $this->getUser()->getEditPermission($this->_librarian)
			: null;
		parent::checkAuth(true, $auth);
	}

	public function checkUsername($sender, $param)
	{
		$username = $this->Username->getSafeText();
		if ($username == '' || !$this->_librarian->allowedUsername($username))
			$param->isValid = false;
	}

	public function onCheckNewPassword($sender, $param)
	{
		if ($this->_librarian->isNew() && (trim($this->Password->getSafeText()) == ''))
			$param->isValid = false;
	}

	public function suggestPatron($sender, $param)
	{
		$token = trim($param->getToken());
		if (!$token)
			return;
		$ds = array();
		$candidates = PatronPeer::doSuggest($token);
		/* @var $c Patron */
		foreach ($candidates as $c)
			$ds[] = array(
				'id'	=> $c->getPatronId(),
				'text'	=> $c->getLastname().' '.$c->getName().' ('.$c->getBarcode().
							')<span class="informal">'.
							Clavis::dateFormat($c->getBirthDate('U')).'</span>');
		$sender->setDataSource($ds);
		$sender->dataBind();
	}

	public function suggestPatronCallBack($sender, $param)
	{
		$this->compilePatron($sender->Suggestions->DataKeys[$param->selectedIndex]);
	}

	public function selectPatronCallBack($sender, $param)
	{
		$this->compilePatron($this->PatronId->getValue());
	}

	private function compilePatron($id)
	{
		$p = PatronQuery::create()->findPk($id);
		if ($p instanceof Patron) {
			$this->PatronLabel->setText($p->getCompleteName());
			$this->PatronId->setValue($p->getPatronId());
		} else {
			$this->PatronLabel->setText('');
			$this->PatronId->setValue(null);
		}
	}

	public function onPatronUnlink($sender, $param)
	{
		$this->compilePatron(null);
	}
}
