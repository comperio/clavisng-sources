<?php

/**
 * ConsortiaListPopup Test Page class Module Library
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 * @package Popups.Library
 */
class ConsortiaListPopup extends ClavisPagePopup
{
	public $_module = "LIBRARY";

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->Page->getIsPostBack())
		{
			$this->NewConsortiumDialog->setVisible(false);
			$this->dataBind();
		}
	}

	public function onOpenNewConsortiumDialog($sender, $param)
	{
		$this->NewConsortiumDialog->setVisible(true);
	}

	public function onSave($sender, $param)
	{
		if (($consortiumId = $this->ConsortiumId->Text) !== '')
		{
			$newConsortium = new Consortia();
			$newConsortium->setConsortiaId($consortiumId);
			$newConsortium->setDescription($this->ConsortiumDescription->Text);

			$currentDate = date('Y-m-d H:i:s');
			$currentUser = $this->User->getID();
			$newConsortium->setDateCreated($currentDate);
			$newConsortium->setCreatedBy($currentUser);
			$newConsortium->setDateUpdated($currentDate);
			$newConsortium->setModifiedBy($currentUser);

			$newConsortium->save();

			$this->ConsortiaList->populate();
			$this->ClearInputDialog();
			$this->NewConsortiumDialog->setVisible(false);

			$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
			//$this->dataBind();
		}
	}

	private function ClearInputDialog()
	{
		$this->ConsortiumId->setText('');
		$this->ConsortiumDescription->setText('');
	}
}
