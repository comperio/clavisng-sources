<?php

/**
 * IssueEditPage class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.2
 */

class IssueEditPopup extends ClavisPagePopup {

	public $_module = 'CATALOG';

	public function onInit($param) {
		parent::onInit($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			switch ($this->getRequest()->itemAt('objectType')) {
				case 'manifestation':
					$issue = new Issue();
					$issue->setManifestationId($this->getRequest()->itemAt('param'));
					break;
				case 'issue':
				default:
					$issue = IssuePeer::retrieveByPK($this->getRequest()->itemAt('param'));
					if (! $issue instanceof Issue) {
						$this->writeMessage(Prado::localize('Il fascicolo con id [{id}] non esiste',
							array('id' => $issue_id)), ClavisMessage::ERROR);
					}
					break;
			}
			$this->IssueEdit->setIssue($issue);
		}
	}

	
	public function onSave($sender, $param) {
		$this->IssueEdit->onSave($sender,$param);
		$authId = $this->IssueEdit->getIssueId();

		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\''.
			urlencode($this->IssueEdit->issue->getFullText()).'\',\''.$authId.'\');');
	}
}
