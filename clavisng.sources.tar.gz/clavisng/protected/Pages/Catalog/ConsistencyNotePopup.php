<?php

/**
 * ConsistencyNotePopup class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.3
 */

class ConsistencyNotePopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';
	
	/** @var ConsistencyNote */
	public $note;

	private $_itemId;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$id = $this->getRequest()->itemAt('param');
		switch ($this->getRequest()->itemAt('objectType')) {
			case 'item':
				$item = ItemQuery::create()->findPk($id);
				if (! $item instanceof Item) {
					$this->writeMessage(Prado::localize('L\'esemplare [{id}] non esiste o non è valido.',
						array('id'=>$id)),ClavisMessage::ERROR);
					$this->closePopup();
				}
				$this->note = new ConsistencyNote();
				$this->note->setManifestationId($item->getManifestationId());
				$this->note->setLibraryId($item->getHomeLibraryId());
				break;
			case 'note':
			default:
				$this->note = ConsistencyNoteQuery::create()->findPk($id);
				if (! $this->note instanceof ConsistencyNote) {
					$this->getPage()->writeMessage(Prado::localize('La nota [{id}] non esiste o non è valida.',
						array('id'=>$id)),ClavisMessage::ERROR);
					$this->closePopup();
				}
				break;
		}
		$this->UpdateData->setObject($this->note);

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {	
			$this->populate();
		}
	}

	public function populate()
	{
		if ($this->note instanceof ConsistencyNote) {
			$this->Collocation->setText($this->note->getCollocation());
			$this->Closed->setChecked($this->note->getClosed());
			$this->TextNote->setText($this->note->getTextNote());
			$this->dataBind();
		}
		
	}

	public function onSave($sender, $param) {
		if (! $this->note instanceof ConsistencyNote)
			throw new Exception('Something gone wrong, note is not a ConsistencyNote');
		$this->note->setCollocation($this->Collocation->getSafeText());
		$this->note->setClosed($this->Closed->getChecked());
		$this->note->setTextNote($this->TextNote->getSafeText());
		ChangelogPeer::logAction($this->note,
			($this->note->isNew()) ? ChangelogPeer::LOG_CREATE : ChangelogPeer::LOG_UPDATE,
			$this->getUser());
		$this->note->save();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn('.
			"'{$this->note->getTextNote()}','{$this->note->getConsistencyNoteId()}');");
	}
	
}
