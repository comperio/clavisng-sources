<?php

/**
 * IssueListPopup class
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.0
 */

class IssueListPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	public function onLoad($param)
	{
		parent::onLoad($param);
		Prado::log($this->getRequest()->itemAt('param'));
		$manif_id = TPropertyValue::ensureInteger($this->getRequest()->itemAt('param'));
	    if ($manif_id > 0)
		{
			$manifestation = ManifestationPeer::retrieveByPK($manif_id);
			Prado::log(Prado::varDump($manifestation));
			$this->IssueList->setManifestation($manifestation);
		}
	}

	//GETTER/SETTER

	/**
	 * Setter method of object manifestation.
	 *
	 * @param Manifestation $manifestation
	 */
	public function setManifestation($manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setControlState("manifestation", $manifestation, null);
	}

	/**
	 * Getter method of object manifestation.
	 *
	 * @return Manifestation
	 *
	 */
	public function getManifestation()
	{
		$this->_manifestation = $this->getControlState("manifestation", null);
		return $this->_manifestation;
	}




}
?>