<?php
/**
 * ItemEditPopup class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Popups.Catalog
 */

/**
 * ItemEditPopup Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.1
 */
class ItemEditPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	private $_item = null;
	private $_manifestation = null;
	public $_title;
	public $customs_type = array('text','text','text');
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !($this->getIsCallback()))
		{
			$this->setListMode(false);
			$objectType = TPropertyValue::ensureString($this->getRequest()->itemAt('objectType'));
			if (is_null($objectType) || ($objectType == 'null'))
				$objectType = 'Item';
		    $id = intval($this->getRequest()->itemAt('param'));

		    switch ($objectType)
			{
				case 'Item':
					$item = null;
					if ($id > 0)
						$item = ItemPeer::retrieveByPK($id);
					else
						$item = new Item();
					
					if(!($item instanceof Item))
					{
						$this->writeMessage(Prado::localize("L'esemplare con id = {id} non esiste", array('id' => $id)),
										ClavisMessage::ERROR);
						return false;
					}

					$this->setItem($item);
					$this->_title = $item->getTrimmedTitle(100);
					break;

				case 'Manifestation':
					$manifestation = null;
					if ($id > 0)
						$manifestation = ManifestationPeer::retrieveByPK($id);
					else
						$manifestation = new Manifestation();
					
					if(!($manifestation instanceof Manifestation))
					{
						$this->writeMessage(Prado::localize("La notizia con id = {id} non esiste", array('id' => $id)),
										ClavisMessage::ERROR);
						return false;
					}
					
					$this->setManifestation($manifestation);
					$this->setListMode(true);
					$this->_title = $manifestation->getTrimmedTitle(100);
					break;
			}
			
			$mediapackage_size_max = intval(ClavisParamPeer::getParam('MEDIAPACKAGE_SIZE_MAX'));
			if ($mediapackage_size_max > 0)
			{
				$mediapackageArray = array();
				for ($co = 1; $co <= $mediapackage_size_max; $co++)
					$mediapackageArray[$co] = $co;
				$this->Mediapackage_size->setDataSource($mediapackageArray);
				$this->Mediapackage_size->dataBind();
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$item = $this->getItem();

		if (LookupValuePeer::classExists('ITEMCUST1'))
			$this->customs_type[0] = 'list';
		if (LookupValuePeer::classExists('ITEMCUST2'))
			$this->customs_type[1] = 'list';
		if (LookupValuePeer::classExists('ITEMCUST3'))
			$this->customs_type[2] = 'list';

		if(!$this->getIsPostBack())
		{
			$this->UpdateData->setObject($item);
			$this->populate();
		}
                
                if( ! $item->isInventoryNumberUnique() )
                {
                    $this->InventoryNumberLabel->Text = Prado::localize("NUMERO DI INVENTARIO") . " <b>(" . Prado::localize("multiplo") . ")</b>";
                }
                else
                {
                    $this->InventoryNumberLabel->Text = Prado::localize("NUMERO DI INVENTARIO");
                }
	}
        
                        

	/**
	 * Saves onto the database the object item.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 * @return null
	 */
	public function itemSave($sender, $param)
	{
		if(!$this->getPage()->getIsValid())
			return false;

		$this->cleanMessageQueue();
		
		$this->_item->setOpacVisible($this->OpacVisible->getChecked());
		if ($this->ItemIcon->getSelectedIndex() == 0)
			$this->_item->setItemIcon(null);
		else
			$this->_item->setItemIcon($this->ItemIcon->getSelectedValue());

		$this->_item->setReprint($this->Reprint->getSafeText());

		//collocazione
		if ($this->Section->getSelectedIndex() == 0)
			$this->_item->setSection(null);
		else
			$this->_item->setSection($this->Section->getSelectedValue());

		$this->_item->setCollocation($this->Collocation->getSafeText());
		$this->_item->setSequence1($this->Sequence1->getSafeText());
		$this->_item->setSequence2($this->Sequence2->getSafeText());
		$this->_item->setSpecification($this->Specification->getSafeText());

		$this->_item->setBarcode($this->Barcode->getSafeText());
		$this->_item->setRfidCode($this->Rfid->getSafeText());
		$this->_item->setMediapackageSize($this->Mediapackage_size->getSelectedValue());

		               
		//stati
		$oldItemStatus = $this->_item->getItemStatus();
		$newItemStatus = $this->ItemStatus->getSelectedValue();
		if (in_array($newItemStatus, ItemPeer::getItemStatusNotAvailable()))
		{
			$this->_item->setLoanClass(ItemPeer::LOANCLASS_UNAVAILABLE);
			$this->LoanClass->setSelectedValue(ItemPeer::LOANCLASS_UNAVAILABLE);
		}
		else
		{
			$this->_item->setLoanClass($this->LoanClass->getSelectedValue());
		}
		$this->_item->setItemStatus($newItemStatus);

		$logDiscard = array();
		// never discarded before
		if (ItemStatus::ITEMSTATUS_DISCARDED == $newItemStatus
			&& ItemStatus::ITEMSTATUS_DISCARDED != $oldItemStatus)  // if the new status is a discarded one and not the previous one
		{
			// we want to discard now
			$currentTime = time();
			$this->_item->setDateDiscarded(time());		// now

			$this->enqueueMessage(Prado::localize('Esemplare messo in stato di ') .
					LookupValuePeer::getLookupValue('ITEMSTATUS', $newItemStatus),
				ClavisMessage::WARNING);

			$logDiscard = array($this->_item, ChangelogPeer::LOG_UPDATE, $this->getUser(),
				'Esemplare messo in stato di ' .  LookupValuePeer::getLookupValue('ITEMSTATUS', $newItemStatus));

			$this->DateDiscardedPanel->setVisible(true);
			$this->DateDiscarded->setTimeStamp($currentTime);
		}
		else if (ItemStatus::ITEMSTATUS_DISCARDED == $newItemStatus)
		{
			$oldDateDiscarded = $this->_item->getDateDiscarded(null);
			$ddate = $this->DateDiscarded->getSafeText();
			$newDateDiscarded = ($ddate) ? new DateTime($ddate) : null;

			if ($newDateDiscarded &&
					$oldDateDiscarded->diff($newDateDiscarded)->days > 0 &&
					!$this->_item->isNew())
			{
				$this->_item->setDateDiscarded($newDateDiscarded);
				$this->enqueueMessage(Prado::localize('Modificata data di scarto da {old} a {new}',
						array('old' => Clavis::dateFormat($oldDateDiscarded),
							  'new' => Clavis::dateFormat($newDateDiscarded))),
					ClavisMessage::WARNING);

				$logDiscard = array($this->_item, ChangelogPeer::LOG_UPDATE, $this->getUser(),
					'Modificata data di scarto da ' . Clavis::dateFormat($oldDateDiscarded) .
						' a '. Clavis::dateFormat($newDateDiscarded));

				$this->DateDiscardedPanel->setVisible(null != $newDateDiscarded);
			}
		}
		
		$this->_item->setPhysicalStatus($this->PhysicalStatus->getSelectedValue());
		$this->_item->setItemMedia($this->ItemMedia->getSelectedValue());

		//valore
		$this->_item->setCurrency($this->ItemCurrency->getSelectedValue());
		$this->_item->setCurrencyValue(ClavisBase::numberFormat($this->ItemCost->getSafeText(), '#.00', null, false));
		$this->_item->setItemSource($this->ItemSource->getSelectedValue());


		//documenti di acquisto TBD
		//dati fisici
		$this->_item->setWidth($this->ItemWidth->getSafeText());
		$this->_item->setHeight($this->ItemHeight->getSafeText());
		$this->_item->setWeight(ClavisBase::numberFormat($this->ItemWeight->getSafeText(), '#.00', null, false));

		$this->_item->setVolumeNumber($this->ItemVolumeNumber->getSafeText());
		$this->_item->setVolumeText($this->ItemVolumeText->getSafeText());

		//TBC
		$this->_item->setLoanAlertNote($this->ItemAlertNote->getSafeText());
		$this->_item->setLoanAlert($this->ItemAlert->getSelectedValue());

		$this->_item->setCustomField1($this->Custom1->getSafeText());
		$this->_item->setCustomField2($this->Custom2->getSafeText());
		$this->_item->setCustomField3($this->Custom3->getSafeText());
		if ($this->customs_type[0] == 'list')
			$this->_item->setCustomField1($this->CustomList1->getSelectedValue());
		if ($this->customs_type[1] == 'list')
			$this->_item->setCustomField2($this->CustomList2->getSelectedValue());
		if ($this->customs_type[2] == 'list')
			$this->_item->setCustomField3($this->CustomList3->getSelectedValue());

                /*
                 * Inventory
                 * Check changed only. When db is imported may have not unuque inventory number.
                 * This help user if other fields modification needed.
                 */
                $iSer = $this->InventorySerieId->getSelectedValue();
                $iNr = $this->InventoryNumber->getSafeText();
                
                
                
                if($iNr != '')
                {
                    
                
                    if( $this->_item->setInventorySerieId() != $iSer  || $this->_item->setInventoryNumber() != $iNr )
                    {
                        $this->_item->setInventorySerieId($iSer);
                        $this->_item->setInventoryNumber($iNr);

                        if(  ! $this->_item->isInventoryNumberUnique() ) 
                        {
                            $this->Msg->setText(Prado::localize('Esiste già il numero di inventario') . 
                                    " " . $iNr . " per la serie " . $iSer);

                            return false;
                        }                  
                    }

                    $this->_item->setInventoryDate($this->InventoryDate->getTimeStamp());

                    $this->_item->save();

                    $iNrs = $this->_item->getIssueExistingInventory(
                            $this->_item->getIssueId(),  
                            $this->_item->getHomeLibraryId(), 
                            $this->_item->getManifestationId());

                    if($iNrs instanceof PropelArrayCollection)
                    {
                        //Prado::log(Prado::varDump($iNrs));

                        $ic = count($iNrs);


                        //if more than one was found
                        if( $ic > 1)
                        {

                            $msg = Prado::localize(' numeri seriali per questi fascicoli') . " ( *";

                            foreach ($iNrs as $iv)
                            {
                                $msg.= $iv['item.inventory_serie_id'] . "-" . $iv['item.inventory_number'] . "*";
                            }

                            $msg .= " )";

                            $msg = Prado::localize('ATTENZIONE: sono in uso '). $ic . $msg;

                            $this->enqueueMessage(  $msg , ClavisMessage::WARNING);
                            //Prado::log($msg);
                        }


                    }// inventory check and suggestion end

                    

                }// inv nr = ''
                else
                {
                    $this->_item->setInventorySerieId(NULL);
                    $this->_item->setInventoryNumber(NULL);
                    $this->_item->setInventoryDate(NULL);
                    $this->_item->save();
                }
                

		$this->getApplication()->getSession()->add('UpdateItemId', $this->_item->getItemId());
		$this->getApplication()->getSession()->add('UpdateClavisManageRequestsList', true);
		
		$this->enqueueMessage(Prado::localize("Esemplare modificato: titolo = '{title}', inventario = {inv}",
													array(	'title' => $this->_item->getTrimmedTitle(50, '/'), 
															'inv' => $this->_item->getCompleteInventoryNumber())),
											ClavisMessage::CONFIRM);

		if (count($logDiscard) == 4)
			ChangelogPeer::logAction(	$logDiscard[0],
										$logDiscard[1],
										$logDiscard[2],
										$logDiscard[3] );
		
		$this->flushDelayedMessage();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}

	public function populateSerieSection() 
	{
		$lid = $this->_item->getOwnerLibraryId();
		$inv_series = InventorySerieQuery::create()
			->orderByClosed()
			->orderByReadonly()
			->orderByInventorySerieId()
			->findByLibraryId($lid);
		//$ds = array(0 => '---');
		foreach ($inv_series as $i)
		{
			$ds[$i->getInventorySerieId()] = $i->getDescription() . ' (' .
				$i->getInventorySerieId() . ')';
		}
		$this->InventorySerieId->setDataSource($ds);
		$this->InventorySerieId->dataBind();
		$this->Section->setLibraryId($lid);
		$this->Section->populateList();
	}

	public function setItem($item)
	{
		if ($item == null)
			return false;

		if (!($item instanceof Item))
			return false;

		$this->_item = $item;
		$this->setViewState("Item", $item, null);
	}

	public function getItem()
	{
		if(is_null($this->_item))
			$this->_item = $this->getViewState("Item", null);
		return $this->_item;
	}

	public function setManifestation($manifestation)
	{
		if ($manifestation == null)
			return false;

		if (!($manifestation instanceof Manifestation))
			return false;

		$this->_manifestation = $manifestation;
		$this->setViewState("Manifestation", $manifestation, null);
	}

	public function getManifestation()
	{
		$this->_manifestation = $this->getViewState("Manifestation", null);
		return $this->_manifestation;
	}

	public function setListMode($mode)
	{
		$this->setViewState("ListMode", $mode, false);
	}

	public function getListMode()
	{
		return $this->getViewState("ListMode", false);
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		//$this->ItemView->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		//if ($component !== $this->ItemView)
		//	$this->ItemView->onCancel(null, null);
	}

	/**
	 * Whether this page can have components where the menus
	 * inside can generate unlink menus.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return true;
	}

	/**
	 * Whether this page can have components where the
	 * menus inside can have the standard links that
	 * popups have.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return true;
	}


	public function populate()
	{
		/* @var $this->_item Item */
		$this->populateSerieSection();
		$listMode = $this->getListMode();
		$this->ItemListPanel->setVisible($listMode);
		$this->ItemViewPanel->setVisible(!$listMode);

		if ($listMode)
		{
			if (is_null($this->getManifestation()))
				return;
		}
		else
		{
			if(is_null($this->getItem()))
				return;

			$ownerLibraryId = $this->_item->getOwnerLibraryId();
			$homeLibraryId = $this->_item->getHomeLibraryId();
			$actualLibraryId = $this->_item->getActualLibraryId();

			if (!$this->getUser()->getEditPermission($this->_item))
			{
				$this->ItemListPanel->setVisible(false);
				$this->ItemViewPanel->setVisible(false);
				$this->ErrorPanel->setVisible(true);
				$this->ErrorText->setText(Prado::localize('L\'utente non ha i diritti per modificare questo esemplare.'));
			}
			else
			{
				$this->ErrorPanel->setVisible(false);
			}

			$this->UpdateData->setObject($this->_item);
			$this->OpacVisible->setChecked($this->_item->getOpacVisible());

			$this->LoanClass->setSelectedValue($this->_item->getLoanClass());

			$itemIcon = $this->_item->getItemIcon();
			if (!is_null($itemIcon))
				$this->ItemIcon->setSelectedValue($itemIcon);
			$this->Reprint->setText($this->_item->getReprint());

			//collocazione
			$this->Section->setSelectedValue($this->_item->getSection());
			$this->Collocation->setText($this->_item->getCollocation());
			$this->Sequence1->setText($this->_item->getSequence1());
			$this->Sequence2->setText($this->_item->getSequence2());
			$this->Specification->setText($this->_item->getSpecification());
			//
			$this->Barcode->setText($this->_item->getBarcode());
			$this->Rfid->setText($this->_item->getRfidCode());
			$this->Mediapackage_size->setSelectedValue($this->_item->getMediapackageSize());

			//inventariazione
			$this->InventorySerieId->setSelectedValue($this->_item->getInventorySerieId());
			$this->InventoryNumber->setText($this->_item->getInventoryNumber());
			$this->InventoryDate->setTimestamp($this->_item->getInventoryDate('U'));

			//stati
			$this->ItemMedia->setSelectedValue($this->_item->getItemMedia());
			$this->ItemStatus->setSelectedValue($this->_item->getItemStatus());
			

			$dateDiscarded = intval($this->_item->getDateDiscarded('U'));
			if ($dateDiscarded > 0)
			{
				$this->DateDiscardedPanel->setVisible(true);
				$this->DateDiscarded->setTimeStamp($dateDiscarded);
			}
			else
			{
				$this->DateDiscardedPanel->setVisible(false);
			}
		
			$this->PhysicalStatus->setSelectedValue($this->_item->getPhysicalStatus());

			//valore
			$this->ItemCurrency->setSelectedValue($this->_item->getCurrency());
			
			$this->ItemCost->setText(ClavisBase::numberFormat($this->_item->getCurrencyValue(), '#.00'));
		
			$this->ItemSource->setSelectedValue($this->_item->getItemSource());

			//documenti di acquisto TBD
			
			//dati fisici
			$this->ItemWidth->setText($this->_item->getWidth());
			$this->ItemHeight->setText($this->_item->getHeight());
			$this->ItemWeight->setText(ClavisBase::numberFormat($this->_item->getWeight(), '#.00'));

			$this->ItemVolumeNumber->setText($this->_item->getVolumeNumber());
			$this->ItemVolumeText->setText($this->_item->getVolumeText());

			//TBC
			if ($ownerLibraryId != 0) {
				$ownerLibrary = LibraryPeer::retrieveByPK($ownerLibraryId);
				if (!is_null($ownerLibrary))
					$this->OwnerLibrary->setText($ownerLibrary->getLabel());
			}

			if ($homeLibraryId != 0) {
				$homeLibrary = LibraryPeer::retrieveByPK($homeLibraryId);
				if (!is_null($homeLibrary))
					$this->HomeLibrary->setText($homeLibrary->getLabel());
			}

			if ($actualLibraryId != 0) {
				$actualLibrary = LibraryPeer::retrieveByPK($actualLibraryId);
				if (!is_null($actualLibrary))
					$this->ActualLibrary->setText($actualLibrary->getLabel());
			}

			$this->ItemAlertNote->setText($this->_item->getLoanAlertNote());
			$this->ItemAlert->setSelectedValue($this->_item->getLoanAlert());

			$this->Custom1->setText($this->_item->getCustomField1());
			$this->Custom2->setText($this->_item->getCustomField2());
			$this->Custom3->setText($this->_item->getCustomField3());
			if ($this->customs_type[0] == 'list')
				$this->CustomList1->setSelectedValue($this->_item->getCustomField1());
			if ($this->customs_type[1] == 'list')
				$this->CustomList2->setSelectedValue($this->_item->getCustomField2());
			if ($this->customs_type[2] == 'list')
				$this->CustomList3->setSelectedValue($this->_item->getCustomField3());
                        
                        /*
                        * Check for better inventory number use.
                        * If a number exist for this issue, check that is
                        * the same of the other for this issue.
                        * If differ or more than one number is used,
                        * warning message was showed
                        */
                        $iNrs = $this->_item->getIssueExistingInventory(
                                $this->_item->getIssueId(),
                                $this->_item->getHomeLibraryId(),
                                $this->_item->getManifestationId()
                                );

                        if($iNrs instanceof PropelArrayCollection)
                        {
                            $ic = count($iNrs);
                            if( $ic > 1)
                            {
                                $this->Msg->setText("Seriali multipli per questo item");
                            }
                        }// inventory check and suggestion end
		}
	}

	public function validateBarcode($sender,$param)
	{
		$candidateBarcode = $param->getValue();
		$isDuplicate = ! ItemPeer::checkBarcodeUnique($candidateBarcode,$this->getItem());
		if ($isDuplicate) {
			$param->IsValid = false;
			$this->getPage()->writeMessage(Prado::localize("Il barcode '{barcode}' è già in uso nel sistema",
					array('barcode' => $candidateBarcode)), ClavisMessage::ERROR);
		} else {
			$param->IsValid = true;
		}
	}

	public function onResetDateDiscarded($sender, $param)
	{
		$this->DateDiscarded->setText('');
	}
	
	public function onCheckItemCost($sender, $param)
	{
		$param->isValid = true;
		
		$value = ClavisBase::numberFormat($this->ItemCost->getSafeText(), '#.00', null, false);
	
		if ($value < 0.00)
		{
			$this->ItemCostValidator->setErrorMessage('<br />' . Prado::localize('il prezzo dev\'essere maggiore di 0'));
			
			$param->isValid = false;
			return $param->isValid;
		}
	}	
	
}
