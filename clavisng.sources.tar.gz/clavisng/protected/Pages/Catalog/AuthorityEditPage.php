<?php
/**
 * AuthorityEditPage class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.0
 */

class AuthorityEditPage extends ClavisPage {

	public $_module = 'CATALOG';

	public function onInit($param) 
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$id = intval($this->getRequest()->itemAt('id'));
			if ($id>0) {
				$this->setAuthorityId($id);
				$this->AuthEdit->setAuthorityId($id);
			} else {
				$auth = new Authority();
				if ($v=$this->getRequest()->itemAt('Title'))
					$auth->setSortText($v);
				if ($v=$this->getRequest()->itemAt('authType'))
					$auth->setAuthorityType($v);
				$this->AuthEdit->authority = $auth;
			}
			$this->UpdateData->setObject(AuthorityPeer::retrieveByPK($id));
		}
	}

	public function setAuthorityId($value) 
	{
		$this->setViewState('AuthId',intval($value),null);
	}

	public function getAuthorityId() 
	{
		return $this->getViewState('AuthId',null);
	}

	public function onSave($sender, $param)
	{
		$wasNew = $this->AuthEdit->authority->isNew();
		$this->AuthEdit->onSave($sender,$param);

		if ($param->getCommandParameter() == 'apply')
			if ($wasNew)
				$this->gotoPage('Catalog.AuthorityEditPage',array('id' => $this->AuthEdit->getAuthorityId()));
			else
				$this->AuthEdit->populate();
		else
			$this->gotoPage('Catalog.AuthorityViewPage',array('id' => $this->AuthEdit->getAuthorityId()));
	}

	public function onCancelOperation($sender, $param)
	{
		if ($this->AuthEdit->getAuthorityId())
			$this->gotoPage('Catalog.AuthorityViewPage', array('id' => $this->AuthEdit->getAuthorityId()));
		else
			$this->gotoPage('Catalog.AuthorityViewPage');
	}
}
