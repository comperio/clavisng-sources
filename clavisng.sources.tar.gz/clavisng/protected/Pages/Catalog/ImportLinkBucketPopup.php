<?php
/**
 * ImportLinkBucketPopup class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Popups.Catalog
 */

/**
 * ImportLinkBucketPopup Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.5.0
 */
class ImportLinkBucketPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->populate();
	}
	
	private function populate()
	{
		$this->Bucket->setDataSource($this->getSession()->itemAt('ImportLinkBucket'));
		$this->Bucket->dataBind();
	}

	public function dataBindSubBucket($sender, $param) {
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem') {
			$item->SubBucket->setDataSource($item->Data['links']);
			$item->SubBucket->dataBind();
		}
	}

	public function bucketItemCreated($sender, $param) {
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem') {
			$m = ManifestationQuery::create()->findPk($item->Data['id']);
			if ($m instanceof Manifestation)
				$item->TitleLink->setText($m->getTrimmedTitle(80,' - '));
		}
	}

	public function onImport($sender, $param)
	{
		$deleted_flds = array();
		foreach ($this->ActionsGrid->getItems() as $rowItem => $item)
		{	
			if ($item->ItemType == 'Item' || $item->ItemType == 'AlternatingItem') {
				if (!$item->EnabledCol->ProcessField->getChecked()) {
					$ftag = "d{$item->FieldCol->Field->getText()}";
					$idx = $item->FieldCol->FieldIdx->getValue();
					// the following will correctly calculate the displacement due to
					// subsequent removal of nodes that have the same tag.
					if (array_key_exists($ftag, $deleted_flds))
						$idx -= $deleted_flds[$ftag];
					else
						$deleted_flds[$ftag] = 1;
					$loop = -1;
					foreach ($this->_turbomarc->$ftag as $field)
						if ($idx == ++$loop)
							$field->remove();
				}
			}
		}
		$this->setResult();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'detail\',\''.$this->_resultId.'\',true);');
	}
	
	public function onLinkAction($sender, $param)
	{
		$link = $param->getItem();
		$manid = $link->Parent->Parent->Data['id'];
		$linkbucket = $this->getSession()->itemAt('ImportLinkBucket');
		if (!array_key_exists($manid, $linkbucket))
			return;
		switch ($param->getCommandName()) {
			case 'choose':
				$this->getSession()->add('ImportLinkBucket',$linkbucket);
				$data = addslashes(serialize($link->Data));
				$bid = addslashes($link->Data['bid']);
				$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js',"onReturn('{$data}','{$bid}',true);");
				break;
			case 'delete':
				if (count($linkbucket[$manid]['links']) < 2)
					unset($linkbucket[$manid]);
				else 
					foreach ($linkbucket[$manid]['links'] as $k => $v)
						if ($v['bid'] == $link->Data['bid'])
							unset($linkbucket[$manid]['links'][$k]);
				$this->getSession()->add('ImportLinkBucket',$linkbucket);
				$this->populate();
				break;
			default:
				break;
		}
	}
	
	public function onCleanup($sender, $param)
	{
		$this->getSession()->add('ImportLinkBucket',array());
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'false\',\'false\',true);');
	}
}
