<?php
/**
 * NewRecordQuickPopup class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Popups.Catalog
 */

/**
 * NewRecordQuickPopup Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.1
 */
class NewRecordQuickPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';
		
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !($this->getIsCallback()))
		{
			$this->ErrorPanel->setVisible(false);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !($this->getIsCallback()))
		{
			$paramId = $this->getRequest()->itemAt('param');
			if (is_numeric($paramId) && ($paramId > 0))
			{
				$manifestation = ManifestationQuery::create()->findPk($paramId);
				if ($manifestation instanceof Manifestation)
				{
					$this->setManifestationId($paramId);
										
					$this->populate();
				}
			}
			else
			{
				$paramArray = unserialize($paramId);
				if (is_array($paramArray))
				{
					if (array_key_exists('manifestationId', $paramArray))
					{
						$manifestationId = $paramArray['manifestationId'];
						$manifestation = ManifestationQuery::create()->findPk($manifestationId);
						if ($manifestation instanceof Manifestation)
						{
							$this->setManifestationId($manifestationId);

							$this->populate();
						}		
					}
					
					if (array_key_exists('mode', $paramArray))
						$this->setMode($paramArray['mode']);
				}
			}
				
		}
	}

	public function setManifestationId($param = null)
	{
		$this->setViewState('ManifestationIdParam', $param, null);
	}

	public function getManifestationId()
	{
		return $this->getViewState('ManifestationIdParam', null);
	}
	
	public function getManifestation()
	{
		return ManifestationQuery::create()->findPk($this->getManifestationId());
	}
	
	public function setMode($param = "New")
	{
		if (($param != "New") && ($param != "Update"))
			$param = "New";
		
		$this->setViewState("Mode", $param, "New");
	}

	public function getMode()
	{
		return $this->getViewState("Mode", "New");
	}
	
	public function populate()
	{
		$manifestation = $this->getManifestation();
		if ($manifestation instanceof Manifestation)	// a manifestation was passed as a parameter, for editing (not creation)
		{
			$yearRaw = $manifestation->getYear();
			if ($yearRaw) 
				$year = $yearRaw['date'];
			else
				$year = '--';
			
			$manTurbomarc = $manifestation->getTurbomarc();
			if ($manTurbomarc instanceof Turbomarc)
			{
				$title = (string) $manTurbomarc->d200->sa;
				$author = trim((string) $manTurbomarc->d200->sf);
				
				$ean = $manTurbomarc->getEAN();
				$publisher = (string) $manTurbomarc->d210->sc;
				$serie = trim(implode('/', $manTurbomarc->getSeries()), '/');
			}
			else
			{
				$title = $manifestation->getTitle();
				$author = "";
				$ean = $manifestation->getEan();
				$publisher = $manifestation->getPublisher();
				$serie = '';
			}
			
			$priceManager = $this->getApplication()->getModule('price');
			$listPrice = $priceManager->getManifestationListPrice($manifestation);
			if (is_null($listPrice))
				$listPrice = '--';
			else
				$listPrice = ClavisBase::numberFormat($listPrice, '#.00');
			
			$this->Title->setText($title);
			$this->Author->setText($author);
			$this->EAN->setText($ean);
			$this->Publisher->setText($publisher);
			$this->Serie->setText($serie);
			$this->Year->setText($year);
			$this->ListPrice->setText($listPrice);
		}
	}
	
	/**
	 * Saves onto the database the object manifestation
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSave($sender, $param)
	{
		if (!$this->getPage()->getIsValid())
			return false;

		$this->cleanMessageQueue();
		
		// begin manifestation saving part
		$titleArray = explode('/', $this->Title->getSafeText());
		$title = rtrim($titleArray[0]) . ' / ' . $this->Author->getSafeText();
		
		$ean = $this->EAN->getSafeText();
		$year = $this->Year->getSafeText();
		$publisher = $this->Publisher->getSafeText();
		$serie = $this->Serie->getSafeText();
		
		$listPrice = ClavisBase::numberFormat($this->ListPrice->getSafeText(), '#.00', null, false);
	
		$manifestation = $this->getManifestation();
		if ($manifestation instanceof Manifestation)
		{
			$isNew = false;
		}
		else
		{
			$manifestation = new Manifestation();
			$isNew = true;
		}
		
		$tm = TurboMarc::createRecord();
		$l = new TurboMarcLeader();
		$l->recLen = '01234';
		$l->recstatus = 'n';
		
		$l->biblevel = ManifestationPeer::LVL_MONOGRAPHIC;
		$l->type = 'a';

		$tm->setLeader($l);
				
		$ean = Clavis::normalizeStdNum($ean);
		if (strlen($ean) == 13)
			$field = $tm->addField('073');
		else
			$field = $tm->addField('010');

		$field->addSubField('a', $ean);
		$field->addSubField('d', $listPrice);
		
		$f100 = $tm->addField('100');
		$f100->setCDF('a', 9, $year);
		$f100->setCDF('a', 8, 'd');
		
		$tm->setTitle($title);
		$tm->setPublication("s.l. : " . $publisher . ", " . $year);
		
		$tm->setSerie($serie);
		
		$manifestation->setUnimarc($tm->asXML());
		
		$manifestation->syncAuthor();
		$manifestation->syncTitle();
		
		$manifestation->setBibLevel(ManifestationPeer::LVL_MONOGRAPHIC);
		$manifestation->setBibTypeFirst('1');
		$manifestation->setBibType('a01');
		$manifestation->setEan($ean);
		
		$manifestation->setManifestationStatus(ManifestationPeer::STATUS_IMPORT);

		try
		{
			$savedCount = $manifestation->save();
			$manifestation->doIndex();
			$manifestation->reload(true);
			$manifestation->setQuick(true);
			$manifestation->save();
			
			ItemQuery::create()
				->filterByManifestation($manifestation)
				->update(array('Title'	=> $title));
			
			$errorCount = 0;
			
			//$this->getApplication()->getSession()->add('UpdateManifestationId', $manifestation->getManifestationId());
		}
		catch (Exception $e)
		{
			$savedCount = 0;
			$errorCount = 1;
		}
		// end of saving part
		
		if ($savedCount > 0)
		{
			if ($isNew)
			{
				$this->enqueueMessage(Prado::localize("Creata notizia con titolo '{title}', EAN = {ean}",
														array(	'title' => $title, 
																'ean' => $ean)),
										ClavisMessage::CONFIRM);


				ChangelogPeer::logAction($manifestation, ChangelogPeer::LOG_CREATE, $this->getUser(),
							'Creata nuova notizia (per ordine rapido) con id = ' . $manifestation->getManifestationId() 
							. ', titolo = ' . $title);
			}
			else	// already existed
			{
				$this->enqueueMessage(Prado::localize("Modificata notizia con titolo '{title}', EAN = {ean}",
														array(	'title' => $title, 
																'ean' => $ean)),
										ClavisMessage::CONFIRM);


				ChangelogPeer::logAction($manifestation, ChangelogPeer::LOG_CREATE, $this->getUser(),
							'Modificata notizia (per ordine rapido) con id = ' . $manifestation->getManifestationId() 
							. ', titolo = ' . $title);
			}
		}
		
		if (($savedCount == 0) || ($errorCount > 0))
		{
			$this->enqueueMessage(Prado::localize($isNew ? "Notizia non creata" : "Notizia non modificata"),
									ClavisMessage::ERROR);
		}
		
		$this->flushDelayedMessage();
		
		// close popup
		if ($savedCount > 0)
		{
			if ($this->getMode() == "New")
				$this->getApplication()->getSession()->add('UpdateManifestationId', $manifestation->getManifestationId());
			elseif ($this->getMode() == "Update")	
				$this->getApplication()->getSession()->add('UpdateClavisItemList', true);
			
			$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'' . $manifestation->getManifestationId() . '\',true);');
		}
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		//$this->ItemView->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		//if ($component !== $this->ItemView)
		//	$this->ItemView->onCancel(null, null);
	}

	/**
	 * Whether this page can have components where the menus
	 * inside can generate unlink menus.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return true;
	}

	/**
	 * Whether this page can have components where the
	 * menus inside can have the standard links that
	 * popups have.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return true;
	}

	public function onCheckEAN($sender, $param)
	{
		$ean = trim($this->EAN->getSafeText());
		if ($ean == "")
		{
			$this->EanOk->setStyle("display: none");
			$this->EanError->setStyle("display: none");
		}
		else
		{
			$eanValid = ClavisBase::checkEanValid($ean);
	
			$this->EanOk->setStyle($eanValid
										? "display: inline"
										: "display: none");

			$this->EanError->setStyle($eanValid
										? "display: none"
										: "display: inline");
		}
	}
	
}
