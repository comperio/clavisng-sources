<?php
/**
 * ImportEditPopup class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Popups.Catalog
 */
Prado::using('Application.Common.ImportDrivers.*');

/**
 * ImportEditPopup Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.5.0
 */
class ImportEditPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';
	private $_mode;
	private $_sourceId;
	private $_resultId;
	/** @var TurboMarc */
	private $_turbomarc;

	public $linkCheck;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$p = $this->getRequest()->itemAt('param') or 0;
		$this->_mode = $this->getRequest()->itemAt('objectType');
		if (!$this->_mode)
			$this->_mode = 'import';
		if (!$p || is_numeric($p)) {
			$this->_sourceId = $this->getSession()->itemAt('ActiveSource');
			$this->_resultId = intval($p);
			$this->getResult();
		} else {
			$this->_turbomarc = TurboMarc::createRecord($p);
		}
		if (!$this->getIsPostBack() && !$this->getIsCallback())
			$this->populate();
	}

	public function getMode() {
		return $this->_mode;
	}

	private function populate()
	{
		if ($this->getUser()->getIsAdmin())
			$this->TurboMarcSource->setText(Clavis::formatXMLString($this->_turbomarc->asXML()));
		else
			$this->TurbomarcSourceTab->setVisible(false);
		$linkbucket = array();
		$actions = ManifestationPeer::createFromTurbomarc($this->_turbomarc,true,$linkbucket);
		foreach ($actions as &$action)
			$action[3] = preg_replace('/\[(.+?)\]/i', '[<pre style="display:inline;"><strong>\1</strong></pre>]', $action[3]);
		$this->ActionsGrid->setDataSource($actions);
		$this->ActionsGrid->dataBind();
		if (count($linkbucket)) {
			$linkbucket = array_shift($linkbucket);
			$this->LinkGrid->setDataSource($linkbucket['links']);
		}
		$this->LinkGrid->dataBind();
		$this->EnabledCol->setVisible($this->_mode == 'import');
	}
	
	private function getResult()
	{
		$results = $this->getSession()->itemAt('NewRecordLastResults');
		$driver = new $results[$this->_sourceId]['DriverClass'];
		$tmxml = $driver->getFullTurbomarcRecord($results[$this->_sourceId]['Results'][$this->_resultId]['Turbomarc']);
		if ($tmxml)
			$this->_turbomarc = TurboMarc::createRecord($tmxml);
	}
	
	private function setResult()
	{
		$results = $this->getSession()->itemAt('NewRecordLastResults');
		$results[$this->_sourceId]['Results'][$this->_resultId]['Turbomarc'] = $this->_turbomarc->asXML();
		$this->getSession()->add('NewRecordLastResults',$results);
	}

	public function onImport($sender, $param)
	{
		$deleted_flds = array();
		foreach ($this->ActionsGrid->getItems() as $rowItem => $item)
		{	
			if ($item->ItemType == 'Item' || $item->ItemType == 'AlternatingItem') {
				if (!$item->EnabledCol->ProcessField->getChecked()) {
					$ftag = "d{$item->FieldCol->Field->getText()}";
					// the following will correctly calculate the displacement due to
					// subsequent removal of nodes that have the same tag.
					if (!isset($deleted_flds[$ftag]))
						$deleted_flds[$ftag] = 0;
					$idx = $item->FieldCol->FieldIdx->getValue() - $deleted_flds[$ftag];
					$loop = -1;
					foreach ($this->_turbomarc->$ftag as $field)
						if ($idx == ++$loop) {
							$field->remove();
							++$deleted_flds[$ftag];
						}
				}
			}
		}
		$this->setResult();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'detail\',\''.$this->_resultId.'\',true);');
	}

	public function onLinkAction($sender, $param)
	{
		$link = $param->getItem();
		$manid = $link->Parent->Data['bid'];
		$linkbucket = $this->getSession()->itemAt('ImportLinkBucket');
		if (!array_key_exists($manid, $linkbucket))
			return;
		switch ($param->getCommandName()) {
			case 'choose':
				$this->getSession()->add('ImportLinkBucket',$linkbucket);
				$data = addslashes(serialize($link->Data));
				$bid = addslashes($link->Data['bid']);
				$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js',"onReturn('{$data}','{$bid}',true);");
				break;
			default:
				break;
		}
	}
}
