<?php
/**
 * LLibraryEditPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Library
 */

/**
 * LLibraryEditPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Library
 * @since 2.0
 */
class LLibraryEditPage extends ClavisPage 
{
	const BASIN_DIST = 1;
	const NOBASIN_DIST = 2;
	
	public $_module = 'ADMIN';
	protected $_max_llibrary_distance;
	
	private function initVars()
	{
		$this->_max_llibrary_distance = LLibraryPeer::getMaxLLibraryDistance();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->setFromAllLibrariesFlag(false);
			$this->MutualSwitch->setChecked(false);
			
			//	populate FromLibrary
			$this->drawFromLibrary(true);	// first time we want to autoselect
			
			$this->GeneralDistanceDropDown->setDataSource(LLibraryPeer::calculateLLibraryDistanceHash());
			$this->GeneralDistanceDropDown->dataBind();

			//	populate LibraryGrid
			$this->populate();
		}
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		parent::checkAuth(LLibraryPeer::isEnabled());
	}
	
	public function setFromAllLibrariesFlag($param = false)
	{
		if (($param !== true) && ($param !== false))
			$param = false;
		
		$this->setViewState('FromAllLibrariesFlag', $param, null);
	}

	public function getFromAllLibrariesFlag()
	{
		$value = $this->getViewState('FromAllLibrariesFlag', false);

		if (($value !== true) && ($value !== false))
			$value = false;
		
		return $value;
	}

	public function onSwitchAllLibrariesFlag($sender, $param)
	{
		$buttonId = $sender->getId();
		if ($buttonId == 'FromAllLibrariesLinkButton')
			$this->setFromAllLibrariesFlag(true);
		elseif ($buttonId == 'FromMyLibrariesLinkButton')
			$this->setFromAllLibrariesFlag(false);
		
		$this->drawFromLibrary();
	}
	
	private function drawFromLibrary($autoSelectFlag = false)
	{
		$actualLibraryId = $this->FromLibrary->getSelectedValue();
		
		if ($this->getFromAllLibrariesFlag())
		{
			$allLibraries = LibraryPeer::getLibrariesHash(	null, 
															null, 
															null, 
															true, // only internal
															false );  // true  -   all, and append notice if external
			
			$this->FromAllLibrariesLinkButton->setStyle('display: none');
			$this->FromMyLibrariesLinkButton->setStyle('display: inline');
			
			$this->FromLibrary->setToolTip(Prado::localize("lista con tutte le biblioteche del sistema"));
		}
		else
		{
			$allLibraries = $this->getUser()->getLibraries();
			
			$this->FromAllLibrariesLinkButton->setStyle('display: inline');
			$this->FromMyLibrariesLinkButton->setStyle('display: none');
			
			$this->FromLibrary->setToolTip(Prado::localize("lista con le sole biblioteche collegate a questo profilo operatore"));
		}
		
		$this->FromLibrary->setDataSource($allLibraries);
		$this->FromLibrary->dataBind();
		
		if ($autoSelectFlag || (!in_array($actualLibraryId, array_keys($allLibraries))))
			$actualLibraryId = intval($this->getUser()->getActualLibraryId());
		
		if ($actualLibraryId > 0)
		{
			try
			{
				$this->FromLibrary->setSelectedValue($actualLibraryId);
			}
			catch (Exception $e)
			{
				//throw ($e);
			}
		}			
	}
	
	public function calculateSortingMode() 
	{
		$sortingExpression = $this->LibraryGrid->getSortingExpression();
		$sortingDirection = $this->LibraryGrid->getSortingDirection();
		
		switch ($sortingExpression) 
		{
			case 'Distance':
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$mode = 3;
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$mode = 4;
				break;

			case 'ToLibraryLabel':
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$mode = 1;
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$mode = 2;
				break;

			case null:
			default:
				$mode = 1;
				break;
		}
		
		return $mode;
	}
	
	private function drawLibraryGrid($allLibraries = array())
	{
		$actualLibraryId = intval($this->FromLibrary->getSelectedValue());

		$allLibraries = LibraryPeer::getLibrariesHash(	null, 
														null, 
														null, 
														true, //null - only internal
														false,//true
				
														null,
														$this->calculateSortingMode() );  // all, and append notice if external

		$distanceDropDownDataSource = LLibraryPeer::calculateLLibraryDistanceHash();

		$gridDataSource = array();
		foreach ($allLibraries as $libraryId => $libraryLabel)
		{
			$lLibrary = LLibraryQuery::create()
						->findPk(array($actualLibraryId, $libraryId));

			if ($libraryId == $actualLibraryId)
			{
				if (!($lLibrary instanceof LLibrary))
					$this->writeMessage(Prado::localize("Attenzione: la distanza 0 ['prestiti locali ammessi'] con la propria biblioteca non è stata inizializzata"),
										ClavisMessage::WARNING);
				
				continue;
			}

			$selectedDistance = (($lLibrary instanceof LLibrary)
									? $lLibrary->getDistance()
									: -1 );

			$gridDataSource[] = array(	'LibraryLabel' => $libraryLabel,
										'LibraryId' => $libraryId,
										'DistanceDataSource' => $distanceDropDownDataSource,
										'SelectedDistance' => $selectedDistance	);
		}	

		$this->LibraryGrid->setDataSource($gridDataSource);
		$this->LibraryGrid->dataBind();
	}
	
	public function populate()
	{
		$this->drawLibraryGrid();
	}

		
	public function onFromLibraryChanged($sender, $param)
	{
		$this->drawLibraryGrid();
		
		if ($this->getIsCallback())
		{
			if (is_null($param))
				$this->LibraryGridPanel->render($this->createWriter());
			else
				$this->LibraryGridPanel->render($param->getNewWriter());
		}
	}
	
	public function onMasterChecked($sender, $param)
	{
		switch ($sender->getID())
		{
			case "MasterCheckYes":
				$checked = true;
				break;

			case "MasterCheckNo":
			default:
				$checked = false;
				break;
		}
		
		$header = $this->LibraryGrid->getHeader();

		foreach ($this->LibraryGrid->getItems() as $rowItem)
			$rowItem->CheckColumn->Checked->setChecked($checked);

		$header->CheckColumn->MasterCheckYes->setVisible(!$checked);
		$header->CheckColumn->MasterCheckNo->setVisible($checked);
	}
	
	public function onCreateBasin($sender, $param)
	{
		$fromLibraryId = intval($this->FromLibrary->getSelectedValue());
		if ($fromLibraryId == 0) 
		{
			$this->writeMessage(Prado::localize("La biblioteca di partenza non è valida"),
				ClavisMessage::ERROR);
			
			return false;
		}

		$libraryIdArray = array();
		foreach ($this->LibraryGrid->getItems() as $rowItem)
		{
			if (($rowItem->getItemType() != "Item") && ($rowItem->getItemType() != "AlternatingItem")
					|| $rowItem->CheckColumn->Checked->getChecked() == false)
				continue;
			
			$libraryId = intval($rowItem->ToLibraryColumn->LibraryId->getValue());
			if ($libraryId > 0)
				$libraryIdArray[] = $libraryId;
		}

		if (count($libraryIdArray) == 0)
		{
			$this->writeMessage(Prado::localize("Non è stata selezionata alcuna biblioteca dalla lista"),
				ClavisMessage::WARNING);
			
			return false;

		}
		
		$libraryIdArray[] = $fromLibraryId;
		
		$otherLibraryIdResult = LibraryQuery::create()
									->filterByLibraryInternal("1")
									->select("LibraryId")
									->where("LIBRARY_ID NOT IN (" . implode($libraryIdArray, ",") . ")")
									->find();

		$this->cleanMessageQueue();
		
		$newBasin = 0;
		$modifiedBasin = 0;
		$newOther = 0;
		$modifiedOther = 0;
		$errors = 0;
		$basinLibraryLabels = "";
		
		do
		{
			$leftLibraryId = array_shift($libraryIdArray); 
				
			if (intval($leftLibraryId) == 0)
				continue;

			$basinLibraryLabels .= LibraryPeer::getLibraryLabel($leftLibraryId) . ", ";
			
			// basin part
			if ($leftLibraryId != $fromLibraryId)	// skip last element, which surely doesn't need new connections
			{
				foreach ($libraryIdArray as $rightLibraryId)
				{
					list(	$deltaNew, 
							$deltaModified, 
							$deltaDeleted, 
							$deltaErrors) = $this->editLLibrary($leftLibraryId, 
																$rightLibraryId, 
																self::BASIN_DIST );

					list(	$deltaNewR, 
							$deltaModifiedR, 
							$deltaDeletedR, 
							$deltaErrorsR) = $this->editLLibrary($rightLibraryId, 
																$leftLibraryId, 
																self::BASIN_DIST );

					$newBasin += $deltaNew + $deltaNewR;
					$modifiedBasin += $deltaModified + $deltaModifiedR;
					$errors += $deltaErrors + $deltaErrorsR;
				}
			}
			// end of basin part
			
			// other libraries part
			foreach ($otherLibraryIdResult as $rightLibraryId)
			{
				list(	$deltaNew, 
						$deltaModified, 
						$deltaDeleted, 
						$deltaErrors) = $this->editLLibrary($leftLibraryId, 
															$rightLibraryId, 
															self::NOBASIN_DIST );

				list(	$deltaNewR, 
						$deltaModifiedR, 
						$deltaDeletedR, 
						$deltaErrorsR) = $this->editLLibrary($rightLibraryId, 
															$leftLibraryId, 
															self::NOBASIN_DIST );

				$newOther += $deltaNew + $deltaNewR;
				$modifiedOther += $deltaModified + $deltaModifiedR;
				$errors += $deltaErrors + $deltaErrorsR;
			}
			// end of others
		}
		while ($leftLibraryId != $fromLibraryId);
		
		if ($newBasin > 0)
			$this->enqueueMessage(Prado::localize("Create {num} distanze per il bacino", 
													array('num' => $newBasin)),
									ClavisMessage::CONFIRM);
		
		if ($modifiedBasin > 0)
			$this->enqueueMessage(Prado::localize("Modificate {num} distanze per il bacino", 
													array('num' => $modifiedBasin)),
									ClavisMessage::CONFIRM);

		if ($newOther > 0)
			$this->enqueueMessage(Prado::localize("Create {num} distanze per il resto delle biblioteche fuori bacino", 
													array('num' => $newOther)),
									ClavisMessage::CONFIRM);

		if ($modifiedOther > 0)
			$this->enqueueMessage(Prado::localize("Modificate {num} distanze per il resto delle biblioteche fuori bacino", 
													array('num' => $modifiedOther)),
									ClavisMessage::CONFIRM);


		if ($errors > 0)
			$this->enqueueMessage(Prado::localize("Si sono verificati {num} errori", 
													array('num' => $errors)),
									ClavisMessage::ERROR);

		if ((	$newBasin + $newOther +
				$modifiedBasin + $modifiedOther +
				$errors) == 0)
			$this->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
								ClavisMessage::INFO);
		else	// at least 1 update has been made
		{
			$basinLibraryLabels = rtrim($basinLibraryLabels, ", ");
			
			$this->enqueueMessage(Prado::localize("Bacino creato"). ($basinLibraryLabels != ""
																		? " " . Prado::localize("fra le biblioteche: ") . $basinLibraryLabels
																		: ""),
								ClavisMessage::CONFIRM);
			
			$this->getUser()->setDistanceHash($fromLibraryId);
			$this->getUser()->reloadUser();

			$this->populate();
		}

		$this->flushMessage();
	}
	
	public function onApply($sender, $param)
	{
		$fromLibraryId = intval($this->FromLibrary->getSelectedValue());
		if ($fromLibraryId == 0)
		{
			$this->writeMessage(Prado::localize("La biblioteca di partenza non è valida"),
				ClavisMessage::ERROR);
			
			return false;
		}

		$this->cleanMessageQueue();

		$generalDistanceFlag = $this->GeneralDistanceSwitch->getChecked();
		if ($generalDistanceFlag)
		{
			$generalDistance = $this->GeneralDistanceDropDown->getSelectedValue();
			$this->enqueueMessage(Prado::localize("Applico distanza {dist} a tutte le biblioteche selezionate", 
													array('dist' => ($generalDistance >= 0
																			? $generalDistance
																			: Prado::localize('nulla')))),
									ClavisMessage::CONFIRM);
		}
		else
		{
			$generalDistance = null;
		}
		
		$mutualFlag = $this->MutualSwitch->getChecked();
		$new = 0;
		$modified = 0;
		$deleted = 0;
		$errors = 0;
		$reciprocalNew = 0;
		$reciprocalModified = 0;
		$reciprocalDeleted = 0;
		
		foreach ($this->LibraryGrid->getItems() as $rowItem)
		{
			if (($rowItem->getItemType() != "Item") && ($rowItem->getItemType() != "AlternatingItem")
					|| ($rowItem->CheckColumn->Checked->getChecked() == false))
				continue;
			
			$distance = (is_null($generalDistance)
							? $rowItem->DistanceColumn->DistanceDropDown->getSelectedValue()
							: $generalDistance);
			
			$toLibraryId = intval($rowItem->ToLibraryColumn->LibraryId->getValue());
			if ($toLibraryId > 0)
			{		
				list(	$deltaNew, 
						$deltaModified, 
						$deltaDeleted, 
						$deltaErrors) = $this->editLLibrary($fromLibraryId, 
															$toLibraryId, 
															$distance );
				$new += $deltaNew;
				$modified += $deltaModified;
				$deleted += $deltaDeleted;
				$errors += $deltaErrors;
				
				if ($mutualFlag)
				{
					list(	$deltaNew, 
							$deltaModified, 
							$deltaDeleted, 
							$deltaErrors) = $this->editLLibrary($toLibraryId,	// inverted
																$fromLibraryId, 
																$distance );
					$reciprocalNew += $deltaNew;
					$reciprocalModified += $deltaModified;
					$reciprocalDeleted += $deltaDeleted;
					$errors += $deltaErrors;
					
				}
			}
		}
		
		if ($new > 0)
			$this->enqueueMessage(Prado::localize("Create {num} distanze", 
													array('num' => $new)),
									ClavisMessage::CONFIRM);
		
		if ($modified > 0)
			$this->enqueueMessage(Prado::localize("Modificate {num} distanze", 
													array('num' => $modified)),
									ClavisMessage::CONFIRM);

		if ($deleted > 0)
			$this->enqueueMessage(Prado::localize("Cancellate {num} distanze", 
													array('num' => $deleted)),
									ClavisMessage::WARNING);

		if ($reciprocalNew > 0)
			$this->enqueueMessage(Prado::localize("Create {num} distanze reciproche", 
													array('num' => $reciprocalNew)),
									ClavisMessage::CONFIRM);
		
		if ($reciprocalModified > 0)
			$this->enqueueMessage(Prado::localize("Modificate {num} distanze reciproche", 
													array('num' => $reciprocalModified)),
									ClavisMessage::CONFIRM);

		if ($reciprocalDeleted > 0)
			$this->enqueueMessage(Prado::localize("Cancellate {num} distanze reciproche", 
													array('num' => $reciprocalDeleted)),
									ClavisMessage::WARNING);
		
		if ($errors > 0)
			$this->enqueueMessage(Prado::localize("Si sono verificati {num} errori", 
													array('num' => $errors)),
									ClavisMessage::ERROR);

		if (($new + $modified + $deleted + 
					$reciprocalNew + $reciprocalModified + $reciprocalDeleted +
					$errors) == 0)
		{
			$this->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
								ClavisMessage::INFO);
		}
		else
		{
			$this->getUser()->setDistanceHash($fromLibraryId);
			$this->getUser()->reloadUser();
			
			$this->populate();
		}
		
		$this->flushMessage();
	}
	
	private function editLLibrary(	$fromLibraryId, 
									$toLibraryId, 
									$distance )
	{
		$new = 0;
		$modified = 0;
		$deleted = 0;
		$errors = 0;
		
		try
		{
			if ($distance == -1)	// to delete, if exists
			{
				$lLibrary = LLibraryQuery::create()
							->findPk(array($fromLibraryId, $toLibraryId));
				if ($lLibrary instanceof LLibrary)
				{
					$lLibrary->delete();
					$deleted++;
				}
			}
			else	// to create or to modify
			{
				$lLibrary = LLibraryQuery::create()
							->filterByFromLibraryId($fromLibraryId)
							->filterByToLibraryId($toLibraryId)
							->findOneOrCreate();

				if ($lLibrary instanceof LLibrary)
				{
					$isNew = $lLibrary->isNew();
					if (intval($lLibrary->getDistance()) != $distance)
					{
						$lLibrary->setDistance($distance);
						$lLibrary->save();

						if ($isNew)
							$new++;
						else
							$modified++;
					}
				}
			}
		}
		catch (Exception $e)
		{
			//throw ($e);
			$errors++;
		}
		
		return array(	$new,
						$modified,
						$deleted,
						$errors );
	}
	
	public function onInitializeZeroDistance($sender, $param)
	{
		$existingZeroLLibraries = LLibraryQuery::create()
								->where("FROM_LIBRARY_ID = TO_LIBRARY_ID")
								->filterByDistance("0")
								->select("FromLibraryId")
								->find();
		
		$existingZeroLLibrariesArray = $existingZeroLLibraries->toArray();

		// only internal libraries and without self-distance = 0
		$librariesQuery = LibraryQuery::create()
							->filterByLibraryInternal("1")
							->select("LibraryId");
		
		if (count($existingZeroLLibrariesArray) > 0)
			$librariesQuery->where("LIBRARY_ID NOT IN (" . implode($existingZeroLLibraries->toArray(), ",") . ")");
		
		$libraries = $librariesQuery->find();

		if ($libraries->isEmpty())
		{
			$this->writeMessage(Prado::localize("Non sono state trovate biblioteche su cui operare."),
									ClavisMessage::WARNING);
			
			return false;
		}
		
		$this->cleanMessageQueue();

		$done = 0;
		$errors = 0;
		
		foreach ($libraries as $libraryId)
		{
			try
			{
				$lLibrary = new LLibrary;
				$lLibrary->setFromLibraryId($libraryId);
				$lLibrary->setToLibraryId($libraryId);
				$lLibrary->setDistance(0);
				$affected = $lLibrary->save();
				
				if ($affected > 0)
					$done++;
			}
			catch (Exception $e)
			{
				//throw ($e);
				$errors++;
			}
			
		}
		
		if ($done > 0)
			$this->enqueueMessage(Prado::localize("Inizializzate {num} distanze zero", array('num' => $done)),
								ClavisMessage::CONFIRM);
		
		if ($errors > 0)
			$this->enqueueMessage(Prado::localize("Si sono verificati {num} errori", array('num' => $errors)),
								ClavisMessage::ERROR);

		if (($done + $errors) == 0)
			$this->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
								ClavisMessage::INFO);
		
		$this->flushMessage();
	}
	
	/**
	 * Are we inside a popup?
	 *
	 * @return boolean
	 */
	public function getPopupFlag() 
	{
		return $this->getPage()->IsPopup();
	}
	
}
