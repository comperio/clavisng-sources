<?php

/**
 * SMSHistory Page class Module Administration
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class SMSHistory extends ClavisPage {

	public $_module = 'ADMIN';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->dataBind();
		}
	}
}
