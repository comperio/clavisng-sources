<?php

/**
 * LoanViewPage class
 *
 * Displays loan data.
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.0
 */

class LoanViewPage extends ClavisPage {

	public $_module = 'CIRCULATION';

	protected $_loanmanager;

	private $_fromLibraryId;
	private $_toLibraryId;
	private $_endLibraryId;
	private $_homeLibraryId;
	private $_loanStatus;

	public function onInit($param)
	{
		parent::onInit($param);
		$this->_loanmanager = $this->getApplication()->getModule('loan');

		$this->LoanList->setAutomaticPopulate(false);

		$this->MultiSoliciter->setGetCheckedItemsFunctionName('getCheckedItems');
		$this->MultiSoliciter->setCountCheckedItemsFunctionName('countCheckedItems');
		$this->MultiSoliciter->setInitialReloadFunctionName('loanListInitialReload');

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
			$this->doCleanSearch(false);
	}

	/**
	 * It manages the mechanism of setting (resetting/initialization) the
	 * dropdowns which perform as filters for the population of the
	 * loans grid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_fromLibraryId = $this->getFromLibraryId();
		$this->_toLibraryId = $this->getToLibraryId();
		$this->_endLibraryId = $this->getEndLibraryId();
		$this->_homeLibraryId = $this->getHomeLibraryId();
		$this->_loanStatus = $this->getLoanStatus();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$librariesWithBlank = LibraryPeer::getLibrariesHash(array(LibraryPeer::BLANKVALUE, LibraryPeer::EXCLUDEMYLIBRARY),
																array('---','<' . Prado::localize('tutte tranne la mia') . '>'),
																null,
																true );

			$this->FromLibrary->setDataSource($librariesWithBlank);
			$this->ToLibrary->setDataSource($librariesWithBlank);
			$this->EndLibrary->setDataSource($librariesWithBlank);
			$this->HomeLibrary->setDataSource($librariesWithBlank);

			$activeList = $this->_loanmanager->GetActiveLoanStatuses2DropDownList(true);    // with blank
			$inactiveList = $this->_loanmanager->GetInactiveLoanStatuses2DropDownList();
			$list = array_merge($activeList, $inactiveList);
			$this->LoanStatus->setDataSource($list);

			$this->ControlSwitches->dataBind();
			$this->FromLibrary->SelectedValue = $this->getUser()->getActualLibraryId();
			$this->_fromLibraryId = $this->getUser()->getActualLibraryId();

			$connection = Propel::getConnection();
			$pdo = $connection->prepare('SELECT max(`param_value`) FROM `clavis_param` where `param_class`="MAXLOANRENEWS"');
			$pdo->execute();
			$maxRenews = intval($pdo->fetchColumn(0));
			if (is_null($maxRenews))
				$maxRenews = -1;

			$renewDS = array();
			if ($maxRenews >= 0)
			{
				$renewDS[-1] = Prado::localize('bloccato');
				$renewDS["-0.5"] = '---';

				if ($maxRenews > 0)
					$renewDS["0.5"] = Prado::localize('più di') . ' 0';

				for ($renCycle = 0; $renCycle <= $maxRenews; $renCycle++)
					$renewDS[$renCycle] = $renCycle;
			}

			ksort($renewDS);

			$this->RenewCount->setDataSource($renewDS);
			$this->RenewCount->dataBind();
			$this->RenewCount->setSelectedValue("-0.5");

			$this->SolicitCount->setDataSource(array(	-1 => '--',
														0 => '0',
														1 => '1',
														2 => '2',
														3 => Prado::localize('più di') . ' 2') );
			$this->SolicitCount->dataBind();

			$oocMode = $this->OocModeFilter->getSelectedValue();
			if ($oocMode == "1")
				$oocMode = true;
			else
				$oocMode = false;

			$this->LoanList->setFilters($this->_fromLibraryId,
										$this->_toLibraryId,
										$this->_endLibraryId,
										$this->_homeLibraryId,
										$this->_loanStatus,

										null,
										null,
										null,
										null,
										null,

										null,
										null,
										null,
										null,
										null,

										null,
										null,
										null,
										null,
										null,

										null,
										$oocMode );

			$this->LoanList->resetDataSource(false);

			$this->ContactBooleanFilter->setDataSource(array(	1 => Prado::localize('con'),
																0 => Prado::localize('senza') ));
			$this->ContactBooleanFilter->dataBind();
			$this->ContactBooleanFilter->setSelectedValue(1);
		}

		$this->doRenderPrintPanel();
	}

	private function doRenderPrintPanel()
	{
		$this->PrintPanel->setStyle('display:' . (count($this->LoanList->getDataSource()) > 0 
														? 'block' 
														: 'none'));
	}

 	public function setToLibraryId($lib)
 	{
 		$this->_toLibraryId = $lib;
 		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
 	}

 	public function getToLibraryId()
 	{
 		if (($lib = $this->_toLibraryId) == null)
 		{
 			$lib = $this->getViewState('toLibraryId', null);
 			$this->_toLibraryId = $lib;
 		}
		return $lib;
 	}

 	public function setFromLibraryId($lib)
 	{
 		$this->_fromLibraryId = $lib;
 		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
 	}

 	public function getFromLibraryId()
 	{
 		if (($lib = $this->_fromLibraryId) == null)
 		{
 			$lib = $this->getViewState('fromLibraryId', null);
 			$this->_fromLibraryId = $lib;
 		}
		return $lib;
 	}

 	public function setEndLibraryId($lib)
 	{
 		$this->_endLibraryId = $lib;
 		$this->setViewState('endLibraryId', $this->_endLibraryId, null);
 	}

 	public function getEndLibraryId()
 	{
 		if (($lib = $this->_endLibraryId) == null)
 		{
 			$lib = $this->getViewState('endLibraryId', null);
 			$this->_endLibraryId = $lib;
 		}
		return $lib;
 	}

 	public function setHomeLibraryId($lib)
 	{
 		$this->_homeLibraryId = $lib;
 		$this->setViewState('homeLibraryId', $this->_homeLibraryId, null);
 	}

 	public function getHomeLibraryId()
 	{
 		if (($lib = $this->_homeLibraryId) == null)
 		{
 			$lib = $this->getViewState('homeLibraryId', null);
 			$this->_homeLibraryId = $lib;
 		}
		return $lib;
 	}

 	public function setLoanStatus($loanStatus)
 	{
 		$this->_loanStatus = $loanStatus;
 		$this->setViewState('loanStatus', $this->_loanStatus, null);
 	}

 	public function getLoanStatus()
 	{
 		if (($loanStatus = $this->_loanStatus) == null)
 		{
 			$loanStatus = $this->getViewState('loanStatus', null);
 			$this->_loanStatus = $loanStatus;
 		}
		return $loanStatus;
 	}

 	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
 	public function isPopup()
 	{
 		return false;
 	}

 	/**
 	 * It refreshes all the components (grids) in the page,
 	 * altogether.
 	 *
 	 */
 	public function globalRefresh()
 	{
 		$toLibraryId = $this->ToLibrary->getSelectedValue();
		$fromLibraryId = $this->FromLibrary->getSelectedValue();
		$endLibraryId = $this->EndLibrary->getSelectedValue();
		$homeLibraryId = $this->HomeLibrary->getSelectedValue();
		$loanStatus = $this->LoanStatus->getSelectedValue();
		$solicitable = $this->Solicitable->getChecked();
		$itemMedia = $this->ItemMedia->getSelectedValue();

		$withItemRequest = $this->WithItemRequest->getChecked();
		if ($solicitable)
		{
			$withExpired = false;
			$this->WithExpired->setChecked(false);
		}
		else
		{
			$withExpired = $this->WithExpired->getChecked();
		}

		$patronId = $this->HiddenValue->Value;
		$renewCount = $this->RenewCount->getSelectedValue();
		$solicitCount = $this->SolicitCount->getSelectedValue();

		$outDateFrom = $this->OutDateFrom->getSafeText() != '' ? $this->OutDateFrom->getTimeStamp() : null;
		$outDateTo = $this->OutDateTo->getSafeText() != '' ? $this->OutDateTo->getTimeStamp() : null;
		$inDateFrom = $this->InDateFrom->getSafeText() != '' ? $this->InDateFrom->getTimeStamp() : null;
		$inDateTo = $this->InDateTo->getSafeText() != '' ? $this->InDateTo->getTimeStamp() : null;
		$dueDateFrom = $this->DueDateFrom->getSafeText() != '' ? $this->DueDateFrom->getTimeStamp() : null;
		$dueDateTo = $this->DueDateTo->getSafeText() != '' ? $this->DueDateTo->getTimeStamp() : null;

		$contactFilter = $this->ContactFilter->getSelectedValue();
		$preferredContact = $this->PreferredCheck->getChecked();
		switch ($this->ContactBooleanFilter->getSelectedValue())
		{
			case 0:
				$contactBoolean = false;
				break;

			case 1:
			default:
				$contactBoolean = true;
		}

		$oocMode = $this->OocModeFilter->getSelectedValue();
		if ($oocMode == "1")
			$oocMode = true;
		else
			$oocMode = false;

  		$this->LoanList->setFilters($fromLibraryId,
									$toLibraryId,
									$endLibraryId,
									$homeLibraryId,
									$loanStatus,

									$solicitable,
									$withItemRequest,
									$withExpired,
									$patronId,
									$renewCount,

									$solicitCount,
									$outDateFrom,
									$outDateTo,
									$dueDateFrom,
									$dueDateTo,

									$inDateFrom,
									$inDateTo,
									$contactFilter,
									$preferredContact,
									$contactBoolean,

									$itemMedia,
									$oocMode );

 		$this->LoanList->resetDataSource();
		$this->doRenderPrintPanel();
 	}

 	/**
 	 * It updates the page in case a new patron is choosen.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onPatronIdChanged($sender, $param)
 	{
 		$patron = null;
 		$id = intval($this->HiddenValue->getValue());
 		if ($id > 0)
 			$patron = PatronQuery::create()
						->findPK($id);
 		if ($patron instanceof Patron)
 		{
 			$completeName = $patron->getCompleteName();
 			$barcode = trim($patron->getBarcode());
 			if ($barcode != '')
 				$barcode = ' (' . $barcode . ')';

 			$this->PatronLabel->setText($completeName . $barcode);
 			$this->setPatronChoiceDone(true, $param);
 		}
 	}

 	/**
 	 * It resets (also visually) the choice of patron.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
	public function onResetPatron($sender, $param)
	{
		$this->HiddenLabel->setValue('');
		$this->HiddenValue->setValue('');
 		$this->PatronLabel->setText('');
		$this->setPatronChoiceDone(false, $param);
	}

 	public function setPatronChoiceDone($flag, $param)
 	{
		$this->PatronLabel->setVisible($flag);
		$this->PatronChoiceButton->setVisible(!$flag);
		$this->PatronResetButton->setVisible($flag);

		if (!is_null($param) && $this->getPage()->getIsCallback())
			$this->PatronPanel->render($param->getNewWriter());
 	}

 	/**
 	 * It resets (also visually) the date choice.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
	public function onResetOutDate($sender, $param)
	{
		$this->OutDateFrom->setText('');
 		$this->OutDateTo->setText('');

 		 if (!is_null($param))
 			$this->OutDatePanel->render($param->getNewWriter());
	}

 	/**
 	 * It resets (also visually) the date choice.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
	public function onResetInDate($sender, $param)
	{
		$this->InDateFrom->setText('');
 		$this->InDateTo->setText('');

 		if (!is_null($param))
 			$this->InDatePanel->render($param->getNewWriter());
	}

	public function onResetDueDate($sender, $param)
	{
		$this->DueDateFrom->setText('');
 		$this->DueDateTo->setText('');

 		if (!is_null($param))
 			$this->DueDatePanel->render($param->getNewWriter());
	}

	/**
	 * Callback from update button in the page.
	 * It performs retrieving of filters and next it populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}

	public function onUnLoan($sender, $param)
	{
		$resultsString = "";
		$clavisLibrarian = $this->getUser();

		$itemId = $param->CommandParameter;
		if ($itemId > 0)
			$checkedDatasource = array($itemId);
		else
			$checkedDatasource = $this->ItemFound->getCheckedItemIds();

		$this->getPage()->cleanMessageQueue();
		foreach ($checkedDatasource as $index => $itemId)
		{
			$item = ItemPeer::retrieveByPK($itemId);
			if (!is_null($item) && ($item instanceof Item))
			{
				$isLate = ($this->_loanmanager->isLoanLate($item) == ClavisLoanManager::LOAN_ISLATE);
				$dueDate = Clavis::dateFormat($item->getDueDate('U'));
				$returnValue = $this->_loanmanager->DoReturnItem($item, $item->getPatron(), $clavisLibrarian);

				switch ($returnValue)
				{
					case ClavisLoanManager::OK:
						$this->getPage()->enqueueMessage(Prado::localize('Esemplare n.') 
																	. $item->getId()
																	. ' (' . $item->getTrimmedTitle(40) . ') '
																	. Prado::localize('ritornato'),
															ClavisMessage::CONFIRM);
						$this->globalRefresh();
					break;

					case ClavisLoanManager::RETN_PATRONREQUEST:
						$this->getPage()->enqueueMessage(Prado::localize('Esemplare n.') 
																	. $item->getId()
																	. ' (' . $item->getTrimmedTitle(40) . ') '
																	. Prado::localize('ritornato e soddisfa una prenotazione esistente'),
															ClavisMessage::WARNING);
						$this->globalRefresh();
					break;

					case ClavisLoanManager::ERROR:
						$this->getPage()->enqueueMessage(Prado::localize('Esemplare n.{itemId} "{title}" NON RITORNATO',
							array('itemId'=>$item->getId(), 'title'=>$item->getTrimmedTitle(40))),ClavisMessage::ERROR);
						$isLate = false;
					break;

					default:
						$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto n. 001485. Contattare il fornitore del software."),
															ClavisMessage::ERROR);
						$isLate = false;
					break;
				}

				if ($isLate)
				{
					$this->getPage()->enqueueMessage(Prado::localize('<b>** consegnato in ritardo</b> (scaduto il {dueDate}) <b>**</b>',
																					array('dueDate' => $dueDate)),
																ClavisMessage::WARNING);
				}

				$this->flushMessage();

			}
			else
			{
				Prado::log('LoanViewPage: o e nulla la actuallibrary o il patron.');
			}
		}

		$this->globalRefresh();
	}

	public function onCleanSearch($sender, $param)
	{
		$this->doCleanSearch(false, $param);
	}

	public function doCleanSearch($doRefresh = true, $param = null)
	{
		$this->FromLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
		$this->ToLibrary->setSelectedIndex(0);
		$this->EndLibrary->setSelectedIndex(0);
		$this->HomeLibrary->setSelectedIndex(0);
		$this->LoanStatus->setSelectedIndex(0);
		$this->Solicitable->setChecked(false);
		$this->WithItemRequest->setChecked(false);
		$this->WithExpired->setChecked(false);
		$this->onResetPatron(null, null);
		$this->RenewCount->setSelectedValue("-0.5");
		$this->SolicitCount->setSelectedIndex(0);
		$this->onResetInDate(null, null);
		$this->onResetOutDate(null, null);
		$this->onResetDueDate(null, null);
		$this->ContactFilter->setSelectedIndex(0);
		$this->PreferredCheck->setChecked(false);
		$this->ContactBooleanFilter->setSelectedValue(1);
		$this->ItemMedia->setSelectedIndex(0);

		if ($doRefresh)
			$this->globalRefresh();
		else
			$this->LoanList->resetDataSource(false);
		
		$this->doRenderPrintPanel();
	}

	public function getCheckedItems($force = false, $reset = false)
	{
		$dataSource = $this->LoanList->getCheckedItems($force, $reset);
		if (is_null($dataSource))
			$dataSource = array();
		return $dataSource;
	}

	public function countCheckedItems()
	{
		$count = $this->LoanList->countCheckedItems();
		if (is_null($count))
			$count = 0;
		return $count;
	}

	public function loanListInitialReload()
	{
		$this->LoanList->initialReload();
	}
	
	public function onPrintLoanReport($sender, $param)
	{
		$this->doRenderPrintPanel();
		
		$datasource = $this->LoanList->getCheckedItems(true, true);   // all + reset
		$ids = implode(',', $datasource);
	
		$this->LoanReportJRP->setObjectId($ids);
		$this->LoanReportJRP->addOptionalParam('P_ORDER', $this->LoanList->getSortingExpression());
		$this->LoanReportJRP->addOptionalParam('P_ORDERDIR', $this->LoanList->getSortingDirection());
		
		$this->LoanReportJRP->printReport();
	}
	
}
