<?php

/**
 *
 * PatronPropertyPopup class
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class PatronPropertyPopup extends ClavisPagePopup
{
	protected $_patron;
	protected $_id;
	protected $_datasource;

	public $_module = "CIRCULATION";
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack() )
		{
			$this->setStoredDataSource(array());
			$this->setPatron(null);
			$this->setPatronId(null);
			
			$patron = null;
			$patronId = intval($this->getRequest()->itemAt('id'));
			
		    $this->setPatronId($patronId);
			if ($patronId > 0)
			{
				$patron = PatronPeer::retrieveByPK($patronId);
				if (!($patron instanceof Patron)) 
					$patron = null;
				
				$this->setPatron($patron);
			}
		}
	}
			
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$patron = $this->getPatron();
			if ($patron instanceof Patron)
			{
				$this->populate();
				$this->PatronError->setVisible(false);
				$this->NewPropertyButton->setVisible(true);
			}
			else
			{
				$this->PatronError->setVisible(true);
				$this->NewPropertyButton->setVisible(false);
				$this->getPage()->writeMessage(Prado::localize("Errore sul passaggio di parametri relativo all'utente"),
												ClavisMessage::ERROR);
			}
		}
	}
	
	public function onChangePage($sender, $param)
	{
		$this->PropertyGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}
	
	public function populate()
	{
		$pageSize = $this->PropertyGrid->getPageSize();
		$currentIndexPage = $this->PropertyGrid->getCurrentPage();
		
		$criteria = new Criteria();
		$criteria->add(PatronPropertyPeer::PATRON_ID, $this->getPatronId());
		
		$recCount = LoanPeer::doCount($criteria);
		
		$criteria->addAscendingOrderByColumn(PatronPropertyPeer::PROPERTY_CLASS);
		
		if ($pageSize > 0)
		{
			$criteria->setLimit($pageSize);
			$criteria->setOffset($currentIndexPage * $pageSize);
		}
			
		$properties = PatronPropertyPeer::doSelect($criteria);
		
		$this->_datasource = array();
		/* @var $property PatronProperty */
		foreach ($properties as $property)     
		{
			$p = array();
			$p['PropertyKey'] = $property->getPropertyClass();
			$p['PropertyLabel'] = LookupValuePeer::getLookupValue("PATRONPROPERTY", $property->getPropertyClass());
			$p['PropertyValue'] = $property->getPropertyValue();
			$p['id'] = $property->getId();

			$this->_datasource[] = $p;
		}

		if ($pageSize > 0)
			$this->PropertyGrid->setVirtualItemCount($recCount);
		
		$this->FoundNumber->setText($recCount);
		$this->PropertyGrid->setDataSource($this->_datasource);
		$this->PropertyGrid->dataBind();
		
		$this->setStoredDataSource($this->_datasource);
	}
	
	public function onCreateNewProperty($sender, $param)
	{
		$this->getPage()->globalEditCancel();
		$this->NewPropertyButton->setVisible(false);
		
		$this->_datasource = $this->getStoredDataSource();
		$this->setNewItem(true);
		
		$newRow = array();
		$newRow['id'] = -1;
		$allValues = LookupValuePeer::getLookupClassValues("PATRONPROPERTY");
		reset($allValues);
		$first = each($allValues); 
		$newRow['PropertyKey'] = $first['key'];
		$newRow['PropertyLabel'] = $first['value'];
		$newRow['PropertyValue'] = "";
		$this->_datasource = array_merge(array($newRow), $this->_datasource);

		//$this->populate();
		$this->PropertyGrid->setEditItemIndex(0);
		$this->PropertyGrid->setDataSource($this->_datasource);
		$this->PropertyGrid->dataBind();
	}
	
	public function itemDataBound($sender, $param) 
	{
		$item = $param->Item;
		
		if ($item->ItemType == "EditItem") 
		{
			$item->setStyle('background-color: #DDDDFF;');
			
			if ($this->getNewItem()) 
			{
				$item->Cells[0]->attributeNewPanel->setVisible(true);
				$item->Cells[0]->attributeEditPanel->setVisible(false);
				
				if (is_null($item->Cells[0]->Controls[1]->Controls[1]->DataSource)) 
					$item->Cells[0]->Controls[1]->Controls[1]->populateList();
			} 
			else 
			{
				$item->Cells[0]->attributeNewPanel->setVisible(false);
				$item->Cells[0]->attributeEditPanel->setVisible(true);
			}
		}
	}
	
	public function editProperty($sender, $param)
	{
		$this->NewPropertyButton->setVisible(false);
		
		$this->getPage()->globalEditCancel();
		$this->_datasource = $this->getStoredDataSource();
		$this->setNewItem(false);
		$this->populate();

		$this->PropertyGrid->setEditItemIndex($param->Item->ItemIndex);
		$this->PropertyGrid->setDataSource($this->_datasource);
		$this->PropertyGrid->dataBind();
	}
	
	public function saveProperty($sender, $param)
	{
		$item = $param->getItem();
		$itemIndex = $item->getItemIndex();
		$id = $this->PropertyGrid->DataKeys[$itemIndex];
		
		$propertyKey = '';
		$propertyValue = '';
		if ($this->getNewItem()) 
		{
			//save da new item
			$propertyKey = $item->Cells[0]->Controls[1]->Controls[1]->getSelectedValue(); 
			$propertyValue = $item->Cells[1]->Controls[1]->getSafeText();
		} 
		else 
		{
			//save da update item
			$propertyValue = $item->Cells[1]->Controls[1]->getSafeText();
		}
			
		/* @var $property PatronProperty */
		$property = PatronPropertyPeer::retrieveByPK($id);
		if ($property instanceof PatronProperty) 
		{
			$property->setPropertyValue($propertyValue);
			$property->save();
		} 
		else 
		{
			$property = new PatronProperty();
			$property->setPatronId($this->getPatronId());
			$property->setPropertyClass($propertyKey);
			$property->setPropertyValue($propertyValue);
			$property->save();
		}
					
		$this->globalEditCancel();
	}
	
	public function deleteProperty($sender, $param)
	{
		$item=$param->Item;
		$itemIndex = $item->ItemIndex;
				
		$id = $this->PropertyGrid->DataKeys[$itemIndex];
			
		/* @var $property PatronProperty */
		PatronPropertyPeer::doDelete($id);
		
		//$this->reloadPage();
		$this->globalRefresh();
	}
	
	public function cancelPropertyEdit($sender, $param)
	{
		$this->globalEditCancel();
	}

	public function setPatronId($id) 
	{
		$this->_id = $id;
		$this->setViewState("id",$id,null);
	}

	public function getPatronId() 
	{
		if (is_null($this->_id)) 
			$this->_id = $this->getViewState("id",null);

		return $this->_id;
	}

	public function setPatron($patron)
	{
		$this->_patron = $patron;
		$this->setViewState("patron", $patron, null);
	}

	public function getPatron()
	{
		if (is_null($this->_patron))
			$this->_patron = $this->getViewState("patron", null);
		
		return $this->_patron;
	}

	public function setStoredDataSource($param = array())
	{
		$this->setViewState("StoredDataSource", $param, array());
	}

	public function getStoredDataSource()
	{
		return $this->getViewState("StoredDataSource", array());
	}
	
	public function setNewItem($param = false)
	{
		$this->setViewState("newItemProperty", $param, false);
	}

	public function getNewItem()
	{
		return $this->getViewState("newItemProperty", false);
	}
	
	public function globalEditCancel()
	{
		//$this->NewPropertyButton->setVisible(true);
		$this->PropertyGrid->setEditItemIndex(-1);
		//$this->PropertyGrid->dataBind();
		$this->globalRefresh();
	}
	
	public function globalRefresh()
	{
		$this->NewPropertyButton->setVisible(true);
		$this->populate();
	}

	public function isUnlink()
	{
		return false;
	}
	
}
