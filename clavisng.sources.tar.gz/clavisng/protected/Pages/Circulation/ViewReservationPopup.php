<?php
/**
 * ViewReservationPopup class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * ViewReservationPopup Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Popups.Circulation
 * @since 2.0
 */
class ViewReservationPopup extends ClavisPagePopup
{
	private $_itemRequestId;
	private $_requestManager;
	public $_llibraryActive;

	public $_module = 'CIRCULATION';

	private function initVars()
	{
		$this->_requestManager = $this->getApplication()->getModule("request");
		$this->_llibraryActive = LLibraryPeer::isEnabled();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$itemRequestId = intval($this->getRequest()->itemAt('param'));
			$this->setItemRequestId($itemRequestId);
			$this->ChangelogList->setObjectId($itemRequestId);
			$this->ChangelogList->setObjectClass('ItemRequest');

			$this->populate();
		}
	}

	public function setItemRequestId($itemRequestId)
	{
		$this->_itemRequestId = $itemRequestId;
		$this->setViewState("ItemRequestId", $itemRequestId, null);
	}

	public function getItemRequestId()
	{
		$this->_itemRequestId = $this->getViewState("ItemRequestId", null);
		return $this->_itemRequestId;
	}

	private function getItemRequest()
	{
		$itemRequest = ItemRequestQuery::create()
						->findPk(intval($this->getItemRequestId()));
		
		if ($itemRequest instanceof ItemRequest)
			return $itemRequest;
		else
			return null;
	}
	
	public function populate()
	{
		$basinFlag = $this->_llibraryActive;
		
		$this->NullRequestButton->setVisible(false);
		$this->getPage()->cleanMessageQueue();
		$this->_itemRequestId = intval($this->getItemRequestId());
		if ($this->_itemRequestId > 0)
		{
			$itemRequest = ItemRequestQuery::create()
							->findPK($this->_itemRequestId);
			
			if ($itemRequest instanceof ItemRequest)	// everything is ok
			{
				$manifestationId = null;
				$issueId = null;
				
				$itemRequestObject = $itemRequest->getItemRequestObject();
				$this->NullRequestButton->setVisible(false);
				$title = $itemRequestObject->getCompleteTitle();
				$itemRequestObjectNavigateUrl = $itemRequestObject->getNavigateUrl() . $itemRequestObject->getId();

				$this->ItemDataPanel->setVisible(false);
				$this->NoItemButton->setVisible(false);

				if ($itemRequestObject instanceof Manifestation)	// .......... request of a manifestation
				{
					$objectString = ' ' . Prado::localize('di una notizia');
					$manifestationId = $itemRequest->getManifestationId();
				}
				elseif ($itemRequestObject instanceof Item)			// ............... request of an item
				{
					$objectString = ' ' . Prado::localize('di un esemplare');
					$basinFlag = false;

					$this->ItemDataPanel->setVisible(true);
					$collocation = $itemRequestObject->getCollocationCombo(Prado::getApplication()->getUser()->getActualLibraryId());
					$inventoryNumber = $itemRequestObject->getCompleteInventoryNumber();
					$homeLibraryId = $itemRequestObject->getHomeLibraryId();
					$homeLibraryText = $itemRequestObject->getHomeLibraryLabel();

					$this->Collocation->setText($collocation);
					$this->InventoryNumber->setText($inventoryNumber);
					$this->HomeLibrary->setText($homeLibraryText);
					$this->HomeLibrary->setNavigateUrl(LibraryPeer::getNavigateUrl($homeLibraryId));

					$this->NoItemButton->setVisible(true);
				}
				elseif ($itemRequestObject instanceof Issue)		// .............. request of an issue
				{
					$objectString = ' ' . Prado::localize('di un fascicolo');	
					$manifestationId = $itemRequest->getManifestationId();
					$issueId = $itemRequest->getIssueId();
				}
				elseif (is_null($itemRequestObject))
				{
					$this->NullRequestButton->setVisible(true);
					$objectString = ' ' . Prado::localize('INCONGRUENTE, con request id: ') . $itemRequest->getRequestId();
					$okFlag = false;
					$this->enqueueMessage(Prado::localize("La prenotazione si riferisce ad un oggetto che non esiste più: "), 
											ClavisMessage::ERROR);

					if (is_null($itemRequest->getManifestation()))
						$this->enqueueMessage(Prado::localize("notizia con id: {manifestationId}", 
																array("manifestationId" => $itemRequest->getManifestationId()), 
												ClavisMessage::ERROR));

					if (is_null($itemRequest->getItem()))
						$this->enqueueMessage(Prado::localize("esemplare con id: {itemId}", 
																array("itemId" => $itemRequest->getItemId()), 
												ClavisMessage::ERROR));
				}
				else
				{
					$this->NullRequestButton->setVisible(true);
					$objectString = ' ' . Prado::localize('ERRORE SCONOSCIUTO, sulla prenotazione con request id: ') . $itemRequest->getRequestId();
					$okFlag = false;

					$this->enqueueMessage(Prado::localize("Errore sconosciuto: la prenotazione si riferisce ad un oggetto che non esiste più: "), 
											ClavisMessage::ERROR);
				}

				$this->ObjectString->setText($objectString);

				$requestDate = $itemRequest->getRequestDate('U');
				$expireDate = $itemRequest->getExpireDate('U');

				$patronId = $itemRequest->getPatronId();
				$toolTip = '';
				$patron = $itemRequest->getPatron();
				if ($patron instanceof Patron)
				{
					$patronCompleteName = $patron->getCompleteName();
					$navigateUrl = PatronPeer::getNavigateUrl($patronId);
				}
				else	// case of an external library
				{
					$basinFlag = false;

					$externalLibraryId = intval($itemRequest->getExternalLibraryId());
					$externalLibrary = LibraryQuery::create()
										->findPK($externalLibraryId);
					if ($externalLibrary instanceof Library)
					{
						$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);
						$navigateUrl = LibraryPeer::getNavigateUrl($externalLibrary->getLibraryId());
						$toolTip = $externalLibrary->getTrimmedDescription(100) . ' (' .
																	Prado::localize('consorzio') . ": ". $externalLibrary->getConsortiaString(100) . ')';
					}
					else
					{
						$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
						$navigateUrl = '';
					}
				}

				$deliveryLibraryId = $itemRequest->getDeliveryLibraryId();
				$deliveryLibraryLabel = $itemRequest->getDeliveryLibraryLabel();

				$creatorId = $itemRequest->getCreatedBy();
				if ($creatorId == 1)
				{
					$creatorName = Prado::localize('da Opac');
					$creatorUrl = '';
				}
				else
				{
					$librarian = $itemRequest->getLibrarianRelatedByCreatedBy();
					$creatorUrl = $librarian->getUrlPage();
					$creatorName = $librarian->getUrlName();
				}

				$managerId = intval($itemRequest->getLibrarianId());
				if ((($managerId > 0) 
						&& ($itemRequest->getRequestStatus() == ItemRequestPeer::STATUS_WORKING)) )
				{
					$this->DeliveryLibraryEditButton->setVisible(false);

					$this->ManagedPanel->setVisible(true);
					$librarianManager = $itemRequest->getLibrarianRelatedByLibrarianId();
					$managerUrl = $librarianManager->getUrlPage();
					$managerName = $librarianManager->getUrlName();

					$this->Manager->setNavigateUrl($managerUrl . $managerId);
					$this->Manager->setText($managerName);
				}
				else
				{
					$this->ManagedPanel->setVisible(false);
				}

				$this->Title->setText($title);
				$this->Title->setNavigateUrl($itemRequestObjectNavigateUrl);

				$this->Patron->setText($patronCompleteName);
				$this->Patron->setNavigateUrl($navigateUrl);
				$this->Patron->setToolTip($toolTip);

				$this->RequestDate->setValue($requestDate);
				$this->ExpireDate->setValue($expireDate);

				$this->Requester->setEnabled($creatorUrl != '');
				$this->Requester->setNavigateUrl($creatorUrl . $creatorId);
				$this->Requester->setText($creatorName);

				if ($basinFlag)
				{
					$this->MaxDistancePanel->setCssClass('panel_on');
					$this->MaxDistance->setText($itemRequest->getCompleteMaxDistance());
					
					if ($manifestationId > 0)
					{
						$this->AvailableItemsPanel->setCssClass('panel_on');
						$this->AvailableItems->setManifestationId($manifestationId);
						$this->AvailableItems->setIssueId($issueId);
						$this->AvailableItems->globalRefresh();
					}
					else
					{	
						$this->AvailableItemsPanel->setCssClass('panel_on');
					}
				}
				else
				{
					$this->MaxDistancePanel->setCssClass('panel_off');
					$this->AvailableItemsPanel->setCssClass('panel_off');
				}

				$this->RequestNote->setText($itemRequest->getRequestNote());

				$this->DeliveryLibrary->setText($deliveryLibraryLabel);
				$this->DeliveryLibrary->setNavigateUrl(LibraryPeer::getNavigateUrl($deliveryLibraryId));

				$this->ItemRequestStatusString->setText($itemRequest->getRequestStatusString());
				
			}
			else	// itemRequest is not a valid object
			{
				$this->getPage()->enqueueMessage(Prado::localize("Errore al tentativo di annullare una prenotazione incongruente: l'id viene passato [{reqId}] ma la prenotazione relativa non esiste",
																	array('reqId' => $this->_itemRequestId)),
													ClavisMessage::ERROR);
			}
		}
		else	// itemRequestId is not a valid request id
		{
			$this->Title->setText('');
			$this->getPage()->enqueueMessage(Prado::localize("Errore interno: il parametro non è stato passato al popup di visualizzazione prenotazione. Riferire all'assistenza."), 
												ClavisMessage::ERROR);
		}
		
		$this->flushMessage();
	}

	public function isUnlink()
	{
		return false;
	}

	private function setDeliveryLibraryEditingVisibility($flag = false)
	{
		$this->DeliveryLibrary->setVisible(!$flag);
		$this->DeliveryLibraryEditButton->setVisible(!$flag);
		$this->DeliveryLibraryCancelButton->setVisible($flag);
		$this->DeliveryLibraryOkButton->setVisible($flag);
		$this->DeliveryLibraryList->setVisible($flag);

		if ($this->getIsCallback())
			$this->DeliveryLibraryPanel->render($this->createWriter());
	}

	public function onEditDeliveryLibrary($sender, $param)
	{

		$this->DeliveryLibraryList->setDataSource(LibraryPeer::getLibrariesHash(null, null, true, true));
		$this->DeliveryLibraryList->dataBind();

		$itemRequestId = $this->getItemRequestId();
		if (!is_null($itemRequestId) && ($itemRequestId > 0))
		{
			$itemRequest = ItemRequestPeer::retrieveByPK($this->_itemRequestId);
			if (!is_null($itemRequest) && ($itemRequest instanceof ItemRequest))
			{
				$deliveryLibraryId = $itemRequest->getDeliveryLibraryId();
				$this->DeliveryLibraryList->setSelectedValue($deliveryLibraryId);
			}
		}

		$this->setDeliveryLibraryEditingVisibility(true);
	}

	public function onCancelDeliveryLibrary($sender, $param)
	{
		$this->setDeliveryLibraryEditingVisibility(false);
	}

	public function onChangeDeliveryLibrary($sender, $param)
	{
		$toReloadFlag = false;
		$deliveryLibraryId = intval($this->DeliveryLibraryList->getSelectedValue());

		$itemRequestId = $this->getItemRequestId();
		if (!is_null($itemRequestId) && ($itemRequestId > 0) && ($deliveryLibraryId > 0))
		{
			$itemRequest = ItemRequestPeer::retrieveByPK($this->_itemRequestId);
			if (!is_null($itemRequest) && ($itemRequest instanceof ItemRequest))
			{
				$item = $itemRequest->getItem();

				$okDestination = true;
				$patron = $itemRequest->getPatron();
				if ($patron instanceof Patron)
					$destination = $patron;
				else
				{
					$externalLibrary = $itemRequest->getExternalLibrary();
					if ($externalLibrary instanceof Library)
						$destination = $externalLibrary;
					else
						$okDestination = false;
				}

				if ($okDestination)
				{
					if (($item instanceof Item))
						$ret = $this->_requestManager->isItemReservable($item, $destination, $deliveryLibraryId);
					else
						$ret = ClavisLoanManager::OK;  // request is for a manifestation: control is not necessary
					switch ($ret)
					{
						case (ClavisLoanManager::RSV_NOTAVAIL) :

							$this->getPage()->writeMessage(Prado::localize("Non è possibile cambiare la biblioteca di destinazione in quanto l'esemplare è prestabile solo localmente. L'unica biblioteca in cui può essere spedito è la sua biblioteca di residenza."), ClavisMessage::ERROR);
							break;

						case (ClavisLoanManager::OK):
						case (ClavisLoanManager::RSV_PATRONHASITEM):
						case (ClavisLoanManager::RSV_PATRONMAXREQ):
						case (ClavisLoanManager::RSV_PATRONREQITEM):

							$toReloadFlag = true;
							$oldDeliveryLibraryId = $itemRequest->getDeliveryLibraryId();
							$oldDeliveryLibraryLabel = $itemRequest->getDeliveryLibraryLabel();
							$itemRequest->setDeliveryLibraryId($deliveryLibraryId);
							$itemRequest->save();

							$deliveryLibraryLabel = $itemRequest->getDeliveryLibraryLabel();
							ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $this->getUser(),
									"Cambiata biblioteca di destinazione della prenotazione con id= {$itemRequestId}: da ({$oldDeliveryLibraryId}) ".
									"{$oldDeliveryLibraryLabel}  a ({$deliveryLibraryId}) {$deliveryLibraryLabel}");
							$this->getPage()->appendDelayedMessage(Prado::localize('Cambiata biblioteca di destinazione '.
									'della prenotazione con id={itemRequestId}: da ({oldDeliveryLibraryId}) {oldDeliveryLibraryLabel} '.
									'a ({deliveryLibraryId}) {deliveryLibraryLabel}',
								array('itemRequestId'	=> $itemRequestId,
									'oldDeliveryLibraryId'	=> $oldDeliveryLibraryId,
									'oldDeliveryLibraryLabel'	=> $oldDeliveryLibraryLabel,
									'deliveryLibraryId'	=> $deliveryLibraryId,
									'deliveryLibraryLabel'	=> $deliveryLibraryLabel)),ClavisMessage::CONFIRM);

							$this->getApplication()->getSession()->add('UpdateClavisManageRequestsList', true);
							
							$this->DeliveryLibrary->setText($deliveryLibraryLabel);
							$this->DeliveryLibrary->setNavigateUrl('index.php?page=Library.LibraryViewPage&id=' . $deliveryLibraryId);


							break;

						case (ClavisLoanManager::ERROR):
						default:

							$this->getPage()->writeMessage(Prado::localize("Errore sul cambio di biblioteca di destinazione."), ClavisMessage::ERROR);
							break;
					}
				}
				else
				{
					$this->getPage()->writeMessage(Prado::localize('Nella prenotazione non è specificato nessun destinatario'), ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize('Errore: nella prenotazione manca indicazione su esemplare o utente.', ClavisMessage::ERROR));
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Errore sul tentato cambio di biblioteca di destinazione della prenotazione', ClavisMessage::ERROR));
		}

		$this->setDeliveryLibraryEditingVisibility(false);

		if ($toReloadFlag)
			$this->popupPreClose($param);
	}

	private function setMaxDistanceEditingVisibility($flag = false)
	{
		$this->MaxDistance->setVisible(!$flag);
		$this->MaxDistanceEditButton->setVisible(!$flag);
		$this->MaxDistanceCancelButton->setVisible($flag);
		$this->MaxDistanceOkButton->setVisible($flag);
		$this->MaxDistanceList->setVisible($flag);

		if ($this->getIsCallback())
			$this->MaxDistancePanel->render($this->createWriter());
	}

	public function onEditMaxDistance($sender, $param)
	{
		$this->setDeliveryLibraryEditingVisibility(false);

		$itemRequest = $this->getItemRequest();
		if ($itemRequest instanceof ItemRequest)
		{
			$manifestation = $itemRequest->getManifestation();
			$deliveryLibraryId = intval($itemRequest->getDeliveryLibraryId());
			
			if (($manifestation instanceof Manifestation) && ($deliveryLibraryId > 0))
			{
//				$this->getApplication()->getModule('request')->calculateRequestDistances(	$manifestation, 
//																							$deliveryLibraryId)));
				
				$this->MaxDistanceList->setDataSource(LLibraryPeer::calculateRequestDistances(false));	// with blank
				$this->MaxDistanceList->dataBind();

				$this->MaxDistanceList->setSelectedValue($itemRequest->getMaxDistance());
				$this->setMaxDistanceEditingVisibility(true);
			}
		}
	}

	public function onCancelMaxDistance($sender, $param)
	{
		$this->setMaxDistanceEditingVisibility(false);
	}

	public function onChangeMaxDistance($sender, $param)
	{
		$maxDistance = $this->MaxDistanceList->getSelectedValue();

		$itemRequest = $this->getItemRequest();
		if ($itemRequest instanceof ItemRequest)
		{
			$oldMaxDistance = $itemRequest->getMaxDistance();
			if ($oldMaxDistance != $maxDistance)
			{
				$currentTime = time();
				
				$itemRequest->setMaxDistance($maxDistance);
				$itemRequest->save();
				
				$this->MaxDistance->setText(ItemRequestPeer::getCompleteMaxDistance($maxDistance));
				$this->RequestDate->setValue($currentTime);
				if ($this->getPage()->getIsCallback())
					$this->RequestDatePanel->render($param->getNewWriter());
				
				$this->getApplication()->getSession()->add('UpdateClavisManageRequestsList', true);
				
				$this->getPage()->writeMessage(Prado::localize("Massima distanza cambiata al valore {maxDistance} per la prenotazione con id: {requestId}.",
																array(	'maxDistance' => ItemRequestPeer::getCompleteMaxDistance($maxDistance),
																		'requestId' => $itemRequest->getRequestId())),
												ClavisMessage::CONFIRM);

				ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $this->getUser(),
									"Cambiata massima distanza della prenotazione con id: " . $itemRequest->getRequestId() .
									" da " . (is_null($oldMaxDistance) ? Prado::localize("nulla") : $oldMaxDistance) . " a " . $maxDistance . ".");
			}
			else	// we don't need to change
			{
				$this->getPage()->writeMessage(Prado::localize("Nessuna variazione della distanza"), 
												ClavisMessage::WARNING);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: la prenotazione non esiste. Contattare l'assistenza e segnalare l'errore", 
											ClavisMessage::ERROR));
		}

		$this->setMaxDistanceEditingVisibility(false);
	}
	
	private function setRequestNoteEditingVisibility($flag = false)
	{
		$this->RequestNote->setVisible(!$flag);
		$this->RequestNoteEditButton->setVisible(!$flag);
		$this->RequestNoteCancelButton->setVisible($flag);
		$this->RequestNoteOkButton->setVisible($flag);
		$this->RequestNoteTextBox->setVisible($flag);

		if ($this->getIsCallback())
			$this->RequestNotePanel->render($this->createWriter());
	}

	public function onEditRequestNote($sender, $param)
	{
		$this->setRequestNoteEditingVisibility(false);

		$itemRequest = $this->getItemRequest();
		if ($itemRequest instanceof ItemRequest)
		{
			$this->RequestNoteTextBox->setText($itemRequest->getRequestNote());
			$this->setRequestNoteEditingVisibility(true);
		}
	}

	public function onCancelRequestNote($sender, $param)
	{
		$this->setRequestNoteEditingVisibility(false);
	}

	public function onChangeRequestNote($sender, $param)
	{
		$requestNote = $this->RequestNoteTextBox->getSafeText();

		$itemRequest = $this->getItemRequest();
		if ($itemRequest instanceof ItemRequest)
		{
			$oldRequestNote = $itemRequest->getRequestNote();
			if ($oldRequestNote != $requestNote)
			{
				$itemRequest->setRequestNote($requestNote);
				$itemRequest->save();
				
				$this->RequestNote->setText($requestNote);

				/// no need to update
				///$this->getApplication()->getSession()->add('UpdateClavisManageRequestsList', true);
				
				$this->getPage()->writeMessage(Prado::localize("Nota modificata al valore '{requestNote}' per la prenotazione con id: {requestId}",
																array(	"requestNote" => $requestNote,
																		"requestId" => $itemRequest->getRequestId())), 
												ClavisMessage::CONFIRM);

				ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $this->getUser(),
									"Modificata nota della prenotazione con id: " . $itemRequest->getRequestId() .
									" da '" . $oldRequestNote . "' a '" . $requestNote . "'.");
			}
			else	// we don't need to change
			{
				$this->getPage()->writeMessage(Prado::localize("Nessuna variazione sulla nota"), 
												ClavisMessage::WARNING);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: la prenotazione non esiste. Contattare l'assistenza e segnalare l'errore", 
											ClavisMessage::ERROR));
		}

		$this->setRequestNoteEditingVisibility(false);
	}
	
	private function popupPreClose($param = null)
	{
		$this->getApplication()->getSession()->add('UpdateItemRequests', true);

		$this->onCancelOperation->setUpdate(true);
		if ($this->getIsCallback())
		{
			$this->ReturnButtonPanel->render($this->createWriter());
		}
	}

	private function onClose()
	{
		$scriptMgr = $this->getPage()->getClientScript();
		$scriptMgr->registerEndScript('parentSubmit','parent.onSubmit();');
	}

	private function setExpireDateEditingVisibility($flag = false)
	{
		$this->ExpireDateLabel->setVisible(!$flag);
		$this->ExpireDateEditButton->setVisible(!$flag);
		$this->ExpireDateOkButton->setVisible($flag);
		$this->ExpireDateCancelButton->setVisible($flag);
		$this->NewExpireDate->setVisible($flag);

		if ($this->getIsCallback())
			$this->ExpireDatePanel->render($this->createWriter());
	}

	public function onEditExpireDate($sender, $param)
	{
		$itemRequestId = $this->getItemRequestId();
		if (!is_null($itemRequestId) && ($itemRequestId > 0))
		{
			$itemRequest = ItemRequestPeer::retrieveByPK($this->_itemRequestId);
			if ($itemRequest instanceof ItemRequest)
				$this->NewExpireDate->setTimestamp($itemRequest->getExpireDate('U'));
		}
		$this->setExpireDateEditingVisibility(true);
	}

	public function onCancelExpireDate($sender, $param)
	{
		$this->setExpireDateEditingVisibility(false);
	}

	public function onChangeExpireDate($sender, $param)
	{
		$toReloadFlag = false;
		$newExpireDate = ($this->NewExpireDate->getSafeText() != '' 
										? $this->NewExpireDate->getTimeStamp() 
										: null );

		if (is_null($newExpireDate))
		{
			$this->getPage()->writeMessage(Prado::localize("Non è possibile effettuare l'operazione di cambio data di scadenza: la data impostata non è valida"), 
											ClavisMessage::ERROR);
			
			$this->setExpireDateEditingVisibility(false);
			return false;
		}

		if ($newExpireDate < time())
		{
			$this->getPage()->writeMessage(Prado::localize("Non è possibile effettuare l'operazione di cambio data di scadenza: la data impostata è minore della data corrente"), 
											ClavisMessage::ERROR);
			
			$this->setExpireDateEditingVisibility(false);
			return false;
		}
		$itemRequestId = intval($this->getItemRequestId());
		if ($itemRequestId > 0)
		{
			$itemRequest = ItemRequestPeer::retrieveByPK($this->_itemRequestId);
			if ($itemRequest instanceof ItemRequest)
			{
				$item = $itemRequest->getItem();
				$deliveryLibraryId = $itemRequest->getDeliveryLibraryId();

				$okDestination = true;
				$patron = $itemRequest->getPatron();
				if ($patron instanceof Patron)
				{
					$destination = $patron;
				}
				else
				{
					$externalLibrary = $itemRequest->getExternalLibrary();
					if ($externalLibrary instanceof Library)
						$destination = $externalLibrary;
					else
						$okDestination = false;
				}

				if ($okDestination)
				{
					if (($item instanceof Item))
						$ret = $this->_requestManager->isItemReservable($item, $destination, $deliveryLibraryId);
					else
						$ret = ClavisLoanManager::OK;  // request is for a manifestation: control is not necessary

					switch ($ret)
					{
						case (ClavisLoanManager::RSV_NOTAVAIL) :

							$this->getPage()->writeMessage(Prado::localize("Non è possibile effettuare l'operazione di cambio data scadenza in quanto l'esemplare è prestabile solo localmente. L'unica biblioteca in cui può essere spedito è la sua biblioteca di residenza."), 
															ClavisMessage::ERROR);
							break;

						case (ClavisLoanManager::OK):
						case (ClavisLoanManager::RSV_PATRONHASITEM):
						case (ClavisLoanManager::RSV_PATRONMAXREQ):
						case (ClavisLoanManager::RSV_PATRONREQITEM):

							$toReloadFlag = true;
							$oldExpireDate = $itemRequest->getExpireDate();
							$itemRequest->setExpireDate($newExpireDate);
							$itemRequest->save();

							$newExpireDate = $itemRequest->getExpireDate();
							ChangelogPeer::logAction($itemRequest, 
													ChangelogPeer::LOG_UPDATE, 
													$this->getUser(),
													"Cambiata data di scadenza della prenotazione con id = {$itemRequestId}: da {$oldExpireDate} " .
														" a {$newExpireDate}");
							$this->getPage()->appendDelayedMessage(Prado::localize('Cambiata data di scadenza della prenotazione con id='.
									'{itemRequestId}: da {oldExpireDate} a {newExpireDate}',
								array('itemRequestId'	=> $itemRequestId,
									'oldExpireDate'	=> $oldExpireDate,
									'newExpireDate'	=> $newExpireDate)),ClavisMessage::CONFIRM);

							$this->getApplication()->getSession()->add('UpdateClavisManageRequestsList', true);
							
							$this->ExpireDate->setValue($itemRequest->getExpireDate('U'));
							break;

						case (ClavisLoanManager::ERROR):
						default:

							$this->getPage()->writeMessage(Prado::localize("Errore sul cambio di data di scadenza."), 
															ClavisMessage::ERROR);
							break;
					}
				}
				else
				{
					$this->getPage()->writeMessage(Prado::localize('Nella prenotazione non è specificata alcuna destinazione'), 
													ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize('Errore: nella prenotazione manca indicazione su esemplare o utente.', 
												ClavisMessage::ERROR));
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Errore sul tentato cambio di data di scadenza', 
											ClavisMessage::ERROR));
		}

		$this->setExpireDateEditingVisibility(false);

		if ($toReloadFlag)
			$this->popupPreClose();
	}

	public function onChangeRequestNoItem($sender, $param)
	{
		$itemRequestId = intval($this->getItemRequestId());
		if ($itemRequestId > 0)
		{
			$itemRequest = ItemRequestPeer::retrieveByPK($this->_itemRequestId);
			if ($itemRequest instanceof ItemRequest)
			{
				$itemRequest->setItemId(null);
				$result = $itemRequest->save();

				if ($result == 1)
				{
					$this->getPage()->writeDelayedMessage(Prado::localize("Ora la prenotazione è solo per notizia"),
															ClavisMessage::CONFIRM);
					
					$this->getApplication()->getSession()->add('UpdateItemRequests', true);
					$this->getApplication()->getSession()->add('UpdateClavisManageRequestsList', true);
					
					$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
				}
				else
				{	$this->getPage()->writeMessage(Prado::localize("L'azione di eliminazione della specificazione dell'esemplare dalla prenotazione è fallita"),
													ClavisMessage::ERROR);
				}
			}
		}
	}
	
	public function onNullRequest($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		$ok = false;

		$request = $this->getItemRequest();
		if ($request instanceof ItemRequest)
			try {
				$this->getApplication()->getModule('request')->doNullRequest($request, $this->getUser(),
						Prado::localize('prenotazione incongruente'));
				$ok = true;
				$this->getApplication()->getSession()->add('UpdateItemRequests', true);
				$this->getPage()->enqueueMessage(Prado::localize("Prenotazione incongruente con id: {reqId} annullata",
																	array('reqId' => $request->getRequestId())),
													ClavisMessage::INFO);
			} catch (Exception $e) {
				$this->getPage()->enqueueMessage(Prado::localize("Errore nell'annullamento della prenotazione incongruente con id: {reqId}",
																	array('reqId' => $request->getRequestId())),
													ClavisMessage::ERROR);
			}
		else
			$this->getPage()->enqueueMessage(Prado::localize("Errore al tentativo di annullare una prenotazione incongruente: la prenotazione non esiste. Riferire i dettagli all'assistenza"),ClavisMessage::ERROR);

		$this->getPage()->flushDelayedMessage();
		
		if ($ok)		//// close popup
			$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}
}
