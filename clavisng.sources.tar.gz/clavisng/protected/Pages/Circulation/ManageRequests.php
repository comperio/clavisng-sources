<?php
/**
 * ManagerRequests class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Circulation
 */

/**
 * ManageRequests class
 *
 * This is the new page for showing and using the requests (intra, inter and extra bibliotecary)
 * It allows the management and actual satisfaction of all visible requests.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.5.2
 */

class ManageRequests extends ClavisPage
{
	const INV_SEP = " // ";

	public $_module = 'CIRCULATION';
    /** @var $_loanmanager ClavisLoanManager */
	protected $_loanmanager;
	protected $_requestmanager;

 	public function initVars()
 	{
 		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestmanager = $this->getApplication()->getModule('request');
 	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{	
			$selectTab = intval($this->getRequest()->itemAt('selectTab'));
			if ($selectTab > 0)
				$this->TabPanel->setActiveViewIndex($selectTab);

			$patronId = intval($this->getRequest()->itemAt('patronId'));
			if ($patronId > 0)
			{
				$this->Requests->doPatronIdChanged($patronId);
			}	
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$myLibrarian = $this->getUser();
		
		if (!$this->getIsPostBack() && !$this->getIsCallBack())
		{
			$this->_requestmanager->resetManagedReservations($myLibrarian);
			$this->_requestmanager->resetExpiredReservations($myLibrarian);

			$this->globalRefresh();
			
			/**
			 * It seems unused here, but it does not hurt ....... 
			 */
			$this->getApplication()->getSession()->remove('ReassignedItemIds');
		}
		else
		{
			$updateClavisManageRequestsList = $this->getApplication()->getSession()->itemAt('UpdateClavisManageRequestsList');
			$updateItemRequests = $this->getApplication()->getSession()->itemAt('UpdateItemRequests');

			if (!is_null($updateClavisManageRequestsList) && ($updateClavisManageRequestsList == true))
			{
				$this->getApplication()->getSession()->remove('UpdateClavisManageRequestsList');
				$this->globalRefresh();
			}
			
			if (!is_null($updateItemRequests) && ($updateItemRequests == true))
			{
				$this->getApplication()->getSession()->remove('UpdateItemRequests');
				$this->populateManagedReservation();
			}

		}
	}

 	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
 	public function isPopup()
 	{
 		return false;
 	}

 	/**
 	 * It refreshes all the components (grids) in the page,
 	 * altogether.
 	 *
 	 */
 	public function globalRefresh($param = null)
 	{
		$this->populate($param);
 	}

	/**
	 * Callback from update-button in the page.
	 * It performs retrieving of filters and next it performs population.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}

	public function doManageRequests($param = null)
	{
		$this->onManageRequests(null, $param);
	}
	
	/**
	 * This is called in order to take under management some itemrequests
	 * which get retrieved by the list-component "Reservation".
	 * Output messages are given, with eventual problems or results.
	 * In the end, a global refreshing of page is performed.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onManageRequests($sender, $param)
	{
		$checkedRequestIds = $this->Requests->getCheckedItemIds(false, true);
		if (count($checkedRequestIds) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Nessuna riga selezionata"),
											ClavisMessage::WARNING);
			return;
		}

		$this->cleanMessageQueue();
		$clavisLibrarian = $this->getUser();

		$successNumber = 0;
		$alreadyManagedNumber = 0;
		$alreadyClosedNumber = 0;
		$patronNotEnabled = 0;
		$externalLibraryNotEnabled = 0;
		$manifestationNotLoanableSince = 0;
		$patronNotAge = 0;
		$itemNotAvail = 0;
		$genericError = 0;
		$toReload = false;
				
		///$localItems = $this->Requests->getLocalItems();
//		$checkedRequestIds = $checkedRequestIdsCombo['requestIds'];
//		$localItems = $checkedRequestIdsCombo;
		
		foreach ($checkedRequestIds as $requestId => $itemId)
		{
			$returnValue = null;
			
			if (!is_null($itemId))		//(array_key_exists($requestId, $localItems))
			{
				//$itemId = $localItems[$requestId];
				//if (intval($itemId) > 0)
				$item = ItemQuery::create()->findPk($itemId);
				if ($item instanceof Item)
				{
					$itemRequest = ItemRequestQuery::create()->findPk($requestId);

                    if($this->_loanmanager->IsLoanAllowed($item,
                                $itemRequest->getLoanDestinationObject(),
                                $itemRequest->getDeliveryLibraryId(),
                                true) // Reserve Mode True
                    )
                        $itemAvailableReturnValue = ClavisLoanManager::OK;
                    else
                        $itemAvailableReturnValue = ClavisLoanManager::LOAN_PATRONNOTENABLED;

					if ($itemAvailableReturnValue != ClavisLoanManager::OK)		// if it's a blocking error
						$returnValue = $itemAvailableReturnValue;
				}
				else
				{
					$returnValue = ClavisLoanManager::LOAN_ITEMNOTAVAIL;
				}
			}
			
			if (is_null($returnValue))		// if management is possible, we try it
				$returnValue = $this->_requestmanager->manageRequest($requestId, $clavisLibrarian);

			switch ($returnValue)
			{
				case ClavisLoanManager::OK:
					$successNumber++;
					$toReload = true;
					break;

				case ClavisLoanManager::RSV_ALREADYMANAGED:
					$alreadyManagedNumber++;
					break;

				case ClavisLoanManager::RSV_ALREADYCLOSED:
					$alreadyClosedNumber++;
					$toReload = true;
					break;

				case ClavisLoanManager::LOAN_PATRONNOTENABLED:
					$patronNotEnabled++;
					break;

				case ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED:
					$externalLibraryNotEnabled++;
					break;
				
				case ClavisLoanManager::LOAN_MANIFESTATIONNOTLOANABLESINCE:
					$manifestationNotLoanableSince++;
					break;

				case ClavisLoanManager::LOAN_PATRONNOTAGE:
					$patronNotAge++;
					break;

				case ClavisLoanManager::LOAN_ITEMNOTAVAIL:
					$itemNotAvail++;
					break;
				
				case ClavisLoanManager::ERROR:
				default:
					$genericError++;
					break;
			}
		}

		$this->enqueueMessage(Prado::localize("Prenotazioni prese in gestione: {num}",
												array('num' => $successNumber)),
										ClavisMessage::CONFIRM);

		if ($alreadyManagedNumber > 0)
			$this->enqueueMessage(Prado::localize("Prenotazioni già prese in gestione: {num}",
													array('num' => $alreadyManagedNumber)),
										ClavisMessage::WARNING);

		if ($alreadyClosedNumber > 0)
			$this->enqueueMessage(Prado::localize("Prenotazioni già soddisfatte o chiuse o annullate: {num}",
													array('num' => $alreadyClosedNumber)),
										ClavisMessage::WARNING);

		if ($patronNotEnabled > 0)
			$this->enqueueMessage(Prado::localize("Prenotazioni non soddisfacibili perché l'utente non è abilitato: {num}",
													array('num' => $patronNotEnabled)),
										ClavisMessage::WARNING);

		if ($externalLibraryNotEnabled > 0)
			$this->enqueueMessage(Prado::localize("Prenotazioni non soddisfacibili perché la biblioteca esterna non è abilitata: {num}",
													array('num' => $externalLibraryNotEnabled)),
										ClavisMessage::WARNING);
		
		if ($manifestationNotLoanableSince > 0)
			$this->enqueueMessage(Prado::localize("Prenotazioni non soddisfacibili perchè la notizia non e' ancora prestabile: {num}",
													array('num' => $manifestationNotLoanableSince)),
										ClavisMessage::WARNING);

		if ($patronNotAge > 0)
			$this->enqueueMessage(Prado::localize("Prenotazioni non soddisfacibili a causa dell'età dell'utente: {num}",
													array('num' => $patronNotAge)),
										ClavisMessage::WARNING);

		if ($itemNotAvail > 0)
			$this->enqueueMessage(Prado::localize("Prenotazioni non soddisfacibili perchè l'esemplare candidato non è disponibile: {num}",
													array('num' => $itemNotAvail)),
										ClavisMessage::WARNING);

		if ($genericError > 0)
			$this->enqueueMessage(Prado::localize("Errori generici, da segnalare al fornitore del software: {num}",
													array('num' => $genericError)),
										ClavisMessage::ERROR);
		
		if (($successNumber
				+ $alreadyManagedNumber
				+ $alreadyClosedNumber
				+ $patronNotEnabled
				+ $externalLibraryNotEnabled
				+ $manifestationNotLoanableSince
				+ $patronNotAge
				+ $itemNotAvail
				+ $genericError) == 0)
			$this->enqueueMessage(Prado::localize("Nessuna prenotazione processata"), 
									ClavisMessage::WARNING);

		if ($toReload)
		{
			$this->ManagedReservation->resetPagination();
			$this->globalRefresh($param);
		}

		$this->flushMessage();
	}

	/**
	 * This is called in order to cease management of itemrequests
	 * which get retrieved by the list-component "ManagedReservation".
	 * Output messages are given, with eventual problems or results.
	 * In the end, a global refreshing of page is performed.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnManageRequests($sender, $param)
	{
		$this->cleanMessageQueue();

		$okCheckedRequestIds = $this->ManagedReservation->getCheckedItemIds(null, true);	// resets
		$clavisLibrarian = $this->getUser();
		$success = 0;
		$error = 0;
		$notSameOperator = 0;
		$notManaged = 0;

		foreach ($okCheckedRequestIds as $requestId)
		{
			$returnCode = $this->_requestmanager->unManageRequest($requestId, $clavisLibrarian);

			switch ($returnCode)
			{
				case ClavisLoanManager::ERROR:
					$error++;
					break;

				case ClavisLoanManager::OK:
					$success++;
					break;

				case ClavisLoanManager::RSV_UNMANAGENOTSAMEOPERATOR:
					$notSameOperator++;

				case ClavisLoanManager::RSV_NOTMANAGED:
					$notManaged++;

				default:
					break;
			}
		}

		$this->enqueueMessage(Prado::localize("Cessata gestione su {num} prenotazioni", 
												array('num' => $success)),
								($success > 0)
									? ClavisMessage::CONFIRM
									: ClavisMessage::WARNING);

		if ($error > 0)
			$this->enqueueMessage(Prado::localize("Errori generici: {num}", array('num' => $error)),
										ClavisMessage::ERROR);

		if ($notSameOperator > 0)
			$this->enqueueMessage(Prado::localize("Si è tentato di cessare la gestione di {num} prenotazioni prese in gestione da un operatore diverso da quello corrente",
															array('num' => $notSameOperator)),
										ClavisMessage::ERROR);

		if ($success > 0)
		{
			$this->ManagedReservation->resetPagination();
			$this->globalRefresh($param);
		}

		$this->flushMessage();
	}

	/**
	 * This is called, as an ajax callback, when blipping the barcode
	 * of an item.
	 * It tries to perform the loan operation (upon the itemrequest that
	 * was taken into management).
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onImmediateLoan($sender, $param)
	{
		/* @var $request ItemRequest */
		/* @var $item Item */

		$panelUpdateFlag = false;
		$this->cleanMessageQueue();
		$itemInput = $this->ItemField->getSafeText();

		if ($itemInput != '')
		{
			$itemInput = trim($itemInput);
			$this->ItemField->setText('');
			$ok = false;

			$item = (object) null;
			$request = (object) null;
			$items = ItemPeer::retrieveByDataInput($itemInput);
			if (!is_null($items) && (count($items) > 0))
			{
				$oldItems = $items;
				$item = is_array($items) 
							? array_shift($items) 
							: $items->shift();
				$itemId = $item->getItemId();

				$exists = false;
				$this->ManagedReservation->resetChecked(false);
				$this->ManagedReservation->doMasterChecked(false, true);   // the 2nd parameter resets the mastercheck too ...
				foreach ($this->ManagedReservation->getCheckedItems(true, true) as $req)   // get all + reset
				{
					if (array_key_exists('localItemIds', $req))
					 {
						if (is_numeric(array_search($itemId, $req['localItemIds'])))
						{
							$exists = true;
							if (array_key_exists('request', $req))
								$request = $req['request'];
							break;
						}
					 }
				}

				if (!$exists)
				{
					$this->writeMessage(Prado::localize("L'esemplare esiste [titolo: '{tit}', id: {id}], ma non si riferisce a nessuna prenotazione presa in gestione dall'operatore corrente",
																	array('tit' => $item->getTrimmedTitle(30), 'id' => $itemId)),
												ClavisMessage::ERROR);
					return;
				}

				// lost check
				$returnMessage = $this->_loanmanager->putLostToAvailableItem($itemId);
				if (count($returnMessage) > 0)
					$this->getPage()->enqueueMessage($returnMessage[0], $returnMessage[1]);

				$itemsCount = count($oldItems);
				$ok = ($itemsCount == 1);
				if ($itemsCount > 1)  // duplicates are found
				{
					$encodedUrl = ItemPeer::encodeItems2Url($oldItems);
					$this->DuplicateItemId->setText($encodedUrl);
					$this->DuplicateItemHyperLink->dataBind();
					$this->drawDuplicateItemBarcodePanel(true, $param);

					$this->getPage()->enqueueMessage(Prado::localize('Prestito non effettuato perché esistono duplicati. Risolvere.'), ClavisMessage::WARNING);
					
					return;
				}
				else
				{
					$this->drawDuplicateItemBarcodePanel(false, $param);
				}
			}
			else
			{
				$this->enqueueMessage(Prado::localize('Nessun esemplare corrisponde'), ClavisMessage::ERROR);
			}

			if ($ok)
			{
				if ($item instanceof Item)
				{
					if ($this->doLoan($item, $request))
						$panelUpdateFlag = true;
				}
			}
			else
			{
				$this->enqueueMessage(Prado::localize('Nessun esemplare corrisponde'), ClavisMessage::ERROR);
			}
		}
		else   // prestito coi check
		{
			if ($this->ItemField->getSafeText() != '')
				return;

			$items = $this->ManagedReservation->getCheckedItems(false);
			if (count($items) == 0)
			{
				$this->writeMessage(Prado::localize("Non è stata selezionata alcuna riga"),
										ClavisMessage::ERROR);
				return;
			}

			$duplicateCount = 0;
			//$errorNotExistCount = 0;
			$errorNotExistArray = array();
			foreach ($items as $row)
			{
				if (count($row['localItemIds']) == 1)
				{
					$request = $row['request'];
					$item = ItemQuery::create()
								->findPK($row['localItemIds'][0]);
					if ($item instanceof Item)
					{
						if ($this->doLoan($item, $request))
							$panelUpdateFlag = true;
					}
					else	// this item does not seem to exist anymore
					{
						//$errorNotExistCount++;
						$errorNotExistArray[] = $row['localItemIds'][0];
					}
				}
				elseif (count($row['localItemIds']) > 1)
				{
					$duplicateCount++;
				}
				else	// fallback (item does not exist)
				{
					//$errorNotExistCount++;
					$errorNotExistArray[] = '--';
				}
			}

			if ($duplicateCount > 0)
				$this->enqueueMessage(Prado::localize("Tra le prenotazioni scelte da soddisfare vi sono casi dove può essere "
															. "usato più di un esemplare locale [totale: {num}]. Usa l'azione 'scegli' "
															. "per attribuire alla prenotazione un solo singolo esemplare.", 
														array('num' => $duplicateCount)),
										ClavisMessage::WARNING);
			
			if (count($errorNotExistArray) > 0)
				$this->enqueueMessage(Prado::localize("Tra le prenotazioni scelte da soddisfare vi sono casi dove l'esemplare "
															. "candidato per il prestito non sembra più esistere: id esemplari = {ids}", 
														array('ids' => implode(',', $errorNotExistArray))),
										ClavisMessage::WARNING);
		}

		if ($panelUpdateFlag)
		{
			$this->ManagedReservation->resetPagination();
			$this->ManagedReservation->populate();
			
			if (!is_null($param) && $this->getIsCallback())
				$this->ManagedReservationListPanel->render($param->getNewWriter());
		}

		$this->flushMessage();
		$this->setFocus($this->ItemField->getClientID());
	}

	public function drawDuplicateItemBarcodePanel($newState = false, $param = null)
	{
		$currentState = $this->DuplicateItemBarcodePanel->getCssClass() == "panel_on" ? true : false;
		if ($currentState != $newState)
		{
			$newCssClass = $newState ? 'panel_on' : 'panel_off';
			$this->DuplicateItemBarcodePanel->setCssClass($newCssClass);
			if (!is_null($param))
				$this->DuplicateItemBarcodePlaceHolder->render($param->getNewWriter());
		}
	}

	/**
	 * It performs the real loan operation, which is called by
	 * $this->onImmediateLoan().
	 *
	 * @param Item $item
	 * @return boolean   (result of operations)
	 */
	public function doLoan($item = null, $itemRequest = null)
	{
		/** @var $itemRequest ItemRequest */

		$return = false;

		if ($item instanceof Item)
		{
			if (is_null($itemRequest))
			{
				$reqId = intval($item->retrieveFirstItemRequestId());
				if ($reqId > 0)
					$itemRequest = ItemRequestQuery::create()
										->findPK($reqId);
			}

			if ($itemRequest instanceof ItemRequest)
			{
				$patron = $itemRequest->getPatron();
				if ($patron instanceof Patron)
				{
					$patronData = $patron->getReverseCompleteName();
					$isPatronAllowed = $this->_loanmanager->IsPatronAllowedToLoan($patron, $item->getItemId(),true);
				}
				else    // extrasystem case
				{
					$externalLibraryId = intval($itemRequest->getExternalLibraryId());
					$isPatronAllowed = $this->_loanmanager->isExternalLibraryAllowedToLoan($externalLibraryId);
					$patron = LibraryQuery::create()
								->findPK($externalLibraryId);   // extrasystem case, patron equals externallibrary inside loanmanager::DoLoanItem
					$patronData = $patron->getLabel(true, true, true);	// this is an external library
				}

				$dueDate = $this->_loanmanager->CalculateDueDate($item);
				$clavisLibrarian = $this->getUser();
				$deliveryLibrary = $itemRequest->getDeliveryLibrary();
				$deliveryLibraryId = $deliveryLibrary->getLibraryId();

//				if ($isPatronAllowed != ClavisLoanManager::OK)
//						$this->enqueueMessage(Prado::localize("L'utente non è abilitato al prestito di '{title}' [barcode: {barcode}].",
//																array('title' => $item->getTrimmedTitle(40), 'barcode' => $item->getBarcode())),
//												ClavisMessage::ERROR);
				switch ($isPatronAllowed)
				{
					case ClavisLoanManager::LOAN_PATRONNOTENABLED:
						$this->enqueueMessage(Prado::localize("L'utente '{patron}' non è abilitato al prestito",
																array(	'patron' => $patronData)),
												ClavisMessage::ERROR);
						break;

					case ClavisLoanManager::LOAN_REACHEDMAX:
						$this->enqueueMessage(Prado::localize("L'utente '{patron}' non è abilitato al prestito di '{title}' [barcode: {barcode}] perchè è stato superato il numero dei prestiti consentiti",
																array(	'patron' => $patronData,
																		'title' => $item->getTrimmedTitle(40), 
																		'barcode' => $item->getBarcode())),
												ClavisMessage::ERROR);
						break;

					case ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED:
						$this->enqueueMessage(Prado::localize("La biblioteca esterna '{patron}' non è abilitata al prestito di '{title}' [barcode: {barcode}]",
																array(	'patron' => $patronData,
																		'title' => $item->getTrimmedTitle(40), 
																		'barcode' => $item->getBarcode())),
												ClavisMessage::ERROR);
						break;
				}
						
				$isItemAvailableReturnValue = $this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId);						
				if ($isItemAvailableReturnValue != ClavisLoanManager::OK)
				{
					// TODO: differenziare, per valori restituiti
					
					$manifestation = $item->getManifestation();
					if ($manifestation instanceof Manifestation)
					{
						if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_MANIFESTATIONNOTLOANABLESINCE)
							$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
																	array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))),
													ClavisMessage::ERROR);

						//if (!$this->_loanmanager->IsRatingAllowed($manifestation, $selectedPatron))
						if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_PATRONNOTAGE)
							$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con piu' di {rating} anni",
																	array('rating' => $manifestation->getRating())),
													ClavisMessage::ERROR);
					}
				}

				if (($isPatronAllowed == ClavisLoanManager::OK)
						&& ($isItemAvailableReturnValue == ClavisLoanManager::OK))
				{
					$loanResult = $this->_loanmanager->DoLoanItem(	$item, 
																	$patron, 
																	$clavisLibrarian, 
																	$deliveryLibrary, 
																	$itemRequest, 
							
																	$dueDate );
					switch ($loanResult)
					{
						case ClavisLoanManager::LOAN_READYTOLOAN:
							$labelText = Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al prestito per l'utente '{patron}'",
																	array(	'patron' => $patronData,
																			'title' => $item->getTrimmedTitle(40), 
																			'barcode' => $item->getBarcode()));

							// ready-to-loan automatic notification
							if (ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true')
							{
								$ret = NotificationHelper::sendNotificationEmail('readyforloan', $patron,
									$clavisLibrarian->getLibrarian(), $deliveryLibrary,
									array($item->getCurrentLoanId()));
								if ($ret) {
									$item->setNotifyCount($item->getNotifyCount() + 1);
									$item->save();
									$loan = $item->getLoanRelatedByCurrentLoanId();
									$loan->setNotifyCount($loan->getNotifyCount() + 1);
									$loan->save();
									$labelText .= Prado::localize(' - notificato automaticamente via email');
								}
							}
							$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);
							$this->UserFocus->setFocusComponent($this->ItemField);
							$return = true;
							break;

						case ClavisLoanManager::LOAN_ILLREQUESTED:
							$this->enqueueMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al transito per l'utente '{patron}'",
																	array(	'patron' => $patronData,
																			'title' => $item->getTrimmedTitle(40), 
																			'barcode' => $item->getBarcode())),
													ClavisMessage::CONFIRM);

							$this->UserFocus->setFocusComponent($this->ItemField);
							$return = true;
							break;

						case ClavisLoanManager::LOAN_LOANALREADYEXISTS:
							$this->enqueueMessage(Prado::localize("Un prestito per l'esemplare '{title}' [barcode: {barcode}] è già in corso",
																	array(	'title' => $item->getTrimmedTitle(40), 
																			'barcode' => $item->getBarcode()),
													ClavisMessage::ERROR));
							break;

						case ClavisLoanManager::RSV_ALREADYMANAGED:
							$this->enqueueMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] è già in gestione ad un altro operatore, per cui non è possibile prestarlo",
																	array(	'title' => $item->getTrimmedTitle(40), 
																			'barcode' => $item->getBarcode()),
													ClavisMessage::ERROR));
							break;

						case ClavisLoanManager::OK:
						case true:
							$this->enqueueMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] in prestito all'utente '{patron}'",
																	array(	'patron' => $patronData,
																			'title' => $item->getTrimmedTitle(40), 
																			'barcode' => $item->getBarcode())),
													ClavisMessage::CONFIRM);	

							$this->UserFocus->setFocusComponent($this->ItemField);
							$return = true;
							break;

						case ClavisLoanManager::ERROR:
						case false:
						default:

							$this->enqueueMessage(Prado::localize("ERRORE: esemplare '{title}' [barcode: {barcode}] non prestato",
																	array(	'title' => $item->getTrimmedTitle(40), 
																			'barcode' => $item->getBarcode())),
													ClavisMessage::ERROR);
							break;
					}
				}
			}
		}
		else
		{
			$this->enqueueMessage(Prado::localize("ERRORE sul passaggio parametri dell'esemplare. Segnalare al fornitore del software"),
									ClavisMessage::ERROR);
		}
		
		return $return;
	}

	public function populate($param = null)
	{
		$this->populateRequests($param);	// pending
		$this->populateManagedReservation($param);
	}
	
	private function populateRequests($param = null)
	{
		$this->Requests->globalrefresh();
		
		if ($this->getPage()->getIsCallback()) 
			$this->RequestsPanel->render(($param instanceof TCallbackEventParameter) 
												? $param->getNewWriter() 
												: $this->getPage()->createWriter());
	}
	
	public function populateManagedReservation($param = null)
	{
		$this->ManagedReservation->populate();

		if ($this->getPage()->getIsCallback())
			$this->ManagedReservationPanel->render(($param instanceof TCallbackEventParameter)
														? $param->getNewWriter()
														: $this->getPage()->createWriter());
	}

	public function onPrintJRPPendingReservation($sender, $param)
	{
		$datasource = $this->Requests->getCheckedItemIds(true, true, true);     // all + reset, + jaspermode

		$requestIds = array();
		$itemIds = array();
		if (array_key_exists('requestIds', $datasource))
			$requestIds = $datasource['requestIds'];
		if (array_key_exists('itemIds', $datasource))
			$itemIds = $datasource['itemIds'];

		if (count($requestIds) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Coda di stampa vuota"), 
											ClavisMessage::WARNING);
			return;
		}

		$requestIdsString = implode(',', $requestIds);
		$itemIdsString = implode(',', $itemIds);

		$this->JRPBox->setObjectId($requestIdsString);
		$this->JRPBox->addOptionalParam('P_ITEMIDPOOL', $itemIdsString);
		$this->JRPBox->printReport();
	}

	public function onPrintJRPManagedReservation($sender, $param)
	{
		$datasource = $this->ManagedReservation->getCheckedItems(true, true, true);     // all + reset, + jaspermode

		if (array_key_exists('requestId', $datasource))
			$requestId = $datasource['requestId'];
		if (array_key_exists('itemId', $datasource))
			$itemId = $datasource['itemId'];

		if (count($requestId) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Coda di stampa vuota"), 
											ClavisMessage::WARNING);
			return;
		}

		$requestId = implode(',', $requestId);
		$itemId = implode(',', $itemId);

		$this->JRPBox2->setObjectId($requestId);
		$this->JRPBox2->addOptionalParam('P_ITEMIDPOOL', $itemId);
		$this->JRPBox2->addOptionalParam('P_ORDER', $this->ManagedReservation->getSortingExpression());
		$this->JRPBox2->addOptionalParam('P_ORDERDIR', $this->ManagedReservation->getSortingDirection());

		$this->JRPBox2->printReport();
	}

	/**
	 * It was used in order to get which tab is active in
	 * this moment.
	 * Now it seems deprecated ...
	 *
	 * @param unknown_type $param
	 * @return array
	 */
	public function getSelectedTabParameter($param = null)
	{
		if (!is_null($param))
			$av = $param;
		else
			$av = $this->TabPanel->getActiveViewIndex();

		return array('selectTab', $av);
	}

	/**
	 * It's used in the template for displaying the number of
	 * item requests in the proper tab.
	 *
	 * @return string
	 */
	public function getReservationFoundString()
	{
		$return = '';
		$recCount = $this->Requests->FoundNumber->getText();

		if (!is_null($recCount))
		{
			$recCount = intval($recCount);
			if ($recCount >= 0)
		 		$return = " ($recCount)";
		}

		return $return;
	}

	public function checkItemCallBack($sender, $param)
	{
		$itemInput = trim($this->BarcodeFilter->getSafeText());
		if ($itemInput != '')
		{
			$this->doCleanFilter(false);
			$this->BarcodeFilter->setText($itemInput);

			$this->globalRefresh();
		}
	}

	public function onReloadPage($sender, $param)
	{
		$this->writeMessage(Prado::localize('Liste prenotazioni ricaricate'),
								ClavisMessage::INFO);
		$this->globalRefresh($param);
	}
	
}
