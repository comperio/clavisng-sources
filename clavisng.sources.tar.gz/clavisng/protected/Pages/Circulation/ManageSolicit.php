<?php
/**
 * ManageSolicit Page class Module Circulation
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2008 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */

Prado::using('Application.Common.SolicitModules.*');

class ManageSolicit extends ClavisPage 
{
	public $_module = 'CIRCULATION';

	private $_datasourceSingle;
	private $_datasource;
	private $_datasourceSingleSessionName;
	private $_datasourceSessionName;

	/* @var Item */
	private $_item;
	/* @var Loan */
	private $_loan;

	/**
	 * Per la logica di checkaggio
	 */
	public	$_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_globalCriteriaSessionName;

	public $mode = null;

	public function onPreInit($param) 
	{
		parent::onPreInit($param);
	
		$itemId = intval($this->getRequest()->itemAt('itemId'));
		$loanId = intval($this->getRequest()->itemAt('loanId'));
		
		if ($itemId > 0) 
		{
			$this->_item = ItemQuery::create()->findPK($itemId);
			$this->_loan = $this->_item->getCurrentLoan();
		} 
		elseif ($loanId > 0) 
		{
			$this->_loan = LoanQuery::create()->findPK($loanId);
			$this->_item = $this->_loan->getItem();
		} 
		else 
		{
			$this->writeMessage(Prado::localize('Parametri errati'),
									ClavisMessage::ERROR);
		}
		if ($this->_loan->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN) {
			$this->mode = 'notify';
		} else if (in_array($this->_loan->getLoanStatus(),ItemPeer::getLoanStatusCurrent())
				&& $this->_loan->getDueDate('U') < time()) {
			$this->mode = 'late';
		} else {
			$this->mode = 'warn';
		}
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = "DataSourceSessionName" . $uniqueId;
		$this->_datasourceSingleSessionName = "DataSourceSingleSessionName" . $uniqueId;
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
		$this->setPatronId($this->_loan->getPatronId());
		$this->setExternalLibraryId($this->_loan->getExternalLibraryId());
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallBack())
		{
			$this->emptyDatasources();
			$this->populate();
		}
		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		$crit = $this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null);

		if ($crit instanceof Criteria)
			$crit = SerializableCriteria::refreshCriteria($crit);

		return $crit;
	}

	public function resetAllDatasource()
	{
		$this->resetSingleDatasource();
		$this->resetOthersDatasource();
	}

	public function getSolicitMode()
	{
		switch ($this->mode) {
			case 'notify':
				return 'readyforloan';
			case 'late':
				return 'solicit';
			case 'warn':
				return 'expiring';
		}
	}

	/**
	 * It populates the grid, and takes the four necessary filter
	 * parameters from given saved data, and eventual other filters
	 * (i.e. patron, which was passed through the "setObject()").
	 *
	 */
	public function populate()
	{
		$criteriaSingle = new Criteria();
		$loansSingle = array();
		$loansOthers = array();
		$recCountOthers = 0;
		$extra = false;

		$patronId = intval($this->getPatronId());
		$externalLibraryId = intval($this->getExternalLibraryId());
		if (($patronId + $externalLibraryId) > 0)
		{
			$extra = ($externalLibraryId > 0);

			if (!$extra)
				$criteriaSingle->add(LoanPeer::PATRON_ID, $patronId);
			else
				$criteriaSingle->add(LoanPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId);

			if ($this->mode == 'notify') {
				$criteriaSingle->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::LOANSTATUS_READYFORLOAN);
			} else {
				$criteriaSingle->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusCurrent(), Criteria::IN);
				$criteriaSingle->addAnd(LoanPeer::DUE_DATE, time(),
					'late'==$this->mode ? Criteria::LESS_THAN : Criteria::GREATER_EQUAL);
			}
			
			$criteriaOthers = clone($criteriaSingle);
			$criteriaSingle->addAnd(LoanPeer::LOAN_ID, $this->_loan->getLoanId());
			$criteriaOthers->addAnd(LoanPeer::LOAN_ID, $this->_loan->getLoanId(), Criteria::NOT_EQUAL);
			$criteriaOthers->addDescendingOrderByColumn(LoanPeer::LOAN_DATE_BEGIN);

			$loansSingle = LoanPeer::doSelect($criteriaSingle);

			$recCountOthers = LoanPeer::doCount($criteriaOthers);
			$this->setGlobalCriteria(clone $criteriaOthers);

			$currentIndexPage = $this->OthersLoanGrid->getCurrentPage();
			$pageSize = $this->OthersLoanGrid->getPageSize();
			$criteriaOthers->setLimit($pageSize);
			$criteriaOthers->setOffset($currentIndexPage * $pageSize);
			$loansOthers = LoanPeer::doSelect($criteriaOthers);
		}

		$singleDatasource = $this->ciclePopulate($loansSingle, null, true);
		$othersDatasource = $this->ciclePopulate($loansOthers, $this->getChecked(), false);

		$this->OthersLoanGrid->setVirtualItemCount($recCountOthers);

		if (count($singleDatasource) > 0)
		{
			$this->setSingleDatasource($singleDatasource);
			$this->SingleLoanGrid->setDataSource($singleDatasource);
			$this->SingleLoanGrid->dataBind();
			$this->SingleLoanPanel->setVisible(true);
		} 
		else 
		{
			$this->SingleLoanPanel->setVisible(false);
		}

		if (count($othersDatasource) > 0)
		{
			$this->setOthersDatasource($othersDatasource);
			$this->OthersLoanGrid->setDataSource($othersDatasource);
			$this->OthersLoanGrid->dataBind();
			$this->OthersLoanPanel->setVisible(true);
		} 
		else 
		{
			$this->OthersLoanPanel->setVisible(false);
		}
		
		$this->OthersFoundNumber->setText($recCountOthers);

		if (!$extra)
		{
			$this->notificationList->setObjectClass('patron');
			$this->notificationList->setObjectId($patronId);
		}
		else
		{
			$this->notificationList->setObjectClass('library');
			$this->notificationList->setObjectId($externalLibraryId);
		}

		$this->notificationList->populate();
	}

	private function ciclePopulate($paramLoans, $paramChecked = array('all' => false), $paramForceChecked = false)
	{
		$datasource = array();
		foreach ($paramLoans as $loan)
		{
			$loanId = $loan->getLoanId();

			if ($paramForceChecked) 
			{
				$checked = true;
			} 
			else 
			{
				if (isset($paramChecked[$loanId])) {
					$checked = $paramChecked[$loanId];
				} else {
					$checked = false;
				}
				if ($paramChecked['all'])
					$checked = !$checked;
			}
			
			$datasource[] = $this->populateFields($loan, $checked);
		}
		
		return $datasource;
	}

	private function populateFields($loan, $checked = false)
	{
		$row = array();
		if ($loan instanceof Loan)
		{
			$loanId = $loan->getLoanId();
			$fromLibraryId = $loan->getFromLibrary();
			$patronId = $loan->getPatronId();

			$externalLibraryId = intval($loan->getExternalLibraryId());
			if ($externalLibraryId > 0)  // extra
				$toLibraryId = $externalLibraryId;
			else  //normal
				$toLibraryId = $loan->getToLibrary();

			$item = $loan->getItem();
			$dueDate = $item->getDueDate('U');
			$actualLibraryId = $item->getActualLibraryId();

			$exceedDate = $dueDate < time();  //

			$loan_title = str_replace("<br>", "\n", $loan->getTitle());
			$inventory = $item->getInventoryCollocationCombo();

			$row = array(	'id' => $loanId,
							'itemId' => $loan->getItemId(),
							'inventory' => $inventory,
							'invserie' => $item->getInventorySerieId(),
							'barcode' => $item->getBarcode(),
							'collocation' => $item->getCollocationCombo(),
							'patronId' => $patronId,
							'externalLibraryId' => $externalLibraryId,
							'title' => $loan_title,
							'fromLibraryId' => $fromLibraryId,
							'fromLibraryDescription' => LibraryPeer::getLibraryDescription($fromLibraryId),
							'fromLibraryLabel' => LibraryPeer::getLibraryLabel($fromLibraryId, '---'),
							'toLibraryId' => $toLibraryId,
							'toLibraryDescription' => LibraryPeer::getLibraryDescription($toLibraryId),
							'toLibraryLabel' => LibraryPeer::getLibraryLabel($toLibraryId, '---'),
							'actualLibraryId' => $actualLibraryId,
							'actualLibraryDescription' => LibraryPeer::getLibraryDescription($actualLibraryId),
							'actualLibraryLabel' => LibraryPeer::getLibraryLabel($actualLibraryId, '---'),
							'solicitCount' => $loan->getNotifyCount(),
							'renewCount' => $loan->getRenewCountLabel(),
							'patronCompleteName' => PatronPeer::getCompleteName($patronId),
							'loanDateBegin' => $loan->getLoanDateBegin('U'),
							'dueDate' => $dueDate,
							'exceedDate' => $exceedDate,
							'checked' => $checked );
		}
		
		return $row;
	}

	public function setPatronId($value)
	{
		$this->setControlState('patron_id', $value, null);
	}

	public function getPatronId()
	{
		return $this->getControlState('patron_id', null);
	}

	public function getPatronName()
	{
		$output = '';
		$patron	= (object) null;
		$patron_id = intval($this->getPatronId());
		if ($patron_id > 0)
			$patron	= PatronPeer::retrieveByPK($patron_id);
		if ($patron instanceof Patron)
			$output = $patron->getLastname() . ' ' . $patron->getName() . " (" . $patron->getBarcode() . ")";
		
		return $output;
	}

	public function setExternalLibraryId($value)
	{
		$this->setControlState('externalLibrary_id', $value, null);
	}

	public function getExternalLibraryId()
	{
		return $this->getControlState('externalLibrary_id', null);
	}

	public function getExternalLibraryLabel()
	{
		$output = '';
		$library = (object) null;
		$externalLibraryId = intval($this->getExternalLibraryId());
		if ($externalLibraryId > 0)
			$library = LibraryQuery::create()
							->findPK($externalLibraryId);
		if ($library instanceof Library)
			$output = $library->getLabel(true, false, true);

		return $output;
	}

	/**
	 * Method which implements the page change in the grid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender,$param)
	{
		$this->OthersLoanGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function resetPagination()
	{
		$this->OthersLoanGrid->setCurrentPage(0);
	}

	public function emptyDatasources()
	{
		$this->resetSingleDatasource();
		$this->resetOthersDatasource();
		$this->resetChecked();
	}

	public function resetFields()
	{
		$this->chkEmail->setEnabled(false);
		$this->chkEmail->setChecked(false);
		$this->chkSnailMail->setEnabled(false);
		$this->chkSnailMail->setChecked(false);
		$this->chkPhone->setEnabled(false);
		$this->chkPhone->setChecked(false);
		$this->chkMobile->setEnabled(false);
		$this->chkMobile->setChecked(false);
		$this->chkSms->setEnabled(false);
		$this->chkSms->setChecked(false);
		$this->SolicitDescription->setText("");
	}

	public function onOthersFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getOthersDatasource();
		$checked = $this->getChecked();
		$row = $dataSource[$index];
		$loanId = $row['id'];

		if ($newChecked != $checked['all']) 
			$checked[$loanId] = true;
		else 
			unset($checked[$loanId]);
		
		$this->setChecked($checked);
	}

	public function onAllOthersFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$this->resetChecked($newChecked);
		$gridItems = $this->OthersLoanGrid->getItems();
		$header = $this->OthersLoanGrid->getHeader();
		foreach ($gridItems as $gridItem)
			$gridItem->CheckColumn->Check->setChecked($newChecked);
		$datasource = $this->getOthersDataSource();
		for ($i = 0; $i < count($datasource); $i++)
			$datasource[$i]["checked"] = $newChecked;
		$this->setOthersDatasource($datasource);
	}

	public function onSingleFlipChecked($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getSingleDataSource();
		$row = $dataSource[$index];
		$checked = $row['checked'];
		$checked = !$checked;
		$row['checked'] = $checked;
		$dataSource[$index] = $row;
		$this->_datasourceSingle = $dataSource;
		$this->setSingleDatasource($this->_datasourceSingle);
		$this->SingleLoanGrid->setDataSource($this->_datasourceSingle);
	}

	/**
	 * It returns the datasource (eventually taking it from the saved session variable).
	 *
	 * @return array
	 */
	public function getSingleDatasource()
	{
		if (is_null($this->_datasourceSingle))
			$this->_datasourceSingle = $this->getApplication()->getSession()->itemAt($this->_datasourceSingleSessionName);
		return $this->_datasourceSingle;
	}

	public function setSingleDatasource($datasource = null)
	{
		$this->_datasourceSingle = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSingleSessionName, $datasource);
	}

	public function resetSingleDatasource()
	{
		$this->setSingleDatasource(array());
	}

	/**
	 * It returns the datasource (eventually taking it from the
	 * saved session variable).
	 *
	 * @return array
	 */
	public function getOthersDatasource()
	{
		if (is_null($this->_datasource))
			$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		
		return $this->_datasource;
	}

	public function setOthersDatasource($datasource = null)
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $datasource);
	}

	public function resetOthersDatasource()
	{
		$this->setOthersDatasource(null);
		$this->_datasource = array();
	}

	public function getDestinations() 
	{
		return array($this->getDestination());
	}

	public function getLoanIds() 
	{
		$this->getSingleDatasource();
		$this->_datasource = $this->getOtherCheckedItems();
		$datasource = array_merge($this->_datasourceSingle,$this->_datasource);
		$loan_ids = array();
		foreach ($datasource as $row) 
			$loan_ids[] = $row['id'];
		
		return $loan_ids;
	}

	private function getDestination() 
	{
		$destination = PatronQuery::create()
							->findPK($this->getPatronId());
		
		if (!($destination instanceof Patron)) 
		{
			$destination = LibraryQuery::create()
								->findPK($this->getExternalLibraryId());
			
			if (!($destination instanceof Library))
				return null;
		}
		
		return $destination;
	}

    public function getContactChannels() 
	{
        $contactChannels = array();
        $d = $this->getDestination();
        if ($d instanceof Patron) 
		{
            if ($d->countAddresss() > 0)
                $contactChannels[] = NotificationPeer::CHANNEL_SNAILMAIL;
            
			foreach ($d->getContacts() as $c) 
			{
                switch ($c->getContactType()) 
				{
                    case ContactPeer::TYPE_EMAIL:
                        $contactChannels[] = NotificationPeer::CHANNEL_EMAIL;
                        break;
                
					case ContactPeer::TYPE_PHONE:
                        $contactChannels[] = NotificationPeer::CHANNEL_PHONE;
                        break;
                    
					case ContactPeer::TYPE_MOBILE:
                        $contactChannels[] = NotificationPeer::CHANNEL_SMS;
                        $contactChannels[] = NotificationPeer::CHANNEL_MOBILE;
                        break;
                }
            }
        } 
		elseif ($d instanceof Library) 
		{
            if (trim($d->getEmail()))
                $contactChannels[] = NotificationPeer::CHANNEL_EMAIL;
			
            if (trim($d->getAddress()))
                $contactChannels[] = NotificationPeer::CHANNEL_SNAILMAIL;
			
            if (trim($d->getPhone()))
                $contactChannels[] = NotificationPeer::CHANNEL_PHONE;
        }
		
        $contactChannels = array_unique($contactChannels);
		
        return $contactChannels;
    }

	protected function resetPageState()
	{
		$this->resetFields();
		$this->emptyDatasources();
		$this->populate();
	}

	public function onChangePage($sender, $param)
	{
		$this->OthersLoanGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		return $checked['all'];
	}

	/**
	 * Are we inside a popup?
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	/**
	 * It returns the checked items....
	 *
	 * @param boolean $force
	 * @return unknown
	 */
	public function getOtherCheckedItems()
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();
		if (!$masterChecked)
		{
			$datasource = array();
			$loans = LoanQuery::create()->findPKs($checkedIds);
			foreach ($loans as $loan)
				$datasource[] = $this->populateFields($loan, true);
			
			$output = $datasource;
		}
		else         // caso del mastercheck inverso
		{
			$datasource = array();
			$globalCriteria = $this->getGlobalCriteria();

			if (!is_null($globalCriteria) && ($globalCriteria instanceof Criteria))
			{
				$globalCriteria->addAnd(LoanPeer::LOAN_ID, $checkedIds, Criteria::NOT_IN);
				$loans = LoanPeer::doSelect($globalCriteria);
				foreach ($loans as $loan)
					$datasource[] = $this->populateFields($loan, true);
			}
			
			$output = $datasource;
		}

		return $output;
	}

}
