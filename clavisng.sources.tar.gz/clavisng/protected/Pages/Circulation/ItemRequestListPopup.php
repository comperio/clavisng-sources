<?php

/**
 * ItemRequestListPopup Page class Module Circulation
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class ItemRequestListPopup extends ClavisPagePopup
{
	public $_module = 'CIRCULATION';

	private $_manifestation;
	private $_item_request;

	public function onInit($param)
	{
		parent::onInit($param);

		if(!$this->getIsPostBack() )
		{

		    $id = intval($this->Request['id']);
			if($id > 0)
			{
				$manifestation = ManifestationPeer::retrieveByPK($id);
				$this->setManifestation($manifestation);
			}

			$request_id = intval($this->Request['requestId']);
			if ($request_id >0)
			{
				$item_request = ItemRequestPeer::retrieveByPK($request_id);
				$this->setItemRequest($item_request);
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->ItemList->setManifestation($this->getManifestation());
			$this->ItemList->setFilter('mine');
			$this->ItemList->setItemRequest($this->getItemRequest());
			//$this->dataBind();
		}
	}

	public function onCancel($sender, $param)
	{

	}

	private function ClearInputDialog()
	{
		//$this->PatronName->Text = '';
		//$this->PatronLastname->Text = '';
	}

	public function globalRefresh()
	{
		//$this->PatronList->populate();
	}



	public function isUnlink()
	{
		return false;
	}

	public function setManifestation($manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setViewState("manifestation", $manifestation, null);
	}

	/**
	 * Getter method of object item.
	 *
	 * @return Item
	 *
	 */
	public function getManifestation()
	{
		if(is_null($this->_manifestation))
			$this->_manifestation = $this->getViewState("manifestation", null);
		return $this->_manifestation;
	}

	public function setItemRequest($item_request)
	{
		$this->_item_request = $item_request;
		$this->setViewState("item_request", $item_request, null);
	}

	/**
	 * Getter method of object item_request.
	 *
	 * @return Item
	 *
	 */
	public function getItemRequest()
	{
		if(is_null($this->_item_request))
			$this->_item_request = $this->getViewState("item_request", null);
		return $this->_item_request;
	}
}
