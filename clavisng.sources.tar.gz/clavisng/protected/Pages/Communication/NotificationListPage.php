<?php

/**
 * NotificationList Page class Module Communication
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class NotificationListPage extends ClavisPage {

	public $_module = "COMMUNICATION";

	public function onLoad($param) {
		parent::onLoad($param);
		//$this->setFocus($this->NotificationList->BarcodeFilter);
		if(!$this->getIsPostBack())
			$this->NotificationList->populate();
	}

	public function globalRefresh()
	{
		$this->NotificationList->populate();
	}


}

?>