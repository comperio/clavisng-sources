<?php

/**
 * NotificationPopupPage Page class Module Communication
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2008 Comperio
 */

class NotificationPopupPage extends ClavisPagePopup {

	public $_module = 'COMMUNICATION';

	/* @var Notification */
	private $_notification = null;

	public function onInit($param)
	{
		parent::onInit($param);
		$notification_id = TPropertyValue::ensureInteger($this->getRequest()->itemAt('param'));
		$notification = NotificationPeer::retrieveByPK($notification_id);
		if ($notification instanceof Notification) {
			$this->setNotification($notification);
		} else {

		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getIsPostBack()) {
			$this->populateForm();
			$this->dataBind();
		}
		$this->UpdateData->setObject($this->getNotification());
	}

	public function populateForm() {
		if ($this->_notification === null)
			return;

		$this->NotificationState->setText(LookupValuePeer::getLookupValue('NOTIFICATIONSTATE',
			$this->_notification->getNotificationState()));
		$this->NotificationChannel->setSelectedValue($this->_notification->getNotificationChannel());

		$this->DeliveryDate->setValue($this->_notification->getDeliveryDate('U'));
		$this->AcknowledgeDate->setValue($this->_notification->getAcknowledgeDate('U'));
		$this->Message->setText($this->_notification->getMessage());

		$this->SetSentButton->setEnabled(in_array($this->_notification->getNotificationState(),
			array(NotificationPeer::STATUS_PENDING,NotificationPeer::STATUS_UNKNOWN)));
		$this->SetDeliveredButton->setEnabled(in_array($this->_notification->getNotificationState(),
			array(NotificationPeer::STATUS_PENDING,NotificationPeer::STATUS_SENT,NotificationPeer::STATUS_UNKNOWN)));

		$objectId = $this->_notification->getObjectId();

		if (!is_null($objectId) && (!$objectId == 0)) {
			switch (strtolower($this->_notification->getObjectClass())) {
				case 'library': //biblioteca
					$library = LibraryPeer::retrieveByPK($objectId);
					if ($library) {
						$label = $library->getLabel();
						$url = 'index.php?page=Library.LibraryViewPage&id='.$objectId;
					} else {
						$label = "(id =".$objectId.")";
						$url = '';
					}
					break;
				case 'librarian': //bibliotecario
					$librarian = LibrarianPeer::retrieveByPK($objectId);
					if ($librarian) {
						$label = $librarian->getCompleteName();
						$url = 'index.php?page=Library.LibrarianViewPage&id='.$objectId;
					} else {
						$label = "(id =".$objectId.")";
						$url = '';
					}
					break;
				case 'patron': //utente
					$patron = PatronPeer::retrieveByPK($objectId);
					if ($patron) {
						$label = $patron->getCompleteName();
						$url = 'index.php?page=Circulation.PatronViewPage&id='.$objectId;
					} else {
						$label = "(id =".$objectId.")";
						$url = '';
					}
					break;
				case 'supplier': //fornitore
					$supplier = SupplierPeer::retrieveByPK($objectId);
					if ($supplier) {
						$label = $supplier->getSupplierName();
						$url = 'index.php?page=Acquisition.SupplierPage&id='.$objectId;
					} else {
						$label = "(id ={$objectId})";
						$url = '';
					}
					break;
				default:
					$label = 'WRONG';
					$url = '#';
					break;
			}
			$this->Receiver->setText($label);
			$this->Receiver->setNavigateUrl($url);
		}
	}


	/**
	 * setter
	 *
	 * @param Notification $notification
	 */
	public function setNotification($notification) {
		$this->_notification = $notification;
		$this->setViewState("notification",$notification,null);
	}


	/**
	 * getter
	 *
	 * @return Notification
	 *
	 */
	public function getNotification() {
		if(is_null($this->_notification)) {
			$this->_notification = $this->getViewState("notification",null);
		}
		return $this->_notification;
	}


	public function globalEditCancel()
	{
	}

	public function onSetSent($sender, $param)
	{
		$this->_notification->setNotificationState(NotificationPeer::STATUS_SENT);
		$this->_notification->setDeliveryDate(time());
		$this->_notification->save();
		$this->populateForm();
	}

	public function onSetDelivered($sender, $param)
	{
		$this->_notification->setNotificationState(NotificationPeer::STATUS_DELIVERED);
		$this->_notification->setAcknowledgeDate(time());
		$this->_notification->save();
		$this->populateForm();
	}

}
