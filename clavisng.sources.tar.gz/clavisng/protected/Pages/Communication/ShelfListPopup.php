<?php
/**
 * ShelfListPopup class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ShelfListPopup Class
 *
 * This page is for being inside the popup which outputs
 * a list of shelves.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Communication
 * @since 2.1
 */
class ShelfListPopup extends ClavisPagePopup
{
	public $_module = 'COMMUNICATION';

	/**
	 * Id of the object whom the calling page is
	 * interacting with, and the popup is opened for.
	 *
	 * @var int
	 */
	private $_objectId = 0;

	/**
	 * Type of the object whom the calling page is
	 * interacting with, and the popup is opened for.
	 *
	 * @var string
	 */
	private $_objectType = '';

	/**
	 * In the onInit we get the 'objectId' and 'objectType'
	 * parameters, for describing the exact object the calling
	 * page is interacting with.
	 *
	 * @param TEventParameter $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack()) {
			$objectId = intval($this->getRequest()->itemAt('id'));
			$objectType = $this->getRequest()->itemAt('objectType');
			if ($objectId != 0)
				$this->setObjectId($objectId);
			if ($objectType != '')
				$this->setObjectType($objectType);
		}
	}

	/**
	 * In the onLoad, the first time this popup page is executed
	 * we reset the 'quick new shelf' panel, and then we initialize
	 * the inner component which visualizes the shelves, by passing
	 * the objectType (ex.: 'patron') and its id.
	 *
	 * NB: the 3rd parameter is the "except" flag.
	 * If false (default, on the component), the component will extract
	 * shelves which contain the object as an item. If true (i.e. in the
	 * except mode) the inner component will extract only the shelves
	 * where the given object is NOT present as an item.
	 *
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->NewShelfDialog->setVisible(false);
			$this->ShelfList->setObjectParameters($this->getObjectType(), $this->getObjectId(), true);
		}
	}

	/**
	 * Setters and getters
	 */
	public function setObjectId($id)
	{
		$this->_objectId = $id;
		$this->setViewState('ObjectId', $id, null);
	}

	public function getObjectId()
	{
		if (is_null($this->_objectId))
			$this->_objectId = $this->getViewState('ObjectId', null);
		
		return $this->_objectId;
	}

	public function setObjectType($type)
	{
		$this->_objectType = $type;
		$this->setViewState('ObjectType', $type, null);
	}

	public function getObjectType()
	{
		$this->_objectType = $this->getViewState('ObjectType', null);
		
		return $this->_objectType;
	}

	/**
	 * It sets visible the panel which is used to quickly
	 * insert a new shelf.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onOpenNewShelfDialog($sender, $param)
	{
		$this->NewShelfDialog->setVisible(true);
		$this->ErrorLabel->setVisible(false);
		$this->setFocus($this->ShelfName->getClientID());
	}

	/**
	 * Saves the new/edited shelf onto the database, and
	 * clears the input dialogs, re-populates the visualization
	 * component, etc.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSave($sender, $param)
	{
		if (($shelfName = trim($this->ShelfName->getSafeText())) != '')
		{
			$myUser = $this->getUser();
			$actualLibraryId = $myUser->getActualLibraryId();
			
			try 
			{
				$shelf = ShelfPeer::createShelf($shelfName,
												$this->ShelfDescription->getSafeText(),
												$myUser,
												$actualLibraryId,
												ShelfPeer::VISIBILITY_LIBRARYOPS);
	
				$this->ShelfList->populate();
				$this->NewShelfDialog->setVisible(false);
				$this->ClearInputDialog();
				$this->ShelfList->ShelfSearch->setText($shelfName);
				$this->ShelfList->populate();
			} 
			catch (Exception $e) 
			{
				switch ($e->getCode()) 
				{
					case ShelfPeer::SHELF_NAMEEXISTS:
						$this->ErrorLabel->setText(Prado::localize("Scaffale '{name}' non creato perché esiste già uno scaffale con questo nome nella biblioteca attuale",
																	array('name' => $shelfName)));
						$this->ErrorLabel->setVisible(true);
						$this->ShelfName->setText('');
						break;
				
					case ShelfPeer::ERROR:
						$this->ErrorLabel->setText(Prado::localize("Scaffale non creato: {error}",
																	array('error'=>$e->getMessage())));
						$this->ErrorLabel->setVisible(true);
						break;
				}
			}
		} 
		else 
		{
			$this->ErrorLabel->setText(Prado::localize("Il nome dello scaffale non può essere nullo"));
			$this->ErrorLabel->setVisible(true);
		}
	}

	/**
	 * Sets the dialog panel (for quick inserting a new
	 * shelf) invisible.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$this->NewShelfDialog->setVisible(false);
		$this->ErrorLabel->setVisible(false);
	}

	/**
	 * Resets the textbox fields used for inserting
	 * a new shelf.
	 *
	 */
	private function ClearInputDialog()
	{
		$this->ShelfName->setText('');
		$this->ShelfDescription->setText('');
	}

	/**
	 * This function is called externally, and performs
	 * a re-population of the inner components (in this case:
	 * "ShelfList").
	 *
	 */
	public function globalRefresh()
	{
		$this->ShelfList->populate();
	}

	/**
	 * Whether a component inside this page can have unlink methods
	 * into its rows.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return false;
	}

	/**
	 * Whether a component inside this page can have methods which
	 * are active in the case it's inside a popup.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return true;
	}

	/**
	 * Whether a component inside this page can have delete methods.
	 *
	 * @return boolean
	 */
	public function isDelete()
	{
		return false;
	}
}