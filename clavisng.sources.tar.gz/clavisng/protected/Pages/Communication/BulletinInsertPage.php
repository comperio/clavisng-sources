<?php

/**
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Communication
 * @since 2.2
 */

class BulletinInsertPage extends ClavisPage
{
	const WEEK = 604800;   // 3600*24*7
	public $_module = 'COMMUNICATION';

	private $_bulletin = null;
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$bulletin = null;
			$id = intval($this->getRequest()->itemAt('id'));

			if ($id > 0)
			{
				$bulletin = BulletinPeer::retrieveByPK($id);
				if (is_null($bulletin) || !($bulletin instanceof Bulletin ))
				{
					///$this->gotoPage("ErrorPage");
					$this->writeMessage(Prado::localize("Il messaggio interno con id = {id} non esiste",
																array('id' => $id)),
										ClavisMessage::ERROR);
					$this->gotoPage('Communication.BulletinListPage');
				}
			}

			$this->UpdateData->setObject($bulletin);
			$this->setIsNew(false);

			if (is_null($bulletin))
			{
				$bulletin = new Bulletin();
				$this->setIsNew(true);
			}

			$this->setBulletin($bulletin);
			$this->populate();
		}
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$allow = true;
		$bulletin = $this->getBulletin();

		if (!is_null($bulletin) && ($bulletin instanceof Bulletin))
			$allow = $this->getUser()->getEditPermission($bulletin);
		parent::checkAuth($allow);
	}

	public function setBulletin($bulletin)
	{
		$this->_bulletin = $bulletin;
		$this->setControlState('Bulletin', $bulletin, null);
	}

	public function getBulletin()
	{
		$this->_bulletin = $this->getControlState('Bulletin', null);
		return $this->_bulletin;
	}

	public function setIsNew($value)
	{
		$this->setViewState("IsNew", $value, false);
	}

	public function getIsNew()
	{
		return $this->getViewState("IsNew", false);
	}

	public function populate()
	{
		$this->Librarian->setText($this->getUser()->getCompleteName());
		$this->Library->setText($this->getUser()->getActualLibrary()->getLabel());

		$bulletin = $this->getBulletin();
		if(is_null($bulletin) || $bulletin->isNew())
		{
			$this->PublishStartDate->setTimestamp(time());
			$this->PublishEndDate->setTimestamp(time() + self::WEEK);
			$this->Scope->setSelectedValue(BulletinPeer::SCOPE_ALL);
			return;
		}

		$this->Library->setText($bulletin->getLibrary()->getLabel());
		$librarianId = $bulletin->getLibrarianId();
		$librarian = LibrarianPeer::retrieveByPK($librarianId);
		if($librarian)
			$this->Librarian->setText($librarian->getCompleteName());
		$this->Title->setText($bulletin->getTitle());
		$this->Scope->setSelectedValue($bulletin->getScope());
		$this->Body->setText($bulletin->getBody());

		$this->PublishStartDate->setTimestamp($bulletin->getPublishStartDate('U'));
		$this->PublishEndDate->setTimestamp($bulletin->getPublishEndDate('U'));
		$this->Sticky->setChecked($bulletin->getSticky());
		$this->ProtectedMessage->setChecked($bulletin->getProtectedMessage());
	}

	//handlers
	public function onSave($sender, $param)
	{
		if (!$this->getIsValid())  // if validation control fails
			return false;

		$bulletin = $this->getBulletin();

		$body = trim($this->Body->getSafeText());
		if ($body == '')
		{
			$this->writeMessage(Prado::localize('Corpo del messaggio vuoto ...'), ClavisMessage::ERROR);
			return false;
		}
		$bulletin->setBody($body);

		$bulletin->setTitle($this->Title->getSafeText());
		$bulletin->setScope($this->Scope->getSelectedValue());

		$bulletin->setPublishStartDate($this->PublishStartDate->getTimestamp());
		$bulletin->setPublishEndDate($this->PublishEndDate->getTimestamp());

		$bulletin->setSticky($this->Sticky->getChecked());
		$bulletin->setProtectedMessage($this->ProtectedMessage->getChecked());

		if ($this->getIsNew())
		{
			$bulletin->setLibrarianId($this->getUser()->getID());
			$bulletin->setLibraryId($this->getUser()->getActualLibraryId());
		}

		try
		{
			$bulletin->save();

			if ($this->getIsNew())
			{
				ChangelogPeer::logAction($bulletin, ChangelogPeer::LOG_CREATE , $this->getUser(), "inserito messaggio interno");
				$this->writeMessage(Prado::localize("Messaggio interno inserito correttamente"), ClavisMessage::CONFIRM);
			}
			else
			{
				ChangelogPeer::logAction($bulletin, ChangelogPeer::LOG_UPDATE  , $this->getUser(), "modificato messaggio interno");
				$this->writeMessage(Prado::localize("Messaggio interno modificato correttamente"), ClavisMessage::CONFIRM);
	 		}

			$this->gotoPage("Communication.BulletinViewPage", array("id" => $bulletin->getBulletinId()));
		}
		catch (PropelException $exception)
		{
			$errorMessage = $exception->getCause()->getMessage();
			$dbClass = Propel::getDB();
			if ($dbClass instanceof DBMySQL)
			{
				$this->getPage()->writeMessage(Prado::localize("Il messaggio interno con id=") .
						$bulletin->getBulletinId() . " " .
						($this->getIsNew() ? Prado::localize("non è stato creato correttamente") : Prado::localize("non è stato modificato correttamente")),
					ClavisMessage::ERROR);
				throw ($exception);
			}
			else
				throw ($exception);
		}
	}

	public function onCancel($sender, $param)
	{
		$bulletin = $this->getBulletin();
		if (!is_null($bulletin) && ($bulletin instanceof Bulletin) && !$bulletin->isNew())
			$this->gotoPage("Communication.BulletinViewPage", array("id" => $bulletin->getBulletinId()));
		else
			$this->gotoPage("Communication.BulletinListPage");
	}

	public function checkPublishEndDate($sender, $param)
	{
		$valid = true;

		if ($this->PublishEndDate->getText() != '' && $this->PublishEndDate->getTimestamp() < time())
		{
			$this->PublishEndDate->setTimestamp(time() + self::WEEK);
			$this->PublishEndDateValidator->setText(Prado::localize("data non valida"));
			$this->getPage()->writeMessage(Prado::localize("Il messaggio da inserire è già obsoleto: la data di fine pubblicazione è troppo vecchia"),
														ClavisMessage::ERROR);
			$valid = false;
		}
		else if ($this->PublishEndDate->getText() == '')
		{
			$this->PublishEndDate->setTimestamp(time() + self::WEEK);
			$this->PublishEndDateValidator->setText(Prado::localize("data assente"));
			$valid = false;
		}

		$param->isValid = $valid;
	}

	public function checkPublishStartDate($sender, $param)
	{
		$valid = true;

		if ($this->PublishStartDate->getText() == '')
		{
			$this->PublishStartDate->setTimestamp(time());
			$this->PublishStartDateValidator->setText(Prado::localize("data assente"));
			$valid = false;
		}

		$param->isValid = $valid;
	}
}
