<?php

/**
 * BulletinViewPage class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Communication
 * @since 2.1
 */

class BulletinViewPage extends ClavisPage {

	public $_module = 'COMMUNICATION';

	protected $_bulletin;
	
	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$bulletin = null;
		    $id = TPropertyValue::ensureInteger($this->getRequest()->itemAt('id'));
			if ($id > 0)
			{
				$bulletin = BulletinPeer::retrieveByPK($id);
				if (is_null($bulletin) || !($bulletin instanceof Bulletin ))
				{
					$this->writeMessage(Prado::localize("Il messaggio interno con id = {id} non esiste",
														array('id' => $id)),
										ClavisMessage::ERROR);
					$this->gotoPage('Communication.BulletinListPage');
				}

				//$this->ItemOrderList->populate();

				$this->ModifyButton->setEnabled($this->getUser()->getEditPermission($bulletin));

			}

			$this->UpdateData->setObject($bulletin);

			if (is_null($bulletin))
			{
				$bulletin = new Bulletin();
				$this->ModifyButton->setEnabled(false);
			}

			$this->setBulletin($bulletin);
			$this->populate();
		}


	}

	/**
	 * setter
	 *
	 * @param Bulletin $bulletin
	 */
	public function setBulletin($bulletin)
	{
		$this->_bulletin = $bulletin;
		$this->setControlState('Bulletin', $bulletin, null);
	}


	/**
	 * getter
	 *
	 * @return Bulletin
	 *
	 */
	public function getBulletin()
	{
		$this->_bulletin = $this->getControlState('Bulletin', null);
		return $this->_bulletin;
	}

	public function onModify($sender, $param)
	{
		$bulletinId = null;
		$bulletin = $this->getBulletin();
		if (!is_null($bulletin) && ($bulletin instanceof Bulletin))
			$bulletinId = $bulletin->getBulletinId();
		$this->gotoPage("Communication.BulletinInsertPage", array("id" => $bulletinId));
	}


	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		//$this->ProfilesGrid->populate();
		$this->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		//if ($component !== $this->LibrarianGrid)
		//	$this->LibrarianGrid->onCancel(null, null);

	}

	public function populate()
	{
		$bulletin = $this->getBulletin();
		if (is_null($bulletin) || ($bulletin->isNew()))
			return;

		$this->Library->setText($bulletin->getLibrary()->getLabel());

		$librarianId = $bulletin->getLibrarianId();
		$librarian = LibrarianPeer::retrieveByPK($librarianId);
		if(!is_null($librarian))
			$this->Librarian->setText($librarian->getCompleteName());

		$this->Title->setText($bulletin->getTitle());
		$this->Scope->setText(LookupValuePeer::getLookupValue('BULLETINSCOPE', $bulletin->getScope()));
		$this->Body->setText($bulletin->getBody());

		$sticky = $bulletin->getSticky();
		$this->StickyYes->setVisible($sticky);
		$this->StickyNo->setVisible(!$sticky);

		$protectedMessage = $bulletin->getProtectedMessage();
		$this->ProtectedMessageYes->setVisible($protectedMessage);
		$this->ProtectedMessageNo->setVisible(!$protectedMessage);

		$this->PublishStartDate->setValue($bulletin->getPublishStartDate('U'));
		$this->PublishEndDate->setValue($bulletin->getPublishEndDate('U'));
	}
}
