<?php

/**
 * ShelfListPage Page
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio SRL
 * @license http://www.comperio.it/license/
 * @version 2.7
 * @package Pages.Communication
 * @since 2.2
 */

class ShelfListPage extends ClavisPage 
{
	public $_module = "COMMUNICATION";

	public function onLoad($param)
	{
		if (!$this->getIsPostBack() && !$this->getIsCallback())
			$this->setFocus($this->ShelfList->ShelfSearch->getClientID());

		parent::onLoad($param);
	}

	/**
	 * It deletes permanently a shelf.
	 * In cascade, all the shelfitems linked to this shelf, get
	 * deleted too.
	 *
	 * @param int $shelfId
	 */
	public function deleteShelf($shelfId)
	{
		$this->cleanMessageQueue();
		$shelfId = intval($shelfId);
		if ($shelfId > 0)
		{
			$shelf = ShelfPeer::retrieveByPK($shelfId);
			if ($shelf instanceof Shelf)
			{
				$name = $shelf->getShelfCompleteName();
				$criteria = new Criteria();
				$criteria->add(ShelfPeer::SHELF_ID, $shelfId);
				$deleted = ShelfPeer::doDelete($criteria);
				$this->enqueueMessage(Prado::localize("Eliminato scaffale '{name}'.", array('name' => $name)), ClavisMessage::CONFIRM);

				if ($deleted > 1)
					$this->enqueueMessage($deleted > 2
						? Prado::localize("Eliminati {num} elementi dello scaffale.",array('num' => $deleted))
						: "Eliminato 1 elemento dello scaffale.",ClavisMessage::CONFIRM);

				if ($deleted > 0)
					$this->globalRefresh();
			}
			else
				$this->enqueueMessage(Prado::localize("Errore: lo scaffale con id: {id} non esiste",
															array('id' => $shelfId)), ClavisMessage::ERROR);
		}

		$this->flushMessage();
	}

	/**
	 * It performs a refresh (populate) of all the components in this page.
	 *
	 */
	public function globalRefresh()
	{
		$this->ShelfList->globalRefresh();
	}

	/**
	 * It returns whether this page can generate the link menus, which are listed
	 * in standard popup's elements, in a component inside this page.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return false;
	}

	/**
	 * It returns whether this page can generate the unlink menu
	 * in a component inside this page.
	 *
	 * @return boolean
	 */
	public function isDelete()
	{
		return true;
	}

}
