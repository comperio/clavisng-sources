<?php
/**
 * Login class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Core
 */

/**
 * Login Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Core
 * @since 2.5.0
 */
class Login extends ClavisPage {

	public function onInit($param) {
		parent::onInit($param);

		// if user is already logged in, redirect.
		if (! $this->getUser()->getIsGuest()) {
			$url = $this->getService()->getDefaultPageUrl();
			$this->getResponse()->redirect($url);
		}

		$scriptMgr = $this->getPage()->getClientScript();
		$scriptMgr->registerBeginScript('script', 'if (window.parent != window) parent.document.getElementById("'.
			$this->getPage()->getForm()->getClientId() . '").submit();');

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()) {
			$globalization = $this->getApplication()->getGlobalization();
			$client_lang = $globalization->getDetectedLanguage();
			$sourcedir = $globalization->getTranslationConfiguration()->itemAt('source');
			$selectedLocale = null;
			// get available locales
			foreach (glob("{$sourcedir}/*_*") as $langdir)
				if (is_dir($langdir)) {
					$locale = basename($langdir);
					if ($client_lang == $locale || (strlen($client_lang) == 2 && substr($locale,0,2) == $client_lang))
						$selectedLocale = $locale;
					$languages[$locale] = extension_loaded('intl') ?
							Locale::getDisplayLanguage($locale,$locale) :
							$locale;
				}
			$this->Language->setDataSource($languages);
			$this->Language->dataBind();
			if ($selectedLocale)
				$this->Language->setSelectedValue($selectedLocale);
			$this->setFocus($this->Username->getClientID());
		}
	}

	public function onLoad($param) {
		parent::onLoad($param);

		if ($this->getApplication()->getSession()->itemAt('Culture') && !$this->getIsPostBack())
			$this->Language->setSelectedValue($this->getApplication()->getSession()->itemAt('Culture'));
	}

	/**
	 * Handle the login phase of a librarian into Clavis
	 *
	 * @param TComponent $sender
	 * @param TParam $param
	 */
	public function loginClick($sender, $param) {
		if ($this->getIsValid()) {
			$this->getApplication()->getSession()->add('Culture', $this->Language->getSelectedValue());
			$authmod = $this->getApplication()->getModule('auth');
			// obtain the URL of the privileged page that the user wanted to visit originally
			$url = $authmod->getReturnUrl();
			if (empty($url) || strpos($url,'page='.$authmod->getLoginPage()) !== false)  // the user accesses the login page directly
				$url = $this->getService()->getDefaultPageUrl();
			$this->getResponse()->redirect($url);
		}
	}

	public function validateUsername($sender, $param) {
		$username = trim($this->Username->getSafeText());
		if ($username == '') {
			$param->setIsValid(false);
			$this->setFocus($this->Username->getClientID());
		}
		else
			$param->setIsValid(true);
	}

	public function validateUser($sender, $param) {
		$username = trim($this->Username->getSafeText());
		if ($username == '')
			return true;

		$password = $this->Password->getSafeText();

		$authManager = $this->Application->getModule('auth');
		if ($authManager->login(strtolower($username), $password))
			$param->setIsValid(true);
		else {
			$param->setIsValid(false);
			$this->Password->setText('');
			$this->setFocus($this->Password->getClientID());
		}
	}

	public function validateLibraries($sender, $param) {
		if (!$this->getIsValid())
			return true;

		if ($this->getUser()) {
			$libraries = $this->getUser()->getLibraries();
			if (!is_null($libraries) && (count($libraries) > 0))
				$param->setIsValid(true);
			else
				$param->setIsValid(false);
		}
	}

	public function onCleanFields($sender, $param) {
		$this->reloadPage();
		return false;

		$this->Username->setText('');
		$this->Password->setText('');

		$this->setFocus($this->Username->getClientID());
	}

}
