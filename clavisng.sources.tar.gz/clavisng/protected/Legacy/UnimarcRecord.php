<?php
/**
 * @version 2.7
 */
require_once('UnimarcUtility.php');
require_once('UnimarcField.php');

class UnimarcRecord {
	const UNIMARC_RECORDEND	= "\x1d";

	public $recstatus;
	public $type;
	public $biblevel;
	public $hiercode;
	public $enclevel;
	public $descrForm;
	public $errorMessage;
	public $fieldList;

	private $_xml = null;

	public static $reverseLinkType = array(
		'410'=>'419',
	 	'412'=>'413',
		'413'=>'412',
		'421'=>'422',
		'422'=>'421',
		'423'=>'423',
		'424'=>'425',
		'425'=>'424',
		'430'=>'440',
		'431'=>'441',
		'432'=>'442',
		'433'=>'443',
		'434'=>'444',
		'435'=>'445',
		'436'=>'446',
		'437'=>'447',
		'440'=>'430',
		'441'=>'431',
		'442'=>'432',
		'443'=>'433',
		'444'=>'434',
		'445'=>'435',
		'446'=>'436',
		'447'=>'437',
		'448'=>'448',
		'451'=>'451',
		'452'=>'452',
		'453'=>'454',
		'454'=>'453',
		'455'=>'456',
		'456'=>'455',
		'461'=>'463',
		'463'=>'461',
		// 462 and 464 should be removed.
		'462'=>'462',
		'464'=>'463',
		'470'=>'470',
		'481'=>'482',
		'482'=>'481',
		'488'=>'488'
			);

	public function init() {
		$this->fieldList = array();
		$this->recstatus = ' ';
		$this->type = ' ';
		$this->biblevel = ' ';
		$this->hiercode = ' ';
		$this->enclevel = ' ';
		$this->descrForm = ' ';
		$this->invalidateXML();
	}

	public function __construct($record = null) {
		$this->init();
		if($record !== null)
			$this->parseRecord($record);
	}

	function readLeader($leader) {
		$this->recstatus	= substr($leader,0,1);
		$this->type			= substr($leader,1,1);
		$this->biblevel		= substr($leader,2,1);
		$this->hiercode		= substr($leader,3,1);
		$this->enclevel		= substr($leader,12,1);
		$this->descrForm	= substr($leader,13,1);
	}

	public function parseRecord($record, $utfconv=false, $uniTranslate=false) {
		//if ($utfconv)
		//	$record = iconv('iso8859-1','utf-8',$record);

		$reclen = intval(substr($record,0,5));
		$dirLen = intval(substr($record,12,5))-25;
		$dirItem = $dirLen/12;
		$dirValue = substr($record,24,$dirLen);
		$this->readLeader(substr($record,5,20));

		$fullcode = substr($record,25+$dirLen);
		$listOfFields = explode("\x1e",$fullcode);

		for ($i=0; $i<$dirItem; $i++) {
			//$fnum = intval(substr($dirValue,$i * 12, 3));
			$fnum = substr($dirValue,$i * 12, 3);

			$len = intval(substr($dirValue,$i * 12 + 3, 4));
			$pos = intval(substr($dirValue,$i * 12 + 7, 5));

			$field =  substr($record,25 + $dirLen + $pos, $len - 1);

            if ($utfconv) {
				$uniField = new UnimarcField($fnum, iconv('iso8859-1', 'utf-8', UnimarcUtility::convertNonSortText($field)));
			} else {
				/* $uniField = new UnimarcField($fnum,utf8_encode(UnimarcUtility::translate($field))); */
				if ($uniTranslate)
					$uniField = new UnimarcField($fnum, utf8_encode(UnimarcUtility::translate($field)));
				else
					$uniField = new UnimarcField($fnum, UnimarcUtility::convertNonSortText($field));
			}

			$this->addField($uniField);
		}
		$this->invalidateXML();
		return true;
	}

    public function parseRecord2($record, $utfconv=false, $uniTranslate=false) {
        //if ($utfconv)
        //	$record = iconv('iso8859-1','utf-8',$record);
        $fields = explode("\x1E", $record);

        //print_r($fields);

        $leader = substr($fields[0], 0, 24);
        $dir = substr($fields[0], 24);

        $this->readLeader(substr($record, 5, 20));

        for ($i = 0; $i < strlen($dir); $i+=12) {
            $fnum = substr($dir, $i, 3);
            $p = ($i / 12) + 1;

            //  print "[$fnum][$p][$i] \n";

            if ($utfconv) {
                $uniField = new UnimarcField($fnum, iconv('iso8859-1', 'utf-8', UnimarcUtility::convertNonSortText($fields[$p])));
            } else {
                /* $uniField = new UnimarcField($fnum,utf8_encode(UnimarcUtility::translate($field))); */
                if ($uniTranslate)
                    $uniField = new UnimarcField($fnum, utf8_encode(UnimarcUtility::translate($fields[$p])));
                else
                    $uniField = new UnimarcField($fnum, UnimarcUtility::convertNonSortText($fields[$p]));
            }

            $this->addField($uniField);
        }
        $this->invalidateXML();
        return true;
    }

    function sortFields() {
        ksort($this->fieldList);
        $this->invalidateXML();
    }

	public function addField($f) {
		$this->fieldList[$f->num][] = $f;
		$this->invalidateXML();
	}
	public function deleteField($num,$item = 0) {
		if (isset($this->fieldList[$num])) {
			array_splice($this->fieldList[$num],$item,1);
			if (count($this->fieldList[$num]) == 0)
				unset($this->fieldList[$num]);
		}
		$this->invalidateXML();
	}

	public function getFieldCount($num) {
		return isset($this->fieldList[$num])?
			count($this->fieldList[$num]):0;
	}
	public function existsField($num,$item = 0) {
		return isset($this->fieldList[$num][$item]);
	}


	public function getField($num,$item = 0) {
		return @$this->fieldList[$num][$item];
	}
	public function setField($num, $item, $field) {
		$this->fieldList[$num][$item] = $field;
		$this->invalidateXML();
	}

	public function getSubFieldCount($num,$tag,$item = 0) {
		return $this->fieldList[$num][$item]->getSubFieldCount($tag);
	}

	public function getSubField($num,$tag,$item=0,$sitem=0) {
		return (isset($this->fieldList[$num][$item]))?
			$this->fieldList[$num][$item]->getSubField($tag,$sitem):'';
	}

	function getFieldNumList() {
		$list = array();
		foreach ($this->fieldList as $k=>$v) {
			foreach($v as $e) {
				$list[] = $k;
			}
		}
		return $list;
	}

	function getISO2709() {
		$fields = array();
		$directory = "";
		$body = "";
		$dirpos = 0;
		foreach ($this->fieldList as $k=>$v) {
			foreach($v as $vv) {
				$f = $vv->getISO2709();
				$directory .= sprintf("%03d%04d%05d",intval($f['num']),intval($f['len']),$dirpos);
				$dirpos += $f['len'];
				$body .= $f['txt'];
				$fields[] = $f;
            	}
        }
		$baseStart = strlen($directory) + 25;
		$recLen = strlen($body) + $baseStart + 1;

		if($recLen > 99999) $recLen = 99999; // Fix for HUGE records

		$leader = sprintf("%05d%1s%1s%1s%1s 22%05d%1s%1s 450 ",
			$recLen, $this->recstatus, $this->type, $this->biblevel,$this->hiercode,
			$baseStart,$this->enclevel,$this->descrForm);
		$txt = $leader.$directory.UnimarcField::UNIMARC_FIELDEND.$body.UnimarcRecord::UNIMARC_RECORDEND;
		return $txt;
	}

	function getXML() {
		// if cached xml is null, rebuild it.
		if (!$this->_xml) {
			$xml = '<?xml version="1.0" encoding="UTF-8"?><record xmlns="http://www.loc.gov/MARC21/slim">';
			// [00621ncm0 2200193   450 ]
			$xml .= sprintf("<leader>01234%1s%1s%1s%1s 2201234%1s%1s 450 </leader>",
				$this->recstatus,
				$this->type,
				$this->biblevel,
				$this->hiercode,
				$this->enclevel,
				$this->descrForm);
			foreach ($this->fieldList as $k=>$v) {
				foreach ($v as $vv) {
					$xml .= $vv->getXML();
				}
			}
			$xml .= '</record>';
			$this->_xml = $xml;
		}
		return $this->_xml;
	}
	function invalidateXML() {
		$this->_xml = null;
	}

	function getTurboMarc($returnXML = true) {
		$xml = Clavis::sanitizeForXML($this->getXML());
		$marcxml = simplexml_load_string($xml);
		$tc = TurboMarc::createCollection();
		$tm = $tc->addRecord();
		$tm->setLeader(strtolower($marcxml->leader));
		foreach($marcxml->controlfield as $cf)
			$tmcf = $tm->setControlField(str_pad(trim($cf->attributes()->tag),3,'0',STR_PAD_LEFT),(string)$cf);
		foreach($marcxml->datafield as $df) {
			$tmdf = $tm->addField(str_pad(trim($df->attributes()->tag),3,'0',STR_PAD_LEFT),(string)$df->attributes()->ind1,$df->attributes()->ind2);
			foreach($df->subfield as $sf)
				$tmsf = $tmdf->addSubField((string)$sf->attributes()->code, (string)$sf);
		}
		return ($returnXML) ? $tm->asXML() : $tm;
	}

	function getTXT() {
		$p = "{$this->recstatus} {$this->type} {$this->biblevel} ".
			"{$this->enclevel} {$this->descrForm}  {$this->hiercode} \n";
		foreach ($this->fieldList as $k=>$v) {
			foreach ($v as $vv) {
				$p .= $vv->getTXT();
			}
		}
		$p .= "\n";
		return $p;
	}
	function getTXTCompact() {
		$txt = sprintf("%1s%1s%1s%1s%1s%1s",$this->recstatus, $this->descrForm, $this->type,
		$this->hiercode, $this->biblevel, $this->enclevel);
		foreach($this->fieldList as $k=>$v) {
			foreach($v as $vv) {
				$txt .= $vv->getTXTCompact();
			}
		}
		return $txt;
	}
	function parseTXTCompact($txt) {
		$lines = explode("\n",$txt);
		$this->recstatus = $lines[0]{0};
		$this->descrForm = $lines[0]{1};
		$this->type      = $lines[0]{2};
		$this->hiercode  = $lines[0]{3};
		$this->biblevel  = $lines[0]{4};
		$this->enclevel  = $lines[0]{5};
		$cnt = count($lines);
		for ($i=1; $i<$cnt; $i++) {
			$line = $lines[$i];
			$num = substr($line,0,3);
			$indic = substr($line,3,2);
			while (array_key_exists($i+1,$lines) &&
					!is_numeric(substr($lines[$i+1],0,3))) {
				// if following line is not numeric, consider it as same field
				// (append it to current one and increment $i)
				// but NOT for controlfields
				if ($num >= '010')
					$line .= $lines[$i+1];
				++$i;
			}
			$f = new UnimarcField($num);
			$f->indicator = $indic;
			$subfields = explode('$',substr($line,5));
			foreach ($subfields as $sf) {
				if (strlen(trim($sf)) > 0) {
					$f->addSubField($sf{0},substr($sf,1));
				}
			}
			$this->addField($f);
		}
		$this->sortFields();
	}

	function getISBD() {
		return $this->getTitle();
	}

	function getTitle() {
		$title['nst'] = '  ';
		$title['txt'] = array();
		$field = @$this->fieldList[200][0];
		if (!$field) {
			$title['txt'][0] = "";
			return $title;
			//die($this->fieldList);
		}
		$title['ind'] = $field->indicator;
		if ($title['ind'] === '  ')
			$title['ind'] = '1 ';
		$findH = false;
		if (!is_array($field->subFieldList))
			return $title;

//		Prado::fatalError(Prado::varDump($field->subFieldList));
		foreach ($field->subFieldList as $k=>$v) {
			$tag = $field->tagList[$k];
			$v = trim($v);
			switch ($tag) {
				case 'a':
					if (count($title['txt']) == 0) {
						$title['txt'][0] = "";
						$match = array();
						if(strpos($v,"*") === false) {
							@$title['txt'][0] = $v;
						} else {
							$title['nst'] = substr($v,0,strpos($v,"*"));
							if(trim($title['nst']) == "*") $title['nst']="";

							$title['txt'][0] = substr($v,strpos($v,"*")+1);
						}

					} else {
						@$title['txt'][0] .= " ; $v";
					}
					break;
				case 'b':
					@$title['txt'][0] .= " [$v]";
					break;
				case 'c':
					@$title['txt'][0] .= ". $v";
					break;
				case 'd':
					@$title['txt'][0] .= " = $v";
					break;
				case 'e':
					@$title['txt'][0] .= " : $v";
					break;
				case 'f':
					@$title['txt'][0] .= " / $v";
					break;
				case 'g':
					@$title['txt'][0] .= " ; $v";
					break;
				case 'h':
					$findH = true;
					@$title['txt'][0] .= " . $v";
					break;
				case 'i':
					@$title['txt'][0] .= ($findH)?", $v":". $v";
					break;
			}
		}
		if (count($title['txt']) < 1)
			$title['txt'][0] = '';
		return $title;
	}
	function setTitle($text, $others = array(), $indicator = '1 ') {
		$unifield = new UnimarcField('200');
		$unifield = $this->parse200($unifield,'a',$text);
		foreach ($others as $text)
			$unifield = $this->parse200($unifield,'c',$text);
		$unifield->indicator = str_pad((string)$indicator, 2,STR_PAD_RIGHT);
		$this->addField($unifield);
	}

	private function parse200($unifield, $firstTag, $text)
	{
		$splitTag = preg_split("/ ([\/:;=])/",$text,-1, PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
		if(count($splitTag) == 0) $splitTag[0] = $text;

		$unifield->addSubField($firstTag,$splitTag[0]);
		$beforeSlash = true;
		for ($i=1; $i<count($splitTag); $i+=2) {
			switch($splitTag[$i]) {
				case "/":
                    if(isset($splitTag[$i+1])) {
                        $unifield->addSubField('f',$splitTag[$i+1]);
                        $beforeSlash = false;
                    }
					break;
				case ":":
                    if(isset($splitTag[$i+1]))
                        $unifield->addSubField('e',$splitTag[$i+1]);
					break;
				case "=":
                    if(isset($splitTag[$i+1]))
					    $unifield->addSubField('d',$splitTag[$i+1]);
					break;
				/*case ".":
					$unifield->addSubField('h',$splitTag[$i+1]);
					break;
				case ",":
					$unifield->addSubField('g',$splitTag[$i+1]);
					break;
					*/
				case ";":
					if ($beforeSlash && isset($splitTag[$i+1]))
						$unifield->addSubField('a',$splitTag[$i+1]);
					elseif(isset($splitTag[$i+1]))
						$unifield->addSubField('g',$splitTag[$i+1]);
					break;
			}
		}
		return $unifield;
	}

	function getEdition($i=0)
	{
		$edit = '';

		if (isset($this->fieldList['205'][$i])) {
			$field = $this->fieldList['205'][$i];
			$check = 0;
			$tmp = 0;
			foreach ($field->subFieldList as $k=>$v) {
				$tag = $field->tagList[$k];
				switch ($tag) {
					case 'a':
						$edit .= $v;
						break;
					case 'd':
						$edit .= " = ".$v;
						break;
					case 'f':
						$edit .= " / ".$v;
						break;
					case 'g':
						$edit .= " ; ".$v;
						break;
					case 'b':
						$edit .= ", ".$v;
						break;
				}
			}
		}
		return $edit;
	}

	public function getEditions() {
		$ret = array();
		$cnt = $this->getFieldCount('205');
		for ($i=0; $i<$cnt; ++$i)
			$ret[] = $this->getEdition($i);
		return $ret;
	}

	function setEdition($text)
	{
		$splitTag = preg_split("/ (=|\/|;) |(,) /",$text ,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if (count($splitTag)==0)
			return;
		$unifield = new UnimarcField('205');
		$unifield->addSubField('a',$splitTag[0]);
		$beforeBrace = true;
		for ($i=1; $i < count($splitTag); $i+=2) {
			switch(trim($splitTag[$i])) {
				case ";":
					$unifield->addSubField('g',$splitTag[$i+1]);
					break;
				case "=":
					$unifield->addSubField('d',$splitTag[$i+1]);
					break;
				case "/":
					$unifield->addSubField('f',$splitTag[$i+1]);
					break;
				case ",":
					$unifield->addSubField('b',$splitTag[$i+1]);
					break;
			}
		}
		$this->addField($unifield);
	}

	function getPublication($i=0,$ind=false) {
		$publ = "";
		if (isset($this->fieldList['210'][$i])) {
			$field = $this->fieldList['210'][$i];
			$check = 0;
			$tmp = 0;
			foreach ($field->subFieldList as $k=>$v) {
				$tag = $field->tagList[$k];
				$v = trim($v);
				switch ($tag) {
					case 'a':
						if ($tmp==1)
							$publ.= " ; ";
						$publ .= $v;
						$tmp = 1;
						break;
					case 'b':
						$publ .= ", ".$v;
						break;
					case 'c':
						$publ .= " : ".$v;
						break;
					case 'd':
						$publ .= ", ".$v;
						break;
					case 'e':
						$publ.= ($check==1)?" ; ".$v:" (".$v;
						$check = 1;
						break;
					case 'f':
						$publ .= ", ".$v;
						break;
					case 'g':
						$publ .= " : ".$v;
						break;
					case 'h':
						$publ .= ", ".$v;
						break;
				}
			}
			if ($check == 1)
				$publ .= ')';
		}
		while (strpos($publ,'))'))
			$publ = str_replace('))',')',$publ);
		return ($ind)?array('txt'=>$publ,'ind'=>$field->indicator):$publ;
	}

	public function getPublications($ind=false) {
		$ret = array();
		$cnt = $this->getFieldCount('210');
		for ($i=0; $i<$cnt; ++$i)
			$ret[] = $this->getPublication($i,$ind);
		return $ret;
	}

	function setPublication($text,$indicator='  ') {
		$splitTag = preg_split("/(, | : | ; | \()/",$text ,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if (count($splitTag)==0)
			return;
		$unifield = new UnimarcField('210');
		$unifield->indicator = substr($indicator,0,2);
		$unifield->addSubField('a',$splitTag[0]);
		$beforeBrace = true;
		for ($i=1; $i < count($splitTag); $i+=2) {
			switch(trim($splitTag[$i])) {
				case ";":
					if ($beforeBrace)
						$unifield->addSubField('a',$splitTag[$i+1]);
					else
						$unifield->addSubField('e',$splitTag[$i+1]);
					break;
				case ":":
					if ($beforeBrace)
						$unifield->addSubField('c',$splitTag[$i+1]);
					else
						$unifield->addSubField('g',$splitTag[$i+1]);
					break;
				case "(":
					$beforeBrace = false;
					//$splitTag[$i+1] = str_replace(")","",$splitTag[$i+1]);
					$unifield->addSubField('e',$splitTag[$i+1]);
					break;
				case ",":
					if ($beforeBrace)
						$unifield->addSubField('d',$splitTag[$i+1]);
					else
						$unifield->addSubField('h',$splitTag[$i+1]);
					break;
			}
		}
		$this->addField($unifield);
	}

	function getPhysicalDesc($i=0) {
		 $physdesc = "";
		if (isset($this->fieldList['215'][$i])) {
			$field = $this->fieldList['215'][$i];
			$physdesc = "";
			foreach ($field->subFieldList as $k=>$v) {
				$tag = $field->tagList[$k];
				$v = trim($v);
				switch ($tag) {
					case 'a':
						$physdesc .= $v;
						break;
					case 'c':
						if ($v != "")
							$physdesc .= " : ".$v;
						break;
					case 'd':
						$physdesc .= " ; ".$v;
						break;
					case 'e':
						if ($v != "")
							$physdesc .= " + ".$v;
						break;
				}
			}
		}
		while (strpos($physdesc,'))'))
			$physdesc = str_replace('))',')',$physdesc);
		return $physdesc;
	}

	public function getPhysicalDescs() {
		$ret = array();
		$cnt = $this->getFieldCount('215');
		for ($i=0; $i<$cnt; ++$i)
			$ret[] = $this->getPhysicalDesc($i);
		return $ret;
	}

	function setPhysicalDesc($text) {
		$splitTag = preg_split("/ (:|;|\+) /",$text ,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if (count($splitTag)==0)
			return;
		$unifield = new UnimarcField('215');
		$unifield->addSubField('a',$splitTag[0]);

		for ($i=1; $i < count($splitTag); $i+=2) {
			switch(trim($splitTag[$i])) {
				case ";":
					$unifield->addSubField('d',trim($splitTag[$i+1]));
					break;
				case ":":
					$unifield->addSubField('c',trim($splitTag[$i+1]));
					break;
				case "+":
					$unifield->addSubField('e',trim($splitTag[$i+1]));
					break;
			}
		}

		$this->addField($unifield);
	}

	function getSerie($i=0) {
		$series = '';
		if (isset($this->fieldList['225'][$i])) {
			$field = $this->fieldList['225'][$i];
			$tmp=0;
			foreach($field->subFieldList as $k=>$v) {
				$tag = $field->tagList[$k];
				switch ($tag) {
					case 'a':
						$series .= $v;
						break;
					case 'd':
						$series .= " = ".$v;
						break;
					case 'e':
						$series .= " : ".$v;
						break;
					case 'f':
						$series .= " / ".$v;
						break;
					case 'h':
						$series .= ". ".$v;
						$tmp=1;
						break;
					case 'i':
						if ($tmp==1) {
							$series.=", ";
						} else {
							$series.=". ";
						}
						$series.=$v;
						break;
					case 'v':
						$series.=" ; ".$v;
						break;
					case 'x':
						$series.=", ".$v;
						break;
				}
			}
		}
		return $series;
	}

	public function getSeries() {
		$ret = array();
		$cnt = $this->getFieldCount('225');
		for ($i=0; $i<$cnt; ++$i)
			$ret[] = $this->getSerie($i);
		return $ret;
	}

	function setSerie($text)
	{
		$splitTag = preg_split("/(, | : | ; | \/ | = |\. |, )/",$text ,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if (count($splitTag)==0)
			return;
		$unifield = new UnimarcField('225');
		$unifield->addSubField('a',$splitTag[0]);
		$beforeH = true;
		for ($i=1; $i < count($splitTag); $i+=2) {
			switch(trim($splitTag[$i])) {
				case "=":
					$unifield->addSubField('d',$splitTag[$i+1]);
					break;
				case ":":
					$unifield->addSubField('e',$splitTag[$i+1]);
					break;
				case "/":
					$unifield->addSubField('f',$splitTag[$i+1]);
					break;
				case ";":
					$unifield->addSubField('v',$splitTag[$i+1]);
					break;

				case ".":
					if ($beforeH)
						$unifield->addSubField('h',$splitTag[$i+1]);
					else
						$unifield->addSubField('i',$splitTag[$i+1]);

					$beforeH = false;
					break;
				case ",":
					if ($beforeH)
						$unifield->addSubField('x',$splitTag[$i+1]);
					else
						$unifield->addSubField('i',$splitTag[$i+1]);
					break;
			}
		}
		$this->addField($unifield);
	}

    function getAuthor($num, $item=0) {
        $field = $this->fieldList[$num][$item];
        $author = "";
        if (in_array($num, array('700', '701', '702', '720', '721', '722'))) {
            foreach ($field->subFieldList as $k => $v) {
                $tag = $field->tagList[$k];
                switch ($tag) {
                    case 'a':
                        $author .= $v;
                        break;
                    case 'b':
                    case 'c':
                    case 'd':
                        $author .= ", $v";
                        break;

                    case 'f':
                        $author .= " ($v)";
                        break;
                }
            }
        } else if (in_array($num, array('710', '711', '712'))) {
            foreach ($field->subFieldList as $k => $v) {
                $tag = $field->tagList[$k];
                switch ($tag) {
                    case 'a':
                        $author .= $v;
                        break;
                    case 'b':
                    case 'c':
                        $author .= ", $v";
                        break;
                    case 'g':
                        $author .= " : $v";
                        break;
                    case 'd':
                    case 'e':
                    case 'f':
                        $author .= " ($v)";
                        break;
                }
            }
        }
        $author = str_replace(array(') (', ', , ', ',,'), array('; ', ', ', ','), $author);
        return $author;
    }

    /**
     * Returns a 5XX field string representation
     * 
     * @param string $num
     * @param int $item
     * @return string Other title with separation for ISBD disply. 
     */
    public function getOtherTitle($num, $item=0) {
        
        $title['nst'] = '  ';
        $title['txt'] = array();
        $field = $this->fieldList[$num][$item];
        
        if (!$field) {
            $title['txt'][0] = "";
            return $title;
            //die($this->fieldList);
        }
        
        $title['ind'] = $field->indicator;
        if ($title['ind'] === '  ')
            $title['ind'] = '1 ';
        
        $findH = false;
        
        if (!is_array($field->subFieldList))
            return $title;
        
        if (in_array($num, array('500', '501', '517', '503', '510', '512', '513', '514', '515', '516', '517'))) {
            foreach ($field->subFieldList as $k => $v) {
                $tag = $field->tagList[$k];
                $v = trim($v);
                
                switch ($tag) {
                    case 'a':
                        if (count($title['txt']) == 0) {
                            $title['txt'][0] = "";
                            $match = array();
                            if (strpos($v, "*") === false) {
                                @$title['txt'][0] = $v;
                            } else {
                                $title['nst'] = substr($v, 0, strpos($v, "*"));
                                if (trim($title['nst']) == "*")
                                    $title['nst'] = "";

                                $title['txt'][0] = substr($v, strpos($v, "*") + 1);
                            }
                        } else {
                            @$title['txt'][0] .= " ; $v";
                        }
                        break;
                    case 'b':
                    case 'm':
                        @$title['txt'][0] .= " [$v]";
                        break;
                    case 'c':
                        @$title['txt'][0] .= ". $v";
                        break;
                    case 'd':
                        @$title['txt'][0] .= " = $v";
                        break;
                    case 'o':
                    case 'e':
                        @$title['txt'][0] .= " : $v";
                        break;
                    case 'f':
                        @$title['txt'][0] .= " / $v";
                        break;
                    case 'g':
                    case 'v':
                        @$title['txt'][0] .= " ; $v";
                        break;
                    case 'h':
                        $findH = true;
                        @$title['txt'][0] .= " . $v";
                        break;
                    case 'j':
                    case 'k':
                    case 'n':
                    case 'q':
                    case 'r':
                    case 's':
                    case 'u':
                    case 'w':
                        @$title['txt'][0] .= ", $v";
                    case 'i':
                        @$title['txt'][0] .= ( $findH) ? ", $v" : ". $v";
                        break;
                }
            }
        }

        return $title;
    }
}
