<?php

class UnimarcField {
	const UNIMARC_FIELDEND = "\x1e";
	const UNIMARC_SUBFIELDEND = "\x1f";

	public $subFieldList;
	public $num;
	public $indicator;
	public $tagList;
	public $tagLink;
	public $isCDF;
	public $posCDF;
	public $lenCDF;
	public $mulCDF;

	public function __construct($num,$field = null) {
		$this->num = $num;
		$this->subFieldList = array();
		$this->tagList = array();
		$this->isCDF = false;


		if ($num >= '100' && $num < '200') {
			$this->initCDFPos();
		}
		if ($field != null) {
			$this->parse($field);
		} else {
			$this->indicator = '  ';
		}
	}

	function parse($field) {
		if ($this->isCDF) {
			$this->indicator = substr($field,0,2);
			$subfields = explode(UnimarcField::UNIMARC_SUBFIELDEND,substr($field,3));
			foreach ($subfields as $v) {
				$tag = substr($v,0,1);
				$v = substr($v,1);
				$this->subFieldList[$tag] = $v;
			}
		} else if ($this->num >= '010') {
			$this->indicator = substr($field,0,2);
			$subfields = explode(UnimarcField::UNIMARC_SUBFIELDEND,substr($field,3));
			foreach ($subfields as $v) {
				$tag = substr($v,0,1);
				$v = substr($v,1);
				$this->addSubField($tag,$v);
			}
		} else {
			$this->addSubField(' ', $field);
		}
		return true;
	}

	protected function isCDF_MV($num,$tag) {
		switch ($num) {
			case '100':  // Standard CDF
			case '105':
			case '106':
			case '109':
			case '110':
			case '116':
			case '117':
			case '120':
			case '122':
			case '127':
			case '130':
			case '135':
			case '140':
				if ($tag == 'a')
					return true;
				break;
			case '115':
			case '121':
			case '126':
				if (($tag == 'a')||($tag == 'b'))
					return true;
				break;
			case '123':
				if (in_array($tag,array('a','d','e','f','g','h','i','j','k','m','n','o','p')))
					return true;
			case '124':
				if (in_array($tag,array('a','b','c','d','e','f','g')))
					return true;
			case '125':
			case '141':
				if (in_array($tag,array('a','b','c','5','9')))
					return true;
			case '128':
				if (in_array($tag,array('a','d')))
					return true;
			case '131':
				if (in_array($tag,array('a','b','c','d','e','f','g','h','i','j','k','l')))
					return true;
			case '145':
				if (in_array($tag,array('a','b','c','d','e','f')))
					return true;
                        case '149':
				if (in_array($tag,array('a','b','c','d','9')))
					return true;
		}
		return false;
	}

	/* updated to Unimarc Update 5 */
	function initCDFPos() {
		switch($this->num) {
			case '100':  // Standard CDF
				$this->posCDF['a'] = array(0,8,9,13,17,18,19,20,21,22,25,26,30,34);
				$this->lenCDF['a'] = array(8,1,4, 4, 1, 1, 1, 1, 1, 3, 1, 4, 4, 2);
				$this->subFieldList['a'] = str_repeat(' ', 36);
				$this->isCDF = true;
                break;
			case '105':
		                $this->posCDF['a'] = array(0,1,2,3,4,5,6,7,8,9,10,11,12);
				$this->lenCDF['a'] = array(1,1,1,1,1,1,1,1,1,1, 1, 1, 1);
				$this->subFieldList['a'] = str_repeat(' ', 13);
				$this->isCDF = true;
				break;
			case '106':
                $this->posCDF['a'] = array(0);
				$this->lenCDF['a'] = array(1);
				$this->subFieldList['a'] = str_repeat(' ', 1);
				$this->isCDF = true;
				break;
			case '109':
                $this->posCDF['a'] = array(0,3,6,9,12,15,18,20,22);
				$this->lenCDF['a'] = array(3,3,3,3,3,3,2,2,1);
				$this->subFieldList['a'] = str_repeat(' ', 23);
				$this->isCDF = true;
				break;
			case '110':
				$this->posCDF['a'] = array(0,1,2,3,4,5,6,7,8,9,10);
				$this->lenCDF['a'] = array(1,1,1,1,1,1,1,1,1,1, 1);
				$this->subFieldList['a'] = str_repeat(' ', 11);
				$this->isCDF = true;
				break;
			case '115':
				$this->posCDF['a'] = array(0,1,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19);
				$this->lenCDF['a'] = array(1,3,1,1,1,1,1,1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
				$this->subFieldList['a'] = str_repeat(' ', 20);
				$this->posCDF['b'] = array(0,1,4,5,6,7,8,9);
				$this->lenCDF['b'] = array(1,1,1,1,1,1,1,6);
				$this->subFieldList['b'] = str_repeat(' ', 15);
				$this->isCDF = true;
				break;
			case '116':
				$this->posCDF['a'] = array(0,1,2,3,4,6,8,10,12,14,16);
				$this->lenCDF['a'] = array(1,1,1,1,2,2,2, 2, 2, 2, 2);
				$this->subFieldList['a'] = str_repeat(' ', 18);
				$this->isCDF = true;
				break;
			case '117':
				$this->posCDF['a'] = array(0,2,4,6,8);
				$this->lenCDF['a'] = array(2,2,2,2,1);
				$this->subFieldList['a'] = str_repeat(' ', 9);
				$this->isCDF = true;
				break;
			case '120':
				$this->posCDF['a'] = array(0,1,2,3,4,5,6,7,9,11);
				$this->lenCDF['a'] = array(1,1,1,1,1,1,1,2,2, 2);
				$this->subFieldList['a'] = str_repeat(' ', 13);
				$this->isCDF = true;
				break;
			case '121':
				$this->posCDF['a'] = array(0,1,2,3,5,6,7,8);
				$this->lenCDF['a'] = array(1,1,1,2,1,1,1,1);
				$this->subFieldList['a'] = str_repeat(' ', 9);
				$this->posCDF['b'] = array(0,1,2,4,5,6,7);
				$this->lenCDF['b'] = array(1,1,2,1,1,1,1);
				$this->subFieldList['b'] = str_repeat(' ', 8);
				$this->isCDF = true;
				break;
			case '122':
				$this->posCDF['a'] = array(0,1,5,7,9);
				$this->lenCDF['a'] = array(1,4,2,2,2);
				$this->subFieldList['a'] = str_repeat(' ', 11);
				$this->isCDF = true;
				break;
			case '123':
				$this->posCDF['a'] = array(0);
				$this->lenCDF['a'] = array(1);
				$this->subFieldList['a'] = str_repeat(' ', 1);
				$this->posCDF['d'] = array(0,1,4,6);
				$this->lenCDF['d'] = array(1,3,2,2);
				$this->subFieldList['d'] = str_repeat(' ', 8);
				$this->posCDF['e'] = array(0,1,4,6);
				$this->lenCDF['e'] = array(1,3,2,2);
				$this->subFieldList['e'] = str_repeat(' ', 8);
				$this->posCDF['f'] = array(0,1,4,6);
				$this->lenCDF['f'] = array(1,3,2,2);
				$this->subFieldList['f'] = str_repeat(' ', 8);
				$this->posCDF['g'] = array(0,1,4,6);
				$this->lenCDF['g'] = array(1,3,2,2);
				$this->subFieldList['g'] = str_repeat(' ', 8);
				$this->posCDF['h'] = array(0);
				$this->lenCDF['h'] = array(4);
				$this->subFieldList['h'] = str_repeat(' ', 4);
				$this->posCDF['i'] = array(0,2,4);
				$this->lenCDF['i'] = array(2,2,2);
				$this->subFieldList['i'] = str_repeat(' ', 6);
				$this->posCDF['j'] = array(0,2,4);
				$this->lenCDF['j'] = array(2,2,2);
				$this->subFieldList['j'] = str_repeat(' ', 6);
				$this->posCDF['k'] = array(0,2,4);
				$this->lenCDF['k'] = array(2,2,2);
				$this->subFieldList['k'] = str_repeat(' ', 6);
				$this->posCDF['m'] = array(0,2,4);
				$this->lenCDF['m'] = array(2,2,2);
				$this->subFieldList['m'] = str_repeat(' ', 6);
				$this->posCDF['n'] = array(0);
				$this->lenCDF['n'] = array(4);
				$this->subFieldList['n'] = str_repeat(' ', 4);
				$this->posCDF['o'] = array(0);
				$this->lenCDF['o'] = array(4);
				$this->subFieldList['o'] = str_repeat(' ', 4);
				$this->posCDF['p'] = array(0,2);
				$this->lenCDF['p'] = array(2,1);
				$this->subFieldList['p'] = str_repeat(' ', 3);
				$this->isCDF = true;
				break;
			case '124':
				$this->posCDF['a'] = array(0);
				$this->lenCDF['a'] = array(1);
				$this->subFieldList['a'] = str_repeat(' ', 1);
				$this->posCDF['b'] = array(0);
				$this->lenCDF['b'] = array(1);
				$this->subFieldList['b'] = str_repeat(' ', 1);
				$this->posCDF['c'] = array(0);
				$this->lenCDF['c'] = array(2);
				$this->subFieldList['c'] = str_repeat(' ', 2);
				$this->posCDF['d'] = array(0);
				$this->lenCDF['d'] = array(1);
				$this->subFieldList['d'] = str_repeat(' ', 1);
				$this->isCDF = true;
				$this->posCDF['e'] = array(0);
				$this->lenCDF['e'] = array(1);
				$this->subFieldList['e'] = str_repeat(' ', 1);
				$this->posCDF['f'] = array(0);
				$this->lenCDF['f'] = array(2);
				$this->subFieldList['f'] = str_repeat(' ', 2);
				$this->posCDF['g'] = array(0);
				$this->lenCDF['g'] = array(2);
				$this->subFieldList['g'] = str_repeat(' ', 2);
				break;
			case '125':
				$this->posCDF['a'] = array(0,1);
				$this->lenCDF['a'] = array(1,1);
				$this->subFieldList['a'] = str_repeat(' ', 2);
				$this->posCDF['b'] = array(0,1);
				$this->lenCDF['b'] = array(1,1);
				$this->subFieldList['b'] = str_repeat(' ', 2);
				// $c is defined as variable length, for ease of implementation
				// I assume it has only 3 positions. When needed, you can add as
				// many as wanted.
				$this->posCDF['c'] = array(0,1,2);
				$this->lenCDF['c'] = array(1,1,1);
				$this->subFieldList['c'] = str_repeat(' ', 3);
				$this->isCDF = true;
				break;
			case '126':
				$this->posCDF['a'] = array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14);
				$this->lenCDF['a'] = array(1,1,1,1,1,1,1,1,1,1, 1, 1, 1, 1, 1);
				$this->subFieldList['a'] = str_repeat(' ', 15);
				$this->posCDF['b'] = array(0,1,2);
				$this->lenCDF['b'] = array(1,1,1);
				$this->subFieldList['b'] = str_repeat(' ', 3);
				$this->isCDF = true;
				break;
			case '127':
				$this->posCDF['a'] = array(0,2,4);
				$this->lenCDF['a'] = array(2,2,2);
				$this->subFieldList['a'] = str_repeat(' ', 6);
				$this->isCDF = true;
				break;
			case '128':
				$this->posCDF['a'] = array(0);
				$this->lenCDF['a'] = array(3);
				$this->subFieldList['a'] = str_repeat(' ', 3);
				$this->posCDF['d'] = array(0);
				$this->lenCDF['d'] = array(3);
				$this->subFieldList['d'] = str_repeat(' ', 3);
				$this->isCDF = true;
				break;
			case '130':
				$this->posCDF['a'] = array(0,1,2,3,4,7,8,9,10);
				$this->lenCDF['a'] = array(1,1,1,1,3,1,1,1, 1);
				$this->subFieldList['a'] = str_repeat(' ', 11);
				$this->isCDF = true;
				break;
				break;
			case '131':
				$this->posCDF['a'] = array(0);
				$this->lenCDF['a'] = array(2);
				$this->subFieldList['a'] = str_repeat(' ', 2);
				$this->posCDF['b'] = array(0);
				$this->lenCDF['b'] = array(3);
				$this->subFieldList['b'] = str_repeat(' ', 3);
				$this->posCDF['c'] = array(0);
				$this->lenCDF['c'] = array(2);
				$this->subFieldList['c'] = str_repeat(' ', 2);
				$this->posCDF['d'] = array(0);
				$this->lenCDF['d'] = array(2);
				$this->subFieldList['d'] = str_repeat(' ', 2);
				$this->posCDF['e'] = array(0);
				$this->lenCDF['e'] = array(2);
				$this->subFieldList['e'] = str_repeat(' ', 2);
				$this->posCDF['f'] = array(0);
				$this->lenCDF['f'] = array(2);
				$this->subFieldList['f'] = str_repeat(' ', 2);
				$this->posCDF['g'] = array(0);
				$this->lenCDF['g'] = array(2);
				$this->subFieldList['g'] = str_repeat(' ', 2);
				$this->posCDF['h'] = array(0);
				$this->lenCDF['h'] = array(4);
				$this->subFieldList['h'] = str_repeat(' ', 4);
				$this->posCDF['i'] = array(0);
				$this->lenCDF['i'] = array(4);
				$this->subFieldList['i'] = str_repeat(' ', 4);
				$this->posCDF['j'] = array(0);
				$this->lenCDF['j'] = array(2);
				$this->subFieldList['j'] = str_repeat(' ', 2);
				$this->posCDF['k'] = array(0);
				$this->lenCDF['k'] = array(2);
				$this->subFieldList['k'] = str_repeat(' ', 2);
				$this->posCDF['l'] = array(0);
				$this->lenCDF['l'] = array(2);
				$this->subFieldList['l'] = str_repeat(' ', 2);
				$this->isCDF = true;
				break;
			case '135':
				$this->posCDF['a'] = array(0,1,2,3,4,5,8,9,10,11,12);
				$this->lenCDF['a'] = array(1,1,1,1,1,3,1,1, 1, 1, 1);
				$this->subFieldList['a'] = str_repeat(' ', 13);
				$this->isCDF = true;
				break;
			case '140':
				$this->posCDF['a'] = array(0,1,2,3,4,5,6,7,8,9,11,13,15,17,19,20,21,22,23,24,25);
				$this->lenCDF['a'] = array(1,1,1,1,1,1,1,1,1,2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1);
				$this->subFieldList['a'] = str_repeat(' ', 26);
				$this->isCDF = true;
				break;
			case '141':
				$this->posCDF['a'] = array(0,1,2,3,4,5,6,7);
				$this->lenCDF['a'] = array(1,1,1,1,1,1,1,1);
				$this->subFieldList['a'] = str_repeat(' ', 8);
				$this->posCDF['b'] = array(0,2,4,5,6,7);
				$this->lenCDF['b'] = array(2,2,1,1,1,1);
				$this->subFieldList['b'] = str_repeat(' ', 8);
				$this->posCDF['c'] = array(0);
				$this->lenCDF['c'] = array(1);
				$this->subFieldList['c'] = str_repeat(' ', 1);
				$this->posCDF['5'] = array(0);
                                $this->lenCDF['5'] = array(15);
                                $this->subFieldList['5'] = str_repeat(' ', 15);
                                $this->posCDF['9'] = array(0,1,2);
				$this->lenCDF['9'] = array(1,1,1);
				$this->subFieldList['9'] = str_repeat(' ', 3);
				$this->isCDF = true;
				break;
			case '145':
				$this->posCDF['a'] = array(0);
				$this->lenCDF['a'] = array(1);
				$this->subFieldList['a'] = str_repeat(' ', 1);
				$this->posCDF['b'] = array(0,2,5);
				$this->lenCDF['b'] = array(2,3,3);
				$this->subFieldList['b'] = str_repeat(' ', 8);
				$this->posCDF['c'] = array(0,2,5);
				$this->lenCDF['c'] = array(2,3,3);
				$this->subFieldList['c'] = str_repeat(' ', 8);
				$this->posCDF['d'] = array(0,2,5);
				$this->lenCDF['d'] = array(2,3,3);
				$this->subFieldList['d'] = str_repeat(' ', 8);
				$this->posCDF['e'] = array(0);
				$this->lenCDF['e'] = array(4);
				$this->subFieldList['e'] = str_repeat(' ', 4);
				$this->posCDF['f'] = array(0,3);
				$this->lenCDF['f'] = array(3,1);
				$this->subFieldList['f'] = str_repeat(' ', 4);
				$this->isCDF = true;
				break;
                        case '149':
				$this->posCDF['a'] = array(0,2,4,6,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23);
				$this->lenCDF['a'] = array(2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1);
				$this->subFieldList['a'] = str_repeat(' ', 24);
				$this->posCDF['b'] = array(0,1,2,3,4,5,6,7);
				$this->lenCDF['b'] = array(1,1,1,1,1,1,1,1);
				$this->subFieldList['b'] = str_repeat(' ', 8);
				$this->posCDF['c'] = array(0,2,4,5,6,7);
				$this->lenCDF['c'] = array(2,2,1,1,1,1);
				$this->subFieldList['c'] = str_repeat(' ', 8);
				$this->posCDF['d'] = array(0,1);
				$this->lenCDF['d'] = array(1,1);
				$this->subFieldList['d'] = str_repeat(' ', 2);
                                $this->posCDF['9'] = array(0,1,2);
				$this->lenCDF['9'] = array(1,1,1);
				$this->subFieldList['9'] = str_repeat(' ', 3);
				$this->isCDF = true;
				break;

		}
	}

	function setCDFField($tag,$pos,$value) {
		if (in_array($pos, $this->posCDF[$tag])) {
			$i = array_search($pos,$this->posCDF[$tag]);
			if (strlen($value) <= $this->lenCDF[$tag][$i]) {
                                $fldLen = $this->lenCDF[$tag][$i];
                                $value = sprintf("%{$fldLen}s",$value);

				$this->subFieldList[$tag] = substr_replace($this->subFieldList[$tag],
					$value,$pos,$this->lenCDF[$tag][$i]);
				return true;
			}
		}
		return false;
	}
	function getCDFField($tag,$pos) {
		if (in_array($pos, $this->posCDF[$tag])) {
			$i = array_search($pos,$this->posCDF[$tag]);
			return substr($this->subFieldList[$tag],$pos, $this->lenCDF[$tag][$i]);
		}
		return null; //false;
	}

	function addSubField($tag, $sf) {
		if ($this->isCDF) {
			$this->subFieldList[$tag]=$sf;
		} else {
			$this->subFieldList[] = $sf;
			$this->tagList[] = $tag;
			$this->tagLink[$tag][] = count($this->subFieldList) - 1;
		}
	}
	function getSubFieldCount($tag) {
		//return count($this->tagList[$tag]);
		$values = array_count_values($this->tagList);
		return (array_key_exists($tag,$values))?$values[$tag]:0;
	}
	function getSubField($tag,$item=0) {
            if(isset($this->tagLink[$tag][$item]))
                    return $this->subFieldList[$this->tagLink[$tag][$item]];

        return null;
    }
	function setSubField($tag,$value,$item=0) {
		if (isset($this->tagLink[$tag][$item])) {
			if ($value === null) {	// with null value, remove subfield
				unset($this->subFieldList[$this->tagLink[$tag][$item]]);
			} else {
				$this->subFieldList[$this->tagLink[$tag][$item]] = $value;
			}
		}
	}
	function appendField($f) {
		foreach ($f->subFieldList as $k=>$v) {
			$tag = $f->tagList[$k];
			$this->addSubField($tag,$v);
		}
    }
    
    public function set200($firstTag, $text) {
        $splitTag = preg_split("/ ([\/:;=])/", $text, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        if (count($splitTag) == 0)
            $splitTag[0] = $text;

        $this->addSubField($firstTag, $splitTag[0]);
        $beforeSlash = true;
        for ($i = 1; $i < count($splitTag); $i+=2) {
            switch ($splitTag[$i]) {
                case "/":
                    $this->addSubField('f', $splitTag[$i + 1]);
                    $beforeSlash = false;
                    break;
                case ":":
                    $this->addSubField('e', $splitTag[$i + 1]);
                    break;
                case "=":
                    $this->addSubField('d', $splitTag[$i + 1]);
                    break;
                /* case ".":
                  $this->addSubField('h',$splitTag[$i+1]);
                  break;
                  case ",":
                  $this->addSubField('g',$splitTag[$i+1]);
                  break;
                 */
                case ";":
                    if ($beforeSlash)
                        $this->addSubField('a', $splitTag[$i + 1]);
                    else
                        $this->addSubField('g', $splitTag[$i + 1]);
                    break;
            }
        }
        return;
    }

	function getTagString() {
		return join('',$this->tagList);
	}

	function getString($sep =' ') {
		$str = array();
		foreach ($this->subFieldList as $k=>$v) {
			if (!is_numeric($this->tagList[$k])) {
				$str[] = $v;
			}
		}
		return join($sep,$str);
	}

	function getTXT() {
		$p = sprintf("%3s %2s : ",$this->num,$this->indicator);
		if ($this->isCDF) {
			foreach($this->subFieldList as $k=>$v) {
				$p .= "\${$k}{$v}";
			}
		} else {
			foreach($this->subFieldList as $k=>$v) {
				$tag = $this->tagList[$k];
				$p .= "\${$tag}{$v}";
			}
		}
		return $p;
	}

	function getXML() {
		if ($this->num != 899) {
			$ind1 = $this->indicator[0];
			$ind2 = $this->indicator[1];
		} else {
			$ind1 = $ind2 = ' ';
		}
		$this->num = str_pad($this->num,3,'0',STR_PAD_LEFT);
		$xml = ($this->num < '010')?
			"<controlfield tag=\"{$this->num}\">":
			"<datafield tag=\"{$this->num}\" ind1=\"{$ind1}\" ind2=\"{$ind2}\">";
		if($this->num < '010') {
			if (isset($this->subFieldList[0]))
				$xml .= $this->subFieldList[0];
		} else if ($this->isCDF) {
			foreach ($this->subFieldList as $k=>$v) {
				$v = htmlspecialchars($v);
				$xml .= "<subfield code=\"{$k}\">$v</subfield>";
			}
		} else {
			foreach ($this->subFieldList as $k=>$v) {
				$tag = $this->tagList[$k];
				$v = strtr($v, "<>", "  ");
				$v = Clavis::sanitizeForXML($v);
				$xml .= "<subfield code=\"{$tag}\">$v</subfield>";
			}
		}
		$xml .= ($this->num < '010')?"</controlfield>":"</datafield>";
		return $xml;
	}

	function getISO2709() {
		$fd = array();
		$fd['num'] = $this->num;
		$txt = (intval($this->num) < '010')?
			'':sprintf("%1s%1s",$this->indicator[0] , $this->indicator[1]);
		$len = strlen($txt);
		if ($this->isCDF) {
			foreach ($this->subFieldList as $k=>$v) {
				$txt .= UnimarcField::UNIMARC_SUBFIELDEND . "$k$v";
				$len += (strlen($v) + 2);
			}
		} else {
			foreach ($this->subFieldList as $k=>$v) {
				$tag = $this->tagList[$k];
				if ($tag == ' ') {
					$txt .= "$v";
					$len += strlen($v);
				} else {
					$titleparts = array();
                                        /*
					if (preg_match("/^([^\*]+)\*(.+)$/",$v,$titleparts)) {
						$v = "\x1B\x48" . $titleparts[1] ."\x1B\x49" .$titleparts[2];
					}*/
					$txt .= UnimarcField::UNIMARC_SUBFIELDEND . "$tag$v";
					$len += (strlen($v) + 2);
				}
			}
		}
		$fd['txt'] = $txt . UnimarcField::UNIMARC_FIELDEND;
		$fd['len'] = $len + 1;
		return $fd;
	}
	function getTXTCompact() {
		$txt = sprintf("\n%3s%1s%1s",$this->num, $this->indicator[0], $this->indicator[1]);
		if ($this->isCDF) {
			foreach ($this->subFieldList as $k=>$v)
				$txt .= "\$$k$v";
		} else {
			foreach($this->subFieldList as $k=>$v) {
				$tag = $this->tagList[$k];
				$txt .= "\$$tag$v";
			}
		}
		return $txt;
	}

    function getEmbeddedField($num)
    {
        $f = null;

        foreach($this->subFieldList as $k=>$v) {
            $tag = $this->tagList[$k];
          //  print "[$tag]  [$v]\n";

            if($tag == "1" && (substr($v,0,3) == "$num") && ($f == null) )
            {
                $f = new UnimarcField($num);
                if($num == "001")
                {
                    $f->addSubField($num,substr($v,3));
                    return $f;
                }

            }
            elseif($tag != "1" && $f != null)
            {
               $f->addSubField($tag,$v);
            }
            elseif($tag == "1" && $f != null)
            {
                return $f;
            }


        }
        //if($f != null)
        //  print $f->getTXTCompact();

        return $f;
    }

    function isEmbedded()
    {
        return (isset($this->tagList[0]) && $this->tagList[0]=="1")?true:false;
    }
}
