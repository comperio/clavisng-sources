<?php
/**
 * Portlet class file
 *
 * @author Dario Rigolin <drigolin@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */


class ClavisPortlet extends TTemplateControl
{
	/**
	 * It reloads the same actual pages, with the same get parameters.
	 *
	 */
	public function reloadPage()
	{
		$this->getResponse()->redirect($_SERVER['REQUEST_URI']);
	}
}
