<?php
/**
 * ModuleMenuPortlet class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */

Prado::using('Application.Portlets.ClavisPortlet');

class ModuleMenuPortlet extends ClavisPortlet
{
	public function onLoad($param) {
		parent::onLoad($param);

		$icon_basepath = $this->getPage()->getTheme()->getBasePath().'/icons/';
		$icon_baseurl = $this->getPage()->getTheme()->getBaseUrl().'/icons/';
		$icon_default = $icon_baseurl.'action_default.png';
		$actualModule = $this->Page->getClavisModule();
		$acls = $this->getUser()->getAclInfo();
		$id = 0;

		if (count($acls) > 0) 
		{
			$data = array();
			if (array_key_exists($actualModule, $acls['acls']))
				foreach ($acls['acls'][$actualModule] as $key => $acl) 
				{
					$iconFile = 'action_'.$acl['page'].'.png';
					if ($acl['menu_visible'])
						$data[] = array('caption_id' => 'leftmenucaption' . $id++,
										'href' => 'index.php?page=' . $acl['page'],
										'text' => Prado::localize($acl['label']),
										'icon' => file_exists($icon_basepath.$iconFile) ?
											$icon_baseurl.$iconFile : $icon_default);
				}
				
			$this->ModuleMenu->setDataSource($data);
			$this->ModuleMenu->dataBind();
		}

		$quickPages =	array(array(	'page' => 'Circulation.NewLoan',
										'label' => '(B)anco prestiti',
										'accessKey' => 'b'),
						array('page' => 'Circulation.PatronList',
										'label' => 'Lista (u)tenti',
										'accessKey' => 'u'),
						array('page' => 'Catalog.RecordList',
										'label' => '(R)icerca catalogo',
										'accessKey' => 'r'),
						array('page' => 'Circulation.ReadyForLoanPage',
										'label' => 'Pronti al (p)restito',
										'accessKey' => 'p'));

		if (count($quickPages)) 
		{
			$quickDatasource = array();
			foreach ($quickPages as $page) 
			{
				$quickDatasource[] = array(	'caption_id' => 'leftmenucaption' . $id++,
											'href' => 'index.php?page=' . $page['page'],
											'text' => Prado::localize($page['label']),
											'icon' => file_exists($icon_basepath.'action_'.$page['page'].'.png') ?
												$icon_baseurl.'action_'.$page['page'].'.png' : $icon_default,
											'accessKey' => $page['accessKey']);
			}

			$this->ShortLinks->setDataSource($quickDatasource);
			$this->ShortLinks->dataBind();
			$this->LeftpanelShortLinks->setVisible(true);
		} 
		else 
		{
			$this->LeftpanelShortLinks->setVisible(false);
		}
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$scripts = $this->getPage()->getClientScript();
		if (!$scripts->isScriptFileRegistered('RollingFunctions.js'))
			$scripts->registerScriptFile('RollingFunctions.js',
				$this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript')).'/RollingFunctions.js');
		if (!$scripts->isEndScriptRegistered('ModuleMenuPortlet_autostart'))
			$scripts->registerEndScript('ModuleMenuPortlet_autostart',"checkVisibleLeftMenu('leftpanelmessages','leftpanelshortlinks','leftpaneltitle','leftpanel','mainpaneltitle','mainpanel','leftmenucaption','leftmessage','bottompanel','flip','".$this->getPage()->getTheme()->getBaseUrl()."/icons/menu','imgcaption');");
	}

	/**
	 * @return boolean whether the rolling fieldset is open or closed
	 */
	public function getOpen()
	{
		$key = 'UI_leftpanel';

		if ($_COOKIE[$key] == 'show')
			return true;
		else if ($_COOKIE[$key] == 'hide')
			return false;
	}

	/**
	 * Sets the value indicating whether the control has to be opened (wrapped) or closed (unwrapped)
	 * @param boolean open/close of the control
	 */
	public function setOpen($value)
	{
		if (strtoupper($value) == 'TRUE')
			$this->_openstate = true;
		else if (strtoupper($value) == 'FALSE')
			$this->_openstate = false;
	}

}
