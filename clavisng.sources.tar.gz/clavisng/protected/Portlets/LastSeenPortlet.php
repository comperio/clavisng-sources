<?php
/**
 * LastSeenPortlet class file
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */

Prado::using('Application.Portlets.ClavisPortlet');

class LastSeenPortlet extends ClavisPortlet
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		$user = $this->getApplication()->getUser();
		$this->LibraryLabel->setCssClass($user->getActualLibraryId() == $user->getDefaultLibraryId() ? 'librarylabel' : 'librarylabel_evidenced');
		$this->LibraryLabel->setText($user->getActualLibraryLabel());

		$userId = $user->getId();
		$userNameLabel = $user->getCompleteName();
		$profileLabel = $user->getProfileLabel();

		if (is_null($profileLabel))
			Prado::fatalError('No librarian profile');

		if ($profileLabel != '')
			$userNameLabel .= '&nbsp;[' . $profileLabel . ']';

		$this->UsernameLabel->setText($userNameLabel);
		$this->UsernameLabel->setNavigateUrl($this->getService()->constructUrl('Library.LibrarianViewPage',
			array('id' => $userId)));
	}

	public function Search($sender, $param) {

	}

	public function onRedoAcl($sender, $param)
	{
		$user = Prado::getApplication()->getUser();
		$userId = $user->getID();
		$librarian = LibrarianPeer::retrieveByPK($userId);

		$newAcl = $librarian->getAuthPages();

		$user->setAuthPages($newAcl);
		$user->saveToString();
	}

	public function teleport($sender, $param)
	{
		$this->getPage()->returnPage();
	}

}
